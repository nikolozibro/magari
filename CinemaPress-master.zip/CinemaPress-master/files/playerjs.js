//	Playerjs.com 12.4.4
//	20.09.2020 19:52:26
//	API - http://bit.ly/plrjsapi

eval(
  (function(p, a, c, k, e, d) {
    e = function(c) {
      return (
        (c < a ? '' : e(parseInt(c / a))) +
        ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36))
      );
    };
    if (!''.replace(/^/, String)) {
      while (c--) {
        d[e(c)] = k[c] || e(c);
      }
      k = [
        function(e) {
          return d[e];
        }
      ];
      e = function() {
        return '\\w+';
      };
      c = 1;
    }
    while (c--) {
      if (k[c]) {
        p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]);
      }
    }
    return p;
  })(
    'B 6E=[];B g8;if(22[\'vr\']){1G(vr,1)};E uY(3k){B o={1O:J,kJ:[],pI:[],hK:\'Ej\',E9:uU,EM:w4,7p:\'12.4.4\',bO:[\'6M\',\'\',\'\'],hM:\'\',2e:J,7E:J,bR:J,EL:J,d0:J,4T:J,7G:J,8E:J,u:\'#ER#Ev#Ew#EC#Eg#E8#Ep#FX#eD#G3#FM#eD#FP#FS#eD#Gl#Gp#Gu#Gt#Gs#eD#Ga#eD#Gd#Fc#Fb#F8#F3#F4#Fl#Fy#FC#FD#eD#Fw\',u2:\'\',u3:\'\',u4:\'\',u5:\'\',u6:\'\',u7:\'\',u8:\'\',u9:\'\',y:\'xx???x=xx??x?=\',p:\'{Fn}\',Fv:-1,sF:"zD",e4:"//zD.a8",6Y:[],dt:H,pr:H,ga:J,ab:J,hg:[],uz:J,ci:\'//.8T//\',26:[],5I:[],7J:[],3e:[],kL:[],bz:[],kl:0,q3:J,5G:J,1A:J,mu:J,aL:J,sL:[],Fs:[],pb:0,7Z:J,da:J,j6:J,Fq:[],hs:J,eg:J,mN:1W,hk:1W,n0:J,xi:E(x){B a;O a},Fm:0,mO:4H,5A:J,bY:J,iE:1K.iE,d:9O.rE,gL:9O.rE,aP:9O.aP,e0:9O.aP.L("e0")==0,Fo:{},fd:["xi","xB"],5W:[],A9:[],EZ:[],kp:[],xB:E(x){B a;O a},Y:0,kh:0,5D:J,dk:-1,9T:3,F0:0,pX:0,9Z:0,3y:{x:1,y:1,x0:1,y0:1},bb:["e3","c8","bU","go","fX","fR","h1","bf","aA"],bS:0,F1:0,e1:0,cM:0,aO:[\'7g\',\'eL\',\'ko\',\'8k\'],Fg:[],iC:H,pd:[],lG:0,kr:J,jv:[J,J,J]};B dc={R:{w:20,h:20,Z:"-",Fh:"-",a:1,6r:-1,1v:"3J",1B:"",1x:1,gi:-1,92:0,2c:1,1q:"",1F:"",3V:"Fj",aE:12,hn:0,1i:"S",2K:"0 3 0 3",bQ:"0 0 0 0",2u:1,gy:"0 0 0 0",Ff:0,gq:1,bg:0,ij:0,AG:0,5B:1,7v:-1,5v:"3z",7i:-1,dh:"0 0 0 0",tm:-1,tr:"3J",cK:-1,iA:-1,5p:"1I",4d:"nv",2c:0,gf:"3z",hA:0.7,qw:0,qy:"3J",gd:"5 5 5 5",Gg:"0 0 0 0",qq:1,qx:"lj-lF",gr:10,qr:0,3w:"",BT:5,BU:0,3G:0,G9:2,Gb:2,D2:0.2,CW:0,CD:0.1,fi:0,BQ:"Gi",BR:1,C6:5,D5:"3z",Db:"3J",CC:"3J",Da:1,Az:1,sU:1,6Q:0,3p:0,ds:20,cq:"<2p W=\'20\' X=\'20\'><g><c7 ry=\'5\' rx=\'5\' cy=\'10\' cx=\'10\' 4A=\'#do\'/></g></2p>",qZ:1,ib:-1,gz:0,ik:1,t0:-1,Gj:0.1,dr:0,2T:"",C1:0,BY:"nv",2X:"",BI:xr,Bh:xr,Ds:0,52:0,5f:"3J",AJ:0,AM:"3z",CO:9,tu:"0 0 10 0",tw:"0 0 0 0",DS:0}};E tX(){O H}E aa(s){if(s.L(\'.\')==-1){s=s.1w(1);s2=\'\';U(i=0;i<s.Q;i+=3){s2+=\'%u0\'+s.8j(i,i+3)}s=Gm(s2)}O s};E wo(){if(o.u!=\'\'){v=8J(v,5N.7y(bM(o.u)))}if(3k.L("#"+v.9l)==0){3v{3k=5N.7y(o[o.fd[0]](3k))}3c(e){}}F{if(3k.L("#"+v.cU)==0){3v{3k=5N.7y(o[o.fd[1]](3k))}3c(e){}}}}E 8a(x){}E ln(y,17){}B tc=E(){B aM=1M("1R");o.1D.1J(aM);K(aM,{\'1i\':\'29\',\'1b\':0,\'1f\':0,\'W\':\'1h%\',\'X\':30,\'2x-1v\':v.yr,\'1o\':v.yX,\'2m\':\'1I\'});B x=1M("1R");o.1D.1J(x);K(x,{\'1i\':\'29\',\'1b\':0,\'1f\':0,\'W\':\'1h%\',\'1v\':v.yq,\'3V-3t\':v.yV,\'2S\':(v.yI+\'px \'+v.yY+\'px\'),\'2m\':\'1I\'});G.8T=E(1F,n){x.1V=1F;6s(x);K(aM,{\'X\':x.2L,\'2m\':\'5a\'});aM.C.5j="G6";U(B i=0;i<x.ay(\'a\').Q;i++){x.ay(\'a\')[i].C.1v=\'#do\'}if(n){1G(G.jw,2G*n)}x.C.5j="FR"};G.jw=E(){3g(x);3g(aM)}};2j(E(w,i,s,e){B 8I=0;B 7Y=0;B ez=0;B cP=[];B cm=[];gU(H){if(8I<5)cm.2P(w.5L(8I));F if(8I<w.Q)cP.2P(w.5L(8I));8I++;if(7Y<5)cm.2P(i.5L(7Y));F if(7Y<i.Q)cP.2P(i.5L(7Y));7Y++;if(ez<5)cm.2P(s.5L(ez));F if(ez<s.Q)cP.2P(s.5L(ez));ez++;if(w.Q+i.Q+s.Q+e.Q==cP.Q+cm.Q+e.Q)1g}B y9=cP.jf(\'\');B yb=cm.jf(\'\');7Y=0;B qU=[];U(8I=0;8I<cP.Q;8I+=2){B qT=-1;if(yb.9J(7Y)%2)qT=1;qU.2P(ba.pF(2w(y9.1w(8I,2),36)-qT));7Y++;if(7Y>=cm.Q)7Y=0}O qU.jf(\'\')}(\'FU\',\'G0\',\'Eh\',\'Ex\'));B v={1r:0,oi:0,lk:"#3z",2W:0,yt:1,8t:"#3z",5v:"#3J",6Q:0,cJ:1,hz:1,3d:0,yj:1,d9:0,1u:{Ez:0,1v:"3z",a:"0.4",h:34,hN:1,1l:1,g5:1,eF:0,hl:3,7B:0,iD:3,5p:"1I",1i:"2F",2K:"0 0 0 0",6Q:0,gS:0,aQ:\'\'},1T:{on:1,f:1,r:1,m:1,4g:5,my:"4g",7R:1,mH:"1P",yk:0,Al:1,pH:1,cC:0.2},19:{5v:"3z",7i:"k1",5B:0.9,7v:-1,1i:"1b",2K:"0 0 0 0",2S:"7 15 7 15",1v:"3J",3V:"zi, zc, lj-lF",aE:12,4p:10,hn:0,5f:"zd",rZ:1,8t:"EF",a:1,6r:-1,EV:0,EG:1h,EN:Ee,ES:1,rQ:1,DA:"Ef",DH:"3z",rP:-1,Eq:-1,DC:0,6j:3,f8:16,sr:"F5",6Q:0,fA:1,lQ:1,l9:"3J",rB:0,rt:"3z",E1:1,CP:0,CT:"k1",m5:0,fG:4H,df:0,8F:0,Be:0,Bk:0,e9:1,3D:0,l3:50,rN:0,jp:1,d8:JA,iM:0,qE:"k1",qI:"0 0 0 0",iN:30,8t:"yG"},1d:{5v:"3z",7i:"JE",5B:0.7,7v:-1,3V:"zi, zc, lj-lF",1i:"2F-2l",2K:"0 0 0 0",2S:"7 10 7 15",1v:"3J",aE:12,f8:16,4p:10,hn:0,Js:"3J",5f:"zd",a:1,1x:5,6r:-1,rC:1,6j:3,fA:1,lQ:1,l9:"3J",m5:0,fG:4H,6Q:0,Ju:1,Jx:"4z",5c:1,JT:"6e",JS:1,JU:"2r",JV:0,Jq:"6g",Jp:0,J2:"6R",iN:30,8t:"yG"},uD:{1i:"2F-2l",2K:"0 10 50 0"},1P:0.8,sT:1,kv:1,a3:0,53:0,wL:1,4V:0,43:0,z6:0,mw:0,3W:0,w8:1,lD:0,su:0,sw:0,gZ:\',\',fM:\';\',hB:\'//\',hw:\'4A\',jl:1,jk:-1,xW:0,J9:\'20 0 0 20\',Jc:\'1f-1b\',JZ:1h,KL:1h,KI:-1,mz:0,xK:1,yr:"i1",yq:"3J",yI:5,yY:10,yX:1,yV:10,kl:0,pJ:1,Dh:1,oz:1,hv:1,4D:\'KF\',ud:0,fb:\'8v\',gY:1,z4:0,wy:0,uf:0,7H:1,a6:1,ux:5,9R:0,zb:1,uA:0,n5:5,yB:0,yF:0,mp:0,9r:1,dM:1,tB:0,AC:0,tL:0,rj:1,iq:0,2H:"Cq",L3:AH,m0:\'1h%\',ga:0,By:{8f:1,1E:0,kU:0,4q:0,1O:1,np:0,nj:0,ni:0,KZ:0,KU:0,KV:0},BD:{8f:1,1E:0,kU:0,4q:0,1O:1,np:0,nj:0,ni:0},sb:1h,oL:1,gt:1,gl:14,e3:\'1h%\',v1:1,vF:20,vT:1,fX:0.7,wa:2,p4:3,bf:10,c8:"3J",bU:"B6",go:"3z",fR:0,h1:ca,td:1,aA:0,nF:1,9D:1,KX:1,Kc:0.3,Ke:3,K2:4,K0:5,K3:0,Kg:Ks,Kr:B3,zw:0,zx:1,pK:1,qu:1,xl:1,t7:0,g9:Ku,qQ:90,qs:0,Bl:1,Bc:"k1",Bt:0,Bg:1,9l:\'2\',cU:\'3\',Kj:10,Kl:1,Kn:1,Hg:-1,H9:1,Hd:1,cV:-1,HE:0,Hx:1,Hq:0,Ht:1,Hu:0,H5:1,GI:0,GH:1,Gx:0,GN:1,GO:0,GY:1,H2:0,mL:1,GW:0,GQ:0,GP:1,GU:0,Iw:1,Ip:"#3J",Ik:"#3z",Ij:"#3z",Iy:"#3J",IK:"#3z",IF:"#3J",HR:"#3z",HU:"#3J",HV:"#3z",HX:"#3J",HW:"#3z",HK:"#3J",HO:1,HY:0,HZ:1,Ib:0.5,Ia:"#3J",I9:"#3z",Ic:1,Ie:1,I7:1,I1:1,I5:1,IZ:10,I6:-1,If:1,Id:1,HN:0,kN:0,HM:"or",HL:"or",HI:"or",HJ:"or",HQ:"50%",Ig:-1,IA:0,IJ:-1,Il:0,Iq:0,ze:1,zL:0,yC:30,Ir:2,xq:10,xm:0,HH:30,vX:1,w0:1,5S:0,2q:{on:0,5v:"3z",2W:0,bH:2,8t:"3z",1i:"1b",2K:"20 0 0 20",W:s9,1l:0}};v.dU="ru";o.HG={"2A":"Авто","1O":"Пуск","59":"Пауза","2o":"Стоп","2e":"Во весь экран","iK":"Выйти из полноэкранного режима","1d":"Настройки","3k":"Параметры","1P":"Громкость","4V":"Выключить звук","9K":"Включить звук","6W":"В ЭФИРЕ","19":"Плейлист","4z":"Качество","6g":"Скачать","2r":"Субтитры","6R":"Скорость","1E":"ошибка","GV":"Включите звук","6e":"Аудио","dQ":"ошибка загрузки","lo":"Очень низкое","fD":"Низкое","eX":"Среднее","f4":"Высокое","pc":"Высокое","8v":"Следующий","cO":"Предыдущий","5i":"Поделиться","Am":"Скопировано в буфер обмена","Cj":"Реклама","lW":"Пропустить","GT":"Пропустить через ","Cd":"Перейти на сайт рекламодателя","e3":"Размер текста","aA":"Сдвиг по времени","c8":"Цвет текста","bU":"Цвет текста 2","go":"Цвет фона","fX":"Прозрачность фона","fR":"Тень","h1":"Толщина текста","bf":"Отступ снизу","sc":"Сон","fO":"Пропускать","sz":"Час","sy":"Минута","sA":"Секунда","AZ":"Да","AW":"Нет","of":"из","6J":"Пароль","AQ":"Ошибка воспроизведения на устройстве","AE":"Играет на устройстве","aW":"Канал","1x":"Масштаб","on":"Вкл.","8l":"Выкл.","nH":"Все сразу","ad":"кбит/с"};B 5g=E(1X){B eo;B GS;B 2Y;B 4k;B 4c;B ls;B dp=0;B bd;B st=J;B lp;if(1X.me!=1W&&1X.mc!=1W&&1X.1B!=1W&&1X.to!=1W){if(1X.Y==1S){if(1X.1B.L("gp")>-1){1X.to==0?1X.Y=0.5:1X.Y=0.2}F{1X.Y=0.15}}eo=AP(1X.7C);if(1X.1B.L("1x")==-1){if(I(o.6Y[1X.me])){o.6Y[1X.me].nm()}}if(1X.1B.L("1x")==-1){o.6Y[1X.me]=G}if(1X.1n==1){1X.mc.1U("2m",H)}2Y=1X.1B.2t(\'|\');4c=ba(1X.to).2t(\'|\');4k=1y 8n();U(B i=0;i<2Y.Q;i++){if(!4c[i]){4c[i]=4c[0]}if(2Y[i]=="gp"){4k[i]=1X.mc.g("1o")}if(2Y[i]=="7j"){4k[i]=1X.mc.C.1o}if(2Y[i]=="y"){4k[i]=1X.mc.g("y")}if(2Y[i]=="x"){4k[i]=1X.mc.g("x")}if(2Y[i]=="1b"){4k[i]=2w(1X.mc.C.1b)}if(2Y[i]=="1x"){4k[i]=1X.mc.g("3l")}if(2Y[i]=="8Q"){4k[i]=1X.mc.bv}if(2Y[i]=="h9"){4k[i]=1X.mc.aU}if(2Y[i]=="3a"){4k[i]=1X.mc.g("3a")}if(2Y[i]=="3l"){4k[i]=1X.mc.g("3l")}if(2Y[i]=="W"){4k[i]=1X.mc.g("W")}if(2Y[i]=="Dy"){4k[i]=1X.mc.1Y;4c[i]=2I.7n(4c[i]);1X.me=="GR"?1r("W",1X.me,4k[i],4c[i],1X.mc.1Y):\'\'}if(2Y[i]=="X"){4k[i]=1X.mc.g("X")}if(2Y[i]=="Dt"){4k[i]=1X.mc.2L}4c[i]=CL(4c[i]);4k[i]=CL(4k[i])}bd=1X.Y*2G/eo.Q;ls=eo.Q;if(2Y.Q==1&&4k[0]==4c[0]){9h()}F{1G(lr,2I.4N(bd))}}E lr(){U(B i=0;i<2Y.Q;i++){B 1H=4k[i]+(4c[i]-4k[i])*(eo[dp]?eo[dp]:0);if(2Y[i]=="gp"){1X.mc.1U("1o",1H)}if(2Y[i]=="7j"){1X.mc.C.1o=1H}if(2Y[i]=="y"){1X.mc.1U("1f",1H)}if(2Y[i]=="x"){1X.mc.1U("1b",1H)}if(2Y[i]=="1b"){1X.mc.C.1b=1H+"px"}if(2Y[i]=="1x"){1X.mc.1U("1x",1H)}if(2Y[i]=="3a"){1X.mc.1U("3a",1H)}if(2Y[i]=="3l"){1X.mc.1U("3l",1H)}if(2Y[i]=="8Q"){1X.mc.bv=1H}if(2Y[i]=="h9"){1X.mc.aU=1H}if(2Y[i]=="W"){1X.mc.1U("W",1H)}if(2Y[i]=="Dy"){K(1X.mc,{"W":1H})}if(2Y[i]=="X"){1X.mc.1U("X",1H)}if(2Y[i]=="Dt"){K(1X.mc,{"X":1H})}}dp++;if(!st){if(dp==ls){9h()}F{lp=1G(lr,2I.4N(bd))}}}E 9h(){st=H;if(1X.1l){if(2Y[0]=="7j"||2Y[0]=="1b"){1l(1X.mc)}F{1X.mc.1U("2m",J)}}if(1X.1B.L("1x")==-1){o.6Y[1X.me]=1S;4e o.6Y[1X.me]}};G.nm=E(){3j(lp);9h()};G.xp=E(){3j(lp);dp=ls-1;lr();9h()};E AP(AN){9N(AN){1j"uX":O[0,0.Hr,0.HF,1.HC,1.HB,1.Hy,1.vZ,0.Hz,0.Ho,0.87,0.Hc,0.Ha,1.Bf,1.H8,1.He,1.Hf,0.Ko,0.Kk,0.Kp,0.Kw,1.Kx,1.A6,1.Cp,1.A6,1.Cr,0.fC,0.j8,0.j8,0.j8,0.j8,1];1g;1j"b3":O[0,0.Kh,0.K6,0.K1,0.K7,0.Kf,0.Kb,0.Ky,0.Kz,0.KY,0.KW,0.KS,0.L0,0.KG,0.Bp,0.KH,0.Jg,0.Jl,0.Ji,0.95,0.Jj,0.Jk,0.J8,0.IX,0.99,0.IV,0.Bd,0.fC,1];1g;1j"Ae":O[0,0.IR,0.28,0.IS,0.Gw,0.J6,0.J0,0.78,0.Bp,0.JK,0.JL,0.Bd,1.Bf,1.JH,1.BB,1.Jv,1.Jt,1.BM,1.BM,1.Jy,1.Jz,1.JB,1.BB,1.L7,1.Eu,1.EH,1.Ey,1.EQ,1.Cp,1.Cr];1g;6S:O[0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1];1g}}};B wY=E(){B N=hJ.FZ,ua=hJ.G5,sE;B M=ua.ix(/(iO|ha|6i|ta|C0)\\/?\\s*(\\.?\\d+(\\.\\d+)*)/i);B M=ua.ix(/(iO|ha|6i|ta|C0|Gh|jI)\\/?\\s*(\\.?\\d+(\\.\\d+)*)/i);if(M&&(sE=ua.ix(/7p\\/([\\.\\d]+)/i))!=1S)M[2]=sE[1];G.au=M?M[1]:N;G.7p=M?M[2]:hJ.Gf;G.iO=G.au=="Fd";G.ov=G.au=="zV 9.0";G.ie=G.au=="zV"||G.au=="FH"||G.au=="FF";G.jI=ua.aS(/(jI)\\/?\\s*/i)>-1;G.ta=G.au=="Fp";G.6i=G.au=="FG";G.ha=22.ha;G.gR=ua.aS("FA NT")>-1;G.5x=(ua.aS(/(8V|hR|FB)\\/?\\s*/i)>-1)||(hJ.Fk===\'F2\'&&hJ.Gr>1);G.tv=v.E7!=1&&ua.aS(/(Gq|FN|LG Dz|G4|FY|EJ Er)\\/?\\s*/i)>-1;G.lg=v.E7!=1&&ua.aS(/(LG Dz)\\/?\\s*/i)>-1;G.8V=ua.aS(/(8V)\\/?\\s*/i)>-1;G.hR=G.5x&&!G.8V;G.41=\'EU\'in 1K.j4.C;G.9f=ua.aS(/(9f)\\/?\\s*/i)>-1;G.2y=(G.5x||G.9f||(ua.aS(/(Ec|FW|iO iU)\\/?\\s*/i)>-1))&&!G.tv;G.oT=G.6i||G.ha;G.p0=!G.2y;G.rb=G.2y||G.tv;G.2e=J;if(G.5x){G.G1=4U(ua.1w(ua.L(\'OS \')+3,4).1Z(\'7l\',\'.\'));if(G.hR&&!\'G2\'in 22){G.2y=G.5x=J;G.tv=H}}if(o.1D.n1||o.1D.mP||o.1D.n2||o.1D.nf||o.1D.n3){G.2e=H}};E 8J(3Z,6m){U(B s in 6m){if(2i(6m[s])==\'3r\'){if(s=="2H"||s=="3h"){3Z[s]=6m[s]}F{U(B s2 in 6m[s]){if(2i(3Z[s])!=\'3r\'){3Z[s]={}}if(2i(6m[s][s2])==\'3r\'){U(B s3 in 6m[s][s2]){if(2i(3Z[s][s2])!=\'3r\'){3Z[s][s2]={}}if(2i(6m[s][s2][s3])==\'3r\'){U(B s4 in 6m[s][s2][s3]){if(2i(3Z[s][s2][s3])!=\'3r\'){3Z[s][s2][s3]={}}3Z[s][s2][s3][s4]=6m[s][s2][s3][s4];if(s3==\'2S\'||s3==\'2K\'){3Z[s][s2][s3][s4]=2w(3Z[s][s2][s3][s4])}}}F{3Z[s][s2][s3]=6m[s][s2][s3];if(s2==\'2S\'||s2==\'2K\'){3Z[s][s2][s3]=2w(3Z[s][s2][s3])}}}}F{3Z[s][s2]=6m[s][s2];if(s==\'2S\'||s==\'2K\'){3Z[s][s2]=2w(3Z[s][s2])}}}}}F{if(s.L("FV")>0&&4j(6m[s])===""){}F{3Z[s]=qv(s,6m[s])}}}O 3Z};B qv=E(1a,52){if(2i(52)==\'5h\'){52=4j(52);if(1a.L("1v")>-1&&52.L("#")!=0&&52!=-1){52="#"+52}}O 52};E wm(cG,1o){O\'4I(\'+(cG=cG.1Z(\'#\',\'\')).ix(1y F7(\'(.{\'+cG.Q/3+\'})\',\'g\')).Fx(E(l){O 2w(cG.Q%2?l+l:l,16)}).8P(1o||1).jf(\',\')+\')\'}E rl(){3v{B 4S=22[\'3m\'],x=\'Ft\';4S.7U(x,x);4S.nR(x);O H}3c(e){O J}};E qa(9a){if(9a){if(o.6Y[9a]){o.6Y[9a].nm()}}};B 2M=E(x){B y=x;if(y){y=x.5L(0).FE()+x.8j(1);if(y.L("7l")>-1){y=y.1Z(/7l/ig," ")}}B en={"of":"of","ad":"ad","AE":"AR on B2","AQ":"AR 1E on B2","nH":"Fz at F6","6J":"kn","AW":"No","sc":"EY","fO":"EX","AZ":"F9","bf":"Fe 2K","h1":"Gc fw","fR":"G8","fX":"9X 1o","go":"9X 1v","e3":"mF 3t","c8":"mF 1v","bU":"mF 1v 2","aA":"4t dN","cO":"Gk","Am":"Gn to G7","lo":"FQ","fD":"FT","eX":"EW","f4":"Ai","pc":"Ai","hT":"HD","hV":"FO HD","FK":"FL HD","q6":"Eo HD","q5":"Em HD 4K","Cj":"Ad","Cd":"Go to EI Ei\'s EO","6e":"En","6W":"Ek","2e":"Ed 2e","iK":"JC 2e"};if(I(en[x])){y=en[x]}if(I(o[\'pP\'+v.dU])){if(I(o[\'pP\'+v.dU][x])){y=o[\'pP\'+v.dU][x]}}if(v.pV){if(v.pV[x]){y=v.pV[x]}}O y};B 8o=E(x,y,z){if(!I(o.hg[y])&&v.ml!=1){B t=o.cW?o.cW:(v.1N?v.1N:\'\');if(v.BD[x]==1&&v.zg==1&&I(v.he)){if(x=="8f"){7d(BL,JD)}if(I(22["iG"+v.he])){22["iG"+v.he].BN(\'p1\'+x,{1N:t});1r("pQ",\'p1\'+x)}F{1r("pQ JF 1E")}}if(v.By[x]==1){if(v.ga==1){B pW={uM:\'kE\',uE:y};if(t!=\'\'){pW.tM=t}ga(\'g0.a7\',\'17\',pW)}}}z?o.hg[y]=H:\'\'};E BL(){if(I(22["iG"+v.he])){22["iG"+v.he].BN(\'Jr\');1r("pQ",\'p1\'+x)}};B lE=E(1e){B x=\'\';1e=1e.1Z("v=","{=");if(1e.L(\'mb.be/\')>-1){x=1e.1w(1e.L(".be/")+4);x.1Z("/","")}F{x=1e.2t(/(mb.be\\/|v\\/|sm\\/|JI\\?|44.JW\\/g0\\/[^#]*#([^\\/]*?\\/)*)\\??{?=?([^#\\&\\?]*)/)[3]}if(x!=\'\'){if(x.L("?t=")>0){v.1A=x.1w(x.L("?t=")+3);B h=0;B m=0;B s=0;if(v.1A.L("h")>0){h=v.1A.1w(0,v.1A.L("h"));v.1A=v.1A.1w(v.1A.L("h")+1)}if(v.1A.L("m")>0){m=v.1A.1w(0,v.1A.L("m"));v.1A=v.1A.1w(v.1A.L("m")+1)}if(v.1A.L("s")>0){s=v.1A.1w(0,v.1A.L("s"));v.1A=v.1A.1w(v.1A.L("s")+1)}if(h>0||m>0||s>0){v.1A=h*mE+m*60+s*1}x=x.1w(0,x.L("?t="))}}O x};B js=E(x,y,li){if(x=="8f"){o.8f=H}if(v.iq==1&&o.8f){if(v.JR==1||li==1){B ev=1K.JM(\'7m\');if(y!==1W){ev.9C=y}ev.J3(x,H,H);o.1z.J5(ev)}F{if(y!==1W){if(2i(y)==\'3r\'){y=5N.IY(y)}}if(2i(v.2H)==\'3r\'){if(I(v.2H[x])||I(v.2H[\'oe\'])){B z=x;if(!I(v.2H[x])&&I(v.2H[\'oe\'])){z=\'oe\'}if(x.L("8c")==0){if(I(v.2H[\'2f\'])){z=\'2f\'}}3v{if(y!==1W){2j(v.2H[z]+"(\'"+x+"\',\'"+v.id+"\',\'"+y+"\')")}F{2j(v.2H[z]+"(\'"+x+"\',\'"+v.id+"\')")}}3c(e){1r("2H",e,x)}}}F{if(v.2H==\'\'){v.2H="Cq"}3v{if(y!==1W){2j(v.2H+"(\'"+x+"\',\'"+v.id+"\',\'"+y+"\')")}F{2j(v.2H+"(\'"+x+"\',\'"+v.id+"\')")}}3c(e){1r("2H",e,x,y)}}}}if(v.vO==1&&li!==1){B zv={17:x,Y:o.P?(x=="4g"?o.zH:o.P.Y()):0};if(y!==1W){zv["1C"]=y}if(x=="1k"||x=="Y"){zv["1k"]=o.P.1k()}if(x=="1P"||x=="9K"){zv["1P"]=v.1P}if(x=="1y"){zv["id"]=6z("Dp")}22.bL.C7(zv,\'*\');B z=x;x=="8f"||x=="1A"||x=="4q"?z=x+"ed":\'\';x=="1O"?z="Jh":\'\';x=="59"?z="8C":\'\';x=="4V"?z="3Q":\'\';x=="9K"?z="JY":\'\';x=="4g"?z="KJ":\'\';x=="KP"?z="KO":\'\';zv["17"]=z;if(z!=\'\'&&z!=x){22.bL.C7(zv,\'*\')}}};G.17=E(x,y){o.2H[x]=y};B 2Z=E(x,y,R){O 6z(x,y,R)};G.2Z=E(x,y,R){O 6z(x,y,R)};E 6z(x,y,R){if(I(o.V)){if(o.oQ==1){O}if(R){if(2i(R)==\'5h\'){if(R.L("id:")==0){R=o.S.qz(R.1w(3),"3X");if(R){if(x=="jY"&&y=="KC"){R.fE()}}}}}if(x=="1O"){if(I(y)){if(2i(y)==\'5h\'){y=y.1Z(/(\\r\\n|\\n|\\r)/gm,"");B 2z=-1;if(y.L("[4g:")>-1&&y.L("]")==y.Q-1){2z=y.1w(y.L("[4g:")+6,y.Q-1);o.2z=2z=2w(2z.1w(0,2z.Q-1));y=y.1w(0,y.L("[4g:"))}if(y.L("#"+v.9l)==0){y=o[o.fd[0]](y)}if(y.L("#"+v.cU)==0&&y.L(v.hB)>0){y=o[o.fd[1]](y)}if(y.L("#0")==0){y=aa(y)}if(v.dZ==1){y=dZ(y)}if(y.L(".8T")==y.Q-4){B 4a=dL(y);4a.bs=E(){if(G.de==4&&G.6f==4H){3v{6z(\'1O\',5N.7y(G.c4))}3c(e){}}};4a.a7();O}if(y.L("id:")==0&&I(o.1t)){B z=y.1w(3);U(B j in o.1t){if(o.1t.2h(j)){if(o.1t[j].cD==z){z=j}}}if(I(o.1t[z])){o.S.Ck(z);2z>-1?o.2z=2z:\'\';O H}F{O J}}if(y.L("KD:")==0){B z=y.1w(10);if(o.2v=="44"){o.P.y8(z);O H}F{y=\'//mb.be/\'+z}}}o.V.d6(y)}F{o.V.2B()}}if(x=="3h"&&I(y)){o.pT=H;o.V.d6(y,1);o.S.4s(0,0)}if(x=="59"){if(o.1O){o.V.2Q();o.V.ir()}}if(x=="aW"&&I(y)){o.1A&&o.6I?o.6I.zt(y):\'\'}if(x.L("KE")==0){if(o.2f){o.2f.KQ(x.1w(6),y)}}if(x=="43"){o.P.nB()}if(x=="9M"){o.9M.jw();o.9M=1y tc();if(v.xG==1){o.9M.8T(v.yM)}F{o.9M.8T("KR 8Y")}if(v.xI==1&&I(v.xH)){o.d7=1y xJ()}}if(x=="9w"){o.S.8s();o.S.Ca("mM")}if(x=="tg"){o.1O?o.V.2Q():o.V.2B()}if(x=="2o"){v.43=0;v.3W=0;o.P.jZ();o.V.9Q()}if(x=="9R"){o.Y=o.P.Y();o.V.fJ()}if(x=="5i"){o.S.Cm()}if(x=="L2"&&I(y)){if(v.2f==1&&o.p!=\'\'){B sv=5N.7y(bM(o.p));U(B l in sv){if(sv.2h(l)){if(I(sv[l].id)){if(y==sv[l].id){v.8k=\'KT\'+(I(sv[l][\'nY\'])?\'nY\'+sv[l][\'nY\']:\'\')+y+\'7l\'+sv[l].7g;v.nE=H;o.V.vg("8k")}}}}}}if(x=="Ka"){2i Ac=="E"?Ac():\'\'}if(x=="zY"&&y){v.zY=y;o.3i?o.3i.K9():\'\'}if(x=="4V"){o.V.4Y()}if(x=="6R"){if(I(y)){o.V.9P(y)}F{O o.5W[o.9T]}}if(x=="fg"){O o.5W}if(x=="9K"){o.V.6P()}if(x=="lx"){if(I(y)){v[x]=y;o.V.hc()}}if(x=="bh"){O o.26}if(x=="zC"){O o.ab?H:J}if(x=="6W"){O o.P?o.P.5H():J}if(x=="vu"){O v.9D==1?o.3e.8j(0,-1):o.3e}if(x=="8x"){O o.5I}if(x=="1P"||x=="B8"){if(I(y)){if(y>=0&&y<=1){o.V.3T(y)}}O o.3Q?0:v.1P}if(x=="3Q"){O I(o.3Q)?o.3Q:J}if(x=="Kd"){o.S?o.S.BV(y):\'\'}if(x=="bZ"){y<2?y=\'\':\'\';if(o[\'u\'+y]!=\'\'){B x2=5N.7y(bM(o[\'u\'+y]));B v2=[];U(B l in v){if(v.2h(l)){if(l.L("9B")==0){v[l]=1S}}}if(2i x2=="3r"){U(B k in x2){if(x2.2h(k)){if(k.L("9B")==0){v[k]=x2[k]}if(k=="1u"){v2[k]=x2[k]}}}}v=8J(v,v2);B oK=J;if(o.S.al()){o.S.7O();oK=H}B oW=J;if(o.S.cI()){o.S.as();oW=H}o.S.4C();o.S=1S;o.S=1y sR();if(o.P.6f()=="5M"){o.S.2B()}o.S.3T(v.1P);if(I(v.1N)){9p(v.1N)}if(oK){o.S.7O()}if(oW){o.S.as()}if(o.2e){o.S.6Z()}if(1a!=\'Dc\'){o.S.4s(o.P.Y(),o.P.1k())}2n()}}if(x=="lB"){O v.lB}if(x=="4J"){o.S.4J(H)}if(x=="4g"){if(I(y)){if(2i y=="5h"){if(y.L("%")>-1){y=2w(y.1w(0,y.L("%")));y=o.P.1k()*y/1h}F{B jo=o.P.Y();if(o.3i&&!o.1A){if(!o.3i.mi){B f=o.3i.96();if(f.t&&f.d){jo=f.t;o.3i.mi=H}}}if(y.L("+")==0){y=jo+2w(y.1w(1))}F{if(y.L("-")==0){y=jo-2w(y.1w(1))}}}}y=y*1;y<0?y=0:\'\';if(o.P.1k()>0){y>o.P.1k()?y=0:\'\'}if(!I(o.2f)&&!I(o.5V)&&o.P.1k()>0){o.2z=1W;o.V.3R(y,H);o.V.mS()}F{o.2z=y}}}if(x=="2e"){!o.2e?o.V.6Z():\'\'}if(x=="oI"){o.2e?o.V.8S():\'\'}if(x=="Kv"){O o.2e}if(x=="3t"){O o.3f+\'/\'+o.4h}if(x=="Kq"){if(I(o.eG)){o.eG.Do()}}if(x=="Bw"||x=="Ki"){if(I(o.eG)){o.eG.IQ()}}if(x=="Y"){B oE=o.P?o.P.Y():0;if(o.3i&&v.aX==1&&!o.1A){B f=o.3i.96();if(f.t){oE=f.t}}O oE}if(x=="HA"){if(o.aY){6z("1O","id:"+o.aY)}if(o.AF){6z("4g",o.AF);6z("1O")}}if(x=="1k"){O o.P?o.P.1k():0}if(x=="2N"){if(y){v.2N=y;o.S.f9()}}if(x=="4z"){if(I(y)){if(R){v.hd=9c(v.hd,y,R);if(o.26.Q==2){o.V.5n(v.hd)}}F{o.V.5n(y)}}F{O o.P?o.P.sd():0}}if(x=="6e"){if(I(y)){if(R){v.oD=9c(v.oD,y,R);if(o.5I.Q==2){o.V.bq(v.oD)}}F{o.V.bq(y)}}F{O o.P?o.P.sf():0}}if(x=="Dd"){O o.2v=="44"}if(x=="Bb"){if(o.5e>0){o.kW=o.5e}o.V.d6(v.3h)}if(x=="5M"){O o.1O}if(x=="kY"){O o.1A}if(x=="1m"){O o.1m[y]}if(x=="Dn"){o.oQ!=1?o.P.nc():\'\'}if(x=="id"){O v.id}if(x=="1r"){v.1r=y}if(x=="iq"){v.iq=y}if(x=="2q"){o.P.wE()}if(x=="Hw"){o.P.wB();if(R){o.pb=9c(o.pb,y,R)}}if(x=="4T"){o.P.d3()}if(x=="7G"){o.P.cn()}if(x=="3k"&&v.ml!=1){eq.1r(3k)}if(x=="2r"){v.2r=y;if(I(y)){if(y.6B().Q<3){o.V.9z(y*1)}F{o.P.dT(y)}}}if(x=="aB"){if(I(o.aB)){if(I(y)){o.aB.2Z(y)}F{O o.aB.Hv()}}}if(x=="qY"){if(o.AI){O o.AI}F{O J}}if(x=="5u"){B 5u=1M("1R");5u.id=y;5u.C.5j=wH;o.1D.1J(5u)}if(x=="C3"){if(o.5A){B 5o=1M("5o");o.1z.1J(5o);B 8W=5o.AK(\'2d\');B 3t=o.P.3t();5o.W=3t.W>0?3t.W:o.9A;5o.X=3t.X>0?3t.X:o.ch;8W.oR(o.P.5P(),0,0,5o.W,5o.X);4z=2;B fB=1K.1M("5o");fB.W=5o.W*4z;fB.X=5o.X*4z;B fa=fB.AK("2d");fa.oR(o.P.5P(),0,0,5o.W*4z,5o.X*4z);if(v.GF==1&&I(v.oV)){!I(v.fS)?v.fS=20:\'\';!I(v.ox)?v.ox="3J":\'\';fa.3V=v.fS+"px GE, GA";fa.H0="#"+v.ox;fa.H3((v.oV=="gL"?o.gL:v.oV),v.fS,5o.X*4z-v.fS-5)}8W.oR(fB,0,0,5o.W,5o.X);B 3N;3v{3N=5o.Is("aQ/Iu")}3c(e){eq.1r(e.8Y);O J}O 3N}F{O J}}if(x=="1x"){}if(x=="2b"){O o.2v==x?o.P.lT():1W}if(x=="1L"){O o.2v==x?o.P.m6():1W}if(x=="2g"){if(!o.1O){o.P.8B(y);O H}F{O J}}if(x=="1x"){if(y){o.P.1x(y)}F{O[o.3y.x,o.3y.y,o.4f.C.1b,o.4f.C.1f]}}if(x=="1N"){if(I(y)){I(y)?v.1N=y:\'\';o.V.9p(\'1N\');O H}F{O v.1N}}if(x=="Iv"){o.V.yn()}if(x=="19"){if(y){if(2i(y)==\'3r\'){3v{o.V.5Q(y);O H}3c(e){O J}}F{if(y.L(".8T")==y.Q-4||y.L(".8T?")>0){B 4a=dL(y);4a.bs=E(){if(G.de==4&&G.6f==4H){3v{6z(\'19\',5N.7y(G.c4))}3c(e){}}};4a.a7();O H}}}}if(x=="8v"){o.S.dA()}if(x=="cO"){o.S.hP()}if(x=="lm"){if(I(y)&&I(o.1t)){!o.1O?v.3W=0:\'\';U(B j in o.1t){if(o.1t.2h(j)){if(o.1t[j].cD==y){y=j}}}if(I(o.1t[y])){o.S.Cl(y);O H}F{O J}}}if(x=="Ii"){B 1H=[];if(I(o.1t)){U(B j in o.1t){if(o.1t[j].4B&&o.1t[j].rr==-1){1H.2P({1N:o.1t[j].1N,id:o.1t[j].id})}}}O 1H}if(x=="Dp"){if(o.3F){O o.1t[o.3F].cD?o.1t[o.3F].cD:o.3F}}if(x=="Io"){if(o.1t){O 42.3I(o.1t).Q}F{O-1}}if(x=="lA"){if(I(o.lA)){O o.lA}}if(x=="Iz"){o.S.j7()}if(x=="IL"){if(o.2f){O H}F{O J}}if(x=="IO"){if(o.2f){O DE()}F{O J}}if(x=="IN"){if(o.2f){O o.2f.59()}F{O J}}if(x=="IB"){if(o.2f){O o.2f.zE()}F{O J}}if(x=="5S"){v.5S=9c(v.5S,y,R);o.P.5S()}if(x=="a3"){if(I(R)){v.a3=9c(v.a3,y,R)}F{if(I(y)){v.a3=y}F{O v.a3}}}if(x=="53"){if(I(R)){v.53=9c(v.53,y,R)}F{if(I(y)){v.53=y}F{O v.53}}}if(x=="r9"||x=="lO"){B z="df";x=="lO"?z="lP":"";if(I(R)){v.19[z]=9c(v.19[z],y,R)}F{if(I(y)){y==\'0/1\'?y=1-v.19[z]:\'\';v.19[z]=y}F{O v.19[z]}}}if(x=="hd"){if(o.26.Q==2){v.hd=o.26[o.2R];v.hd=9c(v.hd,y,R);if(o.26[0]==v.hd){o.V.5n(0)}F{o.V.5n(1)}}}if(x=="v"&&y){if(y.L(\'3h\')==0||y.L(\'bk\')==0){O}O v[y]}if(x.L("g4:")==0){B xx=x.1w(7);if(2i(y)==\'3r\'&&2i(v[xx])==\'3r\'){U(B yy in y){if(y.2h(yy)){v[xx][yy]=y[yy]}}}F{if(x.L(\'vM\')==-1){v[xx]=y}}O H}if(x=="ID"){O o.P?o.P.an():\'\'}if(x=="IE"){O o.7p+\' \'+o.hK}if(x=="hK"){O o.hK}if(x=="pD"){O o.pD}if(x=="ny"){O o.ny}if(x=="6b"){O o.6b}if(x=="HS"){O o.2f?o.uV:1W}if(x=="8M"){o.V.nN();o.oQ=1;v.1T.on=0;o.1z.1V=\'\'}}F{O J}};E 9c(x,y,R){B z=4j(y)+\'\';if(y.L("/")>0){B y2=y.2t("/");if(y2.Q==2){if(x==4j(y2[0])){z=4j(y2[1]);if(R){R.eb(1)}}F{z=4j(y2[0]);if(R){R.eb(0)}}}}O z}E dL(x){B 4a=1y vQ();4a.7x(\'vS\',x,H);O 4a}E DE(){B x;if(o.2f){if(o.2f.qH()){x=o.2f}}if(!x&&o.5V){x=o.5V}if(x){O{1m:x.9C("I4"),7p:x.9C("7p"),I3:x.9C("wq"),1e:o.I0+(x.9C("vp")?x.9C("I2")+x.9C("vp"):\'\'),1B:x.9C("I8"),3h:x.9C("3h"),1P:x.HP(),id:o.uV}}}B 1M=E(x){B y=x;x==\'1R\'||x==\'qM\'?y=\'6O\':\'\';B z=1K.1M(y);if(x==\'qM\'){K(z,{"6t":"3S","2m":"5a"})}O z};B 1r=E(a,b,c,d,e,f,g){if(v.1r==1||v.oi==1){B x=a+(b!=1W?" "+b:"")+(c!=1W?" "+c:"")+(d!=1W?" "+d:"")+(e!=1W?" "+e:"")+(f!=1W?" "+f:"")+(g!=1W?" "+g:"");eq.1r("uY"+(v.rD==1?"2":"")+": "+x);if(v.oi==1&&I(1K.8m("v7"))){1K.8m("v7").1V+=x+\'<br/>\'}}};B tY=E(){if(v.nr==1&&I(v.og)&&v.og!=\'\'){B x=1K.1M(\'dr\');x.CX=\'HT\';x.aP=\'e0://nr.Ih.a8/K?ho=\'+v.og.1Z(/,/ig,"|").1Z(/ /ig,"+");1K.IG.1J(x)}};B CZ=E(1R,fh){B x=["t8","dy","je","g3","c7"];U(B y=0;y<x.Q;y++){B z=1R.t6("2p "+x[y]);if(z.Q>0){U(B y2=0;y2<z.Q;y2++){z[y2].C.4A=fh}}}};B 4t=E(Y){Y<0?Y=0:\'\';B vc=o.P.1k>=b9?H:J;B vh=o.P.1k>=mE?H:J;B 5U=2I.7n(Y/60);B 5Y=2I.7n(Y-5U*60);B 7q=2I.7n(5U/60);B hq=2I.7n(7q/24);5U=5U-7q*60;if(hq>0){7q=7q-hq*24}O ba((hq>0?hq+\':\':\'\')+(7q>0||vh?7q+\':\':\'\')+((7q>0||vc)&&5U<10?\'0\':\'\')+5U+\':\'+(5Y<10?\'0\':\'\')+5Y)};B IC=E(){O IH((22.9O!=22.bL.9O)?1K.sn:1K.9O.aP)};B D3=E(y){B x=J;B ki=1K.ay(\'lV\');U(B i=0;i<ki.Q;i++){if(ki[i].2X.L(y)>-1){x=H}}O x};B ql=E(x,y){x=x.1Z(\'#\',\'\');B r=2w(x.Q==3?x.8j(0,1).fo(2):x.8j(0,2),16);B g=2w(x.Q==3?x.8j(1,2).fo(2):x.8j(2,4),16);B b=2w(x.Q==3?x.8j(2,3).fo(2):x.8j(4,6),16);if(y){O\'4I(\'+r+\', \'+g+\', \'+b+\', \'+y+\')\'}F{O\'II(\'+r+\', \'+g+\', \'+b+\')\'}};B K=E(e,o){if(I(e)){U(B 1a in o){if(o.2h(1a)){if(o[1a]!=\'IM\'&&o[1a]!=1W){if(2i o[1a]==\'In\'&&1a!=\'1o\'&&1a!=\'5j\'){o[1a]+=\'px\'}if((1a.L("1v")>-1||1a.L("D8")>-1)&&o[1a].L("#")==-1&&o[1a].L("4I")==-1){o[1a]=\'#\'+o[1a]}if(1a=="2E"){e.C[\'-ms-\'+1a]=o[1a];e.C[\'-rH-\'+1a]=o[1a];e.C[\'-41-\'+1a]=o[1a];e.C[\'-o-\'+1a]=o[1a]}if(1a=="qG"){if(o[1a].L(" ")>-1){o[1a]=\'"\'+o[1a]+\'"\'}}if(1a=="5u-hL"){e.C.Im(1a,o[1a],\'5m\')}F{e.C[1a]=o[1a]}}}}}};B qk=E(c){O c.1w(0,1)!=\'#\'?c="#"+c:c};B B5=E(x,1v,y){!1v?1v=\'#do\':\'\';1v=qk(1v);B r=6o(iu,Ix);x=x.1Z(/\\(It\\)/g,r);x=x.1Z(/\\(1v\\)/g,1v);B wj=x.1w(0,x.L(\'|||\'));B qd=x.1w(x.L(\'|||\')+3);B 9j=\'\';if(o.1m.41){9j=qd.1Z(/5p:/g,"-41-5p:");9j=9j.1Z(/5p-/g,"-41-5p-");9j=9j.1Z(/@wc/g,"@-41-wc");9j=9j.1Z(/2E/g,"-41-2E")}y.1V=wj;qD(9j+qd)};B qD=E(x){if(o.K){if(o.K.vP){o.K.vP.GX=x}F{o.K.1J(1K.wV(x))}}};B 4a=E(y,z){B x=1y vQ();x.7x(\'vS\',y,H);x.bs=z;x.a7()};B H4=E(x){if(x){U(B i=0;i<5;i++){if(x.H1=="GZ"){1g}F{if(x.vL){x=x.vL}}}}O x};B 8p=E(z){B 8p=1K.1M("3N");if(o.kp.L(z)>-1){o.kp.2P(z);if(z.L("?")>0){z=z+\'&\'+2I.6o()}F{z=z+\'?\'+2I.6o()}}F{o.kp.2P(z)}8p.5R(\'2X\',z);8p.5R(\'X\',\'5z\');8p.5R(\'W\',\'5z\')};B 4w=E(e,o){U(B 1a in o){if(o.2h(1a)){e.5R(1a,o[1a])}}};B 8M=E(e){if(e){3v{e.4Q.2U(e);e=1S}3c(e){}}};B 6o=E(7S,5C){O 2I.7n(uP.Q>1?(5C-7S+1)*2I.6o()+7S:(7S+1)*2I.6o())};B md=E(){O 2I.6o().6B(36).GC(2,12)};B rz=E(x,y){x=42.3I(x).GD(E(3Z,1a){if(1a!=y){3Z[1a]=x[1a]}O 3Z},{});O x};B 4j=E(x){if(2i x=="5h"){O x.1Z(/^\\s+|\\s+$/gm,\'\')}F{O x}};B GB=E(x,n){if(n==0){O"#0"+aw.e(x)}if(n==-1){O aw.e(x)}if(n==1){O"#1"+pw(aw.e(x),1)}};B sX=E(x){if(v[x]!=""){if(2i v[x]!="5h"){o[x+\'o\']=v[x]}F{if(v[x].L("[{")==0){3v{v[x]=v[x].1Z(/bp\'qt/ig,\'"\');o[x+\'o\']=2j(v[x])}3c(e){}}}}};B 5k=E(x){O ba.pF(x)};B bM=E(x){if(x.1w(0,2)=="#1"){O aw.d(pw(x.1w(2),-1))}F if(x.1w(0,2)=="#0"){O aw.d(x.1w(2))}F{O x}};B sW=E(x){if(x){if(x.L(\'3n\')==-1&&x.L(\'.\')==-1&&x.Q>1h){x=\'1C:aQ/qJ;hf,\'+x}}O x};B 1l=E(x){x.C.6b="3G"};B 1n=E(x){x.C.6b="3U"};B 3g=E(x){x?x.C.2m="1I":\'\'};B 6s=E(x){x?x.C.2m="5a":\'\'};B 62=E(x){O x?x.C.6b!="3G"&&x.C.2m!="1I":J};B 4X=E(s){if(2i s=="5h"){if(s.L("px")>0){s=s.1w(0,s.L("px"))}}O 2w(s)};B 3G=E(x){O x.C.2m=="1I"};B iL=E(cG){B kq=2w(cG,16);B r=(kq>>16)&pG;B g=(kq>>8)&pG;B b=kq&pG;O r+","+g+","+b};B 4o=E(o,x,y){o[x+\'1f\']=0;o[x+\'2l\']=0;o[x+\'2F\']=0;o[x+\'1b\']=0;if(I(o[y])){B z=o[y].2t(" ");if(z.Q==4){o[x+\'1f\']=z[0]?4U(z[0]):0;o[x+\'2l\']=z[1]?4U(z[1]):0;o[x+\'2F\']=z[2]?4U(z[2]):0;o[x+\'1b\']=z[3]?4U(z[3]):0}}O o};B Gy=E(x){if(x){x=x.1Z(/ /ig,\'px \')}O x+\'px\'};B nx=E(x,y){O v[x]&&v[x]!=\'\'?v[x]:y};B e6=ba.pF(65,66,67,68,69,70,71,72,73,74,75,76,77,97,98,99,1h,E6,vZ,Gz,GL,GM,GK,GJ,GG,H6,78,79,80,81,82,83,84,85,86,87,88,89,90,Hs,Hp,Hn,Hb,H7,Hl,Hm,Hk,Hj,Hh,tR,Hi,IP);B aw={9v:e6+"Km+/=",e:E(e){B t="";B n,r,i,s,o,u,a;B f=0;e=aw.ul(e);gU(f<e.Q){n=e.9J(f++);r=e.9J(f++);i=e.9J(f++);s=n>>2;o=(n&3)<<4|r>>4;u=(r&15)<<2|i>>6;a=i&63;if(o8(r)){u=a=64}F if(o8(i)){a=64}t=t+G.9v.5L(s)+G.9v.5L(o)+G.9v.5L(u)+G.9v.5L(a)}O t},d:E(e){B t="";B n,r,i;B s,o,u,a;B f=0;e=e.1Z(/[^A-uF-z0-9\\+\\/\\=]/g,"");gU(f<e.Q){s=G.9v.L(e.5L(f++));o=G.9v.L(e.5L(f++));u=G.9v.L(e.5L(f++));a=G.9v.L(e.5L(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t=t+5k(n);if(u!=64){t=t+5k(r)}if(a!=64){t=t+5k(i)}}t=aw.uO(t);O t},ul:E(e){e=e.1Z(/\\r\\n/g,"\\n");B t="";U(B n=0;n<e.Q;n++){B r=e.9J(n);if(r<gE){t+=5k(r)}F if(r>Kt&&r<K5){t+=5k(r>>6|K4);t+=5k(r&63|gE)}F{t+=5k(r>>12|uQ);t+=5k(r>>6&63|gE);t+=5k(r&63|gE)}}O t},uO:E(e){B t="";B n=0;B r=0;B c1=0;B c2=0;gU(n<e.Q){r=e.9J(n);if(r<gE){t+=5k(r);n++}F if(r>K8&&r<uQ){c2=e.9J(n+1);t+=5k((r&31)<<6|c2&63);n+=2}F{c2=e.9J(n+1);c3=e.9J(n+2);t+=5k((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}O t}};B pw=E(s,n){s=s.1Z(/\\+/g,"#");s=s.1Z(/#/g,"+");B a=tO(o.y)*n;if(n<0)a+=e6.Q/2;B r=e6.1w(a*2)+e6.1w(0,a*2);O s.1Z(/[A-uF-z]/g,E(c){O r.5L(e6.L(c))})};B tO=E(x){x=x.2t(5k(61));B lf=\'\';B c1=5k(tR);B po;U(B i in x){if(x.2h(i)){B pv=\'\';U(B j in x[i]){if(x[i].2h(j)){pv+=(x[i][j]==c1)?5k(49):5k(48)}}po=2w(pv,2);lf+=5k(po.6B(10))}}O lf.1w(0,lf.Q-1)};B I=E(x){O x!=1S&&2i(x)!=\'1W\'&&x!=\'1W\'};B tn=E(x,y){O I(x)?x:y};B Ap=E(y){B x=[];if(I(42.yQ)){x=42.yQ([],y)}F{U(B z in y){if(y.2h(z)){x[z]=y[z]}}}O x};B eO=E(el){O el.z3().1b+(22.yK?22.yK:22.L5)};B gh=E(el){L6 g3=el.z3();O g3.1f+22.L4};B 7a=E(x){if(x!=\'\'){if(v.L1==1){22.7x(x)}F{22.9O.aP=x}x=\'\'}};B gD=E(5Y){B 5Y=2I.7n(5Y);B 5U=2I.7n(5Y/60);B 7q=2I.7n(5U/60);5U=2I.7n(5U%60);5Y=2I.7n(5Y%60);7q>0&&5U<10?5U="0"+5U:"";5Y=5Y>=0?((5Y>=10)?5Y:"0"+5Y):"ar";B 6l=(7q>0?7q+":":"")+(5U>=0?5U:"0")+":"+5Y;O 6l};B qo=E(){if(v.4i==1){o.4i?o.1D.2U(o.4i):\'\';o.4i=1S}};B wS=E(){B lS=J;B iP=H;if(o.1m.tv){1r("tv")}G.9p=E(x){o.S?o.S.1N(x):\'\'};G.6u=E(x){if(x){if(2i(x)==\'5h\'){x=x.1Z(/(\\r\\n|\\n|\\r)/gm,"");if(x.L("[{")==0){3v{x=x.1Z(/bp\'qt/ig,\'"\');x=5N.7y(x)}3c(e){x="xT 5N"}}}if(2i(x)==\'3r\'){o.1t=[];o.19=mK(x);if(v.19.KA==1&&!v.4O){B 3I=42.3I(o.1t);B qh=3I.8j(-1)[0];qh?v.4O=qh:\'\'}B y=wW();if(y){x=y.3h;o.cW=y.1N;o.S?o.S.BW(y.1N):\'\';if(I(y.2g)){if(o.P){o.P.8B(y.2g)}F{v.2g=y.2g}}if(I(y.2J)){y.2r=y.2J}if(I(y.1A)){v.1A=o.2z=y.1A}8a("A7");if(I(y.id)){o.3F=y.id}B sx=["2r","lB","sm","1e","DJ","DF","fs","lx","6g","2N","7t","4q","4e","b0"];if(I(v.am)){if(v.am.KB==1&&v.am.lD==1){sx.2P("1N");sx.2P("t1");sx.2P("t2");sx.2P("t3");sx.2P("t4");sx.2P("t5")}}U(B i=0;i<sx.Q;i++){if(I(y[sx[i]])){v[sx[i]]=y[sx[i]]}}if(sx.L(\'1N\')>0){if(v.am.xR==1){o.kd=v.am.xV;o.V.lM(y)}o.V.9p(\'1N\')}if(o.S){o.S.5Q(o.19)}if(o.3b){o.3b.jN()}}F{}}if(2i(x)==\'5h\'){x=mv(x);if(x.L("#"+v.9l)==0){x=o[o.fd[0]](x)}if(x.L("#"+v.cU)==0&&x.L(v.hB)>0){x=o[o.fd[1]](x)}if(x.L("#0")==0){x=aa(x)}x=mv(x);if(v.dZ==1){x=dZ(x)}if(x==\'\'){1r("5w 3h");o.9F=H;js("1E","5w")}o.26=[];o.7J=[];o.5I=[];o.mG=0;o.2R=0;o.5e=0;v.gZ==\'\'?v.gZ=\',\':\'\';if((x.L("]")>-1&&x.L("[")>-1)||I(v.bh)){o.3M=x.2t(v.gZ)}F{o.3M=[x]}o.8x=[];if(I(v.bh)){B bh=v.bh.2t(v.gZ)}if(o.3M.Q>0){B q=0;U(B i=0;i<o.3M.Q;i++){o.3M[i]=4j(o.3M[i]);if(o.3M[i]!=\'\'){if(o.3M[i].L("[")==0&&o.3M[i].L("]")>1){o.26[i]=o.3M[i].1w(o.3M[i].L("[")+1,o.3M[i].L("]")-1);o.3M[i]=o.3M[i].1w(o.3M[i].L("]")+1)}F{if(I(v.bh)){o.26[i]=I(bh[i])?bh[i]:\'\'}F{o.26[i]=i+1}}B is=0;if(I(v.3Y)&&q==0){if(v.3Y.L("i6:")==0){if(v.3Y.1w(4)*1==i){is=1}}if(v.3Y==o.26[i]){is=1}if(v.3Y=="5C"&&i==o.3M.Q-1){is=1}}if(I(o.3Y)){if(o.3Y==o.26[i]){is=1;q=i}}if(is==1){o.mG=i;o.2R=i}o.3M[i]=mA(o.3M[i])}}}F{o.3M[0]=mA(o.3M[0])}O o.3M[o.mG]}}F{O x}};E mA(x){if(I(v.ym)&&x.L("//")==-1){x=v.ym+x}O x};G.yn=E(){if(o.19){B x=o.19.KN();U(B i=0;i<x.Q;i++){x[i].aT=i}o.19=x;o.S.5Q(o.19)}};G.5Q=E(x){if(2i(x)==\'3r\'){o.1t=[];o.KM=x;o.19=mK(x);if(o.S){o.S.5Q(o.19)}}};G.d6=E(x,y){!I(y)?v.3W=1:\'\';v.43=0;v.1k=1W;v.4q=1W;v.4e=1W;o.9F!=2?o.9F=J:\'\';o.aL=J;o.7G=J;o.9Z=0;o.hg=[];o.na=J;o.pU=J;o.uc=J;o.jv=[J,J,J];o.KK=md();o.xX=0;gV();if(v.mL>1){if(I(o.mt)&&v.nE==1){U(B i in o.mt){o.mt[i].pk=1W}v.mL--}}if(o.d7){o.d7.7t()}if(o.P.6f()=="5M"){G.9Q()}if(I(o.5i)){o.5i.4C()}if(I(o.fF)){3j(o.fF)}js("1y");o.V.kb();x=G.6u(x);if(y==1){o.2v=\'\'}o.P.6u(x);if((o.1m.2y||o.1m.6i)&&!I(y)){o.V.2B()}if(I(o.fl)){o.3y={x:1,y:1,x0:1,y0:1};o.P.rO()}8o("1O","2B",J);o.P.eV();o.S.cf();o.S.hW();o.S.4M()};G.gV=E(){gV()};E gV(){o.3u=-1;o.7Z=J;o.j6=J;v.2r=1S;v.lx=1S;o.2J=1S;o.2a=1S;if(I(o.S)){o.S.bn()}o.3e=1S;if(I(o.2r)){o.1D.2U(o.2r);o.2r=1S}o.3u=1S;o.7Z=J}G.lM=E(x){B y=J;if(x&&o.kd){v.1N=o.kd;U(B i=1;i<6;i++){if(I(x[\'t\'+i])){v.1N=v.1N.1Z("{"+i+"}",x[\'t\'+i]);y=H}}}O y};G.ai=E(){if(v.3W==1){if(v.qR==1){1G(E(){o.V.2B()},4v)}F{G.2B()}v.Je=1}hc()};G.hc=E(){hc()};E hc(){if(v.t7==1){if(2i yE!=="1W"){o.th=1y yE()}}}G.eV=E(){B x=J;if(o.1m.2y){x=H;if(v.xe==1&&o.1m.8V){x=J}if(v.xf==1&&o.1m.hR){x=J}if(v.xj==1&&o.1m.5x){x=J}if(v.Jf==1&&o.1m.9f){x=J}}if(v.Jd==1&&o.1m.tv){x=H}O x};G.nd=E(){o.P.3T(v.1P);if(o.3Q){o.P.4Y()}o.aL=H;o.S.4M();if(o.5D&&o.5A){o.4L.Go()}};G.xE=E(){!o.mC?8O(H):\'\'};E 8O(x){o.mC=H;if(o.S){if(o.S.al()){o.S.7O()}}if(o.3b){o.3b.dX()}!x?o.P.2B():\'\';if(!o.na){1G(E(){o.P.eV()},4v)}!o.1O?o.S.2B():\'\';v.8H==1?o.8H.2Z("1O"):\'\';v.2f==1?o.V.kb(\'eL\'):\'\';if(o.1m.2y){o.S.eN()}if(I(o.5i)){o.5i.Ja()?o.5i.uW():\'\'}if(v.Jb==1&&I(v.fs)&&o.dt){if(v.fs!=\'\'&&!I(o.h4)){o.h4=7d(mr,v.yC*2G);mr()}}}G.2B=E(hs){if(!o.1O){B 2o=J;if(o.2v=="44"){if(!o.P.i8()&&v.3W!=1&&v.43==1){2o=H;if(22[\'7c\']){v.3W=1;o.P.nc()}}}if(v.6J==1&&v.x6==0){o.V.kn();2o=H}if(o.9F||2o){if(o.9F){8d("7g")?ju(2):\'\'}}F{o.pT=J;zo(!o.1A);o.9M.jw();if(!o.1A){js("1A");o.1A=H;if(v.1u.pR==1){1G(E(){o.S.C8()},1h)}if(v.1u.7B>0&&v.3W==1){o.da=H;1G(mI,v.1u.7B*2G)}if(v.Jn==1&&v.Jo){Jm()}U(B i=0;i<o.aO.Q;i++){if(v[\'xU\'+o.aO[i]]==1){3m.7U("y6"+o.aO[i],7L.8N())}}if(v.J7==1&&v.IW){IU("1A")}js("1y");o.S.4M();8o("1O","2B",J);o.ab?8o("zC","IT",H):\'\'}F{8o("zE","J4")}if(v.zw==1&&!o.2e){B dd=1y 7L();B tt=dd.ap();if(tt-o.9V<cA){if(v.zx==1){o.1m.2y?G.6Z():\'\'}F{G.6Z()}}}if(o.d7){o.d7.7t()}if(hs!=1&&8d("7g")||8d("6x")){ju(2)}F{if(v.7a==1&&I(v.zy)&&!I(3k.7a)){7a(v.zy);2o=H}if(!2o){1r("2B");if(o.2v!=\'J1\'){o.P.1k()>0?o.S.4s(o.P.Y(),o.P.1k()):\'\'}if(!o.mu){o.mu=H;if(v.1u.7B>0&&v.3W==1){o.da=H;1G(mI,v.1u.7B*2G)}}B mg=J;if(o.P.Y()>1&&v.kN==1&&hs!=1){mg=8d("eL")}if(mg){}F{8O(J)}}}}}F{o.P?o.P.2B():\'\'}};E mI(){o.da=J;o.S.4M()}G.2Q=E(){if(o.1O){1r("2Q");o.P.2Q();o.S.2Q();js("59");v.mz?7w():\'\';v.mR==1?l0():\'\';v.8H==1?o.8H.2Z("59"):\'\';if(!I(o.2f)&&v.kN==0){8d("eL")}o.mC=J}};G.4Y=E(){o.P.4Y();o.S.4Y();o.3Q=H;js("4V")};G.6P=E(){o.P.6P();o.3Q=J;o.S.6P();js("9K")};G.3T=E(x,y){x<0.JO?x=0:\'\';x>1?x=1:\'\';if(x<=0){G.4Y();v.1P=0;x=0}F{if(o.3Q){G.6P()}v.1P=x}js("1P",x);o.S.3T(x,y);o.P.3T(x)};G.8s=E(){o.S.8s()};G.6K=E(){o.S?o.S.6K():\'\'};G.JP=E(){G.6K()};G.ne=E(){o.V.7b();G.6K()};G.4s=E(Y,1k){if(o.3i&&!o.1A){B f=o.3i.96();if(f.t&&f.d){Y=f.t}}o.S.4s(Y,1k)};G.os=E(Y,1k){if(I(o.2z)&&o.2v!="44"&&!o.P.5H()){o.V.3R(o.2z,J);o.2z=1W}};G.eA=E(){B d=1y 7L();o.9V=d.ap();B x=J;if(o.S.al()&&v.1d.8F!=1){o.S.7O();x=H}if(o.3b){if(o.3b.JN()){o.3b.dX();x=H}}if(v.19.8F==0){if(o.S.cI()&&v.19.e9==1){o.S.as();x=H}}if(v.7a==1&&I(v.zG)&&!I(3k.7a)){7a(v.zG);x=H}if(!x){if(v.1T.on==1&&v.1T.2D==1&&v.1T.nO==1){6H(\'1O\',(o.1O?0:1))}G.bK()}};G.zX=E(){if(o.S.al()){o.S.7O()}};G.bK=E(){if(o.P.6f()=="5M"){G.2Q()}F{G.2B()}a0(o.P.Y())};G.3R=E(b8,gq){if(b8<o.P.1k()){if(v.eP.JJ==1){if(b8>o.P.Y()){O}}if(v.4e>0){b8<v.4e?b8=v.4e:\'\'}o.zH=b8;o.P.3R(b8);if(gq){o.S.3R(b8,o.P.1k())}o.ff=H;o.fQ=o.P.Y();a0(o.fQ)}};G.JQ=E(1e,4d,zM){if(o.P.6f()=="5M"&&o.eT!=\'9s\'){2Q();if(o.2e&&zM){o.S.8S()}}22.7x(1e,4d)};G.s8=E(){B x=o.P.an();if(I(v.6g)){x=v.6g}if(x!=\'\'){js("6g");B gR=22.7x(x,(v.JX==1?\'Jw\':\'nv\'));gR.5G()}};G.7b=E(){B Y=o.P.Y();B 1k=o.P.1k();o.S.fZ(Y,1k)};G.mS=E(){B Y=o.P.Y();B 1k=o.P.1k();B aK=1k>0?Y/1k:0;if(!o.ff){o.S?o.S.fZ((o.2z>0?o.2z:Y),1k):\'\'}F{Y!=o.fQ?o.ff=J:\'\'}if((v.ga==1||v.zg==1)&&1k>0){jV("np","2B 25%",aK,0.25);jV("nj","2B 50%",aK,0.50);jV("ni","2B 75%",aK,0.75)}U(B i=0;i<3;i++){if(!o.jv[i]){if(aK>=i*0.25+0.25){wX(i)}}}v.nG==1?1r(1,Y,1k):\'\';if(v.9R==1){if(o.1O){B z=J;B kD=J;if(v.zb==1){if(!o.P.5H()){z=H}}if(Y>0){if(Y==o.Y&&!z){kD=H}F{o.9Z=0}o.Y=Y}F{if(v.JG==1){B ld=o.P.aF();v.nG==1?1r(2,ld,o.kh):\'\';if(!z){if(ld==o.kh){kD=H}F{o.9Z=0}}o.kh=ld}}if(kD){o.9Z++;v.nG==1?1r(3,o.9Z):\'\';if(o.9Z==v.n5*(2G/o.mO)){o.V.fJ()}}}}if(v.2f==1){v.Es!=1&&v.nE==1?mJ("8k",Y,1k):\'\';v.Et!=1&&v.pd==1?mJ("dW",Y,1k):\'\'}if(v.wN==1&&v.nz>0){if(Y>=v.nz){if(!I(o.2f)){if(8d("6x")){o.P.2Q();o.S.2Q()}v.nz=0}}}8a("1O");if(v.6J==1&&v.x6>-1){EB(Y,1k)}if(o.7Z){a0(Y)}if(o.4S&&v.aX==1){if(o.3i){o.3i.nQ(Y,1k)}}if(I(v.4q)){if(v.4q>0&&Y>v.4q){if(o.2v=="44"){o.P.2Q();o.P.3R(v.1A>0?v.1A:0)}F{o.P.jZ();o.V.9Q()}v.1A>0?o.2z=v.1A:\'\';o.V.lC()}}if(I(v.7t)){B r1=v.7t.2t(",");U(B i=0;i<r1.Q;i++){B r2=r1[i].2t("-");if(r2.Q==2){if(Y>r2[0]&&Y<r2[1]){o.P.3R(r2[1])}}}}};E wX(x){o.jv[x]=H;if(v.aX==1&&v.DX==1&&v.xm==x){if(o.4S&&o.3F){o.3i?o.3i.El(o.3F):\'\'}}}E jV(x,y,t,p){if(!I(o.hg[y])){if(t>p){8o(x,y,H)}}};G.fJ=E(){o.9Z=0;if(v.ED==1){js("9R")}F{o.2z>0||o.P.5H()?\'\':o.2z=o.P.Y();B wR=o.S.cI();js("9R");o.P.9R();wR&&v.19.e9==1?o.S.j7():\'\'}};G.vW=E(){o.S.fZ(0,0);o.S.pf(0,0);o.V.4s(0,0);o.S.6K()};G.qb=E(){B Y=o.P.aF();if(v.EA==1){js("aF",Y)}B 1k=o.P.1k();o.S?o.S.pf(Y,1k):\'\'};G.lC=E(){js("EK");if(v.a3==1){if(o.2v=="44"){G.9Q()}if(v.1A>0){o.V.3R(v.1A)}G.2B()}F{if(o.P.5H()||o.2v=="44"){G.9Q()}F{if(v.wL==1){o.V.3R((v.1A>0?v.1A:0),H);if(o.1m.ie){o.P.2Q()}}}o.S.8e();v.wN==1?v.EP=1:\'\';if(8d("ko")||8d("pa")){}F{9h()}}};G.6Z=E(){o.b4.eH.yc=2n;B 2o=J;B 1E=J;o.xM=J;o.aV=H;1G(E(){o.aV=J},dg);U(B x in o.6Y){if(o.6Y.2h(x)){if(I(o.6Y[x])){3v{o.6Y[x].xp()}3c(e){}}}}3v{o.d0=H;if(((o.1m.5x&&v.qu==1)||(o.1m.9f&&v.Ea==1))&&o.5A&&!o.bR){B x=o.P.5P();if(x){if(x.Eb){mZ();2o=H}}}if(!2o){B lH;if(o.1D.mP){o.7E=H;lH=o.1D.mP({ly:"1l"});if(lH!==1W){lH.c6(E(){}).3c(E(1E){})}}F if(o.1D.n1){o.1D.n1({ly:"1l"});o.7E=H}F if(o.1D.n2){o.1D.n2({ly:"1l"});o.7E=H}F if(o.1D.nf){o.1D.nf({ly:"1l"});o.7E=H}F if(o.1D.n3){o.1D.n3();o.7E=H}}}3c(e){1E=H;1r(e)}if(!o.7E&&!2o){if(o.1m.41&&o.kj){mZ()}F{G.tf()}}if(!1E){1G(xN,4H)}};E mZ(){B x=o.P.5P();if(x){o.P.yd();x.FJ();x.1p("FI",xo)}}E xN(){if(o.xM!=H){if(o.8E){o.P.cn()}if(v.1T.pH==1){ll(H);o.4G=H}v.8H==1?o.8H.2Z("kU"):\'\';js("2e");8o("kU","6Z",H)}};B h7;B 9g={x:0,y:0};E od(e){if(o.3b){if(o.3b.Fa()){O}}o.7N=H;4m(h7);h7=7d(E(){o.7N=J;o.S.4J();9g={x:0,y:0};4m(h7)},47);o.S.4J();e.91();e.xu!=0?9g.x++:9g.x--;e.ma!=0?9g.y++:9g.y--;if(e.Fi!=0){if(9g.x>9g.y){if(e.xu>0){o.V.3T(4U(v.1P)-v.1T.cC/10,"no")}F{o.V.3T(4U(v.1P)+v.1T.cC/10,"no")}}F{if(e.ma>0){o.V.3T(4U(v.1P)+(o.1m.gR?-v.1T.cC/10:v.1T.cC/10),"no")}F{o.V.3T(4U(v.1P)-(o.1m.gR?-v.1T.cC/10:v.1T.cC/10),"no")}}o.S.gA()}}E xo(){if(o.1m.5x){o.P.yf();js("oI")}}G.tf=E(){if(o.d0){o.2e=H;o.S.6Z();if(!o.7E){if(I(o.7F)){3v{K(o.7F,{\'W\':\'1h%\',\'X\':\'1h%\',\'1i\':\'nU\',\'1b\':0,\'1f\':0,\'5j\':"iu"})}3c(bW){}}K(o.1D,{\'W\':\'1h%\',\'X\':\'1h%\',\'1i\':\'nU\',\'1b\':0,\'1f\':0,\'5j\':"iu"});o.3f=o.1D.1Y;o.4h=o.1D.2L;3v{1K.bl.C.6A=\'3G\';if(!I(o.19)){1K.yW=E(e){e.91()}}}3c(bW){}}if(v.pK==1){K(o.1D,{\'6a\':\'#3z\'})}if(o.3b){o.3b.dX()}a0(o.P.Y());o.d0=J}};G.8S=E(){lS=H;if(1K.wF){1K.wF()}F if(1K.xg){1K.xg()}F if(1K.xk){1K.xk()}F if(1K.xd){1K.xd()}F if(1K.xc){1K.xc()}F if(1K.x5){1K.x5()}if(!o.7E){G.te(J)}};G.uK=E(x,y){pY(x,y)};E pY(x,wZ){if(I(o.2f)&&!wZ){o.kw=x}F{B 2o=J;B eM=o.bc/x;if(I(o.7F)&&v.tU!=1){3v{K(o.7F,{\'X\':eM})}3c(bW){2o=H;1r("d9 Fr Fu")}}if(!2o){o.4D=x;o.9b=eM;if(o.4D>0){K(o.1z,{\'X\':eM})}js("X",eM)}if(o.2f&&!o.2e){o.4h=eM;o.2f.2n()}}};G.te=E(x){if(lS||x){o.2e=J;if(!o.7E){if(I(o.7F)){3v{K(o.7F,{\'1i\':\'qB\',\'1b\':0,\'1f\':0,\'5j\':\'yp\'});K(o.7F,o.tV);K(o.7F,{\'W\':o.9A,\'X\':o.ch})}3c(bW){}}K(o.1D,{\'W\':o.9A,\'X\':o.ch,\'1i\':\'29\',\'1b\':0,\'1f\':0,\'5j\':\'yp\'});3v{1K.bl.C.6A=\'2A\';1K.yW=E(e){O H}}3c(bW){}}o.S.8S();if(v.pK==1){K(o.1D,{\'6a\':v.lk});if(v.dv==1){o.1D.C.6a=\'dv\'}F{K(o.1D,{\'6a\':v.lk})}}if(v.1T.pH==1){ll(J);o.4G=J}if(o.3b){o.3b.dX()}a0(o.P.Y());o.S.kB();lS=J;js("oI");o.7E=J;o.aV=J}};G.4G=E(x){ll(x)};E ll(x){9g={x:0,y:0};if(x){22.1p("qF",od,{a2:J})}F{4m(h7);22.5X("qF",od,{a2:J})}}G.9Q=E(){v.43=0;o.S.2Q();o.V.vW();o.P.3T(v.1P);if(o.S.al()){o.S.7O()}if(o.3Q){G.4Y()}if(I(o.h4)){4m(o.h4);o.h4=1S}a0(0);1r("2o");js("2o")};G.nN=E(){v.43=0;v.3W=0;o.P.jZ();o.V.9Q()};G.5n=E(x){if(I(o.2R)){if(o.2R!=x){o.2R=x;if(v.rj==1){o.3Y=o.26[x];if(o.4S){3m.7U("r8",o.3Y)}}o.P.5n(x);js("4z",o.26[x]);o.S.py(x)}}};G.gI=E(){o.S?o.S.gI():\'\'};G.bq=E(x){if(I(o.5e)){if(o.5e!=x){o.5e=x;if(v.xS==1){o.8z=v.8z=o.5I[x];if(o.4S){3m.7U("qV",o.8z)}}o.P.bq(x);js("6e",x);o.S.hZ("6e")}}};G.9z=E(x){if(I(o.3u)){if(o.3u!=x){if(x==-1||(v.9D==1&&x==o.3e.Q-1)){pM()}F{v.aA=0;o.3u=x;o.7Z=H;v.gt=1;o.P.9z(x);js("2r",o.3e[x]);o.S.bn()}}F{if(v.9D!=1){pM()}}}};E pM(){js("2r","8l");o.3u=v.9D==1?o.3e.Q-1:-1;v.gt=0;o.7Z=J;o.S.bn();o.j1||o.iZ?o.P.9z(o.3u):\'\';I(o.2r)?o.1D.2U(o.2r):\'\';o.2r=1S}G.9P=E(x){B y=x==o.fH?1:o.5W[x];if(o.4S&&v.wP==1){3m.7U("sM",y)}js("6R",o.5W[x]);o.P.9P(y);o.9T=x;o.S.hZ("6R")};G.ir=E(){a0(o.P.Y());mU()};E a0(Y){if(v.aA){Y=Y-v.aA*1}if(o.7Z&&I(o.2a)){B 2J=o.P.2J();if(2J){B x=o.3u;if(I(2J[x])){if(I(2J[x][1])){B t=2w(Y*10);if(I(2J[x][1][t])){B y=\'\';y=2J[x][0][2J[x][1][t]];if(!I(o.2r)){o.2r=1M(\'1R\');o.1D.1J(o.2r);mU()}if(o.S.kt()||v.bf>v.1u.h){K(o.2r,{"1i":"29","2F":(v.bf*1)})}F{K(o.2r,{"1i":"29","2F":(v.bf*1+v.1u.h*1)})}if(v.Gv==1){y=ET(y)}if(v.iY==1){y=y.1Z(/\\[ea\\]/gm,\'<6V C="1v:\'+(v.bU.L("#")==-1?\'#\':\'\')+v.bU+\'">\');y=y.1Z(/\\[\\/ea\\]/gm,\'</6V>\')}o.2r.1V=\'<6V C="\'+(v.vT==1?\'2x-1v:\'+wm(v.go,v.fX)+\';\':\'\')+\'-41-5u-m8-1g: EE;1v:\'+(v.c8.L("#")==-1?\'#\':\'\')+v.c8+\';2S:\'+v.p4+\'px \'+v.p4*2+\'px;2W-6k:\'+v.wa+\'px;2K:0 0;2C-X:\'+(v.we?v.we:1.8)+\';3V-fw:\'+v.h1+\'">\'+4j(y)+\'</6V>\';if(v.v1==1){if(o.2e){K(o.2r,{"3V-3t":((v.vF+((2w(v.e3)-1h)*v.gl/1h))+"px")})}F{K(o.2r,{"3V-3t":((v.gl+((2w(v.e3)-1h)*v.gl/1h))+"px")})}}iP=J}F{if(!iP&&I(o.2r)){o.2r.1V=\'\';iP=H}}}}}}}E mU(){if(o.2r){K(o.2r,{"1i":"29","W":"1h%","2S-1b":"10%","2S-2l":"10%","1b":0,"1v":v.c8,"1F-8i":"7e","5u-hL":"2W-5u","3S-2H":"1I"});if(v.Ge==1&&I(v.n6)){v.n6!=\'\'?K(o.2r,{"3V-ho":v.n6}):\'\'}if(v.fR==1){K(o.2r,{"1F-bH":"5z 5z Nd RD"})}F{K(o.2r,{"1F-bH":"1I"})}}}B 6n;B 7A;B kP;B 2k;E 8d(x){if(v["8c"+x+"vC"]>0&&o.4S){B tb=3m.5y("jr"+x+"7l"+o.d);if(tb){B ct=1y 7L();o.9V=ct.ap();B vD=(ct.ap()-tb)/RE;if(vD<v["8c"+x+"vC"]){O J}}}if(v["8c"+x+"vy"]>0){if(o.P.1k()>0){if(o.P.1k()<v["8c"+x+"vy"]*60){if(v["8c"+x+"vk"]>0){v.cV=v["8c"+x+"vk"]}F{O J}}}}if(o.hM.L("9E")!=-1&&v.2f==1&&!o.hs&&v[x+\'s\']==1){if(2i qe=="1W"){O J}if(x=="6x"||x=="pa"){if(2i vj!=="1W"){2k=[];O vj(x)}}if(I(o.2f)||I(o.5V)){js("v4",x);O H}F{if(I(v[x])){if(v[x].6B().L(".")>-1||v[x].6B().L(":")>-1||v[x].6B().L("[RC]")>-1){js("v4",x);if(x!="8k"&&x!="dW"){o.V.8s();gw()}6n=0;7A=0;kP=x;2k=v[x].2t(" l6 ");o.4W=[];o.RB=2k.Q;o.ur=1;o.iC=H;U(B i=0;i<2k.Q;i++){2k[i]=2k[i].2t(" or ")}v[x.8P("7l","ek")]=v[x];v[x]=1S;o.51=x;if(x!=\'dW\'){o.2f=1y qe()}o.5V=1y jQ();U(B i=0;i<2k.Q;i++){U(B j=0;j<2k[i].Q;j++){B 6G=4j(2k[i][j]);if(6G.L("[50%]")>0){B 1H=6o(1,2);2k[i][j]=2k[i][j].1Z("[50%]","");if(1H==2){2k[i][j]=\'\'}}}}if(v.oJ==1){U(B i=0;i<2k.Q;i++){B n=i==0?1:0;if(2k[i].Q>n){U(B j=n;j<2k[i].Q;j++){B 6G=4j(2k[i][j]);if(o.1m.ov){er(6G)}F{1G(er,i*1h,6G)}}}}}o.5V.k5(4j(2k[0][0]),x);O H}F{O J}}F{O J}}}F{O J}};G.vg=E(x){8d(x)};E mJ(w,x,d){if(I(o[w+\'o\'])&&v[w+\'s\']==1){B y;U(B i in o[w+\'o\']){if(o[w+\'o\'].2h(i)){if(!I(o[w+\'o\'][i].pk)&&I(o[w+\'o\'][i].Y)&&I(o[w+\'o\'][i].2f)){B z=o[w+\'o\'][i].Y.6B();if(z){if(z.L("%")>0){if(d>0){z=2w(z.1w(0,z.L("%")))*d/1h}F{z=-1}}F{z=2w(z)}if(x>=z){if(v[\'8c\'+w+\'v9\']>0&&z>-1){if(x-z>=v[\'8c\'+w+\'v9\']){z=-1}}if(z>-1){y=o[w+\'o\'][i].2f;v[w]=o[w+\'o\'][i].2f;if(8d(w)){o[w+\'o\'][i].pk=H;1g}}}}}}}}};G.Ry=E(){if(o.51=="8k"&&v.wt==1){if(o.1O){o.P.2Q();o.S.2Q()}K(o.wv,{"1o":1})}};G.Rz=E(x){o.5V=1S;1r("9E 3E");js("RA",o.51);if(x.1B=="dW"){B wb=1y RF(x);o.pd.2P(wb)}F{if(I(o.2f)){if(o.51=="8k"&&v.wt==1){K(o.wv,{"1o":0})}F{if(o.1O){o.P.2Q();o.S.2Q()}}if(v.43==0&&v.RG==1&&o.P.Y()==0&&o.P.1k()==0){v.43=1;o.P.nB()}if((!o.2f.RM()||x.wq)&&o.pX>0){1r("9E RN");o.2f.4C();o.2f=1S;o.2f=1y qe()}o.pX++;if(o.iC&&v.cM>0){3j(o.cM);o.cM=1G(vV,v.cM*2G*60);if(I(v.vJ)){if(v.vJ!=\'\'){o.gj?o.gj.7t():\'\';o.gj=1y RL()}}}o.iC=J;if(v.w1>0){1r("9E RK");js("RH");1G(pO,v.w1*2G,x)}F{pO(x)}}F{1r("9E RI")}}};E pO(x){o.2f.Go(x)}E vV(){if(I(o.2f)){if(o.2f.qH()&&o.bS==0){o.2f.nW();1r("9E vt "+v.cM);2k=[];aJ()}}}G.RJ=E(){js(\'Rx\',o.51);1r("9E 1E");fL()};G.fL=E(){B 2o=J;B ew=J;if(o.51=="7g"){if(v.mj>0&&o.e1>0){ew=H;if(o.bS>=v.mj){2o=H}}if(v.cV>0&&!ew){if(v.us==1&&o.e1==0){}F{if(o.bS>=v.cV){2o=H}}}}!2o?fL():aJ()};G.Rw=E(x){if(v[o.51+"oh"]){U(B i=0;i<3;i++){v[o.51+"oh"]=v[o.51+"oh"].1Z(x+(i==0?\' l6 \':(i==1?\' or \':\'\')),\'\')}}};E fL(){if(2k.Q>0&&2k[6n]){if(7A<2k[6n].Q-1){o.2f?o.2f.nW():\'\';7A++;B 6G=4j(2k[6n][7A]);B dG=nV(6G);if(dG==\'lW\'){o.5V=1y jQ();o.5V.k5(6G,o.51)}if(dG==\'1E\'){fL()}}F{aJ()}}F{aJ()}}E nV(6G){B x=\'lW\';if(v.oJ==1&&o.4W){B lm=J;B n=0;U(B i=0;i<o.4W.Q;i++){if(o.4W[i].kX==0){if(o.4W[i].a5.tQ(6G)){o.4W[i].kX=1;B y=o.4W[i].a5.9e();if(y==\'3E\'){o.5V=o.4W[i].a5;1r("9E tQ");o.4W[i].a5.f5();x=y}F{if(y==\'\'){x=\'ok\';1r("9E Rk");o.5V=o.4W[i].a5;o.4W[i].a5.Rl()}if(y==\'1E\'){x=\'1E\'}}lm=H}if(lm&&o.4W[i].ej==0){n++;if(n<6){oS(o.4W[i])}F{1g}}}}}O x}G.Rm=E(x,y){if(x!=\'\'){B z=6n;B ow=J;if(y){U(B j=0;j<2k.Q;j++){2k[j]==y?z=j:\'\'}}if(2k.Q==1){if(2k[0].Q>1&&7A<2k[0].Q-1&&2k[7A]){B uS=2k[7A].8j(1,99);2k[0].oG(7A+1,99);ow=H}}if(2i(x)=="3r"){U(B i=0;i<x.Q;i++){2k.oG(z+i+1,0,[x[i]]);if(o.1m.ov){er(x[i])}F{1G(er,i*1h,x[i])}}}F{if(2i(x)=="5h"){2k.2P([x]);er(x)}}if(ow){2k[2k.Q-1]=2k[2k.Q-1].8P(uS)}}};G.Rj=E(x,y){if(x!=\'\'){B z=6n;if(y){U(B j=0;j<2k.Q;j++){2k[j]==y?z=j:\'\'}}if(2k[z]){if(2i(x)=="3r"){U(B i=0;i<x.Q;i++){2k[z].2P(x[i])}}F{if(2i(x)=="5h"){2k[z].2P(x)}}}}};G.aJ=E(x){aJ(x)};E er(x){if(v.oJ==1&&o.4W){B i=0;U(B i=0;i<2k.Q;i++){if(2k[i]==x){if(6n>=i){O}F{}}}if(2k.Q==1&&2k[0].Q>1){}F{B n=0;U(i=0;i<o.4W.Q;i++){o.4W[i].kX==0?n++:\'\'}o.4W.2P({ej:0,kX:0,x:4j(x),t:o.51,a5:1y jQ(H)});n<5?oS(o.4W[o.4W.Q-1]):\'\'}}}E oS(x){if(x){x.ej=1;x.a5.k5(x.x,x.t)}}E aJ(kx){B 2o=J;B ew=J;if(o.51=="7g"){if(v.mj>0&&o.e1>0){ew=H;if(o.bS>=v.mj){2o=H}}if(v.cV>0&&!ew){if(v.us==1&&o.e1==0){}F{if(o.bS>=v.cV){2o=H}}}}if(2k.Q>0&&6n==2k.Q-1){if(2k[0][0].L("js:")==0){6n=-1;2k=[[2k[0][0]]]}}if(o.Ri==2){2o=H}if(2k.Q>6n+1&&!2o){o.2f.nW();6n++;o.ur++;7A=0;B 6G=4j(2k[6n][0]);B dG=nV(6G);if(dG==\'lW\'){o.5V=1y jQ();o.5V.k5(6G,kP)}if(dG==\'1E\'){aJ(kx)}}F{gu();o.S.6K();if(I(o.2f)){o.2f.4C();o.2f=1S}o.5V=1S;2k=[];7A=0;6n=0;o.yL!=1?js("Rf",o.51):\'\';o.yL=0;if(v.Rg==1){if(o.pN){o.pN.sQ();o.pN=1W}}kP=\'\';o.bS=0;3j(o.cM);o.gj?o.gj.7t():\'\';o.e1++;if(o.51=="7g"||(o.51=="eL"&&v.kN==1)||o.51=="8k"){if(v.3h!=\'?\'){o.P.e5();B re;if(o.2v=="44"&&!o.q3&&o.1m.5x){re=H;o.51=="7g"?o.P.wD():\'\'}if(re||kx==\'kx\'||v.Rh==1){}F{o.V.2B(1)}}}if(o.kw>0){pY(o.kw);o.kw=0}if(o.51=="ko"){9h()}o.q3=J;o.51=1S}};G.Rn=E(){2k=[[\'\']]};G.kb=E(y){B x=[\'7g\',\'eL\',\'ko\',\'6x\',\'pa\'];B z;U(B i=0;i<x.Q;i++){z=J;if(y){y!=x[i]?z=H:\'\'}if(!z&&I(v[x[i].8P("7l","ek")])){v[\'8c\'+x[i].8P("7l","zu")]--;if(v[\'8c\'+x[i].8P("7l","zu")]>0){v[x[i]]=v[x[i].8P("7l","ek")];v[x[i].8P("7l","ek")]=1S}}}};G.kn=E(){gw();if(I(o.6J)){o.6J.4C();o.6J=1S}o.6J=1y Ro()};G.Ru=E(){gu();o.6J.4C();o.6J=1S};G.gw=E(){gw()};G.gu=E(){gu()};E gw(){if(o.bm){}F{o.bm=1M("1R");o.1D.1J(o.bm);K(o.bm,{"W":"1h%","X":"1h%","1i":"29","1f":0,"1b":0,"2x":"#3z","1o":0.1});o.bm.C.5j=C5}};E gu(){if(o.bm){o.1D.2U(o.bm);o.bm=1S}};E 7w(){if(I(o.2g)){if(v.2g!=o.sK){8B(v.2g,o.2g,v.hw)}1n(o.2g);K(o.2g,{"1o":v.jl});o.S.4M()}};G.lY=E(){if(I(o.2g)){if(62(o.2g)){B t=o.P.Y();if(t==0&&v.xP==1){}F{if(v.zf>0){3j(o.pu);o.pu=1G(l0,v.zf*2G)}F{l0()}}}}};E l0(){3j(o.pu);if(v.mz==1&&!o.1O){}F{K(o.2g,{"1o":0});1G(zs,4v)}}E zs(){if(!o.1O&&v.hv==1){}F{1l(o.2g)}}G.7w=E(){7w()};E zo(x){if(v.yj==1){U(B i=0;i<6E.Q;i++){if(6E[i].2Z("id")!=v.id){6E[i].2Z(\'59\')}}}g8=v.id}E mK(x){B y=42.3I(x).Q;if(y>0){x=mB(x,y,\'\',-1)}O x}E mB(x,y,p,j){B x2=[];B 2o;if(I(x[\'19\'])){x=x[\'19\'];y=x.Q}B ii=0;U(B i=0;i<y;i++){2o=J;if(I(x[i][\'id\'])){x[i][\'cD\']=x[i][\'id\']}x[i][\'id\']="x"+p+\'-\'+i+(I(x[i][\'id\'])?\'-\'+x[i][\'id\']:\'\');j==-1&&i==0&&!I(x[i][\'4B\'])?o.hQ=x[i][\'id\']:\'\';if(!I(o.hQ)){j==0&&!I(x[i][\'4B\'])?o.hQ=x[i][\'id\']:\'\'}x[i][\'hE\']=p;x[i][\'rr\']=j;x[i][\'aT\']=ii;if(I(x[i][\'xb\'])){x[i][\'1N\']=x[i][\'xb\'];B q1=x[i][\'3h\']?x[i][\'3h\'].L(\'[\'):0;B q2=x[i][\'3h\']?x[i][\'3h\'].L(\']\'):0;if(q1>0&&q2>0){B s1=x[i][\'3h\'].1w(q1+1,q2-q1-1);B s2=s1.2t(",");B s3=\'\';U(B k=0;k<s2.Q;k++){s3+="["+s2[k]+"]"+x[i][\'3h\'].1Z("["+s1+"]",s2[k])+(k<s2.Q-1?",":\'\')}x[i][\'3h\']=s3}}if(I(x[i][\'19\'])){x[i][\'4B\']=x[i][\'19\']}if(!I(x[i][\'4B\'])){if(I(x[i][\'3h\'])){if(x[i][\'3h\']==\'\'&&!I(x[i][\'7a\'])){2o=H}}F{2o=H}}if(!2o){o.1t[x[i][\'id\']]=x[i];ii+=1}if(I(x[i][\'4B\'])){B z=42.3I(x[i][\'4B\']).Q;if(z>0){x[i][\'4B\']=mB(x[i][\'4B\'],z,x[i][\'id\'],i)}}if(!2o){x2.2P(x[i])}}O x2}E wW(){B x=[];if(I(v.4O)){if(v.4O.L("x-")!=0){U(B y in o.1t){if(o.1t.2h(y)){if(o.1t[y].cD==v.4O){v.4O=y}}}}if(I(o.1t[v.4O])){v.19.Rv==1?v.19.rJ=0:\'\';x=o.1t[v.4O]}F{x=o.19[0];if(v.4O==o.wI){o.2z=1W}}}F{x=o.19[0]}if(x){U(B i=0;i<10;i++){if(I(x[\'4B\'])){x=x[\'4B\'][0]}F{1g}}v.4O=x.id;if(v.4O==o.wI){x.1A=1W}}O x}E 9h(){8o("4q","9h",H);o.V.kb();if(o.4S&&v.aX==1){o.3i.nQ(0,o.P.1k())}if(o.S.kG()){if(v.19.df==1&&o.S.dn()){o.S.dA();if(o.1O&&o.1m.5x&&o.2v!="b1"){}}F{mm()}}F{7w();js("wK")}}G.vH=E(){mm()};E mm(){if(v.19.lP==1&&!o.S.dn()){o.S.ka();O}if(v.19.AB==1){!o.S.cI()?o.S.as():\'\'}7w();js("wK")}E mv(x){if(x.L(\'js:\')==0){3v{x=2j(x.1w(3))}3c(e){eq.1r(e.8Y)}}O x}E mr(){B nu=2I.7n(7L.8N()/2G);B nq=(I(v.wM)?v.wM:0)+2w(o.P.Y());B 1B=0;o.1m.p0?1B=1:\'\';o.1m.5x?1B=2:\'\';o.1m.9f?1B=3:\'\';o.1m.Rt?1B=4:\'\';o.1m.tv?1B=5:\'\';B 1e=v.fs.1Z("[nu]",nu);1e=1e.1Z("[nq]",nq);1e=1e.1Z("[Rs]",1B);B 8p=1K.1M("3N");8p.5R(\'2X\',1e);8p.5R(\'X\',\'5z\');8p.5R(\'W\',\'5z\');o.1D.1J(8p)}};B xz=E(1e){B 1e;B 4E;B l7;B 8q;B cQ="";B eC=0;B k4=J;B k7=J;B n4;B P;B 3A;o.3y={x:1,y:1,x0:1,y0:1};B kI;B kF;B jG=0;B 2J=[];if(2i(1e)==\'5h\'){1e=4j(1e);if(1e.L("[{")==0){3v{1e=1e.1Z(/bp\'qt/ig,\'"\');1e=5N.7y(1e);kI?1e=o.V.6u(1e):\'\'}3c(e){eq.1r(e);1e="xT 5N"}}if(1e.L("#"+v.9l)==0){1e=o[o.fd[0]](1e)}if(1e){if(1e.L("#"+v.cU)==0&&1e.L(v.hB)>0){1e=o[o.fd[1]](1e)}}if(1e){if(1e.L("#0")==0){if(1e.L(o.ci)>0){1e=aa(1e.1Z(o.ci,\'\'))+o.ci}F{1e=aa(1e)}}}if(v.dZ==1){1e=dZ(1e)}if(2i(1e)==\'5h\'){if(1e.L(".9S")==1e.Q-4||1e.L(".8T")>0){kF=1e.2t(" or ");nJ()}}}o.4f=1M("1R");K(o.4f,{"1i":"29","W":"1h%","X":"1h%","4u":"2E 0.2s 2O","1F-8i":"7e"});o.1D.1J(o.4f);if(!kI){l5()}E nJ(){1e=kF[jG];if(1e.L(o.ci)>0){1e=1e.1Z(o.ci,\'\');v.3h=1e}B 4a=dL(1e);4a.bs=E(){if(G.de==4&&G.6f==4H){as(G)}F{jT(1)}};4a.oN=E(e){jT(1)};4a.a7();kI=H}E jT(x){if(jG+1<kF.Q){jG++;nJ();x=0}if(x==1){4Z("19 cw gP or zp qg")}if(x==2){4Z("Rp 5N")}}E as(x){if(x.c4){B y=x.c4;if(y.L("#"+v.9l)==0){y=o[o.fd[0]](y)}if(y.L("#"+v.cU)==0&&y.L(v.hB)>0){y=o[o.fd[1]](y)}if(1e.L(".9S")==1e.Q-4){B 9S=y.2t(/(\\r\\n\\t|\\n|\\r\\t)/gm);1e=[];B mX=1;B fW=\'\';U(B i=0;i<9S.Q;i++){if(9S[i].L("#Rq")>-1){if(9S[i].L(" - ")>-1){B 1H=9S[i].2t(" - ");fW=1H[1H.Q-1]}}if(9S[i].L("3n")>-1){1e.2P({1N:""+(fW!=\'\'?fW:mX),3h:9S[i]});mX++;fW=\'\'}}}F{y=y.1Z(/(\\r\\n\\t|\\n|\\r\\t)/gm,"");3v{1e=5N.7y(y)}3c(e){jT(2)}}if(I(1e.bx)){1e=Rr(1e)}if(o.S){if(v.19.j9==1){if(!o.S.cI()){o.S.j7()}}}l5();2n();1G(E(){js("19")},1)}}E l5(){1e=o.V.6u(1e);1e&&1e!=\'?\'?6u(1e):\'\'}E 4Z(x){1r("fy: "+x);B y=H;B yy=H;js("RO",x);if(4E){if(4E.Q>0){8q++;y=8q>4E.Q-1;if(y&&v.RP==1){if(o.3M.Q>1&&o.2R>0){if(o.26[o.2R].L(2M("dQ"))==-1){o.26[o.2R]=o.26[o.2R]+\' (\'+2M("dQ")+\')\'}yy=J;o.V.5n(o.2R-1)}}if(!y){B z=J;o.2z>0||!o.1A||P.5H()?\'\':o.2z=4t();if(o.2v!=mh(4E[8q])||o.2v!=\'b1\'){if(o.1O){o.V.9Q();z=H}}1r("Sd bJ",o.2z);6u(\'or\');o.1A&&!o.2f?P.2B():\'\'}F{if(v.9R==1&&yy){y=J;xO()}}}}if(y&&yy){8o("1E","fy",H);if(v.xK&&!o.9F){if(v.xG==1&&x=="cw gP"){o.9M.8T(v.yM)}F{o.9M.8T(x)}if(v.xI==1&&I(v.xH)){o.d7=1y xJ()}}o.9F=H;if(o.1O){o.V.6K();o.S.2Q()}I(o.2g)?o.V.7w():\'\';js("1E",x)}};E xO(){1r("fy fJ Se");I(o.fF)?3j(o.fF):\'\';o.fF=1G(E(){o.V.fJ()},v.n5*2G)}G.4Z=E(){4Z(P.oA())};G.8e=E(y){1r("lC");k4=H;B x=J;if(4s()>0&&!o.5D&&!y){B Y=o.xn;if(Y+10<4s()){1r(\'Sc (pi)\');js("pi");P.2B();P.3R(Y);x=H}}if(!x){o.V.lC();js("4q")}};G.8O=E(){if(v.mR==1){I(o.2g)?o.V.7w():\'\'}v.hv==1?o.V.lY():\'\';o.S.2B();o.V.xE();if(v.Sb==1&&I(v.nL)){if(v.nL.Q>5){ns();4m(n4);n4=7d(ns,v.xq*2G)}}js("1O")};G.eV=E(){if(v.kz==1&&o.5A){if(o.V.eV()){o.bR=P.ot();o.S.4M()}}o.na=H};G.aR=E(){o.V.2Q()};G.fc=E(){1r("S8")};G.fj=E(){1r("ne");o.V.ne();o.fQ?js("4g",o.fQ):\'\'};G.b6=E(){1r("nd");o.V.nd()};G.9i=E(){if(P){1r("4s",4s());o.V.4s(4t(),4s());js("1k",4s());if(I(o.kW)){o.V.bq(o.kW);o.kW=1S}}};E 4t(){B x=P.Y();O x}E 4s(){B x=P.1k();O x}G.cg=E(){};G.7z=E(){1r("8s");o.V.8s();js("9w")};G.bj=E(){if(eC!=4t()){o.V.6K();if(eC==0){if(v.hv==1&&v.xP==1){o.V.lY()}}}eC=4t();js("Y",eC);if(v.2q.on==1){if(2i(ya)==\'E\'){if(!3A&&v.2q.4b!=1&&v.xQ&&v.xQ!=\'\'&&eC>0){o.f6=1y ya();3A=o.f6.ce()}}}};G.nc=E(){if(o.2v=="44"){P?P.i8():\'\'}};G.y8=E(x){o.V.9Q();P.A5(x)};G.i8=E(){if(o.2v=="44"&&P){O P.3E()}F{O H}};G.m6=E(){O P.m6()};G.lT=E(){O P.lT()};G.5n=E(x){1r("S9",x);if((o.2v=="b1"||o.2v=="ws"||(o.2v=="1L"&&(v.7H==0||8R()<2))||(o.2v=="2b"&&(v.9r==0||aH()<2)))&&I(o.3M[x])){B Y=G.Y();o.2z>0?\'\':o.2z=Y;o.V.3R(Y,J);6u(o.3M[x],H);o.V.2B()}if(o.2v=="1L"&&v.7H==1&&8R()>1){P.v3(x)}F if(o.2v=="2b"&&v.9r==1&&aH()>1){P.v6(x)}F if(o.2v=="44"){P.AT(x)}};G.9z=E(x){if(I(o.2a[x])){1r("a0",x);o.3u=x;if(I(o.3e[x])){if(o.4S&&v.nF==1){3m.7U("nK",o.3e[x])}F{o.nI=o.3e[x]}}if(o.2v=="1L"&&o.j1==H){P.vo(x)}F{if(o.2v=="2b"&&o.iZ==H){P.vm(x)}F{if(o.2a[x]=="8A"){nn(o.3u)}F{kQ(o.3u)}}}}};E nn(x){2J[x]=42();2J[x][0]=8n();2J[x][1]=8n();U(B i=0;i<o.2a.Q;i++){1G(kQ,i*4v,i)}}G.9P=E(x){1r("Sa",x);P.fT(x);if(v.2q.on==1){if(3A){3A.fT(x)}}};G.yd=E(){yg()};E yg(){if(o.5A&&o.2a){P.o3();U(B i=0;i<o.2a.Q;i++){P.vq(o.2a[i],o.3e[i],(i==o.3u))}}}G.yf=E(){P.o3()};G.bq=E(x){1r("Sf",x);if(o.8x.Q>0){if(o.8x[x]){B Y=G.Y();o.2z>0?\'\':o.2z=Y;o.V.3R(Y,J);6u(o.8x[x],H);o.V.2B()}}F{if(o.2v=="1L"&&v.a6==1){P.vw(x)}F if(o.2v=="2b"&&v.dM==1){P.v0(x)}}};G.sd=E(){B x=o.26[o.2R];x==1W?x=\'\':\'\';B y=fN()&&v.gY==1&&v.7H==1;O(y?\'\'+2M("2A")+\' \':\'\')+x};G.sf=E(){B x=o.5I[o.5e];x==1W?x=\'\':\'\';O x};G.fN=E(){O fN()};E fN(){B x=J;if(P){if(o.2v=="44"){x=P.2A()}if(o.2v=="1L"&&v.7H==1&&8R()>1&&v.gY==1){x=P.2A()}if(o.2v=="2b"&&v.9r==1&&aH()>1){x=P.2A()}}O x}E 8R(){if(o.2v=="1L"){O P.8R()}F{O 0}}E aH(){if(o.2v=="2b"){O P.aH()}F{O 0}}G.4J=E(x){if(P&&(o.2v=="44"||o.2v=="9n"||I(v.fu))){P.4J()}if(v.y7>0){K(o.4f,{"X":(o.2e?"1h%":o.ch-v.y7)})}if(o.3A&&v.2q.wA==1){o.f6.4J()}};G.3t=E(){O P.3t()};G.9R=E(){1r(\'9R\');o.9Z=0;o.1A?v.3W=1:\'\';6u(1e)};if(!I(o.2g)){nC()}if(I(v.2g)){if(v.2g!=\'\'){8B(v.2g,o.2g,v.hw);if(v.mR==1&&!o.1A){1l(o.2g)}}F{v.2g=1S}}E 9e(){cQ=P?P.6f():\'\'}E y5(1e){4E=1e.2t(" or ");U(B i=0;i<4E.Q;i++){if(4E[i].L(" l6 ")>-1){l7=4E[i].2t(" l6 ");4E[i]=l7[6o(0,l7.Q-1)]}}8q=0}E xY(){9e();if(cQ=="5M"||o.5D){o.V.mS()}if(cQ!=""){o.V.qb()}}E nC(){if(o.2g){o.1D.2U(o.2g)}o.2g=1M("1R");K(o.2g,{"3S-2H":"1I","1o":v.jl,4u:"1o 0.5s"});if(v.xW==1){Sg()}F{K(o.2g,{\'1i\':\'29\',\'1b\':0,\'1f\':0,\'W\':\'1h%\',\'X\':\'1h%\'})}o.1D.1J(o.2g)}E 6u(x,y,xZ){v.fM==\'\'?v.fM=\';\':\'\';if(x.L(\'{\')>-1&&x.L(\'}\')>-1&&x.L(v.fM)>-1){B z=x.2t(v.fM);o.8x=[];U(B i=0;i<z.Q;i++){o.5I[i]=z[i].1w(z[i].L("{")+1,z[i].L("}")-1);o.8x[i]=z[i].1w(z[i].L("}")+1);if(I(v.8z)){if(v.8z==o.5I[i]){o.5e=i}}}x=o.8x[o.5e]}!I(4E)?4E=[]:\'\';x&&x!=\'or\'&&x!=\'x\'?y5(x):\'\';B ft=o.2v;if(4E.Q>0){o.2v=mh(4E[8q]);B ce=J;if(xZ){ce=H}1e=4E[8q];if(!ce&&x!=\'x\'&&P&&o.2v==ft&&(ft=="b1"||ft=="9n"||(ft=="44"&&o.1A&&!k7)||(ft=="1L"))){P.2X(1e);1r("2X")}F{1r("Sm");lI();wT(1e)}if(o.fH){if(o.9T!=o.fH){P.fT(o.5W[o.9T])}}}if(!y){4m(o.mN);o.mN=7d(xY,o.mO);if(I(v.2r)){if(v.2r!=\'\'){dT(v.2r)}}if(v.lh==1){if(v.kz==1&&o.1m.2y){}F{if(o.2v=="44"){K(o.4f,{"1f":-dg,"1b":-dg})}F{3g(o.4f)}v.1u.1l=0}}}}E mh(x){B 1B="b1";if(x){if(x.L(".zF")>0){1B="1L"}F if(x.L(".zA")>0){1B="2b"}F if(x.L("ws://")==0){1B="ws"}F if(x.L(\'44.a8/\')>-1||x.L(\'mb.be/\')>-1){1B="44";if(v.pJ==1){B y=\'e0://3N.44.a8/vi/\'+lE(x)+\'/\';wQ(y+\'wO.j5\',E(z){z>1h?v.2g=y+\'wO.j5\':v.2g=y+\'Sn.j5\';if(o.1t){o.1t[o.3F][\'2g\']=v.2g}v.3W==1||o.1A?\'\':8B(v.2g,o.2g,v.hw)})}}F if(v.9n==1&&x.L(\'9n.a8/\')>-1){1B="9n"}F if(v.Sl==1){Sk(x)?1B="bp":\'\'}}o.5A=1B=="b1"||1B=="1L"||1B=="2b"||1B=="ws";O 1B}E wQ(1e,wU){B 3N=1y Sh();3N.bs=E(){wU(G.X)};3N.2X=1e}E wT(x){o.2v=mh(x);o.p3=J;if(o.5A){P=1y zI(x,o.4f,J)}if(o.2v=="44"){P=1y CB(x,o.4f)}if(v.9n==1&&o.2v=="9n"){P=1y Si(x,o.4f)}if(o.2v=="bp"){P=1y Sj(x)}o.S?o.S.C4():\'\';B t=0;if(I(v.1k)){if(o.3i&&v.aX==1&&!o.1A){t=o.3i.96().t}1G(E(){o.V.4s(t,v.1k)},1h)}}E lI(){if(P){P.4C();P=1S;cQ="9I"}if(3A){3A.4C();3A=1S;3A=1W;o.f6.7t();o.3A=1S;o.f6=1S}};G.4C=E(){lI()};G.S7=E(){4E=[];lI()};G.6u=E(x,y,z){6u(x,y,z)};G.8B=E(x){8B(x,o.2g,v.hw)};G.2B=E(){if(P){k4=J;k7=J;if(o.5D){o.4L.2B()}F{P.2B();v.hv==1?o.V.lY():\'\'}if(I(3A)){3A.2B()}if(o.6I){if(o.5A){if(o.9V>0&&!o.6I.S6()){o.6I.jN()}}F{o.kL=[];o.S.hZ("aW")}}if(o.5A&&v.w9>-1&&!o.pU&&!o.1m.5x){if(o.9V>0){P.wk()}}}F{1G(G.2B,4v)}};G.wB=E(17){if(o.3A){if(v.2q.wA==1){if(o.sL[o.3A]>2){O}}if(17){17.9G();22.17?22.17.5F=H:\'\'}B 1H=P;P.pS(H,o.3A);3A.pS(J,o.4f);P=3A;3A=1H;P.2B();3A.2B();js("2q")}};G.wD=E(){P.2X(1e)};G.oc=E(){v.8H==1?o.8H.2Z("1l"):\'\';o.n0=H};G.gQ=E(){if(v.1u.pt){v.1u.pt=J;o.S?o.S.rA(1):\'\'}o.n0=J};G.wE=E(){if(I(o.3A)){62(o.3A)?1l(o.3A):1n(o.3A)}};G.d3=E(){if(o.5A&&o.4T){o.eg=H;P.4T()}};G.cn=E(){if(o.5A&&o.7G){P.7G()}};G.io=E(){if(v.a1==1&&I(v.wG)){if(!I(o.a1)){o.a1=1M("1R");K(o.a1,{\'1i\':\'29\',\'1b\':0,\'1f\':0,\'W\':\'1h%\',\'X\':\'1h%\',"3S-2H":"1I","5j":wH});o.1D.1J(o.a1)}6s(o.a1);8B(v.wG,o.a1,\'4A\')}if(P){ju(0);P.io()}};G.e5=E(){if(o.a1){3g(o.a1)}P?P.e5():\'\'};G.2Q=E(){if(o.5D){o.4L.2Q()}F{P?P.2Q():1r("RV")}if(I(o.3A)){3A.2Q()}};G.jZ=E(){k7=H;o.V.3R(0,J);I(o.2g)?o.V.7w():\'\';6u(\'x\')};G.bK=E(){P?P.bK():\'\'};G.3R=E(x){if(P){if(o.5D){o.4L.3R(x)}F{P.3R(x);if(v.2q.on==1){if(3A){3A.3R(x)}}}}};G.4Y=E(){if(P){P.4Y();o.5D?o.4L.4Y():\'\'}};G.6P=E(){if(P){P.6P();o.5D?o.4L.6P():\'\'}};G.3T=E(x){P?P.3T(x):\'\';if(o.5D){o.4L.3T(x)}};G.i0=E(){O P?P.i0():J};G.5H=E(){O P?P.5H():J};G.6f=E(){O cQ};G.9I=E(){O k4};G.Y=E(){B x=0;if(P){x=4t();if(o.5D){B y=o.4L.4t();y?x=y:\'\'}F{if(4s()>0&&x!=4s()){o.xn=x+0.RW}}O x}F{O 0}};G.1k=E(){B x=0;if(P){x=4s();x==0&&I(v.1k)?x=v.1k*1:\'\';if(o.5D){B y=o.4L.4s();y?x=y:\'\'}}O x};G.aF=E(){O P?P.aF():0};G.RU=E(){nC()};G.nB=E(){if(o.5A){P.43()}};G.1x=E(x){if(ba(x).L(":")>0){B y=x.2t(":");B z0=o.3f/o.4h;B z1=o.P.3t();if(z1.W>0){z0=z1.W/z1.X}B z=y[0]/y[1];if(z0!=z){if(o.5A){if(v.zz==1){K(P.5P(),{\'3r-aN\':\'sJ\'})}F{K(P.5P(),{\'3r-aN\':\'4A\'})}}B w2=o.4h*z;B x2=w2/o.3f;B h2=o.3f/z;B y2=h2/o.4h;if(x2<1){o.3y.x0=o.3y.x=4U(x2);o.3y.y=1}F{o.3y.x=1;o.3y.y0=o.3y.y=4U(y2)}K(o.4f,{"2E":"3l("+o.3y.x+") 3a("+o.3y.y+")"});o.fl=x}}F{o.3y.x+=4U(x);o.3y.y+=4U(x);K(o.4f,{"2E":"3l("+o.3y.x+") 3a("+o.3y.y+")"})}if(v.1T.RT==1){if(!o.xa){if(o.3y.x>0||o.3y.y>1){RQ(o.4f,\'o.RR\');o.xa=H}}F{if(o.3y.x==1&&o.3y.y==1){K(o.4f,{"1f":0,"1b":0})}}}o.S.p7()};G.rO=E(){if(o.5A){K(P.5P(),{\'3r-aN\':\'sO\'})}o.3y.x=o.3y.x0;o.3y.y=o.3y.y0;K(o.4f,{"2E":"3l("+o.3y.x+") 3a("+o.3y.y+")"});o.S.p7();o.fl=1S};G.RS=E(){B x=1W;I(o.2a)?I(o.2a[o.3u])?x=o.2a[o.3u]:\'\':\'\';O x};G.an=E(){O an()};E an(){O 4E.Q>0?(4E[8q]?4E[8q]:\'\'):\'\'};G.5P=E(){O P?P.5P():J};G.dT=E(x){dT(x)};G.5S=E(){if(o.5A){P.5S()}};E dT(x){if(x!=\'\'){B 1A=0;B g6=\'\';o.2a=x.2t(",");o.3e=[];o.3u=-1;if(rl()&&v.nF==1){if(3m.5y("nK")!=1S){g6=3m.5y("nK")}}F{if(o.nI){g6=o.nI}}U(B i=0;i<o.2a.Q;i++){if(o.2a[i].L("#0")==0){o.2a[i]=aa(o.2a[i])}if(o.2a[i].L("#"+v.9l)==0){o.2a[i]=o[o.fd[0]](o.2a[i])}if(o.2a[i].L("[")==0&&o.2a[i].L("]")>1){o.3e[i]=o.2a[i].1w(o.2a[i].L("[")+1,o.2a[i].L("]")-1);o.2a[i]=o.2a[i].1w(o.2a[i].L("]")+1)}F{o.3e[i]=o.2a[i].1w(o.2a[i].x8("/")+1);o.3e[i]=o.3e[i].1w(0,o.3e[i].x8("."))}if(o.2a[i].L("#0")==0){o.2a[i]=aa(o.2a[i])}if(o.2a[i].L("#"+v.9l)==0){o.2a[i]=o[o.fd[0]](o.2a[i])}}if(o.3e.Q>1&&v.iY==1){o.3e.2P(nx(\'RX\',2M(\'nH\')));o.2a.2P("8A")}if(o.3e.Q>0&&v.9D==1){o.3e.2P(nx(\'RY\',2M(\'8l\')));o.2a.2P("")}U(B i=0;i<o.2a.Q;i++){if(I(v.zm)){if(v.zm==o.3e[i]){1A=i;o.3u=i}}if(g6!=\'\'){if(g6==o.3e[i]){1A=i;o.3u=i}}}if(v.9D==1&&v.gt==0){o.3u=o.3e.Q-1}I(o.S)?o.S.bn():\'\';if(v.gt==1){o.3u=1A;if(v.iY==1&&o.2a[1A]=="8A"){nn(o.3u)}F{kQ(o.3u)}}F{v.9D!=1?o.3u=-1:\'\'}}F{o.V.gV()}}E kQ(x){if(I(o.2a[x])){if(o.2a[x].L(".")>-1){o.kS=o.2a[x].2t(" or ");o.dJ=0;kM()}}}E kM(x){B 1e=4j(o.kS[o.dJ]);B 4a=dL(1e);4a.bs=E(){if(G.de==4&&G.6f==4H){o.7Z=H;zr(1e,G.c4,x)}F{if(o.dJ+1<o.kS.Q){o.dJ++;kM()}F{gc("dQ")}}};4a.oN=E(e){if(o.dJ+1<o.kS.Q){o.dJ++;kM()}F{gc("dQ")}};4a.a7()}E gc(x){1r("2r cw gP or zp qg");if(o.3e[o.3u].L(2M("dQ"))==-1){o.3e[o.3u]=o.3e[o.3u]+\' (\'+2M(x)+\')\'}v.S4==1?o.2a[o.3u]=\'\':\'\';o.3u=-1;o.7Z=J;if(o.S5){o.S.bn();o.S.4M()}F{1G(E(){o.S.bn();o.S.4M()},1h)}if(I(o.2r)){o.1D.2U(o.2r);o.2r=1S}}E zr(1e,x,y){if(1e.L(\'.kc\')>-1||1e.L(\'.za\')>-1||1e.L(\'.kf\')>-1||1e.L(\'.zj\')>-1){B l=o.3u;if(I(2J[l])&&o.2a[l]=="8A"){}F{2J[l]=42();2J[l][0]=8n();2J[l][1]=8n()}B 3H=8n();3H=x.2t(/\\r|\\n/);B nk=1;B t1=0;B t2=0;3v{B eh=(I(v.zq)?v.zq:0);if(1e.L(\'dN=\')>0){eh=1e.1w(1e.L(\'dN=\')+6)*1}U(i=0;i<3H.Q;i++){if(1e.L(\'.kc\')>-1||1e.L(\'.zj\')>-1){if(3H[i].L(\'-->\')>-1&&3H[i].L(\':\')>-1){t1=h5(3H[i].1w(0,3H[i].L(\'-->\')))*1+eh;t1==0?t1=1:\'\';t2=h5(3H[i].1w(3H[i].L(\'-->\')+4,12))*1+eh;I(2J[l][0][t1])?\'\':2J[l][0][t1]=\'\';U(B j=t1;j<t2;j++){2J[l][1][j]=t1}nk++}F{3H[i]=4j(3H[i]);if(3H[i]!=\'\'&&3H[i].Q>0&&3H[i]!=nk&&3H[i]!=\'S3\'){2J[l][0][t1]=(2J[l][0][t1]&&2J[l][0][t1]!=\'\'?2J[l][0][t1]+\'<br>\':\'\')+(o.2a[l]=="8A"&&y>0?\'[ea]\':\'\')+3H[i]+(o.2a[l]=="8A"&&y>0?\'[/ea]\':\'\')}}}if(1e.L(\'.za\')>-1||1e.L(\'.kf\')>-1){if(3H[i].L(\'S2:\')>-1){t1=h5(3H[i].1w((1e.L(\'.kf\')>-1?3H[i].L(\'=0\')+3:12),12))*1+eh;t2=h5(3H[i].1w((1e.L(\'.kf\')>-1?3H[i].L(\'=0\')+14:23),10))*1+eh;B p=\'\';if(3H[i].L(\'0,,\')>0){p=3H[i].1w(3H[i].L(\'0,,\')+3)}F{if(3H[i].L(\'zh,\')>0){p=3H[i].1w(3H[i].L(\'zh,\')+6)}}if(2J[l][0][t1]!=1W){2J[l][0][t1]+=\'\\n\'+(o.2a[l]=="8A"&&y>0?\'[ea]\':\'\')+p+(o.2a[l]=="8A"&&y>0?\'[/ea]\':\'\')}F{2J[l][0][t1]=p}2J[l][0][t1]=2J[l][0][t1].1Z(/{.*?}/,\'\');2J[l][0][t1]=2J[l][0][t1].1Z(/\\\\\\\\N/,\'<br>\');2J[l][0][t1]=2J[l][0][t1].1Z(/\\\\N/,\'<br>\');U(B j=t1;j<t2;j++){2J[l][1][j]=t1}}}}o.S.bn();o.V.ir()}3c(e){gc("1E")}}F{gc("1E")}}G.2J=E(){O 2J};E ns(){B 4a=dL(v.nL+\'?1e=\'+4E[8q]);4a.bs=E(){if(G.de==4&&G.6f==4H){if(G.c4){v.1N=G.c4;o.V.9p(\'1N\')}}};4a.a7()}};E h5(kc){B 1H=kc.2t(\':\');B 6l=0;1H.Q==2?1H.RZ("ar"):\'\';1H[0]!=\'ar\'?6l+=1H[0]*mE:\'\';1H[1]!=\'ar\'?6l+=1H[1]*60:\'\';6l+=1H[2].1w(0,2)*1;6l=6l*10+1H[2].1w(3,1)*1;O 6l}B zI=E(1e,1z,2q){B 1c=1M("5O");if(v.S0==1){B cl=1M("d9");4w(cl,{"zO":"no","zP":"H","zN":"H","2X":""});K(cl,{"1i":"29","W":"1h%","X":"1h%","2W":0});1z.1J(cl);B zQ=22.7d(E(){if(cl.eH.1K.de==="S1"){22.4m(zQ);K(cl.oP.bl,{"2S":0,"2K":0});cl.oP.bl.1J(1c)}},1h)}F{1z.1J(1c)}B 1L;B 4y=J;B q4=J;B 9H=J;B 2b;B 7r=J;B ws;B q0=J;B 6w=J;B 9q=J;B 7f=0;B 7W=J;B 1E;B Re;B kO=J;B jA=J;B h3=-1;B aZ=-1;B pA;B lR;B m9;B hI;B Rd;B uT=\'5O/Qr; Qs="Qq.Qp, Qm.40.2"\';K(1c,{\'W\':\'1h%\',\'X\':\'1h%\',\'3r-aN\':\'sO\',\'4u\':"D9 0.2s 2O",\'7S-X\':\'2A\',\'5C-X\':\'1I\',\'7S-W\':\'2A\',\'5C-W\':\'1I\'});if(v.zz==1||v.4A==1){if(v.Qn==1||v.4A==1){K(1c,{\'3r-aN\':\'4A\'})}F{K(1c,{\'3r-aN\':\'sJ\'})}}if(v.oL==1&&o.1m.2y){4w(1c,{\'Dl\':\'1\'})}v.Qo==1?1c.Qt=\'Qu\':\'\';4w(1c,{\'2X\':1e,\'x-41-4T\':\'zJ\'});if(v.QA==1){4w(1c,{\'2q\':\'J\'})}if(v.QB==1){4w(1c,{\'Qz\':\'Qy\'})}if(!o.1m.tv){4w(1c,{\'43\':(v.43==1&&v.3W==0?\'aL\':\'1I\')})}om();if(2q){1c.3W=H;1c.3Q=H}if(!I(1e)){1e=\'\'}if(1e.L(".zA")>0&&o.bO.L("8r")!=-1){6w=H;B mx=J;B mo=J;if(p5()){v.43==1||v.3W==1||v.mw==1?jD(J):\'\'}F{6w=J;1r("8r cw uI")}}F if(((3k.1L==1&&v.ml!=1)||1e.L(".zF")>0)&&(o.bO.L("6M")!=-1||I(22.5l))){4y=H;3v{if(I(5l)){if(!5l.z7()||(o.1m.6i&&v.Qv==1&&!o.1m.5x)||(o.1m.6i&&o.1m.5x&&v.Qw==1)||(o.1m.jI&&v.Qx==1)){1r(\'6M Ql \',5l.z7());4y=J}F{if(v.43==1||v.3W==1||v.z6==1||2q){cF(J)}}}F{4y=J}}3c(1E){4y=J}}F if(1e.L("ws://")==0&&v.Qk==1){7W=H;q9()}if(o.1m.tv&&v.3W==1&&!4y&&!6w&&!7W){1G(E(){o.V.ai()},1h)}if(v.6I==1){I(o.6I)?o.6I.dX():\'\';o.6I=1y Q8()}E jD(x){1r("8r");v.mw=1;B k0={dw:60};if(o.3M.Q>1){v.9r=0;v.yz=H}F{v.yz?v.9r=1:\'\'}if(o.8x.Q>1){v.dM=0;v.yx=H}F{v.yx?v.dM=1:\'\'}if(I(v.bT)){if(I(v.bT.dw)){if(v.bT.dw>b9){v.bT.dw=b9}}if(2i v.bT=="3r"){U(B 1a in v.bT){k0[1a]=v.bT[1a]}}}2b=9o.b7().ce();js("2b",2b,1);v.yB==1&&!2q?2b.ah({\'pC\':{\'Q9\':9o.Qa.Q7}}):\'\';2b.Q6(1c,1e,(v.3W==1||2q||x));if(I(v.mD)){if(2i(v.mD)=="3r"){2b.Q3(v.mD)}}2b.ah({\'ak\':{\'Q4\':k0.dw}});2b.ah({\'ak\':{\'Sp\':k0.dw}});2b.ah({\'ak\':{\'Qb.ol\':J}});2b.ah({\'ak\':{\'Qc.ol\':J}});if(v.yF==1){2b.Qi(1W,H)}if(v.mp==1){2b.ah({\'ak\':{\'jP\':{\'jO\':{\'9s\':J,\'5O\':J}}}})}2b.on(9o.b7.2H.Qj,E(1C){if(!mx){1r("8r zR");B q=tH();tJ();o.iZ=J;if(v.Qh==1){m9=1y Qg(2b,2q)}9q=2b.Qd();9q?1r("ue"):\'\';if(v.9r==1){if(v.mp==1||q>0){o.2R=q;2b.ah({\'ak\':{\'jP\':{\'jO\':{\'9s\':J,\'5O\':J}}}})}F{o.2R=2b.lL("5O").Q-1}o.S.cf(o.2R);2b.jS("5O",o.2R);2b.jS("9s",o.2R)}o.V.ai();mx=H}});2b.on(9o.b7.2H.Qe,E(1C){if(!mo){B 6D=2w(o.5e);if(6D>0&&v.dM==1){2b.v5(2b.nS("9s")[6D])}mo=H}});2b.on(9o.b7.2H.Qf,E(1C){if(9q){o.V.4s(2b.Y(),2b.1k())}});2b.on(9o.b7.2H.QC,E(1C){2b.QD(-1)});2b.on(9o.b7.2H.R2,E(1C){if(1C.R3=="5O"&&1C.R1!=1C.yo&&v.9r==1){o.2R=1C.yo;o.S.cf(o.2R);1r("8r uh "+o.2R)}});2b.on(9o.b7.2H.R0,E(1C){if(I(1C.mq)){if(1C.mq.1B=="QX"){js("tF",1C.mq.1e)}}});2b.on(9o.b7.2H.uB,E(1C){o.ny=1C;if(1C.1E=="QY"){1E="8r "+1C.1E+": "+1C.17.8Y+", "+1C.17.17;1r(1E);o.P.4Z()}F if(1C.1E=="QZ"||1C.1E=="R4"){1E="8r "+1C.1E+" 1E: "+1C.17;1r(1E);o.P.4Z()}F if(1C.1E=="R5"||1C.1E=="Rb"){1E="8r "+1C.1E+" 1E: "+1C.17;1r(1E);o.P.4Z()}F if(1C.1E=="6g"){1E="8r em oy 1E Rc";1r(1E);o.P.4Z()}});7r=H}E cF(x){1r("6M");if(o.3M.Q>1){v.7H=0;v.yZ=H}F{v.yZ?v.7H=1:\'\'}if(o.8x.Q>1){v.a6=0;v.z2=H}F{v.z2?v.a6=1:\'\'}o.j1=J;B pp=J;if(v.7g&&v.z5==1){pp=H;v.z5=0}B lc={pC:(v.z4==1&&!2q),Ra:(v.43==1||v.3W==1||2q||x)&&!pp,ec:60,pn:60,R9:yU,R6:yU,R7:J};if(v.wy==1){lc[\'R8\']=E(4a,1e){4a.QW=H}}if(I(v.6F)){if(I(v.6F.ec)){if(v.6F.ec>b9){v.6F.ec=b9}v.6F.pn=v.6F.ec}if(I(v.6F.yN)){v.6F.pn=v.6F.ec=v.6F.yN}if(2i v.6F=="3r"){U(B 1a in v.6F){lc[1a]=v.6F[1a]}}}1L=1y 5l(lc);js("1L",1L,1);1L.uo(1e);1L.QV(1c);1L.on(5l.7m.QJ,E(){1r("6M zR")});1L.on(5l.7m.QK,E(17,1C){!2q?o.V.ai():\'\'});1L.on(5l.7m.QL,E(17,1C){if(!2q&&v.7H==1&&8R()>1){tC();o.S?o.S.cf(o.2R):\'\'}});1L.on(5l.7m.QI,E(17,1C){pE()});1L.on(5l.7m.QH,E(17,1C){pE()});1L.on(5l.7m.QE,E(17,1C){if(!2q){if(1C.gG.6W!=9q){9q=1C.gG.6W;o.S.4M()}9q=1C.gG.6W;if(9q){1r("ue");o.uc=1e.L("?r7")>-1;if(1c.1k>0&&1c.cX>0){if(1c.1k-1c.cX<10){if(o.gH>0){if(o.gH==1c.cX&&o.tA==1c.1k){o.lG++;if(o.lG>2){o.lG=0;o.gH=-1;1L.8M();cF(H);8e()}}F{o.gH=-1}}F{o.gH=1c.cX;o.tA=1c.1k}}}}}if(v.7H==1){o.2R=1L.lZ;o.S?o.S.cf(o.2R):\'\'}m7()});1L.on(5l.7m.QF,E(17,1C){if(I(1C.uG)&&!2q){js("tF",1C.uG.QG)}q4=H;uu()});1L.on(5l.7m.QM,E(17,1C){js("QN",1C,1)});1L.on(5l.7m.QT,E(17,1C){!2q&&v.a6==1?p9():\'\'});1L.on(5l.7m.QU,E(17,1C){if(!2q&&v.a6==1){pg()}});if(v.QS==1){lR=1y QR(1L,2q)}F{1L.QO=J}1L.on(5l.7m.uB,E(17,1C){v.1r==1?eq.1r(1C):\'\';o.pD=1C;if(1C.em){9N(1C.1B){1j 5l.un.QP:if(v.uA==1){1r("QQ");B 5M=o.1O;!2q&&5M?o.V.2Q():\'\';o.V.7w();7f=1;pz(5M)}F{1E=1C.gG;o.2z>0||2q||v.6W==1||7W?\'\':o.2z=4t();1L.8M();if(!2q){o.P.4Z()}}1g;1j 5l.un.So:um();1g;6S:1E="6M em 1E, 8M";1L.8M();!2q?o.P.4Z():\'\';1g}}F{1r("6M ",1C.1B,1C.gG,(1C.mf?1C.mf.jt:\'\'));js("SV",(1C.mf?1C.mf.jt:\'\'));if(7f>0){7f=2;pz()}}});9H=H}E pE(){if(!2q&&v.7H==1&&8R()>1){if(o.2R!=1L.lZ){o.2R=1L.lZ;o.S?o.S.cf(o.2R):\'\';1r("6M uh "+o.2R)}}}E q9(){if(I(22.uj)){if(p5()){if(!I(o.ws)){o.ws=1y Ty()}ws=1y uj(1c,1e,{pC:H});q0=H}F{7W=J;1r("cw uI")}}}E uu(){pB()};G.5S=E(){pB()};E pB(){if(v.AY){if(1c.d5.Q>0){if(v.5S==1){1c.d5[1c.d5.Q-1].eT="vs"}F{1c.d5[1c.d5.Q-1].eT="3G"}if(!o.5S){o.5S=H;o.S.4M()}}F{if(o.5S){o.5S=J;o.S.4M()}}}}E pz(x){if(7f>0){3j(pA);pA=1G(uq,v.ux*2G)}}E uq(){if(7f>0){1r("Tu")}if(7f==1){1L.uo(1e)}if(7f==2){1L.8M();cF(H);1c.1O()}}B k3=0;B jM=0;E um(){B 8N=pj.8N();if(!k3||(8N-k3)>dg){k3=pj.8N();1r("6M em P 1E, 3v to ek");1L.uN();1L.pZ();if(o.1O){hF()}}F{if(!jM||(8N-jM)>dg){jM=pj.8N();1r("6M em P 1E, 3v to ek");1L.Tm();1L.uN()}F{1r("6M em P 1E, pi Ti")}}}1c.1p(\'Tj\',uR);1c.1p(\'1E\',nZ);1c.1p(\'9I\',8e);1c.1p(\'1O\',8O);1c.1p(\'59\',aR);1c.1p(\'E4\',bj);1c.1p(\'ff\',fc);1c.1p(\'mi\',fj);1c.1p(\'CN\',b6);1c.1p(\'CU\',cg);1c.1p(\'9w\',7z);1c.1p(\'Dr\',9i);1c.1p(\'Ts\',uJ);1c.1p(\'CR\',op);1c.1p(\'Cz\',oq);E uR(){if(!4y&&!6w){!2q?o.V.ai():\'\'}}E nZ(){if(!4y&&!6w){if(1c.1E){1r(1c.1E,1c.1E.jt,1c.1E.8Y);B x=1c.1E.jt;1E=1W;if(x==1){1E="Tv"}if(x==2){1E="oy"}if(x==3){1E="bM"}if(x==4){1E="cw gP"}1r("Tw fy: ",1E)}if(1E!=1W){4Z()}}}E 4Z(){!2q?o.P.4Z():\'\'}E 8e(){!2q?o.P.8e():\'\'}E 8O(){if(!o.1A&&v.7g){1r(\'DV 1O\');59();o.V.2B();O}if(4y&&7f>0){}F{if(!2q){if(aZ==-1){B x=J;if(4y){if(I(o.2f)||I(o.5V)){59();x=H}}if(!x){jA=H;o.P.8O()}}}}}E aR(){!2q&&!o.Dx?o.P.aR():\'\'}E bj(){!2q?o.P.bj():\'\';if(aZ>-1){if(4t()>aZ){59();aZ=-1}}}E fc(){!2q?o.P.fc():\'\'}E fj(){!2q?o.P.fj():\'\'}E b6(){if(2q){ob()}F{o.P.b6();o7();if(4y&&7f>0){7f=0;1r("Tf up");1L.pZ();hF();o.S.2B()}if(I(v.fu)){2n()}}}G.fu=E(){O(1c.fp/1c.c0)};E ob(){if(1c.c0>0){K(1z,{"X":1z.1Y/(1c.fp/1c.c0)-2w(v.2q.2W)})}}E o7(){if(v.kV==1){4m(o.p6);o.p6=7d(p8,1h);p8()}}E p8(){if(1c.c0>0){o.V.uK(1c.fp/1c.c0);4m(o.p6)}}E 9i(){!2q&&!7W?o.P.9i():\'\'}E cg(){!2q?o.P.cg():\'\'}E 7z(){if(4y&&7f>0){}F{!2q?o.P.7z():\'\'}}E uJ(){o.V.os()}E p5(){B jH=22.ug=22.ug||22.Tr;B gJ=22.uH=22.uH||22.Tp;B jE=jH&&2i jH.jE===\'E\'&&jH.jE(uT);B tE=!gJ||gJ.p2&&2i gJ.p2.Tn===\'E\'&&2i gJ.p2.7t===\'E\';O jE&&tE}E tH(){B q=0;if(!2q&&v.9r==1){o.26=[];B x=2b.lL("5O");if(x.Q>1){B y=\'\';U(B i=0;i<x.Q;i++){o.26[i]=I(x[i].X)?nM(x[i],v.tL):i;if(o.26[i]==y||v.tD==1){y=o.26[i];if(I(x[i].ac)){o.26[i]+=" "+gW+" &ef;"+2w(x[i].ac/2G)+\' \'+2M(\'ad\')+\'</6V>\';v.tD!=1?o.26[i-1]+=" "+gW+" &ef;"+2w(x[i-1].ac/2G)+\' \'+2M(\'ad\')+\'</6V>\':\'\';y=\'\'}}F{y=o.26[i]}if(I(v.3Y)&&q==0){if(v.3Y==o.26[i]){q=i}}if(I(o.3Y)){if(o.3Y==o.26[i]){q=i}}}o.26[x.Q]=2M("2A")}o.p3=H}O q}E tJ(){if(!2q&&v.dM==1){o.5e=0;B x=2b.nS("9s");if(x.Q>1){U(B i=0;i<x.Q;i++){o.5I[i]=i;if(I(x[i].dU)){o.5I[i]=ph(x[i].dU)}F{if(I(x[i].ty)){o.5I[i]=2M("6e")+" "+x[i].ty}}if(I(o.8z)){if(o.8z==o.5I[i]){o.5e=i}}}}1r("8r tW ",o.5e);o.S.hW(o.5e)}}B gW="<6V C=\'1o:0.5\'>";E tC(){if(!2q&&v.7H==1){B x=1L.dE;B q=0;o.26=[];if(x.Q>1){U(B i=0;i<x.Q;i++){if(I(x[i].X)){B y=nM(x[i],v.tB);if(o.26.L(y)>-1||v.Tq==1){if(I(x[i].ac)){B yi=o.26.L(y);yi>-1?o.26[yi]+=" "+gW+" &ef;"+2w(x[yi].ac/2G)+\' \'+2M(\'ad\')+\'</6V>\':\'\';o.26[i]=y+" "+gW+" &ef;"+2w(x[i].ac/2G)+\' \'+2M(\'ad\')+\'</6V>\'}}F{o.26[i]=y}if(I(x[i].tz)){o.7J[i]=x[i].tz[0]}}F if(I(x[i].6X)){o.26[i]=x[i].6X}F{o.26[i]=i}if(I(v.3Y)&&q==0){if(v.3Y==o.26[i]){q=i}}if(I(o.3Y)){if(o.3Y==o.26[i]){q=i}}}if(v.gY==1){o.26[x.Q]=2M("2A")}F{1L.va=0;1L.f3=0}if(v.uf==1||q>0){1L.f3=0;if(v.fb=="8v"||(!o.1A&&v.43==0)){1L.nP=q}F{if(v.fb=="e2"){1L.nT=q}}}F{v.gY==1?o.2R=1L.dE.Q-1:o.2R=1L.Sq}m7()}o.p3=H;o.S?o.S.4M():\'\'}}E m7(){if(o.7J.Q>0&&v.a6==1){p9();pg()}}E p9(){if(!2q&&v.a6==1){B x=1L.oo;o.5I=[];B 2o;if(x.Q>1){U(B i=0;i<x.Q;i++){2o=J;if(I(x[i].dV)&&o.7J.Q>0){if(x[i].dV!=o.7J[o.2R]){U(B j=0;j<o.7J.Q;j++){if(o.7J[j]==x[i].dV){2o=H}}}}if(!2o){o.5I[i]=I(x[i].6X)?ph(x[i].6X):i;if(I(v.8z)){if(v.8z==o.5I[i]){o.5e=i;1L.lJ=i}}}}}}}E pg(){if(!2q){B x=1L.oo;B y=1L.lJ;if(x[y].dV){if(o.7J.Q>0){if(o.7J[o.2R]!=x[y].dV){U(B i=0;i<x.Q;i++){if(x[i].6X==x[y].6X&&x[i].dV==o.7J[o.2R]){1L.lJ=i;y=i;1g}}}}}o.5e=y;1r("6M tW ",o.5e);o.S.hW(o.5e)}};E ph(x){B r=x.la();if(r=="Sr"||r=="en"){x="Sv"}F if(r=="Sw"||r=="ru"){x="Русский"}O x};E nM(x,y){B r=x.X+\'p\';if(x.X<4H){r=\'lo\'}F if(x.X>=4H&&x.X<=cA){r=\'fD\'}F if(x.X>cA&&x.X<=ca){r=\'eX\'}F if(x.X>ca&&x.X<=4v){r=\'f4\'}F if(x.X>4v&&x.X<=b9){r=\'pc\'}F if(x.X>b9&&x.X<=tT){r=\'hT\'}F if(x.X>tT&&x.X<=wx){r=\'hV\'}F if(x.X>wx&&x.X<=vY){r=\'q6\'}F if(x.X>vY){r=\'q5\'}if(x.W==SA&&x.X<=Sz){r=\'fD\'}F if(x.W==uU&&x.X<=w4){r=\'eX\'}F if(x.W==Tb&&x.X<=Ta){r=\'f4\'}F if(x.W==T9&&x.X<=T2){r=\'hT\'}F if(x.W==T1&&x.X<=SW){r=\'hV\'}F if(x.W==SY&&x.X<=SX){r=\'q6\'}F if(x.W==SZ&&x.X<=T0){r=\'q5\'}if(v.1d.SR==1&&I(v.1d[\'6X\'+r])){r=v.1d[\'6X\'+r]}F{if(y==1){r=2M(r)}if(y==2&&I(x.ac)){r=2w(x.ac/2G)+\' \'+2M(\'ad\')}}O r};E 4t(){if(6w){O 7r?2b.Y():0}F{O 1c.cX}};G.2B=E(){B p=H;if(4y&&!q4){if(!9H){cF(H)}!jA?o.P.8O():\'\';1L.pZ()}if(6w&&!7r){jD(H);p=J}if(7W){if(!q0){q9()}ws.1O();p=J}if(1c.C.1f=="-SQ"){G.e5()}p?hF():\'\'};B SS;E hF(){if(1e!="1I"){B qf=1c.1O();if(qf!==1W){qf.c6(E(){}).3c(E(1E){1r("ST",1E.8Y);if(1E.8Y.L(\'bJ\')==-1&&1E.8Y.L(\'SU by\')==-1){if(!o.1m.rb||1E.8Y.L(\'g0 qg Tc\')==-1){if(v.w8==1&&!o.3Q){o.V.4Y();1c.1O()}F{o.S.2Q();o.V.7w()}}F{if(o.1m.tv&&(4y||6w)){}F{o.S.2Q();o.V.7w();js("T8")}}}})}}}G.io=E(){if(o.5V||o.2f){if(o.8E){cn()}if(!o.eg&&o.1m.2y&&o.1m.41){if(!1c.3Q){1c.3Q=H;kO=H}K(1c,{"1i":"29","1b":-47,"1f":-47});aZ=4t();if(!7W){1c.1O()}if(aZ==0&&o.2z>0){hI=o.2z}}}};G.e5=E(){if(!o.eg&&(o.1m.2y||o.1m.41)){K(1c,{"1i":"qB","1b":0,"1f":0});if(I(v.fu)){2n()}if(kO){!o.3Q?1c.3Q=J:\'\';kO=J}if(hI>0){o.2z=hI;hI=0}aZ=-1}};G.2Q=E(){59()};E 59(){if(7W){ws.59()}F{1c.59()}};G.bK=E(){!1c.8C?2Q():hF()};G.3R=E(x){if(6w&&7r){2b.4g(x)}F{1c.cX=x}};G.4Y=E(){1c.3Q=H};G.6P=E(){1c.3Q=J};G.3T=E(x){1c.1P=x};G.wk=E(){if(o.wg!=1c){B bJ;B 8W;if(o.kJ[1c]){bJ=o.kJ[1c];8W=o.pI[1c]}F{22.pL=22.pL||22.T7;8W=1y pL();bJ=8W.T3(1c);o.kJ[1c]=bJ;o.pI[1c]=8W}B hx=8W.T4();hx.hx.52=v.w9;bJ.wi(hx);hx.wi(8W.T5);o.pU=H;o.wg=1c}};G.i0=E(){O!1c.8C};G.5H=E(){O v.6W==1||7W?H:9q};G.5P=E(){O 1c};G.ot=E(){4w(1c,{\'S\':\'1\'});O H};G.43=E(){4w(1c,{\'43\':\'aL\'});if(4y&&!9H){cF(J)}if(6w&&!7r){jD(J)}};G.6f=E(){B 6p="5M";if(1c.8C){6p="8C"}if(1c.9I){6p="9I"}O 6p};G.pS=E(x,y){2q=x;y.1J(1c);1z=y;if(x){1c.3Q=H;ob();if(o.26.Q>0){if(4y){h3=o.2R;1L.f3=0;1L.nT=0}}}F{if(!o.3Q){1c.3Q=J}1c.1P=v.1P;o7();if(o.26.Q>0){if(4y){1L.f3=-1;if(h3>-1){h3<1L.dE.Q?1L.nP=h3:\'\'}}}}};G.Y=E(){O 4t()};G.1k=E(){B x=1c.1k;if(6w&&7r){x=2b.1k()}if(I(v.4q)){x=v.4q}O x!=T6&&!o8(x)?x:0};G.aF=E(){B x=0;if(1c.8h){if(1c.8h.Q>0){B y=4t();U(B i=0;i<1c.8h.Q;i++){if((y>=1c.8h.1A(i)||y>=1c.8h.1A(i)-1h)&&y<=1c.8h.4q(i)){x=1c.8h.4q(i)}}x==0?x=1c.8h.4q(1c.8h.Q-1):\'\'}}if(I(v.4q)){x>v.4q?x=v.4q:\'\'}O x};G.2A=E(){B x=J;if(4y){if(9H){x=1L.va}}F if(6w){if(7r){B y=2b.SP();x=y.ak.jP.jO.5O}}O x};G.3t=E(){O{"W":1c.fp,"X":1c.c0}};G.2X=E(x){1e=x;jA=J;o.9F!=2?o.9F=J:\'\';if(4y){4y&&1L?1L.8M():\'\';cF(H);oj()}F{4w(1c,{\'2X\':x,\'3W\':0});om();59()}};E om(){if(o.1m.6i){B y=1c.d5;if(y){U(B i=0;i<y.Q;i++){y[i].eT="SO"}}y=1c.oo;if(y){U(i=0;i<y.Q;i++){y[i].ol=(i==0?1:0)}}if(22.Sx){1c.1p(\'Sy\',E(17){o.4T=17.Ss=="St";!2q?o.V.gI():\'\'})}}oj()}G.4T=E(){1c.Su()};G.7G=E(){cn()};E oj(){if(o.1m.41){if(I(1c.Te)&&!o.1m.8V){o.7G=H}if(1K.SB&&!1c.SC){o.7G=H}}}E cn(){if(o.1m.6i){if(1c.SK==="k8-in-k8"){1c.vf("dj");o.8E=J}F{1c.vf("k8-in-k8");o.8E=H}}F{if(!1K.SL){2j(\'1c.SM().c6(p => {o.8E = H;}).3c(1E => {o.8E = J;});\')}F{2j(\'1K.SN().c6(ok =>{o.8E = J;}).3c(1E => {});\')}}};E op(){o.8E=H};E oq(){o.8E=J};G.v6=E(x){if(7r){B x=2w(x);if(x==2b.lL("5O").Q){o.2R=2b.SJ(\'5O\')}F{2b.ah({\'ak\':{\'jP\':{\'jO\':{\'9s\':J,\'5O\':J}}}});2b.jS(\'5O\',x);2b.jS(\'9s\',x)}}};G.SI=E(x){if(o.ws){o.ws.uZ(ws,x,-1)}};G.SE=E(x){if(o.ws){o.ws.uZ(ws,-1,x)}};G.v0=E(x){if(7r){if(1c.8h.Q>0){2b.v5(2b.nS(\'9s\')[2w(x)])}}};G.v3=E(x){if(9H){B y=2w(x);if(x==1L.dE.Q){y=-1;1L.f3=-1}if(v.fb=="e2"){1G(7z,4v);1L.nT=y}if(v.fb=="8v"){1r("6M 8v SD "+y);1L.nP=y}if(y==-1){o.2R=1L.lZ}m7()}};G.m6=E(){O 1L};G.lT=E(){O 2b};G.8R=E(){O 8R()};E 8R(){B x=0;if(9H){if(1L.dE){x=1L.dE.Q}}O x}G.aH=E(){O aH()};G.4J=E(){2n()};E 2n(){B x=1c.fp/1c.c0;if(x){x=(x).vE(2);B z=2j(v.fu).vE(2);if(z!=x){if(o.3f>o.4h){K(1c,{\'3r-aN\':\'4A\',\'X\':\'1h%\',\'W\':o.4h*z})}F{K(1c,{\'3r-aN\':\'4A\',\'W\':\'1h%\',"X":(o.3f/z),"1i":"29","1f":"50%","1b":"50%","2E":"sV(-50%, -50%)"})}}}}E aH(){B x=0;if(7r){x=2b.lL("5O").Q}O x}G.vw=E(x){if(9H){1L.lJ=2w(x)}};G.vo=E(x){if(9H&&lR){lR.SF(x)}};G.vm=E(x){if(7r&&m9){m9.SG(x)}};G.fT=E(x){if(x){1c.SH=x}};G.o3=E(){B x=1c.Td;B y=[];U(B i=0;i<x.Q;i++){if(x[i].lX.la()==\'6D\'){x[i].5X("ej",o1);y.2P(x[i])}}U(B i=0;i<y.Q;i++){1c.2U(y[i])}};G.vq=E(x,y,z){if(x!=\'\'){if(x.L(\' or \')>0){B xx=x.2t(\' or \');x=xx[0]}B 6D=1K.1M(\'6D\');6D.5R(\'2X\',x);6D.5R(\'o0\',y);6D.5R(\'Tt\',\'vu\');6D.5R(\'eT\',\'vs\');if(z){6D.5R(\'6S\',\'\')}1c.1J(6D);6D.1p("ej",o1)}};E o1(e){if(e.4d.o0){U(B i=0;i<o.3e.Q;i++){if(o.3e[i]==e.4d.o0){o.V.9z(i)}}}};G.oA=E(){O 1E};G.4C=E(){4y&&1L?1L.8M():\'\';6w&&2b?2b.Tk():\'\';7W&&ws?ws.2o():\'\';1c.5X(\'1E\',nZ);1c.5X(\'9I\',8e);1c.5X(\'1O\',8O);1c.5X(\'59\',aR);1c.5X(\'E4\',bj);1c.5X(\'ff\',fc);1c.5X(\'mi\',fj);1c.5X(\'CN\',b6);1c.5X(\'CU\',cg);1c.5X(\'9w\',7z);1c.5X(\'Dr\',9i);1c.5X(\'CR\',op);1c.5X(\'Cz\',oq);1c.2X=\'\';if(1z.lX=="vU"){1z.oP.bl.2U(1c)}F{1z.2U(1c)}1c=1S}};B CB=E(1e,f7){B 6x=J;if(1e.L(\'6x\')==0){6x=H;1e=1e.1w(5)}B lv=lE(1e);B 1E;B 3d;B fI=J;B 3E=J;B kY=J;B i9=J;B 2A=H;B oF=[];B bd=1;B eU=J;B ou;B bP=0;B i4=0;B ic=J;B l8=\'yw\'+v.id+(6x?\'6x\':\'\');B 1z=1M(\'1R\');1z.5R(\'id\',l8);f7.1J(1z);o.4T=J;!6x?o.V.gI():\'\';if(o.1m.2y){v.43=1}if(v.D6!=1){B 7s=1M(\'1R\');f7.1J(7s);K(7s,{1i:"29",1f:0,1b:0,"2x-1v":"#i1",X:"1h%",W:"1h%","1o":0});7s.1p("ye",E(17){17.5F=H});if(o.1m.2y){7s.1p("e8",E(17){17.5F=H});7s.1p("2u",E(17){17.5F=H});7s.1p("eu",E(17){17.5F=H;eA(17);if(v.cJ==1){1G(Dg,1h);1G(l4,2G)}})}F{7s.1p("r3",E(17){B x=H;if(v.2f==1){if(I(v.7g)&&!kY){x=J}if(I(v.mg)&&9e()=="8C"&&Y()>0){x=J}}if(x&&v.cJ==1&&v.Dh==1&&v.Df!=1){3g(G);1G(l4,47)}})}v.cJ==1?3g(7s):\'\'}E l4(){6s(7s)}E Dg(){if(v.Df!=1){3g(7s)}}if(v.43==1&&v.3W==0){7z()}if(!22[\'7c\']){22.Tl=E(){ip();U(B i=0;i<6E.Q;i++){if(6E[i].2Z("id")!=v.id){if(6E[i].2Z(\'Dd\')){6E[i].2Z(\'Dn\')}}}};if(!D3("44.a8/D1")){B 5P=1K.1M(\'lV\');5P.2X="e0://3C.44.a8/D1";5P.6X="Tx";B oO=1K.ay(\'lV\')[0];oO.4Q.k6(5P,oO);5P.oN=E(e){o.V.ai();if(v.DD!=1){1E=\'Th To fy\';o.P.4Z()}}}}F{ip()}E ip(){if(v.43==1||6x){!fI?8b():\'\'}F{o.V.ai()}}E 8b(){if("7c"in 22){if(I(7c.kE)&&!fI){1r("CE 8b");B oM=0;if(v.D6==1){oM=1}o.2z>0?bP=2w(o.2z):\'\';3d=1y 7c.kE(l8,{X:o.9b,W:o.bc,Tg:lv,Q5:{Q1:1,ML:l8,MM:1,MN:1,e9:1,Dl:((v.oL==0||(v.MK!=1&&o.1m.8V))&&o.1m.2y?0:1),MJ:3,S:oM,MG:0,MH:1,CX:0,3W:0,a3:0},2H:{\'MI\':oU,\'MO\':Cy,\'4Z\':4Z,\'MP\':Dv}});if(o.2z>0){o.2z=1W}2n();fI=H}F{1G(8b,4v)}}F{1G(8b,4v)}}B fP;E oU(){1r("CE f5");3E=H;3j(ou);o.V.6K();if(6x){if(o.1m.oT){o.V.4Y()}3d.hY();o.2f.MV()}F{if(v.3W==1&&o.1m.oT&&!o.kr){o.V.4Y();if(o.1m.2y){4m(fP);fP=7d(Cu,cA)}}if(v.43==0){3d.hY()}F{o.V.ai()}o.P.9i();if(bd!=1){9P(bd)}b6();2n()}}E Cu(){B x=3d.Cs();if(x==2||x==-1){o.S.2Q();o.S.6K();4m(fP)}if(x==1){4m(fP)}}E Cy(17){if(6x){if(17.1C==7c.cv.CM){o.2f.MW()}if(17.1C==7c.cv.CH){}}F{if(17.1C==7c.cv.CH){if(i4==1){i4=0;oU()}o.V.2B();if(bP>0){3d.B9(bP,H);bP=0;o.2z=1W}l4();kY=H;3E=H;if(i9){3d.oB()}F{o.P.8O();o.P.bj()}Dw();if(I(v.3Y)){U(B i=0;i<o.26.Q;i++){if(v.3Y==o.26[i]){5n(i)}}v.3Y=1S}F{if(I(o.3Y)){U(B i=0;i<o.26.Q;i++){if(o.3Y==o.26[i]){5n(i)}}o.3Y=1S}}eU=J}if(17.1C==-1&&eU&&o.1O){o.V.6K();eU=J;aR()}if(17.1C==7c.cv.MU){aR()}if(17.1C==7c.cv.CM){8e()}if(17.1C==7c.cv.MT){if(!o.1O){o.V.2B()}eU=H;7z()}if(17.1C==7c.cv.MQ){}}}E 4Z(17){if(6x){o.2f.MR()}F{if(17.1C==2){1E="DV 44 id"}if(17.1C==5){1E="oy 5w"}if(17.1C==E6||17.1C==s9||17.1C==1h){1E="G 5O is MS"}if(v.MF==1){I(v.DB)?1E=v.DB:\'\'}if(v.DD!=1){o.P.4Z()}F{1l(o.2g)}}}E 8e(){v.1A>0?bP=v.1A:\'\';o.P.8e();o.P.9i()}E aR(){if(!o.Dx){o.V.2Q()}}E bj(){o.P.bj()}E b6(){o.P.b6();o.V.os()}E 9i(){o.P.9i()}E cg(){o.P.cg()}E 7z(){if(o.P){o.P.7z()}F{ou=1G(7z,1h)}}E Dv(17){oH(17.1C)}E Dw(){if(!ic){B x=3d.ME()+\'\';if(x!=\'\'&&x!=1W){o.26=x.2t(\',\');if(v.oz==0){B y=o.26.L(\'2A\');if(y>-1){o.26.oG(y,1)}}U(B i=0;i<o.26.Q;i++){o.26[i]=oC(o.26[i])}ic=H;oH(3d.Ms())}}}E oH(x){o.2R=o.26.L(oC(x+\'\'));o.S.py(o.2R)}G.3t=E(){O{"W":0,"X":0}};G.2X=E(x){lv=lE(x);if(o.2z>0){bP=2w(o.2z)}h6(lv)};E 9e(){B 6p=-1;if(3E){6p=3d.Cs()}B x=\'\';if(6p==-1){x="8C"}if(6p==1||6p==3){x="5M"}if(6p==2){x="8C";if(o.1O){o.S.2Q();o.V.6K()}}if(6p==5){x="8C"}if(6p==0){x="9I"}O x}E 2n(){3d?3d.Mt(o.3f,o.4h):\'\'}E oC(x){B y=x;if(x=="Mu"){y="lo"}if(x=="Mr"){y="fD"}if(x=="Mq"){y="eX"}if(x=="Mn"){y="f4"}if(x=="Mo"){y="hT"}if(x=="Mp"){y="hV"}if(v.AC==1){y=2M(y)}if(x=="2A"){y=2M("2A")}oF[y]=x;O y}E Y(){O 3E?3d.Mv():0};E 9P(x){3d?3d.Mw(x):\'\';bd=x};G.i8=E(){ip()};G.2B=E(){if(3E){3d.hY()}F{if(!fI){8b()}F{}}};G.2Q=E(){if(3E){3d.oB()}};G.bK=E(){if(3E){9e()==\'5M\'?3d.oB():3d.hY()}};G.3R=E(x){3E?3d.B9(x,H):\'\'};G.5P=E(){O J};G.4Y=E(){3E?3d.4V():\'\'};G.6P=E(){3E?3d.MC():\'\'};G.3T=E(x){3E?3d.B8(x*1h):\'\'};G.i0=E(){O 9e()==\'5M\'};G.5H=E(){O J};G.AT=E(x){5n(x)};E 5n(x){if(3E){if(I(o.26[x])){B y=oF[o.26[x]];2A=y==\'2A\';B z=Y();3d.MD(y)}}}G.fT=E(x){9P(x)};G.3E=E(){O 3E};G.6f=E(){O 9e()};G.Y=E(){O Y()};G.1k=E(){B x=3E?3d.Aw():0;if(I(v.4q)){x=v.4q}O x};G.aF=E(){B x=0;if(3E){x=3d.MB()*3d.Aw()}O x};G.4J=E(){2n()};G.oA=E(){O 1E};G.2A=E(){O v.oz==1?2A:J};G.A5=E(x){h6(x)};E h6(x){1e=x;if(3d){i4=1;3d.MA(x,0)}}G.io=E(){if(o.1m.2y&&o.1m.9f){G.2B();i9=H}F{if(9e()=="5M"){G.2Q()}}};G.e5=E(){i9=J};G.ot=E(){O H};G.4C=E(){3E?3d.8M():\'\';3E=J;ic=J;3v{if(1z){f7.2U(1z)}f7.2U(7s)}3c(e){}}};B sR=E(){B b=[];B dF=[];B 4F=[];B 9w=J;B iX;B 8u=J;B 1d;B 19;if(o.5c){o.5c.1l();o.5c=1S}B ji;o.5W=[0.25,0.5,0.75,1,1.25,1.5,2];if(v.1d.Mx==1&&I(v.1d.fg)){v.1d.fg=v.1d.fg.1Z(/\\n/ig,\'\');o.5W=v.1d.fg.2t(",")}o.fH=o.5W.L(\'1\')>-1?o.5W.L(\'1\'):o.5W.L(1);o.9T==3?o.9T=o.fH:\'\';!I(v.1d.1x)?v.1d.1x=5:\'\';o.A9=[\'+ \'+v.1d.1x+\'%\',\'&My; \'+v.1d.1x+\'%\',\'1h%\'];B iR=J;B 7Q=0;B iH=0;B eE=J;B oa=H;B bg=1y BC();B 1d;B 5T=[];B oZ=J;B oY=J;B fn=0;B a4=[];if(v.eP.1i=="S-2l"){v.eP.1i="S"}U(B y in v){if(v.2h(y)){if(y.L("9B")==0&&v[y]){!I(v[y].oX)?v[y].oX=v[y].5T:v[y].5T=v[y].oX;5T[v[y].5T]=y;if(v.eP.1i!="S"){if(v[y].1i=="S-2l"){a4.2P([y,v[y].5T]);oZ=H}F{if(v[y].1i=="S"||v[y].1i==1W){oZ?oY=H:\'\'}}}fn<v[y].5T?fn=v[y].5T:\'\'}}}if(oY){a4.zS(E(a,b){O a[1]-b[1]});U(B i=0;i<a4.Q;i++){5T[v[a4[i][0]].5T]=1S;v[a4[i][0]].5T=fn+1;fn++;5T[v[a4[i][0]].5T]=a4[i][0]}}if(v.1u.1l==1&&v.1u.cs==1){o.1u=1M("1R");o.1D.1J(o.1u);K(o.1u,{\'1i\':\'29\',\'1b\':0,\'1f\':0,\'W\':\'1h%\',\'X\':\'1h%\',\'4u\':\'1f 0.3s 7C-6l\',\'3S-2H\':\'1I\'})}B 6L=1M("1R");if(v.1u.1l==1&&v.1u.cs==1){o.1u.1J(6L)}F{o.1D.1J(6L)}K(6L,{\'1i\':\'29\',\'1b\':0,\'2F\':0,\'W\':\'1h%\',\'X\':v.1u.h});6L.dH=E(){!o.1m.2y?o.V.zX():\'\'};if(o.qO){3g(bg.c());3g(6L)}U(B i=1;i<5T.Q;i++){if(5T[i]){B y=5T[i];if(y){if(o.1m.2y){if(v[y].Z=="1P"&&v.Mz==1&&o.1m.9f){v[y].gT=0}F{if(v[y].Z=="1P"||(v[y].Z=="2e"&&v.MX)){v[y].on=0}}}if(o.qO){v[y].on=0}if(v[y].on==1){B Z=v[y].Z;if(Z=="2C"||Z=="1P"){b[y]=1y D7(y,Z);b[y].2n(b[y].s("w"))}F{b[y]=1y A1(y)}dF.2P(y);if(b[y].g("Z")=="1N"){if(b[y].s("1F")==\'\'){if(b[y].s("B")!=\'\'){if(!I(v[b[y].s("B")])){b[y].1U("2m",J)}}F{b[y].1U("2m",J)}}}if(b[y].g("Z")=="4b"){B lu=b[y].s("2T");if(lu){if(lu.L("2Z:")==0&&lu.L(",0/1")>0){B z=lu.2t(",");2Z(z[0].1w(4))==0?b[y].eb(0):\'\'}}}b[y].1U("1x",b[y].s("1x"))}}}}if(I(v.1d)){1d=1y 7O("1d");v.1d.8F==1?1d.1n():1d.1l()}if(I(v.19)){19=1y 7O("19");if(I(o.19)){19.rK(o.19);if(v.19.j9==0||!I(v.19.j9)){v.19.8F==0?19.1l():\'\'}F{19.1n()}}F{19.1l(1)}}if(I(v.Ab)){if(v.Ab.on==1){o.5i=1y MY()}}fV();2n(H);4n();oa=J;E Au(R){B x=0;B Nn=J;if(R){if(R.g("Z")==\'2C\'){x=4F.1b+R.s("3P");if(4F.ex!=1S){}F{4F.ex=[]}}F{if(4F.ex!=1S){B a9=R.g("W")+R.s("4x")+R.s("3P");if(iQ(R)){a9=0}if(R.s("3G")==1&&!R.g("1n")){a9=0}if(R.s("9L")>0){a9=0}x=bg.g("w")-v.1u.iD*1-a9+R.g("W")/2+R.s("3P");B i=0;4F.2l-=a9;U(i=0;i<4F.ex.Q;i++){B ag=b[4F.ex[i]];if(ag.s("9L")>0){K(ag.c(),{"1b":(ag.g("x0")-a9)})}F{K(ag.c(),{"1b":(ag.g("x")-a9)})}ag.1U("x0",ag.g("x"))}4F.ex.2P(R.g("1a"));R.1U(\'dB\',1)}F{if(R.s("3G")==1&&!R.g("1n")){if(R.g("Z")=="1P"){if(R.s("1l")==1&&R.s("gT")==1&&eE){7Q+=R.g("W")+R.s("3P")+R.s("4x");eE=J}}}F{if(R.s("9L")>0){x=4F.1b+R.s("3P")+R.s("4x")}F{B 2o=J;if(R.g("Z")=="1P"){if(R.s("1l")==1&&R.s("gT")==1){if(!o.ck&&!o.7N){2o=H;eE=J}F{if(!eE){7Q-=R.g("W")+R.s("3P")+R.s("4x");eE=H}}}}if(iQ(R)){2o=H}if(!2o){4F.1b+=R.g("W")/2+R.s("3P");x=4F.1b;4F.1b+=R.g("W")/2+R.s("4x")}F{x=4F.1b}}}}}}O x}E o9(R){B W=o.2e&&v.1u.hN==0?o.9A:o.3f;B X=o.4h;B 94=0;if(R!=bg){94=W/2+R.s("3P")-R.s("4x")}B cB=X/2;B nX=R.g("W");B ja=R.g("X");B 1i=R.s("1i");if(1i.L("7e")>-1){94=o.3f/2+R.s("3P")-R.s("4x")}if(1i.L("1f")==0){cB=ja/2+(R.s("As")*o.4h/1h)}if(1i.L("2F")==0){cB=o.4h-(R==bg?ja:ja/2)-(R.s("Ar")*o.4h/1h)}if(1i.L("2l")>-1){94=o.3f-nX/2+R.s("3P")-R.s("4x")-(R.s("Np")*o.3f/1h)}if(1i.L("1b")>-1){94=nX/2+R.s("3P")-R.s("4x")+(R.s("jn")*o.3f/1h)}if(1i=="c9"){94=-o.qi/2+(R.s("jn")*o.qi/1h)+R.s("3P")-R.s("4x");cB=-o.jg/2-(R.s("Ar")*o.jg/1h)+(R.s("As")*o.jg/1h)}if(1i.L("S")>-1){B cx=Au(R);94=(bg?(bg.c()?4X(bg.c().jq):0):0)+cx;if(1i=="S-2l"){94+=7Q}if(v.1u.1i=="1f"){cB=v.1u.h/2}F{cB=X-v.1u.h/2}}O{x:94,y:cB+R.s("8L")-R.s("bG")}}E 2n(8A){B w=o.2e&&v.1u.hN==0?o.9A:o.3f;B h=o.4h;K(bg.c(),{\'1f\':(v.1u.1i=="1f"?0:o.4h-v.1u.h)-v.h8});bg.1U("y0",(o.4h-v.1u.h-v.h8));if(v.1u.hN==0&&bg){K(bg.c(),{\'W\':w,\'1b\':0,\'2K-1b\':0});bg.1U("w",w);if(o.2e){K(bg.c(),{\'1b\':\'50%\',\'2K-1b\':-w/2})}}4F={"1b":v.1u.iD*1,"2l":(bg.g("w")-v.1u.iD*1)};B o2=J;if(!bg.g("1n")){bg.1U("2m",H);o2=H}B 1a;U(B i=0;i<dF.Q;i++){1a=dF[i];if(b[1a]){B cc=o9(b[1a]);if(cc){b[1a].1U("x0",cc.x);b[1a].1U("y0",cc.y);if(b[1a].s("3G")==1&&!b[1a].g("1n")&&!8A){qc(b[1a])}F{K(b[1a].c(),{"1i":"29","1b":b[1a].g("x0"),"1f":b[1a].g("y0")})}}}}if(o2){bg.1U("2m",J)}7Q=0;U(1a in b){if(b.2h(1a)){if(b[1a].s("1i")=="S-2l"&&b[1a].g("Z")!="2C"&&7Q>-1){7Q=4F.2l-4F.1b}if(b[1a].g("Z")=="2C"&&bg){B bE;if(b[1a].s("Nm")==1){bE=b[1a].s("w")}F{if(b[1a].s("1i").L("S")>-1){bE=4F.2l-4F.1b-b[1a].s("3P")-b[1a].s("4x");K(b[1a].c(),{"1b":(4X(bg.c().jq)+4F.1b+b[1a].s("3P")+bE/2)});7Q=-1}F{bE=bg.g("w")-b[1a].s("3P")-b[1a].s("4x");K(b[1a].c(),{"1b":(4X(bg.c().jq)+b[1a].s("3P")+bE/2)})}}b[1a].1U("x0",b[1a].g("x"));b[1a].2n(bE)}}}if(1d){hm(1d)}if(I(v.19)){hm(19)}iR||o.2e||iH!=7Q?4n():\'\'}E qc(b){B 1b=0;B 1f=0;if(b.s("1i").L("2l")>-1&&b.s("1i").L("S")==-1){1b=o.3f+b.g("W")+10}if(b.s("1i").L("1b")>-1){1b=-b.g("W")-10}if(b.s("1i").L("1f")>-1){1f=-b.g("X")*2}if(b.s("1i").L("2F")>-1||b.s("1i").L("S")>-1){1f=o.4h+b.g("X")+b.g("W")+10}if(1b>0){K(b.c(),{"1b":1b})}if(1f>0){K(b.c(),{"1f":1f})}}E hm(x){B 1f=-47;x.hr();B y=o.4h-v.1u.h*(x.s("1i").L("1f")>-1?1:2);B fe=y-(o.2e&&!o.1m.2y?(1h+x.s("iN")*1):x.s("iN"));fe<1h?fe=1h:\'\';K(x.c(),{\'5C-X\':fe});x.co()?K(x.co(),{\'5C-X\':fe}):\'\';if(x.g("1n")){1f=o.4h/2-x.g("X")/2+x.s("8L")-x.s("bG");if(x.s("1i").L("1f")>-1){1f=x.s("8L")-x.s("bG")}if(x.s("1i").L("2F")>-1){1f=o.4h-v.1u.h-x.g("X")+x.s("8L")-x.s("bG")}1f<0?1f=0:\'\'}if(x.s("1i").L("2l")>-1){K(x.c(),{"1i":"29","2l":x.s("4x")-x.s("jW"),"1f":1f})}F if(x.s("1i").L("1b")>-1){K(x.c(),{"1i":"29","1b":x.s("3P"),"1f":1f})}F{if(x.g("1a")=="19"&&x.s("3D")==1){K(x.c(),{"1i":"29","1b":o.3f/2-x.g("W")/2+x.s("3P")/2-x.s("4x")/2,"1f":1f})}F{K(x.c(),{"1i":"29","1b":o.3f/2-x.g("W")/2+x.s("3P")-x.s("4x"),"1f":1f})}}x.8y()};G.dP=E(1a){B R=b[1a];B Z=R.g("Z");if(Z){B d=1y 7L();o.9V=d.ap();if(Z&&Z!=""){4P(R)}}};G.rU=E(z,x,y){U(B 1a in b){if(b.2h(1a)){if(b[1a].s(z)==x){b[1a].1U(y?"6s":"3g")}}}};G.qz=E(x,s){B y;U(B 1a in b){if(b.2h(1a)){if(b[1a].s(s)==x){y=b[1a]}}}O y};E 4P(R,1B){o.kr=H;ji=R;B a=R.g("Z");if(a=="1O"){o.V.2B();if(v.1T.on==1&&v.1T.2D==1&&v.1T.nO==1){6H(\'1O\',1)}}F{if(a=="59"){o.V.2Q();if(v.1T.on==1&&v.1T.2D==1&&v.1T.nO==1){6H(\'1O\',0)}}if(a=="2o"){o.V.nN()}}if(a=="Ae"){o.V.3R(0,J)}if(a=="2e"){!o.5D?o.V.6Z():\'\'}F{if(a=="iK"){o.V.8S()}}if(a=="2C"){B ld=o.P.1k();B lt=R.g("2u")*ld;if(v.4e>0){ld-=v.4e;lt=R.g("2u")*ld+v.4e}if(v.Ah>0){if(v.Ah/ld<=1-R.g("2u")){O}}o.V.3R(lt,H);if(o.3i){o.3i.nQ(lt,ld);o.2z>0?o.2z=1W:\'\'}}if(a=="1P"){B x=R.g("2u");x<0.Nl?x=0:\'\';x>1?x=1:\'\';if(o.4S&&v.sT==1){3m.7U("tl",x);if(R.g("2u")>0||o.1m.8V||v.kv==0){3m.nR("gO")}F{3m.7U("gO",1)}}o.V.3T(x)}if(a=="4V"){if(o.4S&&!o.1m.8V&&v.kv==1){3m.7U("gO",1)}o.V.4Y();if(v.1T.2D==1&&v.1T.Aj==1){6H(\'4V\',0)}}F{if(a=="9K"){if(o.4S){3m.nR("gO")}o.V.6P();if(v.1T.2D==1&&v.1T.Aj==1){6H(\'4V\',1)}}}if(a.L("Y")==0){R.Ni()?R.fk():R.On()}if(a=="bX"){o.P.nb()}if(a=="1x+"){o.P.aI(0.1)}if(a=="1x-"){o.P.aI(-0.1)}if(a=="1x"){o.P.aI(0)}if(a=="6W"){2Z("Bb");R.1U("mT",1);R.1U("iI",1)}if(a=="5i"){js("5i");o5()}if(a=="1d"){if(1d){if(!1d.g("1n")){1d.1n()}F{1d.1l()}}}if(a=="19"){if(o.eK==a){O}if(I(v.19)){if(19.g("1n")){19.1l()}F{1G(E(){19.1n()},1h)}}}if(a=="8v"){o.S.dA()}if(a=="cO"){o.S.hP()}if(a=="4b"){if(R.s("dr")==1&&R.s("2T")!=""){B x=4j(R.s("2T"));if(o.eK==a+x){O}if(x.L(\'{Y}\')>-1){x=x.1Z(\'{Y}\',(I(o.3i)?o.3i.96().t:o.P.Y()))}if(x.L(\'{3h}\')>-1){x=x.1Z(\'{3h}\',o.P.an())}if(x.L(\'{1N}\')>-1){x=x.1Z(\'{1N}\',v.1N.1Z(/,/ig," "))}if(x=="4T"){o.P.d3()}if(x=="Nj"){o.V.3R(R.s("jn")*o.P.1k()/1h);!o.1O?o.V.2B():\'\'}R.s("C1")==1?o.V.2Q():\'\';B y=x.2t(",");if(x.L("2Z:")==0){B z=x.1w(4).2t(";");U(B i=0;i<z.Q;i++){y=z[i].2t(",");if(y.Q>1){if(y[0]==\'4g\'){if(v.1T.2D==1&&v.1T.tq==1){6H(\'4g\',y[1]>0?1:0)}}2Z(y[0],y[1],R);y[1]==\'0/1\'?qo():\'\'}F{if(y[0]=="C3"&&v.Nk==1){B ss=2Z(y[0]);if(ss){if(ss.L("1C")>-1){B 3N=1K.1M(\'3N\');3N.5R(\'2X\',ss);K(3N,{1i:"nU",2l:(I(v.iJ)?v.iJ:20),2F:(I(v.iJ)?v.iJ:20),W:0,4u:"W 0.5s b3-Nq(.75,-0.5,0,1.75)"});3N.C.5j=C5;1K.bl.1J(3N);1G(E(){K(3N,{W:(I(v.BZ)?v.BZ:4H)})},1);3N.dH=E(){G.4Q.2U(G)}}}F{1r(y[0]+" 1E")}}F{2Z(y[0])}}}}F{if(x.L("js:")==0){if(x.L("(")>0&&x.L(")")>0){2j(x.1w(3))}F{2j(y[0].1w(3)+\'(\'+(I(y[1])?\'"\'+y[1]+\'"\':\'\')+(I(y[2])?\',"\'+y[2]+\'"\':\'\')+\')\')}}if(x.L("3n")==0||x.L("/")==0||x.L("?")==0||x.L("1e:")==0){x.L("1e:")==0?x=x.1w(4):\'\';22.7x(x,R.s("BY"))}if(x.L("6g")==0){o.V.s8()}if(x=="2Z:7G"){o.P.cn()}}if(x.L("1d#")>-1){if(1d){B si=x.1w(9).2t(",");if(1d.g("1n")&&1d.g("7x")==si[0]){1d.1l()}F{U(B i=0;i<si.Q;i++){i==0?1d.1n():\'\';1d.7x(si[i])}}}}if(x.L("1d:")>-1&&v.1d.Nr==1){if(!o.5c){o.5c=1y Nx()}if(1B=="7P"){o.5c.1n(x)}F{o.5c.tg(x)}}}}};G.1N=E(t){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="1N"){if(b[x].s("B")==t||t=="1N"){if(v[t]!=\'\'||b[x].s("1q")!=\'\'){b[x].1U("2m",H)}F{b[x].1U("2m",J)}b[x].6d(v[t])}}}}o4()};G.BW=E(){o4()};G.C8=E(){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="4b"){if(b[x].s("1B")=="1F"){b[x].8U()}}}}};E o4(){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="4b"){if(b[x].s("1B")=="1F"){b[x].Cx(H)}}}}}E o5(){if(I(o.5i)){o.5i.ve()}}G.Cm=E(){o5()};G.uw=E(){if(v.1N!=\'\'){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="1N"){B y=J;if(!b[x].g("1n")){y=H;b[x].1U("2m",H)}b[x].6d(v.1N);if(y){b[x].1U("2m",J)}}}}}};G.Ny=E(y,z){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="4b"&&b[x].s("1B")=="1F"){if(b[x].s("3X")==y){if(!b[x].g("1n")){b[x].1U("2m",H)}b[x].6d(z)}}}}};G.4J=E(){2n()};G.Nw=E(){2n(H)};G.rT=E(){hm(1d)};G.hr=E(){hm(19)};G.2B=E(){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="1O"){b[x].On()}}}if(G.cI()&&v.19.e9==1){G.as()}o.1O=H;4n()};G.2Q=E(){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="59"||b[x].g("Z")=="2o"){b[x].fk()}}}if(19){if(v.19.Ay==1&&!19.5w()){19.1n()}}o.1O=J;4n();if(v.1u.1l==1&&v.1u.dY==1){hj(H)}};G.4Y=E(){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="4V"){b[x].On()}G.3T(0)}}4n()};G.6P=E(){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="9K"){b[x].fk()}}}if(v.1P<0.1){v.1P=0.5;o.V.3T(v.1P)}F{G.3T(v.1P)}4n()};G.3T=E(1P,y){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="1P"){b[x].7b(1P,1,(y=="no"?y:H))}if(b[x].g("Z")=="4V"){b[x].Du(1P)}}}4n()};G.6Z=E(){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="2e"){b[x].On();b[x].1U("1x",b[x].s("1x"))}}}4n();iR?1G(4n,4v):\'\';eN()};G.8S=E(){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="iK"){b[x].fk()}}}2n();4m(o.hk);4n()};G.8e=E(){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="1O"){b[x].sI()}}}};G.xy=E(){4n()};E 4n(){U(B x in b){if(b.2h(x)){if(b[x].g("Z")!="dO"){b5(b[x])}}}b5(bg);if(iH!=7Q){iH=7Q;2n()}if(v.1u.1l==1&&v.1u.cs==1){eJ(!o.da&&!o.5t&&!o.2e&&o.1O&&v.1u.eF!=1&&!o.5D)}};E i2(){B 1n=8u&&v.1u.g5==1;if(!o.1O&&v.1u.1l==1&&v.1u.dY==1){1n=J}if(1n){U(B x in b){if(b.2h(x)){if(b[x].g("Z")!="dO"){b5(b[x],J)}}}K(o.1D,{"6t":"6S"});o.iT=H;b5(bg,J);if(bg.g("1n")){gQ()}eJ(J)}}E hj(){B 1l=o.1O&&v.1u.g5==1&&!o.3q&&!o.bY;if(!o.1O&&v.1u.1l==1&&v.1u.dY==1){1l=H}if(1d){if(1d.g("1n")&&o.rY){1l=J}}if(1l){U(B x in b){if(b.2h(x)){if(b[x].g("Z")!="dO"){b5(b[x],H)}}}b5(bg,H);if(!bg.g("1n")){8u=H;o.P.oc();if(o.1O){K(o.1D,{"6t":"1I"});o.iT=J}}eJ(H)}}E eN(){if(v.1u.g5==1){if(v.1u.eF==1&&!o.2e&&!o.aV){}F{4m(o.hk);o.hk=7d(hj,((v.1u.7B>0?v.1u.7B:v.1u.hl)*2G))}}}E b5(R,bB){B 1l=J;B 1n=J;B bD=J;if(v.1u.1l==1){if(!o.da&&!o.5t&&!o.2e&&o.1O&&v.1u.eF!=1&&!o.5D){1l=H;1n=J;bD=H}F{1l=J;1n=H}if(I(bB)&&!o.5D){1l=bB;1n=!1l}if(v.1u.1l==1&&v.1u.cs==1&&(R.s("1i").L("S")==0||R.s("Z")=="2C")){1l=J;1n=H}if(v.1u.dY==1&&!o.1O){1l=H;1n=J;bD=J}}F{if(R.s("1l")!=1){1n=H}}if(1n&&!o.iT){K(o.1D,{"6t":"6S"});o.iT=H}if(R.s("Z")=="4b"&&R.s("1i").L("S")==-1){1l=J;1n=H}if(o.5D){if(R.s("Z")=="2C"){if(o.P.1k()==-1){1l=H;1n=J}}}B o6=J;B hp=iQ(R);if(R.s("1l")==1){if(R.s("Nv")==1){if(bD||bB||(o.1O&&!o.5t)){!bD&&!bB?\'\':hp=H}}if(R.s("Ns")==1){if(o.1O&&!o.5t){hp=H}}if(R.s("Bu")==1||R.s("Bi")==1||R.s("BF")==1){iR=H}}if(hp){1l=H;1n=J}F{!1l?1n=H:\'\'}if(R.s("Z")=="1P"){if(R.s("1l")==1&&R.s("gT")==1){1l=H;1n=J;if(!bD&&(o.7N||o.ck)&&!bB&&R.s("cz")!=1){1l=J;1n=H}F{o6=H}}}if(o.bR||(!o.1A&&v.1u.1l==1&&v.1u.pR==1)||(!o.aL&&v.1u.1l==1&&v.1u.Bx==1)){if(R.s("1i").L("S")>-1||R.s("1i").L("2F")>-1){1l=H;1n=J}if(v.1u.eF==1&&!o.2e){1l=J;1n=H}}if(1d){if(1d.g("1n")&&v.1d.8F!=1){bD=J;bB=J}}if(R.g("Z")=="5i"){if(I(o.5i)){if(o.5i.5w()){1l=H;1n=J;R.1U("5p","1I")}}}if(R.g("Z")=="19"||R.g("Z")=="8v"||R.g("Z")=="cO"||R.s("Cg")==1){if(19.5w()&&R.s("Cg")!=0){1l=H;1n=J;R.1U("5p","1I")}}if(o.Nt==1){1l=H;1n=J}if(o6){B cc=o9(R);if(cc){cc.y>0?R.1U("y0",cc.y):\'\';K(R.c(),{"1i":"29","1f":R.g("y0")})}}if(1l){az(R,(oa?H:J))}if(1n){BG(R)}if(R==bg){if(!1l&&1n){gQ();6s(6L);8u=J}if(1l&&!1n){o.P.oc();bw();3g(6L);8u=H}if(19){if(v.19.8F==1&&!19.5w()){if(1n||o.bR){if(v.19.Bk==1&&o.2e){}F{if(!19.g("1n")){if(v.19.Be==1){!o.1O?19.1n():\'\'}F{19.1n()}}}}F{if(1l&&19.g("1n")){19.1l()}}}}}};E iQ(R){B x=J;if(R.s("1l")==1){if(R.s("CJ")==1){o.1O?x=H:\'\'}if(R.s("dY")==1){!o.1O?x=H:\'\'}if(R.s("L8")==1){o.1m.p0?x=H:\'\'}if(R.s("Nh")==1){o.1m.2y?x=H:\'\'}if(R.s("Bi")==1){if(o.3f>R.s("Bh")){R.1U("cz",1);x=H}F{R.1U("cz",0)}}if(R.s("Bu")==1){if(o.3f<=R.s("BI")){R.1U("cz",1);x=H}F{R.1U("cz",0)}}if(R.s("Ng")==1){o.1A?x=H:\'\'}if(R.s("N4")==1){if(o.1A||!o.3i||o.P.5H()){x=H}if(o.3i){if(o.3i.96().t==0){x=H}}}if(R.s("pR")==1){!o.1A?x=H:\'\'}if(R.s("N5")==1){if(I(R.s("BK"))){3k[R.s("BK")]?x=H:\'\'}}if(R.s("N6")==1&&o.1m.5x){!o.1A||o.pT?x=H:\'\'}if(R.s("N3")==1){!o.P.9I()?x=H:\'\'}if(R.s("N2")==1){!o.P.5H()?x=H:\'\'}if(R.s("MZ")==1){!o.5t?x=H:\'\'}if(R.s("N0")==1){!o.2e?x=H:\'\'}if(R.s("BF")==1){o.2e?x=H:\'\'}if(R.s("N1")==1){!o.3Q?x=H:\'\'}if(R.s("N7")==1){o.P.5H()&&o.P.an().L("?r7")==-1?x=H:\'\'}if(R.s("CG")==1){62(o.2g)?x=H:\'\'}if(R.s("Bx")==1){!o.aL?x=H:\'\'}if(R.s("N8")==1){o.aL?x=H:\'\'}if(R.s("Ne")==1){o.iU?x=H:\'\'}if(R.s("Nf")==1){!o.iU?x=H:\'\'}if(R.s("E3")==1){if(R.g("g7")){x=H}}if(R.s("Q2")==1){!o.ab?x=H:\'\'}if(R.s("Nc")==1){o.ab?x=H:\'\'}if(R.s("N9")==1){if(v.43==1&&v.cJ==1){if(o.2v=="44"&&!I(v.2g)&&v.pJ==0){if(!o.1A||o.P.6f()=="9I"){if(v.2g==\'\'){}F{x=H}}}}}}if(R.g("Z")=="4b"){if(R.s("2T")){if(R.s("2T")=="2Z:4T"||R.s("2T")=="4T"){if(!o.4T&&!o.eg){x=H}}if(R.s("2T")=="2Z:7G"){if(!o.7G||(!o.1A&&v.43==0)){x=H}}if(R.s("2T")=="2Z:Bw"){if(!o.iU){x=H}}if(R.s("2T").L("5S")>-1){if(!o.5S){x=H}}}}if(R.g("Z")=="19"||R.g("Z")=="8v"||R.g("Z")=="cO"){if(19.5w()){x=H}}if(R.g("Z")=="1d"){if(1d.5w()){x=H;R.1U("5p","1I")}}if(R.g("1B")=="1F"){if(R.g("Q")==0){x=H}}if(R.g("1d#")){if(!R.g("1U#3U")){x=H}}if(R.s("4L")==1){B cb=1K.8m("Na"+v.id);if((o.P.1k()==0&&o.P.Y()==0)||!o.5A||!62(cb)||!o.Nb){x=H}}if(R.g("Z")=="1k"){if(o.P.5H()){x=H}}if(R.g("1a")=="mM"&&o.1m.2y){if(o.bR&&o.1m.9f){x=H}}O x}E az(R,q8){if(R.g("1n")){if(o.aV||R.s("5p")=="1I"||q8){R.1U("2m",J)}F{Bv(R)}R.1U("1n",J)}};E BG(R){if(!R.g("1n")){if(R.s("5p")=="1I"||o.aV){R.1U("2m",H);if(o.aV){R.1U("1o",1)}if(R.g("Z")=="1P"){if(o.gK){qc(R)}}}F{Bj(R)}if(R.s("Z")=="1P"){o.S.3T(o.3Q?0:v.1P)}if(R.s("Z")=="2C"){o.V.qb()}R.1U("1n",H)}};E Bv(R){qa(R.g("1a"));B 5b="gp|";B 4R="0|";B 1l=1;B a=R.s("5p");B p=R.s("1i");if(a=="1x"){5b+="1x|";4R+="0|"}if(a=="1i"){if(p.L("2l")>-1&&p.L("S")==-1){5b+="x|";4R+=4X(o.3f+R.g("W"))+"|"}if(p.L("1b")>-1){5b+="x|";4R+=4X(-R.g("W"))+"|"}if(p.L("1f")>-1){5b+="y|";4R+="0|"+(-R.g("X"))+"|"}if(p.L("2F")>-1||p.L("S")>-1||p=="c9"){5b+="y|";if(R.g("Z")=="2C"||R.g("Z")=="1P"){4R+=4X(o.4h+R.s("h")+(R.s("h")<20?20-R.s("h"):0))+"|"}F{4R+=4X(o.4h+R.g("X"))+"|"}}if(p=="7e"){5b+="1x|";4R+="0|"}}B m=1y 5g({"mc":R,"me":R.g("1a"),"1B":5b.1w(0,5b.Q-1),"to":4R.1w(0,4R.Q-1),"1l":1l})};E Bj(R){qa(R.g("1a"));B 5b="";B 4R="";B a=R.s("5p");B p=R.s("1i");if(R.g("1o")!=1){5b="gp|";4R=(R.g("1a")==\'bg\'?v.1u.a:"1")+"|"}if(a=="1x"){if(R.g("3l")!=R.s("1x")){R.1U("1x",0);5b+="1x|";4R+=R.s("1x")+"|"}}if(a=="1i"){if(p=="7e"){if(R.g("3l")!=R.s("1x")){5b+="1x|";4R+=R.s("1x")+"|"}}F{if(p.L("S")>-1){if(R.g("y")!=R.g("y0")){5b+="y|";4R+=R.g("y0")+"|"}}F{5b+="x|y|";4R+=R.g("x0")+"|"+R.g("y0")+"|"}}}if(5b!=""&&4R!=""){B m=1y 5g({mc:R,me:R.g("1a"),1B:5b.1w(0,5b.Q-1),to:4R.1w(0,4R.Q-1),1n:1})}F{R.1U("2m",H)}};G.hO=E(1a,1B,q8){B 4J=J;B 2o=J;B R=b[1a];B Z=R.g("Z");B 2T=R.s("2T");if(1B=="7P"){if(o.gK){if(Z=="1P"||Z=="4V"||Z=="9K"){o.7N=H;o.ck=H;4J=H;4n();if(v.eP.Br==1){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="2C"){3g(b[x].c())}}}}}}if((v.1d.f0==1&&(Z=="1d"||2T.L("Bs")==0))||2T.L("1d:")==0){3j(o.eI);if(!1d.g("1n")||ji!=R){4P(R,1B);o.eK=Z+2T;1G(E(){o.eK=1S},4v)}}if(v.19.f0==1&&Z=="19"){3j(o.q7);if(!19.g("1n")||ji!=R){4P(R,1B);o.eK=Z;1G(E(){o.eK=1S},4v)}}}if(1B=="6l"){if(o.gK){if(Z=="1P"||Z=="4V"||Z=="9K"){o.7N=J;o.ck=H;1G(E(){if(!o.7N){o.ck=J;U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="1P"){az(b[x]);2n()}if(b[x].g("Z")=="2C"){if(v.eP.Br==1){6s(b[x].c())}}}}}},4v)}}if((v.1d.f0==1&&(Z=="1d"||2T.L("Bs")==0))||2T.L("1d:")==0){3j(o.eI);o.eI=1G(E(){if(!o.3q){bw(1)}},(v.1d.d1>0?v.1d.d1*2G:2G))}if(v.19.f0==1&&Z=="19"){3j(o.q7);o.q7=1G(E(){if(!o.3q){19.g("1n")?19.1l(1):\'\'}},(v.19.d1>0?v.19.d1*2G:2G))}}if(4J){1G(2n,10)}};G.lq=E(){if(o.4G&&!o.2e){o.V.4G(J);o.4G=J}if(o.2g){if(v.jk>-1&&62(o.2g)){K(o.2g,{1o:v.jl})}}if(o.1O&&v.Bm==1){o.V.2Q()}if(v.1u.7B>0){3j(o.Bq);o.Bq=1G(4n,v.1u.7B*2G)}F{4n()}};G.xA=E(){if(o.2g){if(v.jk>-1&&62(o.2g)){K(o.2g,{1o:v.jk})}}if(!o.1O&&v.Bm==1){o.V.2B()}4n();eJ(J)};G.dD=E(9y,9x){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="2C"||b[x].g("Z")=="1P"){b[x].dD(9y,9x)}}}};G.sP=E(){if(v.1u.1l==1){if(v.1u.eF==1&&!o.2e){O}if(!o.5t&&o.P.6f()=="5M"){o.5t=H;4n()}if(v.1u.g5==1){i2();eN()}eJ(J)}};G.cS=E(9y,9x){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="2C"||b[x].g("Z")=="1P"){b[x].cS(9y,9x)}}}};G.fZ=E(Y,1k){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="2C"){b[x].7b(Y,1k)}if(b[x].g("Z")=="Y"){j3(b[x],Y,1k)}if(b[x].s("AU")==1){b[x].nb()}}}};E eJ(x){if(v.1u.1l==1){x?bw():\'\';if(v.1u.cs==1){if(!o.1O&&v.1u.dY==1){x=H}if(x&&!o.pe){K(o.1u,{"1f":bg.h()})}if(!x&&o.pe){K(o.1u,{"1f":0})}o.pe=x}}}E gQ(){8u=J;o.P.gQ();if(o.pq){o.pq=J;2n();1G(2n,cA)}}E j3(x,Y,1k){if(v.4e>0){Y-=v.4e;1k-=v.4e}B y=4t(Y);if(x.s("AV")=="1"){y=4t(1k-Y)}if(x.s("Mm")=="1"){if(x.s("Ml")=="1"){y=y+(1k>0?\' \'+2M(x.s("Lx"))+\' \'+4t(1k):\'\')}F{Y==0?y=4t(1k):\'\'}}x.6d(y)}G.pf=E(Y,1k){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="2C"){b[x].BO(Y,1k)}}}};G.8s=E(){if(v.lh==1){3j(iX);iX=1G(8s,4v)}F{8s()}};E 8s(){if(!9w){js("Ly");U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="dO"){b[x].CA();9w=H}}}}}G.Ca=E(y){U(B x in b){if(x==y){b[x].1U("3g")}}};G.6K=E(Y,1k){3j(iX);if(9w){js("8h");U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="dO"){b[x].eS();9w=J}}}}};G.gA=E(){U(B x in b){if(b.2h(x)){if(b[x].s("2T")=="1P 8Q"){b[x].1U("6s");b[x].6d(2M(\'1P\')+\' \'+(o.3Q?0:2I.iW(v.1P*1h))+\'%\');3j(o.gA);o.gA=1G(Ci,2G)}}}};E Ci(){U(B x in b){if(b.2h(x)){if(b[x].s("2T")=="1P 8Q"){b[x].6d(\'\');b[x].1U("3g");3j(o.gA)}}}}G.3R=E(Y,1k){if(v.4e>0){Y-=v.4e;1k-=v.4e}U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="2C"){1k>0?b[x].1U("2u",Y/1k):\'\';b[x].BP()}if(b[x].g("Z")=="Y"){j3(b[x],Y,1k)}if(b[x].g("Z")=="6W"){b[x].1U("mT",0.5);b[x].1U("iI",0)}}}};G.4s=E(Y,1k){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="1k"){if(v.4e>0){1k-=v.4e}b[x].6d(4t(1k))}if(b[x].g("Z")=="2C"){b[x].7b(Y,1k);b[x].ee(1k)}if(b[x].g("Z")=="Y"){j3(b[x],Y,1k)}}}};G.7O=E(){1d.g("1n")?1d.1l():1d.1n()};G.al=E(){if(1d){O 1d.g("1n")?H:J}F{O J}};G.p7=E(){if(1d){1d.aI()}};G.bw=E(){bw()};G.Lz=E(x){if(1d){1d.A3(x)}};G.wz=E(){if(1d){1d.fm()}};G.wC=E(x){if(1d){O 1d.vv(x)}};E bw(x){if(1d){1d.g("1n")?1d.1l(x):\'\'}o.5c?o.5c.1l():\'\'};G.as=E(){if(19){if(19.g("1n")){19.1l(1)}F{19.1n()}}};G.j7=E(){if(19){1G(E(){19.1n()},1h)}};G.cI=E(){if(19){O 19.g("1n")?H:J}F{O J}};G.cZ=E(x){O 19?19.g(x):\'\'};G.5Q=E(x){if(19){19.rK(x)}};G.dA=E(){if(19){19.dA()}};G.kB=E(){if(19){19.kB()}};G.fV=E(){fV()};E fV(){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="8v"){K(b[x].c(),{"1o":(!19.dn()?0.5:1)})}if(b[x].g("Z")=="cO"){K(b[x].c(),{"1o":(!19.rv()?0.5:1)})}}}}G.dn=E(){if(19){O 19.dn()}F{O J}};G.kG=E(){if(19){O 19.kG()}F{O J}};G.ka=E(){if(19){19.ka()}};G.hP=E(){if(19){19.hP()}};G.Ck=E(x){if(x&&19){19.h6(x)}};G.Cl=E(x){if(x&&19){19.kA(x)}};G.BV=E(x){if(x&&19){K(19.co(),{"Lw":"1I"});1K.8m(x).1J(19.co());3g(19.c())}};G.Lv=E(){};G.py=E(x){if(1d){1d.5n();1d.g("1n")?1G(E(){1d.1l()},4H):\'\'}};G.cf=E(x){if(1d){1d.5n()}if(o.5c){o.5c.g4()}};G.gI=E(x){if(1d){1d.d3()}2n();4n()};G.hZ=E(x){if(1d){1d.hi(x);1d.g("1n")?1d.1l():\'\'}if(o.5c){o.5c.g4()}};G.hW=E(x){if(1d){1d.hi("6e")}if(o.5c){o.5c.g4()}};G.bn=E(){if(1d){1d.9z();1d.g("1n")?1G(E(){1d.1l()},4H):\'\'}if(o.5c){o.5c.g4()}};G.fU=E(i6,2m,fx){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="1d"){if(b[x].s("dz")==1){b[x].D0()}}if(b[x].g("9Y")=="1d#"+i6){b[x].1U("1U#3U",2m);if(b[x].g("1B")=="1F"){if(fx){b[x].6d(fx)}}F{if(v.1d[\'1d\'+i6+\'Z\']=="2r"){if(fx==2M("8l")){b[x].eb(0)}F{b[x].eb(1)}}2n()}b5(b[x])}}}};G.C4=E(){if(1d){1d.5n();1d.hi("6e");1d.hi("6g")}};G.f9=E(){U(B x in b){if(b.2h(x)){if(b[x].g("Z")=="2C"){b[x].f9()}}}};G.4J=E(){2n();if(8u){o.pq=H}};G.rA=E(x){if(!8u||x==1){2n();4n()}F{v.1u.pt=H}};G.4M=E(){4n();2n();4n();if(o.bR){3g(6L)}F{!8u?6s(6L):\'\'}};G.xs=E(17){if(g8==v.id&&v.1T.on==1){B x=17.Aq;if(x==1W){x=17.zZ}if(I(o.2f)||I(o.6J)||o.Ls==1){O J}if(((v.1T.7R==1&&x==32)||(v.1T.Lt==1&&x==13))&&(o.5G||o.5t)){if(v.1T.2D==1){6H(\'1O\',o.1O?0:1)}o.V.bK();17.91();O J}!v.1T.i3?v.1T.i3=0.2:\'\';!v.1T.1x?v.1T.1x=5:\'\';if(v.1T.Al==1&&o.5G){if(o.P.1k()>0){U(B i=48;i<58;i++){if(x==i){o.V.3R((o.P.1k()*(x-48)*10)/1h,H)}}}}if(x==39&&o.5G){il(v.1T.my)}if(x==37&&o.5G){im(v.1T.my)}if(x==38&&o.5G){il(v.1T.mH)}if(x==40&&o.5G){im(v.1T.mH)}if(x==Lu&&o.5G){il(v.1T.An)}if(x==LA&&o.5G){im(v.1T.An)}}};E il(x){if(x=="4g"){if(o.P.1k()>0){if(o.P.Y()+4U(v.1T.4g)<o.P.1k()){o.V.3R(o.P.Y()+4U(v.1T.4g),H)}}}if(x=="1P"){o.V.3T(4U(v.1P)+4U(v.1T.i3));17.91()}if(x=="1x"){o.P.1x(v.1T.1x/1h);17.91()}if(v.1T.2D==1){6H(x,1)}}E im(x){if(x=="4g"){if(o.P.1k()>0&&o.1A){o.V.3R((o.P.Y()-v.1T.4g>=0?o.P.Y()-v.1T.4g:0),H)}}if(x=="1P"){o.V.3T(4U(v.1P)-4U(v.1T.i3));17.91()}if(x=="1x"){o.P.1x(-v.1T.1x/1h);17.91()}if(v.1T.2D==1){6H(x,0)}};G.xF=E(17){if(g8==v.id){B x=17.Aq;if(x==1W){x=17.zZ}if(x==57){if(v.1r==1){}}if(o.2e&&x==27){o.V.8S()}if(I(o.2f)||I(o.6J)){O J}if(v.1T.f==1&&x==70&&v.lh!=1&&(o.5G||o.5t)){if(v.1T.2D==1){6H(\'2e\',o.2e?0:1)}o.2e?o.V.8S():o.V.6Z()}if(v.1T.m==1&&x==77&&(o.5G||o.5t)){if(v.1T.2D==1){6H(\'4V\',o.3Q?1:0)}o.3Q?o.V.6P():o.V.4Y()}}};G.4C=E(){4m(o.hk);U(B x in o){if(x.L("18")==0&&x.L("vl")>-1){4m(o[x])}}U(B i=0;i<dF.Q;i++){1a=dF[i];if(b[1a]){b[1a].4C()}}if(1d){1d.4C()}if(19){19.4C()}bg.4C();if(6L.4Q==o.1D){o.1D.2U(6L)}F{o.1u?o.1u.2U(6L):\'\'}};G.i2=E(){i2()};G.hj=E(){hj();4n()};G.eN=E(){eN()};G.kt=E(){O 8u}};B A1=E(1a){B i;B C=[];B w;B h;B n7=0;B bg;B jd;B 7k;B j0=0;B 3U=H;B DN=J;B 3l=1;B 3a=1;B 2c;B 8X;B 3w;B 7M;B Z;B 9Y=\'\';B x0;B y0;B on;B 7P=J;B ae=J;B cL=0;B LB;B LI=0;B dB=0;B AD=0;B hy=0;B iV=J;B g7=J;B dz;B iv;B mQ=J;C=8J(C,dc.R);C=8J(C,v[1a]);B V=[C.Z];Z=V[0];I(C.Ax)?V[1]=C.Ax:\'\';I(C.AX)?V[1]=C.AX:\'\';I(C.1N)?C.1F=C.1N:\'\';if(I(C.mn)){C.mn!=-1&&o.3f<ca?C.1x=C.mn:\'\'}if(I(C.2T)){if(C.1B=="1F"&&C.2T!=\'\'){if(I(v[C.2T+\'1F\'])){C.1F=v[C.2T+\'1F\']}}if(C.2T.L("1d#")==0){9Y=C.2T;if(C.3w==\'\'&&9Y.L(",")==-1){C.3w=2M(v.1d[\'1d\'+9Y.1w(9)+\'Z\'])}}if(C.2T.L("5S")>0){v.AY=H}if(C.2T=="LJ"){C.LH=1y LF(C)}}B bi=C.3w?C.3w.2t("///"):[];B nw=0;B 2D=1y 8n();B 1q=1y 8n();B c5=1y 8n();B LC=1y 8n();B fK=0;B 9U;if(C.1B=="1F"){if(I(C.1F)){2D[0]=4j(C.1F);C.hU=C.1F.Q;if(C.1F.L("/")==0){C.DU=1}if(C.1F.L("|")==0){C.E0=1}if(C.1F.L("-")==0){C.DW=1}if(Z=="Y"||Z=="1k"){if(C.1F.L(\'0:\')==0){C.n9=H}if(C.1F.2t(":").Q==3){C.CS=H}F{if(C.1F.L(\'ar:ar\')>-1){C.CK=H}}}if(C.AV==1&&C.1F.L("-")==0){C.DT=1}if(C.1F.L("///")>0&&Z=="4b"){C.cR=C.1F.2t("///");C.1F=2D[0]=C.cR[0]}}if(v.nr==1){1G(8U,1h);1G(8U,4v);1G(8U,2G)}}F{if(I(C.1q)){2D[0]=C.1q;if(2D[0].L("///")>0&&2D[0].L("hf")==-1){2D=C.1q.2t("///")}if(I(C.iB)){2D[1]=C.iB}if(C.jj==1){if(I(C.nt)){if(C.nt!=\'\'){2D.2P(C.nt);fK=2D.Q-1}}}}}if(Z=="4b"){if(C.LD==1&&I(C.CQ)){C.nA=C.2T}}B 18=1M("1R");if(C.1i==\'c9\'){o.c9.1J(18)}F{if(C.1i.L(\'S\')>-1&&v.1u.1l==1&&v.1u.cs==1){o.1u.1J(18)}F{o.1D.1J(18)}}B jd=1M("1R");18.1J(jd);K(18,{"1i":"29","1b":0,"1f":0,"1o":1,"eB":"gg","qA":"h0"});if(I(C.3X)){if(C.3X!=\'\'){4w(18,{"id":(v.id+"di"+C.3X)})}F{}}if(C.AU==1){K(18,{"4u":"2E 0.2s 2O"})}if(2D.Q>0){U(i=0;i<2D.Q;i++){1q[i]=1M("1R");K(1q[i],{"1i":"29","1f":0,"1b":0,"6C":"1I","1o":C.a,"4u":"1o 0.1s 2O,2E 0.1s 2O"});if(C.1B=="ey"&&C.2X!=\'\'){if(C.2X.L(".qJ")>-1||C.2X.L(".j5")>-1||C.2X.L("hf")>-1){C.2X.L("//")==-1&&C.2X.L("hf")==-1?C.2X=\'//\'+C.2X:\'\';B z=1M("3N");C.iF=1;z.1p("ej",ng);z.2X=C.2X;1q[i].1J(z);C.w=1q[i].1Y;C.h=1q[i].2L;if(I(C.3X)){if(C.3X!=\'\'){4w(1q[i],{"id":(v.id+"di"+C.3X+"B4")})}}}}if(C.1B=="1F"){K(1q[i],{"1v":(C.1v),"eB":C.aE,"qG":C.3V,"gk-dI":C.hn+\'px\',"2S":"0 e7 0 e7","9W-7R":"cj"});if(C.2u==1){if(C.1F.L("<a ")>-1||1a=="am"){K(1q[i],{"6C":"2A"})}}if(C.B1==1){K(1q[i],{"3V-fw":"B1"})}2D[i]==\'6W\'?2D[i]=2M("6W"):\'\';1q[i].1V=tj(2D[i]);1G(n8,1h);C.w=1q[i].1Y;C.h=1q[i].2L;if(I(C.3X)){if(C.3X!=\'\'){4w(1q[i],{"id":(v.id+"di"+C.3X+"LE")})}}}if(C.1B=="K"){B5(2D[i],C.1v,1q[i])}B av=2D[i].6B();B j2=av.L(\'<2p\')>-1||av.L(\'<Lr\')>-1;if(C.1B=="2p"&&(av.L(\'<g>\')>-1||j2)){if(Z=="4V"||Z=="4b"){av=av.1Z(/hX/g,\'hX\'+v.id+1a)}if(av.L(\'3S\')>-1){bo(1q[i])}1q[i].1V=(!j2?"<2p W=\'20\' X=\'20\' 3K:3L=\'3n://3C.w3.3O/6U/3L\' 3K=\'3n://3C.w3.3O/47/2p\'>":\'\')+av+(!j2?"</2p>":\'\');1q[i].1Y>20?C.w=1q[i].1Y:\'\';1q[i].2L>20?C.h=1q[i].2L:\'\';K(1q[i],{"W":C.w,"X":C.h});if(C.cK!=-1){iS(1q,C.cK)}if(I(C.3X)){if(C.3X!=\'\'){4w(1q[i],{"id":(v.id+"di"+C.3X+"B4"+i)})}}}18.1J(1q[i]);i>0?1l(1q[i]):\'\'}9X();iv?ng():\'\';if(C.2T=="4L"){C.4L=1;C.1l=1;o.4L?1q[0].1V=o.4L.jY(C.cK!=-1?C.cK:\'#3J\'):\'\';1q[0].hC=6c;1q[0].hD=5J;1q[0].gF=cp}F{if((bg.1Y*C.1x<35||bg.2L*C.1x<35)&&C.1B!=\'1F\'){mV();bo(7k)}F{bo(bg)}}if(Z=="4b"){if(C.dr==1&&I(C.2T)){if(C.2T.L("2Z:")==0){B 1H=C.2T.1w(4).2t(",");if(1H.Q==2){B nl=1H[1].2t("/");if(nl.Q==2){1H[0]==\'hd\'?1H[0]="3Y":\'\';if(v[1H[0]]==nl[1]){C.a=1;K(1q[0],{"1o":C.a})}}}}}}if(Z=="1d"&&C.dz==1){dz=1y Lq(18,bg)}if(C.2u==0){K(18,{"6C":"1I"})}if(C.iF==1){1l(bg)}if(C.2c==1){jh()}if(C.1i.L("2l")>-1){dB=1}if(C.1i.L("1f")>-1){AD=1}if(C.1i.L("2F")>-1||C.1i.L("18")>-1){hy=1}2n();B t=\'\';if(C.92!=0){t+="bX("+C.92+"gM)"}if(C.Le==1){t+=" 3l(-1)"}if(C.Lf==1){t+=" 3a(-1)"}if(t!=\'\'){K(18,{"2E":t})}if(Z=="dO"){eS()}B 1H=[];B i;if(Z=="19"){1H=[\'df\',\'AB\',\'j9\',\'Ay\',\'rJ\',\'lP\'];U(i=0;i<1H.Q;i++){if(I(C[1H[i]])&&!I(v.19[1H[i]])){v.19[1H[i]]=C[1H[i]]}}}if(Z=="1N"){1H=[\'lD\',\'sw\',\'su\'];U(i=0;i<1H.Q;i++){if(I(C[1H[i]])&&!I(3k[1H[i]])){v[1H[i]]=C[1H[i]]}}}C.bV==1?bu():\'\';if(Z=="4b"&&C.on==0){3g(18)}}E mV(){if(7k){7k.4Q.2U(7k)}7k=1M("1R");K(7k,{"1i":"29","1f":0,"1b":0,"W":C.1B=="ey"?bg.1Y:(bg.1Y>35?bg.1Y:35)*C.Az,"X":C.1B=="ey"?bg.2L:(bg.2L>35?bg.2L:35)*C.sU});C=4o(C,\'gy\',\'gy\');if(v.1u.gS==1||C.gS==1){K(7k,{"2x-1v":"#i1","1o":0.5})}18.1J(7k)}E bo(x){if(Z.L("Y")==0&&V.Q==1){C.2u=0}if(Z=="4b"&&C.dr==0){C.2u=0}if(C.2u==1){if(C.gq==1){K(x,{"6t":"3S"})}K(x,{"6C":"2A"});if(o.1m.2y){x.1p("ae",E(17){17.9G();ae=H});x.1p("e8",E(17){17.9G()});x.1p("eu",E(17){17.9G();if(!ae){aq(17)}ae=J})}F{x.dH=aq}}F{K(x,{"6t":"6S"})}if(!o.1m.2y){x.hC=6c;x.hD=5J}if(C.3G==1||C.2c==1){x.gF=cp}}E 9X(){if(bg){bg.4Q.2U(bg)}bg=1M("1R");K(bg,{"1i":"29","1f":0,"1b":0});if(I(C.3X)){if(C.3X!=\'\'){4w(bg,{"id":(v.id+"di"+C.3X+"Lg")})}}w=C.w;h=C.h;C=4o(C,\'2K\',\'2K\');C=4o(C,\'bQ\',\'bQ\');if(C.1B=="1F"){w=1q[nw].1Y;h=1q[nw].2L}C=4o(C,\'dh\',\'dh\');C=4o(C,\'AA\',\'AA\');if(o.1m.6i){C.DP/=C.1x;C.DO/=C.1x;C.DI/=C.1x;C.DM/=C.1x}if(I(C.3X)&&I(v.4b)&&C.Z=="4b"){if(C.3X!=\'\'&&2i(v.4b)==\'3r\'){U(B i=0;i<42.3I(v.4b).Q;i++){if(v.4b[i][C.3X]){if(v.4b[i][C.3X]=="8l"){C.on=0}F{B 1H=v.4b[i][C.3X].2t(":");if(1H[0]=="2K-1b"){if(1H[1].L("%")>0){C.jn=2w(1H[1])}F{C.3P=2w(1H[1])}}}}}}}C.h=h;C.w=w;if(C.bg==1){h=h+C.8G+C.8D;w=w+C.6q+C.6T;C.h=h;C.w=w;if(C.1B=="1F"){C.ia=1q[0].2L}}F{C.5B=0}K(bg,{"W":(C.AG==1?AH:w),"X":h,"sS":(C.ij*h)/2,"2x":C.5v,"1o":C.5B,"4u":"1o .1s 2O, 2x .1s 2O, 2E .1s 2O"});if(C.1B=="ey"){K(bg,{"W":w,"X":h,"sS":(C.ij*h/C.1x)/2,})}if(C.tm==1){K(bg,{"2W":"5z 6y "+C.tr})}jd.1J(bg)}E 2n(){K(bg,{"1f":(-bg.2L/2),"1b":(-bg.1Y/2)});if(7k){B x=C.1B=="ey"?bg.1Y:(bg.1Y>35?bg.1Y:35);B y=C.1B=="ey"?bg.2L:(bg.2L>35?bg.2L:35);K(7k,{"1f":(-y/2)+C.zU-C.zT,"1b":(-x/2)+C.Ld-C.Lc})}U(i=0;i<2D.Q;i++){if(C.1B=="2p"){K(1q[i],{"1f":-2I.4N(2w(1q[i].C.X))/2,"1b":-2w(1q[i].C.W)/2})}F{K(1q[i],{"1f":-2I.4N(1q[i].2L)/2,"1b":-1q[i].1Y/2})}if(bg){K(1q[i],{"1f":(4X(1q[i].C.1f)+C.8G/2-C.8D/2+C.DI/2+C.DM/2),"1b":(4X(1q[i].C.1b)+C.6q/2-C.6T/2+C.DP/2+C.DO/2)})}}}E 6c(){B i;7P=H;if(C.c5==1){if(on&&I(C.iB)){i=1}F{i=0}if(9U&&c5.Q>2){i=2}if(c5[i]){jm();1n(1q[c5[i]])}}if(C.bg==1){if(C.7v!=-1){K(bg,{"1o":C.7v})}if(C.7i!=-1){K(bg,{"2x":C.7i})}}if(C.6r>-1&&!DN){U(i=0;i<2D.Q;i++){if(1q[i].C.6b!="3G"){K(1q[i],{"1o":C.6r})}}}if(C.iA!=-1){iS(1q,C.iA)}if(C.L9==1){cL=cL+45;K(1q[0],{"2E":"bX("+cL+"gM)"})}if(C.gi>C.1x&&C.gi>-1){1x(C.gi)}if(Z=="1d"&&o.S.al()){}F{if(C.2c==1&&C.bV!=1){1n(2c);K(2c,{"1o":1})}}if(Z=="4V"){o.V.4G(H);o.4G=H}o.bY=H;o.S.hO(1a,"7P")}E 5J(){7P=J;B i;if(C.c5==1){if(on&&I(C.iB)){i=1}F{i=0}if(9U&&c5.Q>2){i=2}jm();1n(1q[i])}if(C.bg==1){if(C.7v!=-1){K(bg,{"1o":C.5B})}if(C.7i!=-1){K(bg,{"2x":C.5v})}}if(C.6r>-1){U(i=0;i<2D.Q;i++){if(1q[i].C.6b!="3G"){K(1q[i],{"1o":C.a})}}}if(C.gi>-1){1x(C.1x)}if(C.iA!=-1){iS(1q,(C.cK==-1?\'#3J\':C.cK))}if(Z=="4V"&&!o.2e){o.V.4G(J);o.4G=J}if(C.2c==1&&C.bV!=1){1l(2c);K(2c,{"1o":0})}o.bY=J;o.S?o.S.hO(1a,"6l"):\'\'}E aq(17){17.5F=H;if(!iV){o.S.dP(1a);if(Z=="4b"){fE()}if(C.2c==1&&C.bV!=1){1l(2c);K(2c,{"1o":0})}if(C.La==1){cL=cL+45;K(1q[0],{"2E":"bX("+cL+"gM)"})}g7=H;if(C.E3==1||(1a=="mM"&&C.1l==1&&C.CJ==1)){o.S.4M()}}}E fE(){if(2D){if(2D.Q>1){if(on==H){1n(1q[0]);1l(1q[1])}F{1n(1q[1]);1l(1q[0])}}if(C.2c==1&&bi.Q>1){3w.1V=(on==H?bi[0]:bi[1]);bu()}}if(I(C.nA)){if(on==H){C.2T=C.nA}F{C.2T=C.CQ}}if(I(C.cR)){if(C.cR.Q>1){if(on==H){6d(C.cR[0])}F{6d(C.cR[1])}}}on=on!=H;if(C.bg==1&&I(C.nD)){if(C.nD!=-1){if(on){C.Cv=C.5v;C.5v=C.nD}F{C.5v=C.Cv}9X();bo(bg);2n();if(C.1B=="1F"){8U()}F{1x(C.1x)}}}}E sI(17){17.5F=H;o.S.dP(1a)}E jm(){U(B i=0;i<2D.Q;i++){if(1q[i].C.6b!="3G"){K(1q[i],{"1o":C.a});1l(1q[i])}}}E n8(1F){if(1q[0]){if(1q[0].1Y>o.3f-C.3P-C.4x-C.6q-C.6T){if(C.nh==1){if(!1F){1F=1q[0].1V}1q[0].1V=\'<nh>\'+1F+\'</nh>\'}F{K(1q[0],{"9W-7R":"rq"})}K(1q[0],{"W":o.3f-C.3P-C.4x-C.6q-C.6T})}}}E ng(){if(bg){iv=J;C.iF=0;1l(bg);if(1q[0]){C.w=1q[0].1Y*C.1x;C.h=1q[0].2L*C.1x;if(C.mW>0){C.h=C.mW*C.1x;K(1q[0],{X:C.mW})}1x(C.1x)}C.aF=0;9X();mV();bo(7k);1n(bg);2n();o.S.4J();if(!62(18)){3g(18)}}F{iv=H}}E At(17){17.5F=H}E cp(){if(!o.bY){6c()}bu()}E 1x(x){if(x>0){if(o.1m.6i&&C.bV!=1){K(bg,{"Dj":x+""})}F{K(bg,{"2E":"1x("+x+")"})}U(i=0;i<2D.Q;i++){if(o.1m.6i&&C.bV!=1){K(1q[i],{"Dj":x+""})}F{K(1q[i],{"2E":"1x("+x+")"})}}3l=x;3a=x}}E jh(){2c=1M("1R");K(2c,{\'1i\':\'29\',\'1b\':0,\'1f\':0,\'X\':\'2A\',"1o":0,"4u":"1o 0.1s 2O"});8X=1M("1R");C=4o(C,\'gd\',\'gd\');C=4o(C,\'Dk\',\'Dk\');K(8X,{\'1i\':\'29\',\'1b\':0,\'1f\':0,\'W\':\'1h%\',\'X\':30,\'2x-1v\':C.gf,\'1o\':C.hA,\'2W-6k\':C.qw});3w=1M("1R");K(3w,{\'1i\':\'29\',\'1b\':C.jc,\'1f\':C.jb,\'1v\':C.qy,\'3V-ho\':C.qx,\'3V-3t\':C.gr,"gk-dI":C.qr+\'px\',\'1o\':C.qq,"2C-X":"1",\'9W-7R\':\'cj\'});if(C.hH==1){7M=1M("1R");7M.1V=\'<2p W="dR" X="iz" sh="0 0 8 6" 7p="1.1" 3K="3n://3C.w3.3O/47/2p" 3K:3L="3n://3C.w3.3O/6U/3L"><dy id="BJ" 46="1I" 4A="#\'+C.gf.1Z("#","")+\'" 4A-BE="Bz" 2N="0 0 8 0 4 6"></dy></2p>\'}if(C.bV==1){K(2c,{"1o":1});bo(2c)}F{K(2c,{"6C":"1I"})}18.1J(2c);3w.1V=C.3w==\'\'?2M(Z):bi[0];2c.1J(8X);2c.1J(3w);if(C.hH==1){2c.1J(7M);B mY=o.iE?\'-dR\':\'-iz\';B ps=C.Lb;if(!I(ps)){ps=\'\'}B tp=ps.L("1f")>-1;if(tp){K(7M,{"2E":"bX(-Lh)"})}K(7M,{\'1i\':\'29\',\'2l\':(ps.L("2l")>-1?10*C.1x:\'2A\'),\'1b\':(ps.L("1b")>-1?10*C.1x:(ps==\'\'||ps==\'1f\'?\'50%\':\'2A\')),\'2K-1b\':(ps==\'\'||ps==\'1f\'?\'-qm\':0),\'2F\':(tp?\'2A\':mY),\'1f\':(tp?mY:\'2A\'),\'1o\':C.hA})}bu()}E bu(){if(C.2c==1){K(2c,{"1f":(hy==1?-h-2c.2L+3:-2c.2L/2)+C.Li-C.Lo,"1b":(dB==1?-3w.1Y:(hy==1?-w/2:+3w.1Y))-(hy==1?0:3w.1Y/2+5)+C.Lp-C.Ln,"X":C.jb+C.gr+C.BX,"W":C.Cn+3w.1Y+C.jc});K(8X,{\'X\':2c.2L});2c.C.5j="2G"}}G.c=E(){O 18};G.s=E(x){O C[x]};G.ss=E(x,x2){O I(C[x])?C[x][x2]:J};G.g=E(x){9N(x){1j"W":O w;1g;1j"X":O h;1g;1j"x":O 4X(18.C.1b);1g;1j"y":O 4X(18.C.1f);1g;1j"1o":O 18.C.1o?18.C.1o:1;1g;1j"1n":O 3U;1g;1j"3l":O 3l;1g;1j"3a":O 3a;1g;1j"Z":O Z;1g;1j"9Y":O 9Y;1g;1j"g7":O g7;1g;1j"1B":O C.1B;1g;1j"Q":O C.hU?C.hU:0;1g;1j"1a":O 1a;1g;1j"x0":O x0;1g;1j"y0":O y0;1g;1j"7P":O 7P;1g;1j"1d#":O 9Y.L("1d#")==0;1g;1j"1d:":O 9Y.L("1d:")==0;1g;1j"1U#3U":O mQ;1g;6S:O J}};G.1U=E(k,x){9N(k){1j"1n":7P?5J():\'\';3U=x;1g;1j"2m":CY(x);1g;1j"6s":6s(18);1g;1j"3g":3g(18);1g;1j"1x":1x(x);1g;1j"3l":K(18,{"2E":"3l("+x+")"});3l=x;1g;1j"3a":K(18,{"2E":"3a("+x+")"});3a=x;1g;1j"1o":K(18,{"1o":x});1g;1j"mT":K(1q[0],{"1o":x});1g;1j"iI":K(1q[0],{"D9":"iI("+x+")"});1g;1j"1b":K(18,{"1b":x});1g;1j"1f":K(18,{"1f":x});1g;1j"W":K(18,{"W":x});1g;1j"X":K(18,{"X":x});1g;1j"ro":C.ro=x;1g;1j"dB":dB=x;1g;1j"1U#3U":mQ=x;1g;1j"x":K(18,{"1b":x});1g;1j"y":K(18,{"1f":x});1g;1j"5p":C.5p=x;1g;1j"x0":x0=x;1g;1j"y0":y0=x;1g;6S:O J}};E CY(x){if(x&&o.1m.2y){iV=H;1G(Di,cA)}if(!x){if(C.jj==1&&9U){1l(1q[fK]);1n(1q[0]);9U=J}}if(C.iF==1){x?1n(18):1l(18)}F{if(1a=="Lm"||1a=="Dc"){x?1n(18):1l(18)}F{K(18,{"2m":(x?"5a":"1I")})}3U=x;x?1n(18):\'\'}}E Di(){iV=J}G.6d=E(1F){6d(1F);C.Lj=1F};G.nb=E(){K(18,{"2E":"bX("+j0+"gM)"});j0+=20};G.Cx=E(x){if(C.1F.L("{1N")>-1){6d(C.1F)}};G.fE=E(){fE()};E 6d(1F){if(C.1B=="1F"){if(I(1F)){if(C.CS){if(1F.Q==4){1F=(C.n9?\'0:0\':\'ar:0\')+1F}if(1F.Q==5){1F=(C.n9?\'0:\':\'ar:\')+1F}}if(C.CK){if(1F.Q==4){1F=\'0\'+1F}}C.hU=1F.Q}1F=(C.E0==1?\'| \':\'\')+(C.DU==1?\'/ \':\'\')+(C.DT==1?\'-\':(C.DW==1?\'- \':\'\'))+1F;B DQ=1q[0].1Y+(C.bg==1?C.8G+C.8D:0);B DL=1q[0].2L+(C.bg==1?C.8G+C.8D:0);1q[0].1V=(Z=="4b"?tj(1F):1F);if(C.Lk==1){1q[0].1V+=\'<6V C="2m:dj-5a;W:dK"></6V><6V C="2W-1f: e7 6y #do;2W-1b: e7 6y dv;2W-2l: e7 6y dv;1i: 29;2l:e7;1f: 50%;2K-1f: -5z;"></6V>\'}if(Z=="1N"){K(1q[0],{"W":"2A","9W-7R":"cj"});n8(1F)}C.w=1q[0].1Y+(C.bg==1?C.8G+C.8D:0);C.h=1q[0].2L+(C.bg==1?C.8G+C.8D:0);if(DQ!=C.w||DL!=C.h||(C.w>0&&n7==0)){8U()}if(1q[0].1Y>0){n7=C.w}F{if(1F!=\'\'){1G(8U,1h)}}}}G.8U=E(){8U()};E 8U(){if(C.1B=="1F"){if(1q[0]){if(1q[0].1Y>0){w=C.w=1q[0].1Y;h=C.h=1q[0].2L;9X();bo(bg);2n();o.S.rA()}}}}G.Du=E(x){if(C.Ds==1&&!o.1m.2y){B y=\'hX\';B z=[];U(B i=1;i<4;i++){z[i]=1K.8m(y.8P(v.id,1a,\'Ll\',i))}if(z[1]){if(x<=0.2){z[3]?1l(z[3]):\'\';z[2]?1l(z[2]):\'\';z[1]?1l(z[1]):\'\'}if(x>0.2&&x<=0.5){z[3]?1l(z[3]):\'\';z[2]?1l(z[2]):\'\'}if(x>0.2){z[1]?1n(z[1]):\'\'}if(x>0.5){z[2]?1n(z[2]):\'\'}if(x>0.5&&x<=0.8){z[3]?1l(z[3]):\'\'}if(x>0.8){z[3]?1n(z[3]):\'\'}}}};G.On=E(){if(!on){if(2D){if(2D.Q>1&&V.Q>1){1l(1q[0]);1n(1q[1])}}if(V.Q>1){Z=V[1];if(C.2c==1){3w.1V=sN(1);bu()}}if(C.jj==1&&9U){1l(1q[fK]);9U=J}on=H}};E sN(x){O C.3w==\'\'?2M(V[x]):(bi.Q>1?bi[x]:bi[0])}G.eb=E(x){B y=\'hX\';B z=1K.8m(y.8P(v.id,1a,\'LK\'));if(z){K(z,{"4u":"2E 0.1s 7C-6l"});if(x==1){z.C.2E=\'sV(0, 0)\'}F{z.C.2E=\'sV(-Ao, 0)\'}}F{if(x==1){C.a=1}F{C.a=0.5}}K(1q[0],{"1o":C.a})};G.fk=E(){if(on){if(2D){if(2D.Q>1&&V.Q>1){1n(1q[0]);1l(1q[1])}}Z=V[0];if(V.Q>1){if(C.2c==1){3w.1V=sN(0);bu()}}on=J;9U=J}};G.sI=E(){if(C.jj==1){jm();1n(1q[fK]);9U=H}};G.CA=E(){B 2o=J;if(C.1l==1&&C.CG==1){if(62(o.2g)){2o=H}}if(!2o){6s(18);B bx=18.ay("*");U(B i=bx.Q;i--;){K(bx[i],{"5p-1O-6p":"LL"})}3U=H}};G.eS=E(){eS()};E eS(){3g(18);B bx=18.ay("*");U(B i=bx.Q;i--;){K(bx[i],{"5p-1O-6p":"8C"})}3U=J}G.4C=E(){if(2D.Q>0){U(i=0;i<2D.Q;i++){18.2U(1q[i]);1q[i]=1S}}if(bg){bg.du("dH");bg.du("hC");bg.du("hD");bg.4Q.2U(bg);bg=1S}if(C.1i==\'c9\'){o.c9.2U(18)}F{if(18.4Q==o.1D){o.1D.2U(18)}F{if(o.1u){if(18.4Q==o.1u){o.1u.2U(18)}}}}if(2c){18.2U(2c)}18=1S};G.D0=E(){dz?dz.tg():\'\'};E tj(x){B z=x+\'\';if(x.L(\'{Y}\')>-1&&I(o.3i)){x=x.1Z(\'{Y}\',gD(o.3i.96().t))}if(x.L(\'{1N\')>-1){B y=o.cW?o.cW:(v.1N?v.1N:\'\');if(x.L(\'{b0}\')>-1&&o.S){x=x.1Z(\'{b0}\',o.S.cZ(\'b0\'))}if(o.aY&&o.S){y=o.S.cZ(\'aY\')}x=x.1Z(\'{1N}\',y);if(o.aY&&!o.S){1G(6d,1h,z)}}O x}E iS(1q,fh){U(B i=0;i<1q.Q;i++){CZ(1q[i],fh)}if(C.2T=="4L"){if(o.4L){o.4L.D8(1q[0],fh)}}}};B D7=E(1a,Z){B i;B C=[];B w;B h;B bg;B 3U=H;B x0;B y0;B 3l=1;B 3a=1;B ei=0;B 8w=0;B Ma;B 3q;B i5;B 2u;B 3p;B Bo;B Ch;B rd;B Cf;B 2c;B 8X;B 3w;B 7M;B 2N=[];o.Av=-1;B ih;B 7P;B r5;U(i in dc.R){C[i]=dc.R[i]}B Z=v[1a].Z;B 1B=v[1a].1B;U(i in dc[Z]){C[i]=dc[Z][i]}U(i in v[1a]){C[i]=v[1a][i]}C.w=2w(C.w);C.h=2w(C.h);C=4o(C,\'2K\',\'2K\');C=4o(C,\'bQ\',\'bQ\');B 18=1M("1R");if(v.1u.cs==1&&v.1u.1l==1){o.1u.1J(18)}F{o.1D.1J(18)}Z=="2C"?o.c9=18:\'\';K(18,{"1i":"29","1f":0,"1b":0,"1o":1,"eB":"gg","qA":"h0"});if(C.Da==1){18.C.5j=5}9X();B 7K=1M("1R");K(7K,{"1i":"29","2F":2I.4N(-C.h/2),"1b":2I.4N(-C.w/2)});if(C.B0==1){K(7K,{"2W-6k":C.6Q*C.h/2,"X":C.h,"6A":"3G","3S-2H":"1I"})}if(I(C.3X)){if(C.3X!=\'\'){4w(18,{"id":(v.id+"di"+C.3X)})}}18.1J(7K);if(Z==\'2C\'&&v.t7==1){Bn()}if(C.2c==1){jh()}B 8g=1M("1R");gB(8g,0.3,(C.5d==1?"2O-5d(#"+C.D5+", #"+C.iw+")":C.iw),C.w,C.Mb);if(C.CF==1&&I(C.it)){B hb=1M("1R");hb.1V=C.it.1Z(/\\#CV/g,"#"+C.iw);8g.1J(hb);K(hb,{"1i":"29","2F":-2I.4N(C.h/2),"1b":0,"3S-2H":"1I"});K(8g,{"6A":"3G","2x":"1I"});B x=["t8","dy","je","g3","c7"];U(B y=0;y<x.Q;y++){B z=hb.t6("2p "+x[y]);if(z.Q>0){U(B y2=0;y2<z.Q;y2++){z[y2].C.4A=C.iw}}}}7K.1J(8g);B M9=[];B af=1M("1R");gB(af,C.D2,(C.5d==1?"2O-5d(#"+C.Db+", #"+C.De+")":C.De),0,C.M8);7K.1J(af);if(C.6r>0){B cu=1M("1R");gB(cu,C.CW,C.M5,0,C.6r);7K.1J(cu)}B 6v=1M("1R");gB(6v,C.CD,(C.5d==1?"2O-5d(#"+C.CC+", #"+C.1v+")":C.1v),0,C.a);if(C.CF==1&&I(C.it)){B iy=1M("1R");iy.1V=C.it.1Z(/\\#CV/g,"#"+C.1v);K(iy,{"1i":"29","2F":-2I.4N(C.h/2),"1b":0,"3S-2H":"1I"});K(6v,{"6A":"3G","2x":"1I"});6v.1J(iy)}if(C.52==1){B 7I=1M("1R");C=4o(C,\'tw\',\'tw\');C=4o(C,\'tu\',\'tu\');K(7I,{"1i":"29","2F":C.h/2,"2l":0,"3S-2H":"1I","3V-3t":(C.CO+"px"),"1v":C.5f,"2C-X":"1h%","2S-1f":C.M6,"2S-2F":C.M7,"2S-1b":C.Mc,"2S-2l":C.Md,"2K-1f":C.Mj,"2K-2F":C.Mk,"2K-1b":C.Ce,"2K-2l":C.Cb,"2W-6k":(C.DS+"px"),"2m":"1I"});if(C.AJ==1){K(7I,{"2x":"#"+C.AM})}6v.1J(7I);B gX=J;B gN=J}o.jg=C.h;7K.1J(6v);if(C.fi==1){v.fi=1;B gv=1M("1R");K(gv,{"1i":"29","1f":0,"1b":0});18.1J(gv);I(v.2N)?qW(v.2N):\'\'}if(C.3p==1){if(C.cq.6B().L(\'<2p\')==-1){C.cq==\'\'?C.cq="<2p W=\'20\' X=\'20\'><g><c7 ry=\'5\' rx=\'5\' cy=\'10\' cx=\'10\' 4A=\'#do\'/></g></2p>":\'\'}3p=1M("1R");3p.1V=C.cq.6B();C=4o(C,\'AO\',\'AO\');K(3p,{"1i":"29","1f":-10+C.Mi-C.Mh,"1b":-2G,"3S-2H":"1I","X":20,"W":C.ds,"1o":C.qZ,"4u":"2E 0.1s 2O, 1o 0.1s 2O"});if(C.gz==1||C.rh==1){K(3p,{"2E":"1x(0)"})}F{if(C.ik!=1){K(3p,{"2E":"1x("+C.ik+")"})}}18.1J(3p);if(C.t0!=-1){B x=["t8","g3","c7"];U(B y=0;y<x.Q;y++){B z=3p.t6("2p "+x[y]);if(z.Q>0){U(B y2=0;y2<z.Q;y2++){z[y2].C.4A="#"+C.t0}}}}C.dm=3p.1Y}if(C.92!=0){K(18,{"2E":"bX("+C.92+"gM)"})}if(C.3G==1){1l(18);3U=J}if(Z=="1P"){if(C.1l==1&&C.gT==1){o.gK=H;C.3G=H}F{o.gK=J}}C.9L=0;if(C.92!=0){C.gx=2I.tP(C.92);if(C.gx>45&&C.gx<Me){C.9L=90}if(C.gx>Mf&&C.gx<B3){C.9L=C2}}E gB(x,y,z,B7,Ct){K(x,{"1i":"29","2F":0,"1b":0,"W":B7,"X":C.h,"2x":z?(z.L("2O")>-1?z:\'#\'+z):\'\',"2W-6k":(C.B0==1?1:C.6Q*C.h/2),"1o":Ct,"3S-2H":"1I","4u":"2E 0.2s 7C-in-6l"})}E 9X(){bg=1M("1R");C=4o(C,\'dh\',\'dh\');B ia=C.h+C.8G+C.8D;B AS=C.w+C.6q+C.6T;if(C.bg==1){}F{C.5B=0}C=4o(C,\'gy\',\'gy\');if(v.1u.gS==1||C.gS==1){C.5v=\'#i1\';C.bg=1;C.5B=0.5}K(bg,{"1i":"29","1f":0,"1b":0,"W":AS,"X":ia*C.sU,"sS":(C.ij*ia)/2,"6a":C.5v,"1o":C.5B,"6C":"2A","4u":"1o .1s 2O, 2x .1s 2O"});if(C.tm==1){K(bg,{"2W":"5z 6y #"+C.tr})}if(C.2u==1){if(C.gq==1){K(bg,{"6t":"3S"})}if(!o.1m.2y){bg.dH=aq;bg.Mg=r6;bg.M4=qX;bg.gF=cp}}F{K(bg,{"6t":"6S"})}if(!o.1m.2y){bg.hC=6c;bg.gF=cp;bg.hD=5J}if(o.1m.2y){bg.1p("e8",E(17){17.5F=H;if(!I(17.5E)&&17.ao.Q>0){17.5E=17.ao[0].ge;17.7V=17.ao[0].mk}ih=17;6c(17);qX(17)});bg.1p("eu",E(17){17.5F=H;5J(17);r6(ih)});bg.1p("2u",E(17){17.5F=H});bg.1p("ae",E(17){if(!I(17.5E)&&17.ao.Q>0){17.5E=17.ao[0].ge;17.7V=17.ao[0].mk}ih=17;cp(17)})}K(bg,{"1b":2I.iW(-C.w/2-C.6q)});K(bg,{"1f":2I.iW(-C.h/2-C.8G+C.zU-C.zT)});18.1J(bg)}E 2n(W){if(W!=w){w=W;o.qi=w;B aK=w/8g.1Y;K(bg,{"W":(w+C.6q+C.6T),"1b":-w/2-C.6q,});K(7K,{"1b":-w/2});K(8g,{"W":w});K(7K,{"W":w});B xx=af.1Y*aK;if(xx>8g.1Y){xx=8g.1Y}K(af,{"W":xx});B wp=6v.1Y*aK;K(6v,{"W":wp});ra(wp,J);if(Z=="2C"){BA()}if(C.fi==1){ee()}}}E ra(x,1I){if(C.3p==1){if(x<C.dm/2&&C.ds!=20){x=C.dm/2}if(x>w-C.dm/2&&C.ds!=20){x=w-C.dm/2}B y=x-w/2-C.dm/2+C.M3-C.LR;K(3p,{"1b":y})}}E rg(){K(3p,{"2E":"1x("+C.ik+")"})}E 6c(17){o.S.hO(1a,"7P");if(C.bg==1){if(C.7v!=-1){B m=1y 5g({"mc":bg,"1B":"7j","to":C.7v,"Y":0.1,"me":(1a+"bg")})}if(I(C.7i)){if(C.7i!=-1){K(bg,{"2x-1v":C.7i})}}}if(I(C.hu)){if(C.hu!=-1){K(6v,{"2x-1v":C.hu})}}if(C.3p==1){if(C.A0==1&&I(C.r0)){if(C.i7==1&&3q){}F{3p.1V="<2p W=\'"+C.ds+"\' X=\'20\' 3K:3L=\'3n://3C.w3.3O/6U/3L\' 3K=\'3n://3C.w3.3O/47/2p\'>"+C.r0.6B()+"</2p>"}}if(C.gz==1){if(C.rh==1&&!o.1A){}F{rg()}}F{if(C.ib!=-1){B m2=1y 5g({"mc":3p,"1B":"7j","to":C.ib,"Y":0.1,"me":(1a+"3p")})}}}if(C.2c==1&&(o.P.1k()>0||Z=="1P")){1n(2c);K(2c,{"1o":1})}if(C.ep>0){K(bg,{"2E":"3a("+((C.ep-1)/5+1)+")"});r4(C.ep)}if(Z=="1P"){o.V.4G(H);o.4G=H}o.bY=H}E r4(x){K(8g,{"2E":"3a("+x+")"});K(af,{"2E":"3a("+x+")"});cu?K(cu,{"2E":"3a("+x+")"}):\'\';K(6v,{"2E":"3a("+x+")"})}E 5J(){if(!i5){if(C.6r>0){K(cu,{"W":0})}if(I(C.hu)){if(C.hu!=-1){K(6v,{"2x-1v":C.1v})}}if(C.bg==1){if(C.7v!=-1){B m=1y 5g({"mc":bg,"1B":"7j","to":C.5B,"Y":0.1,"me":(1a+"bg")})}if(I(C.7i)){if(C.7i!=-1){K(bg,{"2x-1v":C.5v})}}}if(C.3p==1){if(C.A0==1&&I(C.r0)){if(C.i7==1&&3q){}F{3p.1V="<2p W=\'"+C.ds+"\' X=\'20\' 3K:3L=\'3n://3C.w3.3O/6U/3L\' 3K=\'3n://3C.w3.3O/47/2p\'>"+C.cq.6B()+"</2p>"}}if(C.gz==1){K(3p,{"2E":"1x(0)"})}F{if(C.ib!=-1){B m2=1y 5g({"mc":3p,"1B":"7j","to":C.qZ,"Y":0.1,"me":(1a+"3p")})}}}if(C.ep>0){K(bg,{"2E":"3a(1)"});r4(1)}if(Z=="1P"&&!o.2e){o.V.4G(J);o.4G=J}o.S.hO(1a,"6l")}if(C.2c==1&&(o.P.1k()>0||Z=="1P")){1l(2c);K(2c,{"1o":0})}if(o.j6&&Z=="2C"){o.th.1l();o.Av=-1}o.bY=J}E aq(17){17.5F=H}E At(17){17.5F=H}E r6(17){if(Z=="1P"){if(o.7N){i5=H;3j(r5);r5=1G(E(){i5=J;5J()},2G)}}rn();o.3q=J;if(C.3p==1){if(C.i7==1&&I(C.qS)){3p.1V="<2p W=\'20\' X=\'20\' 3K:3L=\'3n://3C.w3.3O/6U/3L\' 3K=\'3n://3C.w3.3O/47/2p\'>"+C.cq.6B()+"</2p>"}}aj(17.5E,17.7V);o.S.dP(1a);o.S.cS(17.5E,17.7V);17.5F=H}E qX(17){3q=H;if(C.3p==1){if(C.i7==1&&I(C.qS)){3p.1V="<2p W=\'20\' X=\'20\' 3K:3L=\'3n://3C.w3.3O/6U/3L\' 3K=\'3n://3C.w3.3O/47/2p\'>"+C.qS.6B()+"</2p>"}}ei=gh(bg);8w=eO(bg);aj(17.5E,17.7V);7b(2u,1,"no")}E aj(fY,gn){B x;B Ba=2I.5C(1K.j4.aU,1K.bl.aU);B Ak=2I.5C(1K.j4.bv,1K.bl.bv);if(o.1m.2y){}F{gn=gn+Ak;fY=fY+Ba}if(C.9L>0){x=gn-ei-C.6T;2u=x/w;if(C.9L==C2){x=gn-ei-C.6q;2u=x/w;2u=(2u-1)*-1}}F{x=fY-8w-C.6q;2u=x/w;if(C.92>LS&&C.92<LT){x=fY-8w-C.6T;2u=x/w;2u=(2u-1)*-1}}2u>1?2u=1:\'\';2u<0?2u=0:\'\'}G.ee=E(){ee()};G.f9=E(){qW()};E qW(){if(2N){U(B i=0;i<2N.Q;i++){gv.2U(2N[i])}}2N=[];if(v.2N){if(2i(v.2N)=="5h"){v.2N=2j(v.2N)}U(B i=0;i<42.3I(v.2N).Q;i++){if(v.2N[i].Y){2N[i]=1M("1R");K(2N[i],{\'1i\':\'29\',\'1b\':0,\'1f\':-C.h/2,\'W\':(I(v.2N[i].W)?v.2N[i].W:C.C6),\'X\':C.h,\'1o\':(I(v.2N[i].1o)?v.2N[i].1o:C.BR),\'3S-2H\':\'1I\',\'2m\':\'1I\',\'2x-1v\':(I(v.2N[i].1v)?v.2N[i].1v:C.BQ)});2N[i].Y=v.2N[i].Y;gv.1J(2N[i])}}ee()}}E ee(){B x=o.P.1k();U(B i=0;i<2N.Q;i++){if(x>0){K(2N[i],{\'1b\':w*(2N[i].Y/x)-w/2,\'2m\':\'5a\'})}F{3g(2N[i])}}}E rn(){3q=J}E cp(17){if(C.6r>0){if(o.1A||Z!=\'2C\'){K(cu,{"W":17.5E-8w})}}if(C.2c==1&&(o.P.1k()>0||Z=="1P")){!62(2c)?1n(2c):\'\';ei=gh(bg);8w=eO(bg);aj(17.5E,17.7V);if(Z=="2C"){if(v.LQ==1){if(o.P.5H()&&o.P.an().L("?r7")>0){3w.1V=\'- \'+gD((1-2u)*o.P.1k(H))}F{3w.1V=gD(2u*o.P.1k())}}F{B d=o.P.1k();if(v.4e>0){d=d-v.4e}3w.1V=gD(2u*d)}}if(Z=="1P"){3w.1V=2I.4N(2u*1h)}K(2c,{"1f":(-3w.2L*2-C.BT*1)-(C.BU==1?(C.h/2)*(C.ep>0?C.ep:1):0),"1b":(-w/2+(17.5E+1K.j4.aU-8w)-2c.1Y/2),"X":C.jb+C.gr+C.BX,"W":C.Cn+3w.1Y+C.jc,});K(8X,{\'X\':2c.2L});2c.C.5j="2G"}if(o.j6&&Z=="2C"&&o.th){if(o.P.1k()>0){if(C.2c==0){ei=gh(bg);8w=eO(bg);aj(17.5E,17.7V)}B 1b=(-w/2+(17.5E-8w)-v.g9/2);1b>w/2-v.g9?1b=w/2-v.g9:\'\';K(o.bA,{"1f":(-v.qQ-(v.Co>0?v.Co*1:5)-v.qs),"1b":(1b<-w/2?-w/2:1b)});o.th.Y(2u*o.P.1k(),17.5E,8w,w)}}}G.c=E(){O 18};G.s=E(1a){O C[1a]};G.ss=E(x,x2){O C[x][x2]};G.g=E(x){9N(x){1j"W":O w;1g;1j"LP":O 8g.1Y;1g;1j"X":O C.h;1g;1j"x":O 4X(18.C.1b);1g;1j"y":O 4X(18.C.1f);1g;1j"1o":O 18.C.1o?18.C.1o:1;1g;1j"1n":O 3U;1g;1j"3l":O 3l;1g;1j"3a":O 3a;1g;1j"Z":O Z;1g;1j"1a":O 1a;1g;1j"x0":O x0;1g;1j"y0":O y0;1g;1j"2u":O 2u;1g;6S:O J}};G.1U=E(1a,x){9N(1a){1j"1n":3U=x;1g;1j"3q":3q=x;1g;1j"2m":Z=="2C"||C.1l==1?K(18,{"6b":(x?"3U":"3G")}):K(18,{"2m":(x?"5a":"1I")});3U=x;1g;1j"3l":K(18,{"2E":"3l("+x+")"});3l=x;1g;1j"3a":K(18,{"2E":"3a("+x+")"});3a=x;1g;1j"1o":K(18,{"1o":x});1g;1j"1b":K(18,{"1b":x});1g;1j"1f":K(18,{"1f":x});1g;1j"2u":2u=x;1g;1j"cz":C.cz=x;1g;1j"W":K(18,{"W":x});1g;1j"X":K(18,{"X":x});1g;1j"ro":C.LM=x;1g;1j"x":K(18,{"1b":x});1g;1j"y":K(18,{"1f":x});1g;1j"x0":x0=x;1g;1j"y0":y0=x;1g}};G.2n=E(x){2n(x)};G.lq=E(x){};G.dD=E(9y,9x){if(3q){if(Z=="1P"){aj(9y,9x);o.S.dP(1a);o.7N=H}aj(9y,9x);7b(2u,1,"no")}};G.cS=E(9y,9x){if(3q){rn();3q=J;aj(9y,9x);o.S.dP(1a);7b(2u,1,"no")}};E 7b(Y,1k,rc){Y<0?Y=0:\'\';if(v.4e>0&&1k>1){1k=1k-v.4e;Y=Y-v.4e}if(C.3p==1&&C.rh==1&&C.gz!=1){if(!C.Cc&&Y>0){rg();C.Cc=H}}if(3q&&1k!=1){}F{B 4c;if(1k>0&&Y>0){if(Y>1k){Y=1k}4c=w*(Y/1k);if(4c==6v.1Y){4c=-1}}F{4c=0}if(4c>=0){K(6v,{"W":4c});ra(4c,H)}if(I(7I)){if(1k<2&&Z=="2C"){if(gX){3g(7I);gX=J}}F{if(!gX){6s(7I);gX=H}7I.1V=Z=="2C"?4t(Y==0?1k:Y):2I.iW(Y*1h);if(4c<7I.jU+C.Cb+C.Ce){if(!gN){K(7I,{"1b":0,"2l":"2A"});gN=H}}F{if(gN){K(7I,{"2l":0,"1b":"2A"});gN=J}}}}}};G.7b=E(Y,1k,rc){if(1k!=Ch||Y!=Cf){7b(Y,1k,rc)}};G.BP=E(){2u>1?2u=1:\'\';2u<0?2u=0:\'\';K(6v,{"W":(2u*w)})};G.BO=E(Y,1k){if(1k>0&&Y>0){B 4c=w*(Y/1k);K(af,{"W":4X(4c)});Bo=1k;rd=Y}F{rd=0;K(af,{"W":0})}};E Bn(){o.bA=1M("1R");K(o.bA,{\'1i\':\'29\',\'1b\':0,\'1f\':0,\'W\':v.g9,\'X\':v.qQ,\'6A\':\'3G\',"3S-2H":"1I","2x-1v":"#LN","2W-6k":v.Bt+\'px\',"2m":"1I"});if(v.qs==1){K(o.bA,{"2W":v.Bl+"px 6y "+qv(\'1v\',v.Bc)})}if(v.Bg==1){K(o.bA,{"5u-bH":"rs 5z g1 4I(0,0,0,0.5)"})}o.bA.C.5j="fC";18.1J(o.bA)}E jh(){2c=1M("1R");K(2c,{\'1i\':\'29\',\'1b\':0,\'1f\':0,\'X\':\'2A\',"3S-2H":"1I","1o":0,"4u":"1o 0.1s 2O"});8X=1M("1R");C=4o(C,\'gd\',\'gd\');K(8X,{\'1i\':\'29\',\'1b\':0,\'1f\':0,\'W\':\'1h%\',\'X\':30,\'2x-1v\':C.gf,\'1o\':C.hA,\'2W-6k\':C.qw});3w=1M("1R");K(3w,{\'1i\':\'29\',\'1b\':C.jc,\'1f\':C.jb,\'1v\':C.qy,\'3V-ho\':C.qx,\'3V-3t\':C.gr,"gk-dI":C.qr+\'px\',"2C-X":"1",\'1o\':C.qq});C.BH?C.hH=C.BH:\'\';if(C.hH==1){7M=1M("1R");7M.1V=\'<2p W="dR" X="iz" sh="0 0 8 6" 7p="1.1" 3K="3n://3C.w3.3O/47/2p" 3K:3L="3n://3C.w3.3O/6U/3L"><dy id="BJ" 46="1I" 4A="\'+qk(C.gf)+\'" 4A-BE="Bz" 2N="0 0 8 0 4 6"></dy></2p>\'}18.1J(2c);2c.1J(8X);2c.1J(3w);if(C.hH==1){2c.1J(7M);K(7M,{\'1i\':\'29\',\'1b\':\'50%\',\'2K-1b\':\'-qm\',\'2F\':(o.iE?\'-dR\':\'-iz\'),\'1o\':C.hA})}};E BA(){if(o.3i&&v.aX==1&&!o.1A){B f=o.3i.96();if(f.t&&f.d){7b(f.t,f.d)}}};G.4C=E(){18.2U(7K);if(bg){bg.du("dH");bg.du("hC");bg.du("hD");bg.4Q.2U(bg);bg=1S}if(3p){18.2U(3p)}if(18.4Q==o.1D){o.1D.2U(18)}F{if(o.1u){if(18.4Q==o.1u){o.1u.2U(18)}}}18=1S}};B BC=E(){B i;B C=[];B w;B h;B 3U=H;B 3l=1;B 3a=1;B x0=0;B y0=0;B 9a=6o(iu,LO);B Z,1a="bg";B 1B="LU";C["1i"]=v.1u.1i;U(B k in v.1u){if(v.1u.2h(k)){C[k]=v.1u[k]}}if(C.1n==0){v.1u.h=C.h=0;C.2S=C.2K="0 0 0 0";C.5d=0}C["1x"]=1;C=4o(C,\'2K\',\'2K\');C=4o(C,\'bQ\',\'bQ\');if(I(C.fq)){if(C.fq!=20&&C.2K=="-20 0 0 0"){C.8L=C.fq}}B 18=1M("1R");K(18,{\'1i\':\'29\',\'1b\':0,\'1f\':0,\'W\':(C.hN==1?\'1h%\':o.9A),\'X\':C.h-C.8L,\'LV\':C.a,\'3S-2H\':\'1I\',\'eB\':\'gg\',\'qA\':\'h0\'});o.1D.1J(18);B bg=1M("1R");K(bg,{\'M1\':\'29\',\'M2\':0,\'M0\':0,\'LZ\':\'1h%\',\'X\':C.h-C.bG-C.8L,\'1o\':C.a,\'2m\':\'5a\',\'2K-1b\':C.3P,\'2K-2l\':C.4x,\'2W-6k\':C.6Q});18.1J(bg);w=18.1Y;v.h8=-C.8L;if(C.5d==1){if(C.1v==\'3z\'||v.1u.aQ!=\'\'){v.h8=98-C.h;B 3N=\'1C:aQ/qJ;hf,LW+LX/T/D+LY/Nz/NA==\';if(v.1u.aQ.L("1C:aQ")>-1){3N=v.1u.aQ}K(bg,{\'X\':C.h+v.h8,\'2x\':\'1e(\'+3N+\') fo-x 50% 1h%\',\'2x-3t\':\'2A\'})}F{B dC=\'to 2F, 4I(\'+iL(C.1v)+\',0), 4I(\'+iL(C.1v)+\',1)\';K(bg,{\'2x\':\'-rH-2O-5d(\'+dC+\')\',\'2x\':\'-41-2O-5d(\'+dC+\')\',\'2x\':\'-ms-2O-5d(\'+dC+\')\',\'2x\':\'-o-2O-5d(\'+dC+\')\',\'2x\':\'2O-5d(\'+dC+\')\'})}}F{K(bg,{\'2x-1v\':C.1v})}G.h=E(){O C.h-C.8L};G.c=E(){O 18};G.s=E(1a){O C[1a]};G.g=E(x){if(18){9N(x){1j"w":18.1Y>0?w=18.1Y:\'\';O w;1g;1j"W":O 18.1Y;1g;1j"X":O 18.2L;1g;1j"x":O 4X(18.C.1b);1g;1j"y":O 4X(18.C.1f);1g;1j"1o":O 18.C.1o?18.C.1o:1;1g;1j"1n":O 3U;1g;1j"3l":O 3l;1g;1j"3a":O 3a;1g;1j"1a":O 1a;1g;1j"x0":O x0;1g;1j"y0":O y0;1g;1j"9a":O 1a+9a;1g;6S:O J}}F{O J}};G.1U=E(1a,x){9N(1a){1j"1n":3U=x;1g;1j"w":w=x;1g;1j"2m":K(18,{"2m":(x&&!o.qO?"5a":"1I")});3U=x;1g;1j"1x":K(18,{"2E":"1x("+x+")"});3l=x;3a=x;1g;1j"3l":K(18,{"2E":"3l("+x+")"});3l=x;1g;1j"3a":K(18,{"2E":"3a("+x+")"});3a=x;1g;1j"1o":K(18,{"1o":x});1g;1j"1b":K(18,{"1b":x});1g;1j"1f":K(18,{"1f":x});1g;1j"W":K(18,{"W":x});1g;1j"X":K(18,{"X":x});1g;1j"x":K(18,{"1b":x});1g;1j"y":K(18,{"1f":x});1g;1j"x0":x0=x;1g;1j"y0":y0=x;1g}};G.4C=E(){o.1D.2U(18);18=1S}};B 7O=E(is){B i;B C=[];B f=[];B b2=[];B Pf=[];B 5q=[];B 7u=[];B 1Q=[];B f2=[];B fv=[];B Pg=[];B 4l=[];B 6h=[];B 3x=[];B bt=[];B bC=J;B 2V;B kR=-1;B 5w=H;B 1a=is;B 19;B 53=[];B bF=[];B 3F=\'\';B dl=\'\';B 5r=-1;B jX=J;B Pe=J;B jz=J;B kH=J;B ht=J;B gs=J;B k2;B rp;B jR;B hl;B rX;B jF=-1;B cN=0;B 5K="2u";B 9m=(o.1m.2y?"e8":"jK");B 9d=(o.1m.2y?"eu":"jJ");C=8J(C,v[is]);C=4o(v[is],\'2K\',\'2K\');if(C.iM==0){C.qI="0 0 0 0"}C=4o(v[is],\'dh\',\'qI\');C=4o(v[is],\'2S\',\'2S\');C.jW=0;B hG="<2p W=\'"+C.6j*2+"\' X=\'"+(C.6j*2>C.4p?(C.6j*2):C.4p)+"\' 3K:3L=\'3n://3C.w3.3O/6U/3L\' 3K=\'3n://3C.w3.3O/47/2p\'><g><c7 ry=\'"+(C.6j)+"\' rx=\'"+C.6j+"\' cy=\'"+(C.6j*2>C.4p?(C.6j):(C.4p/2))+"\' cx=\'"+C.6j+"\' 4A=\'#"+C.5f+"\'/></g></2p>";B A8="<2p W=\'"+C.6j*2+"\' X=\'"+C.4p+"\' 3K:3L=\'3n://3C.w3.3O/6U/3L\' 3K=\'3n://3C.w3.3O/47/2p\' ><g><c7 ry=\'"+(C.6j-1)+"\' rx=\'"+(C.6j-1)+"\' cy=\'"+(C.4p/2+2)+"\' cx=\'"+C.6j+"\' 46=\'#"+C.5f+"\' 46=\'1\' 4A-1o=\'0\'/></g></2p>";B xx=4;B DZ="<2p W=\'"+(xx+2)+"\' X=\'"+(C.4p)+"\' 3K:3L=\'3n://3C.w3.3O/6U/3L\' 3K=\'3n://3C.w3.3O/47/2p\'><g><2C x1=\'1\' y1=\'"+(C.4p/2-xx)+"\' x2=\'"+xx+"\' y2=\'"+(C.4p/2)+"\' 46=\'#"+C.1v+"\' 46-W=\'1\' 46-et=\'4N\'/><2C x1=\'"+xx+"\' y1=\'"+(C.4p/2)+"\' x2=\'1\' y2=\'"+(C.4p/2+xx)+"\' 46=\'#"+C.1v+"\' 46-W=\'1\' 46-et=\'4N\'/></g></2p>";B l2="<2p W=\'"+(xx+10)+"\' X=\'"+(C.4p+2)+"\' 3K:3L=\'3n://3C.w3.3O/6U/3L\' 3K=\'3n://3C.w3.3O/47/2p\' C=\'fr:1b\'><g><2C x1=\'1\' y1=\'"+(C.4p/2+2)+"\' x2=\'"+xx+"\' y2=\'"+(C.4p/2-xx+2)+"\' 46=\'#"+C.1v+"\' 46-W=\'1\' 46-et=\'4N\' /><2C x1=\'1\' y1=\'"+(C.4p/2+2)+"\' x2=\'"+xx+"\' y2=\'"+(C.4p/2+xx+2)+"\' 46=\'#"+C.1v+"\' 46-W=\'1\' 46-et=\'4N\'/></g></2p>";B 1z=1M("1R");o.1D.1J(1z);K(1z,{\'6A\':\'3G\',\'2m\':\'5a\',\'1o\':0,\'2W-6k\':C.6Q});if(is=="1d"){1z.C.5j=1h}F{1z.C.5j=99}B 18=1M("1R");if(C.C9>0&&o.3f<ca){C.aE=C.C9}K(18,{\'1i\':\'es\',\'1f\':0,\'1b\':0,\'2m\':\'5a\',\'W\':\'1h%\',\'2S-1f\':C.8G,\'2S-2l\':C.6T+20,\'2S-2F\':C.8D,\'2S-1b\':C.6q,\'1v\':C.1v,\'3V-3t\':C.aE,\'3V-ho\':C.3V,\'gk-dI\':C.hn+\'px\'});if(o.1m.6i){K(18,{\'7S-W\':BS})}if(is!=="19"){K(18,{\'6A-y\':\'8Q\'})}1z.1J(18);if(C.3D!=1){B 6N=1M("1R");K(6N,{\'2m\':\'5a\',\'6A\':\'3G\',\'2W-6k\':C.6Q});if(C.3D!=1){if(o.1m.6i){K(6N,{\'7S-W\':BS})}}18.1J(6N)}if(is=="19"){4w(18,{id:(v.id+"7l"+is)});if(C.3D==1){K(18,{\'W\':\'1h%\',\'2S-2l\':C.6T,\'2S-2F\':C.8D+20,\'6A-x\':\'8Q\',\'9W-7R\':\'cj\'});K(1z,{\'W\':o.3f-C.4x-C.3P,\'X\':C.l3+C.8G+C.8D})}F{K(18,{\'6A-y\':\'8Q\'});if(C.vz==1){lU()}}if(C.iM==1){K(1z,{\'2x-1v\':C.qE})}if(v.19.3b==1){3g(1z)}}if(C.fA==1){B 54=1M("1R");B 9u=iL(C.iM==1?C.qE:C.5v);if(C.3D==1){eZ(54,\'to 2l, 4I(\'+9u+\',\'+(C.5B*1+0.3)+\'), 4I(\'+9u+\',0)\',\'1b\',12,5,7,10,7,10,12,15);54.1p(5K,E5)}F{eZ(54,\'to 2F, 4I(\'+9u+\',\'+(C.5B*1+0.3)+\'), 4I(\'+9u+\',0)\',\'1f\',5,12,10,7,10,7,15,12);54.1p(5K,CI)}B 56=1M("1R");if(C.3D==1){eZ(56,\'to 1b, 4I(\'+9u+\',\'+(C.5B*1+0.3)+\'), 4I(\'+9u+\',0)\',\'2l\',8,5,13,10,13,10,8,15);56.1p(5K,Dq)}F{eZ(56,\'to 2F, 4I(\'+9u+\',0), 4I(\'+9u+\',\'+(C.5B*1+0.3)+\')\',\'2F\',5,8,10,13,10,13,15,8);56.1p(5K,Cw)}54.1p("jK",eQ);54.1p("jJ",eQ);56.1p("jK",eQ);56.1p("jJ",eQ);18.1p("qF",Af,{a2:H});54.1p("8K",9k);56.1p("8K",9k);1z.1J(54);1z.1J(56);4m(rp);rp=7d(D4,2G)}18.1p(9m,Ag);18.1p(9d,se);if(is=="1d"){U(B i=1;i<11;i++){if(I(v["9B"+is][is+i])){v.1d[is+i]=v["9B"+is][is+i];if(I(v["9B"+is][is+i+"1N"])){v.1d[is+i+"1N"]=v["9B"+is][is+i+"1N"]}if(I(v["9B"+is][is+i+"Z"])){v.1d[is+i+"Z"]=v["9B"+is][is+i+"Z"]}}if(I(v.1d[is+i])){if(v.1d[is+i]==1){aD(\'f\',i);aG(f[i],b2[i],5q[i],7u[i]);5q[i].1V=2M(v.1d[is+i+"Z"]);if(I(v.1d[is+i+"1N"])){if(v.1d[is+i+"1N"]!=\'\'){5q[i].1V=v.1d[is+i+"1N"]}}if(I(v.1d[is+i+"Z"])){1Q[i]=v.1d[is+i+"Z"];7D(i);if(1Q[i]==\'1x\'){jF=i}}f[i].1p(9m,6c);f[i].1p(9d,5J);f[i].1p(5K,aq);f[i].1p("8K",9k);if(v.1d[is+i+"1l"]==1){K(f[i],{"X":0})}}}}}E Af(){4m(jR);jR=7d(se,dg);9t()}E Ag(){o.3q=H}E se(){if(C.f0==1){3j(o.eI);o.eI=1G(E(){if(!o.3q){az()}},(v.1d.d1>0?v.1d.d1*2G:2G))}o.3q=J}E 6c(17){if(o.2e){o.4G?o.V.4G(J):\'\'}B i=17.4d.7h(\'lK\');B x;if(i){x=\'f\'}F{if(17.4d.7h(\'aC\')){i=17.4d.7h(\'aC\');x=\'f2\'}}if(i){i=2w(i);B dx=J;if(I(2j(x)[i])){if(C.7v>-1){K(2j(x+\'bg\')[i],{\'1o\':C.7v})}if(C.6r>-1){K(2j(x+\'1N\')[i],{\'1o\':C.6r});K(2j(x+\'52\')[i],{\'1o\':C.6r})}if(is=="19"){if(1Q[i].L("19")==0){B id=1Q[i].1w(8);if(3F==id||dl==id){K(2j(x+\'1N\')[i],{\'1v\':C.5f});K(2j(x+\'52\')[i],{\'1v\':C.5f});dx=H}F{K(2j(x+\'1N\')[i],{\'1v\':C.1v})}}}if(C.so==1&&I(C.lz)&&dx){}F{K(2j(x+\'bg\')[i],{\'6a\':C.7i})}}}};E 5J(17){if(o.2e){o.4G?o.V.4G(H):\'\'}B i=17.4d.7h(\'lK\');B x;B dx=J;9t();if(i){x=\'f\'}F{if(17.4d.7h(\'aC\')){i=17.4d.7h(\'aC\');x=\'f2\'}}if(i){if(I(2j(x)[i])){if(C.7v>-1){K(2j(x+\'bg\')[i],{\'1o\':C.5B,"4u":"1o 0.1s 2O"})}if(C.6r>-1){K(2j(x+\'1N\')[i],{\'1o\':C.a,"4u":"1o 0.1s 2O"});K(2j(x+\'52\')[i],{\'1o\':C.a,"4u":"1o 0.1s 2O"})}if(is=="19"){if(1Q[i].L("19")==0){B id=1Q[i].1w(8);if(3F==id||dl==id){K(2j(x+\'1N\')[i],{\'1v\':C.5f});K(2j(x+\'52\')[i],{\'1v\':C.5f});dx=H}F{if(I(o.bz[id])){f1(i)}F{K(2j(x+\'1N\')[i],{\'1v\':C.1v})}}}}if(C.so==1&&I(C.lz)&&dx){}F{K(2j(x+\'bg\')[i],{\'6a\':C.5v})}}}}E aq(17){if(!ht){B d=1y 7L();o.9V=d.ap();B i=17.4d.7h(\'lK\');if(i){if(I(f[i])){if(I(1Q[i])){4P(i,0)}}}}}E 9k(17){17.5F=H;9t()}E s7(17){if(!ht){B d=1y 7L();o.9V=d.ap();B i=17.4d.7h(\'aC\');if(i){if(i==0){db()}F{if(I(3x[i])){DG(i)}}}}}E hS(17){B x=17.4d.7h(\'Aa\');if(x){sa(x)}}E DK(17){9t();B i=17.4d.7h(\'aC\');if(I(3x[i])){if(3x[i].L("=")>0){B x=3x[i].1w(0,3x[i].L("="));B y=3x[i].1w(3x[i].L("=")+1);v[x]=y;if(o.4S&&v.td==1&&x!="aA"){3m.7U("jr"+x,y)}o.V.ir();sa(x)}}}E Dm(17){B i=17.4d.7h(\'aC\');B x=3x[i];if(I(x)){if(x.L("=")>0){B z=x.1w(0,x.L("="));B y=x.1w(x.L("=")+1);v[z]=y;rW();7D(o[2V+\'lN\']);if(2V=="fO"){8a("vn")}}}}E 7D(i){if(I(1Q[i])){B 8Z=J;B 7T=J;B 5Z=\'\';if(is=="1d"){if(1Q[i]=="4z"){5Z=o.P.sd()}if(1Q[i]=="6e"){5Z=o.P.sf()}if(1Q[i]=="aW"){if(o.6I){5Z=o.kL[o.Pd]}}if(1Q[i]=="6e"||1Q[i]=="aW"||1Q[i]=="4z"){if(o[\'d2\'+1Q[i]].Q==0){8Z=H}F{if(o[\'d2\'+1Q[i]].Q==1&&(C.wn!=1||o[\'d2\'+1Q[i]][0]==1)){8Z=H}F{7T=H}}}if(1Q[i]=="4T"){if(!o.4T){8Z=H}F{7T=H}}if(1Q[i]=="6g"){if(o.2v!=\'b1\'&&!v.6g){8Z=H}F{7T=H}}if(1Q[i]=="2r"){if(I(o.2a)){7T=H;if(o.7Z||v.9D==1){5Z=o.3e[!o.7Z?o.3e.Q-1:o.3u]}F{5Z=\'\'}B sg=J;U(B s=0;s<o.2a.Q;s++){if(o.2a[s]!=\'\'){sg=H;1g}}if(!sg){8Z=H;7T=J}}F{8Z=H}}if(1Q[i]=="6R"){5Z=o.5W[o.9T];7T=H;if(o.2v=="9n"||(o.P.5H()&&v.Pa!=1)){8Z=H;7T=J}}if(1Q[i]=="1x"){5Z=2I.4N(o.3y.x*1h)+\'%\';7T=H}if(1Q[i].L("7o")>0){B x=\' \';B y=[\'sz\',\'sy\',\'sA\'];U(B z=0;z<y.Q;z++){if(I(v[1Q[i]+y[z]])){if(v[1Q[i]+y[z]]!=\' \'){x+=(x!=\' \'?\':\':\'\')+v[1Q[i]+y[z]]}}}5Z=x!=\' 0:0\'&&x.L(":")>-1?x:\' \';7T=H}}7u[i].1V=5Z+(5Z!=\'\'&&C.Pb!=1?\' &ef;<2p W="g1" X="Ao" sh="-1 -1 5 8" 7p="1.1" 3K="3n://3C.w3.3O/47/2p" 3K:3L="3n://3C.w3.3O/6U/3L"><je 46="#\'+C.5f+\'" 46-W="1" 4A="1I" 2N="0 0 3 3 0 6"></je></2p>\':\'\');if(8Z){1l(f[i]);if(is=="1d"){bt[i]?3j(bt[i]):\'\';if(o.S){o.S.fU(i,J,5Z)}F{bt[i]=1G(E(){o.S.fU(i,J,5Z)},4H)}}K(f[i],{\'1i\':\'29\',\'2l\':0,\'1f\':-1h})}if(7T){if(C.3D==1){K(f[i],{\'2m\':\'dj-5a\'})}F{1n(f[i])}if(is=="1d"){bt[i]?3j(bt[i]):\'\';if(o.S){o.S.fU(i,H,5Z)}F{bt[i]=1G(E(){o.S.fU(i,H,5Z)},4v)}}K(f[i],{\'1i\':\'es\',\'2l\':0,\'1f\':0})}2n()}U(B j=1;j<f.Q;j++){if(f[j]){if(62(f[j])){B 4M=J;5w?4M=H:\'\';5w=J;4M&&o.S?o.S.4M():\'\'}}}};E 4P(i,zW){if(I(1Q[i])){o.rY=H;9t();B x=rV();if(2V!=1Q[i]){2V=1Q[i];if(2V==\'4z\'||2V==\'6e\'||2V==\'2r\'||2V==\'6R\'||2V==\'aW\'||2V==\'1x\'||2V.L("7o")>0){kR=i;B 3o=Ap(o[\'d2\'+2V]);if(2V=="sc"){3o=8a("Pc")}if(2V=="fO"){3o=8a("Ph")}B e2=o[\'Pi\'+2V];B A2=o[\'Po\'+2V];U(B j=1;j<f.Q;j++){if(f[j]){f[j].C.2m="1I"}}f2=[];aD(\'f2\',0);aG(f2[0],fv[0],4l[0],6h[0]);K(f2[0],{"2W-2F":"5z 6y "+(C.A4==1?"#"+C.8t.1Z("#",""):"4I(1h,1h,1h,0.7)")});cN=zW;4l[0].1V=(x[0]<2||cN==1||C.s0==1?\'\':l2)+(v.1d[is+i+"1N"]&&v.1d[is+i+"1N"]!=\'\'?v.1d[is+i+"1N"]:2M(v.1d[is+i+"Z"]));if(2V==\'2r\'&&!o.j1&&!o.iZ){6h[0].1V=2M("3k");K(6h[0],{\'1v\':C.1v,\'1F-m8\':\'Pp\',\'6C\':\'2A\',\'6t\':\'3S\'});6h[0].1p(5K,vB);if(jX){U(j=0;j<o.bb.Q;j++){if(v.iY==0&&o.bb[j]=="bU"){}F{3o.2P("Pn"+o.bb[j])}}}}if(2V==\'1x\'){aI();K(6h[0],{\'W\':C.4p*2.5,\'1F-8i\':\'2l\'})}K(4l[0],{\'3V-3t\':C.f8});3x[0]="Pm";if(cN!=1&&x[0]>1){f2[0].1p(9m,6c);f2[0].1p(9d,5J);f2[0].1p(5K,s7);f2[0].1p("8K",9k)}F{K(f2[0],{"6t":\'6S\'})}if(C.vA==1){3g(f2[0])}if(I(3o)){U(j=0;j<3o.Q;j++){B y=j+1;B fz=J;B 8l=J;if(3o[j]&&4j(3o[j])!=\'\'){if(2V==\'4z\'){if(3o[j]==2M("2A")){fz=H}}aD(\'f2\',y,fz);aG(f2[y],fv[y],4l[y],6h[y],1Q[i]);if(2i(3o[j])==\'5h\'){if(3o[j].L("<<<")==0){3o[j]=3o[j].1Z(\'<<<\',\'\');8l=H}if(3o[j].L(\'7o\')>0){o[2V+\'lN\']=i}if(3o[j].L("s6")==0){B 1H=3o[j];if(1H.L("7o")>0){4l[y].1V=2M(3o[j].1w(1H.L("7o")+5))}F{4l[y].1V=2M(3o[j].1w(7))}if(3o[j]==\'Pj\'){K(f2[y],{"2W-1f":"5z 6y 4I(1h,1h,1h,0.7)"})}}F{4l[y].1V=3o[j]}}F{4l[y].1V=3o[j]}3x[y]=2V+j;if(e2==j||A2==j){6h[y].1V=e2==j?hG:A8;e2==j?K(4l[y],{\'1v\':C.5f}):\'\'}if(2i(3o[j])==\'5h\'){if(3o[j].L("s6")==0){B t=3o[j].1w(7);if(t.L("1v")>0){6h[y].1V="<1R C=\'"+(v[t]=="3z"?\'2W:5z 6y #fC;X:dR;W:dR;\':\'X:dK;W:dK;\')+";2x-1v:"+(v[t].L("#")==-1?\'#\':\'\')+v[t]+";2W-6k:dK;\'></1R>"}F{6h[y].1V=v[3o[j].1w(7)]}}}if(2V==\'4z\'){if(3o[j]==2M("2A")&&o.P.fN()){K(4l[y],{\'1v\':C.5f})}if(I(v.kK)){if(v.kK.L(3o[j])>-1){3g(f2[y])}}}B s5="";if(2i(3o[j])==\'5h\'){if(3o[j].L("s6")==0){4w(f2[y],{\'Pk\':i,\'Aa\':3o[j].1w(7)});s5="hS"}}if(!8l){f2[y].1p(9m,6c);f2[y].1p(9d,5J);if(s5=="hS"){f2[y].1p(5K,hS)}F{f2[y].1p(5K,s7)}f2[y].1p("8K",9k)}F{K(f2[y],{"6t":"6S"})}}}}2n()}if(1Q[i]==\'6g\'){o.V.s8()}if(1Q[i].L(\'19\')>-1){B id=1Q[i].1w(8);if(I(o.1t[id])){if(I(o.1t[id][\'3h\'])){o.2z=1W;cd(i);if(I(o.1t[id][\'1A\'])){v.1A=o.2z=o.1t[id][\'1A\']}8a("A7");if(I(o.1t[id][\'7a\'])&&v.7a==1&&v.Pl==1){7a(o.1t[id][\'7a\'])}F{jx(id);o.V.d6(o.1t[id][\'3h\']);v.19.8F==0&&v.19.e9==1?1G(az,4H):\'\';jz=J;kH=J;jy(id)}}F{if(I(o.1t[id][\'4B\'])){5Q(id);if(jz){5r==-1?4P(0,0):\'\'}F if(kH){5r==-1?4P(2w(f.Q)-2,0):\'\'}}}}if(o.3b){o.3b.jN()}}if(1Q[i]==\'4T\'){o.P.d3()}}}};G.A3=E(x){7D(o[x+\'lN\'])};E sa(x){9t();U(B i=0;i<f2.Q;i++){if(f2[i]){f2[i].C.2m="1I"}}f2=[];aD(\'f2\',0);aG(f2[0],fv[0],4l[0],6h[0]);K(f2[0],{"2W-2F":"5z 6y "+(C.A4==1?"#"+C.8t.1Z("#",""):"4I(1h,1h,1h,0.7)")});if(x.L("7o")>0){f2[0].1p(5K,rW);4l[0].1V=2M(x.1w(x.L("7o")+5))}F{f2[0].1p(5K,rS);4l[0].1V=(C.s0!=1?l2:\'\')+2M(x)}K(4l[0],{\'3V-3t\':C.f8});f2[0].1p(9m,6c);f2[0].1p(9d,5J);f2[0].1p("8K",9k);B 4r=[];B sC=J;if(x.L("3t")>0){4r=[\'50%\',\'75%\',\'1h%\',\'P9%\',\'s9%\',\'P8%\',\'4H%\',\'OW%\',\'cA%\',\'ca%\']}if(x.L("5B")>0){4r=[\'0\',\'0.2\',\'0.3\',\'0.4\',\'0.5\',\'0.6\',\'0.7\',\'0.8\',\'0.9\',\'1\']}if(x.L("dN")>0){U(i=-5;i<5.5;i+=0.5){4r.2P(2I.4N(i*1h)/1h)}}if(x.L("fw")>0){4r=[4H,ca,b9]}if(x.L("2F")>0){U(i=0;i<21;i++){4r[i]=i*10}}if(x.L("sz")>0){U(i=0;i<24;i++){4r[i]=i}}if(x.L("sy")>0||x.L("sA")>0){U(i=0;i<60;i++){4r[i]=i}}if(x.L("bH")>0){sC=H;4r=[0,1]}if(x.L("1v")>0){4r=[\'3J\',\'B6\',\'OX\',\'OY\',\'OV\',\'OU\',\'OQ\',\'OR\',\'OT\',\'OZ\',\'P0\',\'P6\',\'P7\',\'P5\',\'P4\',\'P1\',\'P2\',\'3z\'];B vx=v[x].1Z("#","");if(4r.L(vx)==-1){4r[8]=vx}}U(y=1;y<=4r.Q;y++){aD(\'f2\',y,J);aG(f2[y],fv[y],4l[y],6h[y]);K(6h[y],{\'2S-1b\':0});if(x.L("1v")>0||x.L("2F")>0||x.L("7o")>0||x.L("dN")>0){y%3!=0?K(f2[y],{\'fr\':\'1b\'}):\'\';K(f2[y],{\'W\':\'33.3%\'});if(x.L("1v")>0){4l[y].1V="<1R C=\'"+(4r[y-1]=="3z"?\'2W:5z 6y #fC;X:AL;W:AL;\':\'X:dS;W:dS;\')+";2x-1v:#"+4r[y-1]+";2W-6k:dS;\'></1R>";K(f2[y],{\'2C-X\':1})}F{4l[y].1V=4r[y-1]}}F{if(x.L("fw")>0){4l[y].1V=4r[y-1]}F{y%2!=0?K(f2[y],{\'fr\':\'1b\'}):\'\';K(f2[y],{\'W\':\'50%\'});if(sC){4l[y].1V=2M(4r[y-1]+\'fx\')}F{4l[y].1V=4r[y-1]}}}3x[y]=x+\'=\'+4r[y-1];if((4r[y-1]==v[x]&&ba(v[x])!=" ")||v[x]==\'#\'+4r[y-1]){6h[y].1V=hG;K(4l[y],{\'1v\':C.5f})}f2[y].1p(9m,6c);f2[y].1p(9d,5J);if(x.L("7o")>0){f2[y].1p(5K,Dm)}F{f2[y].1p(5K,DK)}f2[y].1p("8K",9k)}2n()}E jx(id){if(I(o.1t[id][\'2g\'])){v.2g=o.1t[id][\'2g\'];I(v.2g)?o.P.8B(v.2g):\'\'}if(I(o.1t[id][\'1N\'])){o.cW=o.1t[id][\'1N\']}}E jy(id){if(I(o.1t[id][\'1N\'])){if(v.lD==1){if(o.V.lM(o.1t[id])){}F{v.1N=(v.sw==1&&I(o.tk)?o.tk+(v.su==1?\'<br>\':\' \'):\'\')+o.1t[id][\'1N\']}o.V.9p(\'1N\')}}if(v.fi==1){if(I(o.1t[id][\'2N\'])){v.2N=o.1t[id][\'2N\']}F{v.2N=[]}o.S.f9()}v.7t=1W;B xv=[\'1e\',\'DJ\',\'DF\',\'lB\',\'sm\',\'4q\',\'7t\',\'4e\',\'fs\',\'6g\',\'b0\',\'lx\'];U(B i=0;i<xv.Q;i++){if(I(o.1t[id][xv[i]])){v[xv[i]]=o.1t[id][xv[i]]}}v.1A=0;if(I(o.1t[id][\'1A\'])){v.1A=o.2z=o.1t[id][\'1A\']}if(I(o.1t[id][\'2J\'])){o.1t[id][\'2r\']=o.1t[id][\'2J\']}if(I(o.1t[id][\'2r\'])){o.P.dT(o.1t[id][\'2r\'])}if(I(o.1t[id][\'bZ\'])){6z(\'bZ\',o.1t[id][\'bZ\'])}}E cd(x){if(5r==0&&!o.1A){K(5q[5r],{\'1v\':C.1v});K(b2[5r],{\'6a\':C.5v});7u[5r].1V=\'\'}F{o.sq=x;if(5r>-1){f1(5r)}if(3F!=\'\'){o.bz[3F]=H;53=rz(53,3F)}}if(1Q[x]){B id=1Q[x].1w(8);7u[x].1V=hG;K(5q[x],{\'1v\':C.5f,\'1F-m8\':\'1I\',\'1o\':C.a});if(C.so==1&&I(C.lz)){K(b2[x],{\'6a\':C.lz})}5r=x;3F=id;o.3F=3F;v.4O=3F;o.lA=5q[x].1V;o.sq=3F;dl=o.1t[id][\'hE\'];if(o.S){o.S.fV()}}}E 5Q(id){B x=id==0?o.19:o.1t[id];o.sq=id;U(B i=0;i<f.Q;i++){if(C.3D==1){18.2U(f[i])}F{6N.2U(f[i])}f[i]=1S}f=[];5r=-1;if(I(x[\'4B\'])){B y=42.3I(x[\'4B\']).Q;aD(\'f\',y);1Q[y]="vI";aG(f[y],b2[y],5q[y],7u[y]);if(C.3D==1){K(f[y],{"W":(C.jp==1?C.d8:"2A"),"X":C.l3})}if(C.rZ==1){if(C.3D==1){K(f[y],{"P3":"5z 6y #"+C.sr})}F{K(f[y],{"Pq":"5z 6y #"+C.sr})}}B 1H=x.1N;if(C.s0!=1){1H=l2+1H}5q[y].1V=1H;K(5q[y],{\'3V-3t\':C.f8});B p=x[\'hE\'];f[y].1p(9m,6c);f[y].1p(9d,5J);f[y].1p(5K,E(){DR(p)});x=x[\'4B\']}B y=42.3I(x).Q;53=[];bF=[];U(B i=0;i<y;i++){aD(\'f\',i);1Q[i]="19"+x[i].id;if(!I(o.bz[x[i].id])&&!I(x[i].4B)){53[x[i].id]=i;bF[x[i].id]=i}aG(f[i],b2[i],5q[i],7u[i]);if(C.3D==1){if(C.6j==0){K(5q[i],{\'W\':C.d8-C.rM-C.rL});3g(7u[i])}K(f[i],{"W":(C.jp==1?C.d8:"2A"),"X":C.l3})}if(C.rZ==1&&i<y-1){B kZ=1M("1R");f[i].1J(kZ);if(C.3D==1){K(kZ,{"1i":"29","1f":0,"2l":0,"W":1,"X":"1h%","2x":"#"+C.8t,"6C":"1I"})}F{K(kZ,{"1i":"29","2F":0,"1b":0,"W":"1h%","X":1,"2x":"#"+C.8t,"6C":"1I"})}}5q[i].1V=x[i].1N?x[i].1N:\'&ef;\';if(v.aX==1&&v.DX==1&&x[i].id){if(o.DY){if(o.DY.L(x[i].id)>-1){x[i].rG=1}}}if(I(x[i].rG)){if(x[i].rG==1){o.bz[x[i].id]=H;f1(i)}}if(I(x[i].4B)){7u[i].1V=DZ;K(7u[i],{"1v":C.1v})}f[i].1p(9m,6c);f[i].1p(9d,5J);f[i].1p(5K,aq);f[i].1p("8K",9k);if(I(o.bz[x[i].id])){f1(i)}if(3F==x[i].id){cd(i)}if(dl==x[i].id){K(5q[i],{\'1v\':C.5f});K(7u[i],{\'1v\':C.5f})}}2n();5w=J;o.S?o.S.4M():\'\'}E eZ(x,y,z,x1,y1,x2,y2,x3,y3,x4,y4){B ww=(C.3D==1?\'E2\':\'1h%\');B hh=(C.3D==1?\'1h%\':\'E2\');K(x,{\'1i\':\'29\',\'2m\':\'dj-5a\',\'W\':ww,\'X\':hh,\'1F-8i\':\'7e\'});if(C.E1==1){K(x,{\'2x\':\'-rH-2O-5d(\'+y+\')\',\'2x\':\'-41-2O-5d(\'+y+\')\',\'2x\':\'-ms-2O-5d(\'+y+\')\',\'2x\':\'-o-2O-5d(\'+y+\')\',\'2x\':\'2O-5d(\'+y+\')\',})}if(C.3D==1||o.1m.2y){K(x,{\'6t\':\'3S\'})}F{K(x,{\'3S-2H\':\'1I\'})}if(C.m5==1){K(x,{\'5C-W\':C.fG+\'px!5m\'})}if(z=="1f"){K(x,{\'1f\':-1,\'1b\':0})}if(z=="2F"){K(x,{\'2F\':-1,\'1b\':0})}if(z=="1b"){K(x,{\'1f\':0,\'1b\':0})}if(z=="2l"){K(x,{\'1f\':0,\'2l\':0})}if(z=="2l"||z=="1b"){K(x,{\'1F-8i\':\'1b\',\'2S-1f\':1z.2L/2-10})}x.1V="<7e><1R "+(C.CP==1?"Pr=\'G.C.6a=\\"#"+C.CT+"\\"\' PQ=\'"+(C.rB==1?"G.C.6a=\\"#"+C.rt:"G.C.2x=\\"1I")+"\\"\'":"")+" C=\'3S-2H:2A;6t:3S;W:dS;X:dS;2W-6k:dS;"+(C.rB==1?"2x-1v:#"+C.rt+";":"")+(z=="1f"?"2K-1f:dK;":"")+(z=="2F"?"2K-1f:dK;":"")+(z=="2l"?"2K-1b:rs;":"")+(z=="1b"?"2K-2l:rs;":"")+"\'><2p W=\'20\' X=\'20\' 3K:3L=\'3n://3C.w3.3O/6U/3L\' 3K=\'3n://3C.w3.3O/47/2p\'><g><2C x1=\'"+x1+"\' y1=\'"+y1+"\' x2=\'"+x2+"\' y2=\'"+y2+"\' 46=\'#"+C.l9+"\' 46-W=\'"+C.lQ+"\' 46-et=\'4N\'/><2C x1=\'"+x3+"\' y1=\'"+y3+"\' x2=\'"+x4+"\' y2=\'"+y4+"\' 46=\'#"+C.l9+"\' 46-W=\'"+C.lQ+"\' 46-et=\'4N\'/></g></2p></1R></7e>"}G.8y=E(){if(C.fA==1){8y()}};E D4(){if(bC){8y()}}E 8y(e){if(C.fA==1&&!gs){if(C.3D==1){B h=18.PR;B m=1z.1Y+C.6q+C.6T;B t=18.aU}F{B h=18.wl;B m=1z.2L;B t=18.bv}if(h>m){if(t>0){if(!62(54)){1n(54);B m1=1y 5g({"mc":54,"1B":"7j","to":1,"Y":0.3,"me":"54"})}}F{if(62(54)){B m2=1y 5g({"mc":54,"1B":"7j","to":0,"Y":0.3,"me":"54","1l":H})}if(e){e.ma<0?e.91():\'\'}}if(t<h-m-10){if(!62(56)){1n(56);B m3=1y 5g({"mc":56,"1B":"7j","to":1,"Y":0.3,"me":"56"})}}F{if(62(56)){B m4=1y 5g({"mc":56,"1B":"7j","to":0,"Y":0.3,"me":"56","1l":H})}if(e){e.ma>0?e.91():\'\'}}}F{1l(54);1l(56)}}}E Cw(){B x=18.bv+1z.2L-60;B m=1y 5g({"mc":18,"1B":"8Q","to":x,"Y":0.3,"me":"wh","7C":"b3"});1G(8y,2G)}E CI(){B x=18.bv-1z.2L+60;B m=1y 5g({"mc":18,"1B":"8Q","to":x,"Y":0.3,"me":"PP","7C":"b3"});1G(8y,2G)}E eQ(17){3j(o.eI);17.9G()}E Dq(){B x=18.aU+(1z.1Y+C.6q+C.6T)-60;B m=1y 5g({"mc":18,"1B":"h9","to":x,"Y":0.3,"me":"PO","7C":"b3"});1G(8y,2G)}E E5(){B x=18.aU-(1z.1Y+C.6q+C.6T)+60;B m=1y 5g({"mc":18,"1B":"h9","to":x,"Y":0.3,"me":"wf","7C":"b3"});1G(8y,2G)}E DR(x){if(x==\'\'){5Q(0)}F{if(I(o.1t[x])){5Q(x)}}2V=\'\'}E f1(x){7u[x].1V=\'\';K(5q[x],{\'1v\':C.DA});if(C.DC==1){K(5q[x],{\'1F-m8\':\'2C-PL\'})}if(C.rQ>-1){K(5q[x],{\'1o\':C.rQ})}K(b2[x],{\'6a\':C.DH});if(C.rP>-1){K(b2[x],{\'1o\':C.rP})}}E DG(i){if(I(3x[i])){9t();if(3x[i].L("4z")==0){o.V.5n(3x[i].1w(7))}if(3x[i].L("6e")==0){o.V.bq(3x[i].1w(10))}if(3x[i].L("2r")==0){o.V.9z(3x[i].1w(8))}if(3x[i].L("aW")==0&&v.6I==1){o.6I.zt(3x[i].1w(7))}if(3x[i].L("1x")==0){if(3x[i]==\'PM\'){o.P.1x(C.1x/1h)}if(3x[i]==\'PN\'){o.P.1x(\'-\'+C.1x/1h)}if(3x[i]==\'PS\'){o.P.rO()}}if(3x[i].L("7o")>0){if(3x[i].L("PT")>0){8a(2V+\'0\');7D(o[2V+\'lN\']);if(2V=="fO"){8a("vn")}db()}}if(3x[i].L("6R")==0){o.V.9P(3x[i].1w(5));fm();1G(az,4H)}}};G.fm=E(){fm()};G.vv=E(x){U(B i=0;i<1Q.Q;i++){if(1Q[i]==x){O H}}O J};E fm(){U(B i=0;i<1Q.Q;i++){if(1Q[i]=="6R"){7D(i);if(2V==\'6R\'){d4();4P(i,0)}}}}E aD(x,i,fz){if(I(2j(x))){2j(x)[i]=1M("1R");if(i<2||x=="f"||2V!=\'4z\'||fz){if(C.3D==1){18.1J(2j(x)[i])}F{6N.1J(2j(x)[i])}}F{if(C.3D==1){18.k6(2j(x)[i],2j(x)[i-1])}F{6N.k6(2j(x)[i],2j(x)[i-1])}}if(x==\'f\'){4w(2j(x)[i],{\'lK\':i})}if(x==\'f2\'){4w(2j(x)[i],{\'aC\':i})}2j(x+\'bg\')[i]=1M("1R");2j(x)[i].1J(2j(x+\'bg\')[i]);2j(x+\'3N\')[i]=1M("1R");2j(x)[i].1J(2j(x+\'3N\')[i]);K(2j(x+\'3N\')[i],{\'1i\':\'29\',\'2l\':0,\'1f\':0,\'W\':\'1h%\',\'X\':\'1h%\',\'6C\':\'1I\'});2j(x+\'1N\')[i]=1M("1R");2j(x)[i].1J(2j(x+\'1N\')[i]);2j(x+\'52\')[i]=1M("1R");2j(x)[i].1J(2j(x+\'52\')[i]);if(x=="f2"&&is=="1d"&&C.rC==0){3g(2j(x+\'52\')[i])}}};E aG(x,aM,eW,rR,PZ){K(x,{\'1i\':\'es\',\'2l\':0,\'1f\':0,\'6t\':\'3S\',\'X\':\'2A\',\'W\':\'1h%\',\'6A\':\'3G\',\'2m\':\'5a\',\'2C-X\':\'1.Q0\'});if(C.rN&&C.3D==1){K(x,{\'PY\':C.rN})}if(C.3D==1){K(x,{\'2m\':\'dj-5a\',\'9L-8i\':\'1f\',\'9W-7R\':\'rq\'})}K(aM,{\'1i\':\'29\',\'2l\':0,\'1f\':0,\'W\':\'1h%\',\'X\':\'1h%\',\'6a\':C.5v,\'1o\':C.5B,\'6C\':\'1I\',\'4u\':\'1o 0.2s 2O,2x .2s 2O\'});K(eW,{\'1i\':\'es\',\'2l\':0,\'1f\':0,\'fr\':(C.8i?C.8i:\'1b\'),\'1v\':C.1v,\'2S-1f\':C.fq,\'2S-2l\':C.rL,\'2S-2F\':C.PX,\'2S-1b\':C.rM,\'6C\':\'1I\',\'1o\':C.a,\'4u\':\'1o 0.2s 2O,1v 0.2s 2O\',});K(rR,{\'1i\':\'es\',\'2l\':0,\'1f\':0,\'fr\':(C.vG?C.vG:\'2l\'),\'2S-1f\':C.fq+(C.4p<C.aE?(C.aE-C.4p)/2:0),\'2S-2l\':C.rL,\'2S-1b\':C.rM,\'6C\':\'1I\',\'3V-3t\':C.4p,\'1o\':C.a,\'1v\':C.5f,\'4u\':\'1o 0.2s 2O,1v 0.2s 2O\'});if(C.m5==1){K(x,{\'5C-W\':C.fG+\'px!5m\'});K(eW,{\'5C-W\':(C.fG-70)+\'px!5m\'})}F{if(C.3D==1){if(C.jp==1){K(x,{\'W\':C.d8});K(eW,{\'W\':C.d8-70})}}F{K(eW,{\'9W-7R\':\'cj\'});K(rR,{\'9W-7R\':\'cj\'})}}}E db(){U(B i=1;i<f.Q;i++){if(I(f[i])){if(C.3D==1){f[i].C.2m="dj-5a"}F{f[i].C.2m="5a"}}}9t();d4();2n();2V=\'\';kR=-1};E d4(){U(B j=0;j<f2.Q;j++){if(f2[j]){if(C.3D==1){18.2U(f2[j])}F{6N.2U(f2[j])}f2[j]=1S}}f2=[];2V=\'\'}E wu(){O 18.1Y};G.hr=E(){lU()};E lU(){if(is=="19"){if(C.3D==1||C.vz==1){B x=o.3f-C.4x-C.3P;K(1z,{\'W\':x});K(18,{\'W\':x});6N?K(6N,{\'W\':x}):\'\'}}}E 2n(){if(!gs){if(is=="1d"){o.S?o.S.rT():\'\';B x=C.vA==1&&f.Q>1?f[1]:f[0]}if(is=="19"){lU();o.S?o.S.hr():\'\';B x=f[0];if(v.yJ==1){k9()}}f.Q>1&&!x?(f[1]?x=f[1]:\'\'):\'\';f.Q>2&&!x?(f[2]?x=f[2]:\'\'):\'\';if(x){x.1Y==0&&f2.Q>0?x=f2[0]:\'\'}if(18.1Y-18.jU>0&&x&&C.3D!=1){if(I(54)){K(54,{"W":6N.1Y})}if(I(56)){K(56,{"W":6N.1Y})}C.jW=(18.1Y-x.1Y)-(18.jU-x.jU)}F{C.jW=0}}};E rV(){B x=0;B y=0;B z=\'\';U(B i=1;i<f.Q;i++){if(I(f[i])){if(f[i].C.6b=="3U"){x++;y=i;z=1Q[i]}}}O[x,y,z]}E vB(){jX=!jX;rS()}E rS(){db();U(B i=0;i<1Q.Q;i++){if(1Q[i]=="2r"){4P(i,cN)}}}E 9t(){3j(rX);rX=1G(E(){o.rY=J},47)}E rW(){B x=2V;db();U(B i=0;i<1Q.Q;i++){if(1Q[i]==x){4P(i,0)}}}E az(x){if(is==\'1d\'&&v.1d.8F==1){}F{if(is==\'19\'&&v.19.3b==1&&v.19.PU!=1){o.3b?o.3b.uW():\'\';bC=J}F{if((x!=1||(C.PV==1&&C.8F==1))&&!o.1m.tv){B m=1y 5g({"mc":1z,"1B":"7j","to":0,"Y":0.1,"me":is,"7C":"uX"});hl=1G(E(){K(1z,{"6b":"3G","1o":0,"1f":-47});bC=J},4H)}F{K(1z,{"6b":"3G","1o":0,"1f":-47});bC=J}}if(is==\'19\'){if(v.19.vd==1&&o.S){o.S.rU("Z","19",H)}}4m(jR)}};G.c=E(){O 1z};G.co=E(){if(1z.PW(18)){O 18}};G.s=E(1a){O C[1a]};G.ss=E(1a){O C};G.1n=E(){db();3j(hl);bC=H;if(is==\'19\'&&v.19.3b==1){o.3b?o.3b.ve():\'\'}F{K(1z,{"6b":"3U","1o":1,"4u":"1o 0.2s 2O"});B x=rV();if(x[0]==1){if(x[2]=="4z"||x[2]=="6e"||x[2]=="2r"||x[2]=="6R"||x[2]=="1x"||x[2].L("7o")>0){4P(x[1],0)}}}if(o.S){is==\'1d\'?o.S.rT():\'\';if(is==\'19\'){o.S.hr();if(v.19.vd==1){o.S.rU("Z","19",J)}}}if(o.1m.6i){K(18,{\'7S-W\':\'2A\'});if(C.3D!=1){K(6N,{\'7S-W\':\'2A\'})}}ht=H;4m(k2);k2=7d(v8,1h)};E v8(){4m(k2);ht=J}G.7x=E(i){4P(i,1)};G.1l=E(x){az(x)};G.5n=E(){U(B i=0;i<1Q.Q;i++){if(1Q[i]=="4z"){7D(i);if(o.26.Q>1){1n(f[i])}if(2V==\'4z\'){d4();4P(i,cN)}}}};G.d3=E(){U(B i=0;i<1Q.Q;i++){if(1Q[i]=="4T"){7D(i)}}};G.hi=E(x){U(B i=0;i<1Q.Q;i++){if(1Q[i]==x){7D(i);if(o[\'d2\'+x]){if(o[\'d2\'+x].Q>1){1n(f[i])}}if(2V==x){d4();4P(i,cN)}}}};G.9z=E(){U(B i=0;i<1Q.Q;i++){if(1Q[i]=="2r"){7D(i);if(o.3e){if(o.3e.Q>0){B x=J;if(o.2a){U(B y=0;y<o.2a.Q;y++){if(o.2a[y]!=\'\'){x=H;1g}}}F{x=H}x?1n(f[i]):\'\'}}if(2V==\'2r\'){d4();4P(i,0)}}}};G.rK=E(x){o.19=x;5Q(0);if(I(v.4O)){if(v.4O.L("x-")!=0){U(B y in o.1t){if(o.1t.2h(y)){if(o.1t[y].cD==v.4O){v.4O=y}}}}if(I(o.1t[v.4O])){cY(o.1t[v.4O]);B y=o.1t[v.4O][\'aT\'];cd(y);if(v.19.rJ==1&&C.3b!=1){5Q(0);1G(E(){2n()},4v)}F{1G(E(){bI(y);2n()},4v)}v.4O=1W}F{cd(0)}}F{cd(0)}if(C.3b==1){if(!I(o.3b)){o.3b=1y PK()}}};G.h6=E(x){if(I(o.1t[x])){cY(o.1t[x]);4P(o.1t[x][\'aT\'],0);bI(o.1t[x][\'aT\'])}};G.kA=E(x){if(I(o.1t[x])){cY(o.1t[x]);if(o.1t[x]["3h"]){cd(o.1t[x][\'aT\']);jx(x);o.V.d6(o.1t[x]["3h"],1);jy(x);bI(o.1t[x][\'aT\']);if(o.3b){o.3b.jN()}}F if(o.1t[x]["4B"]){5Q(x)}}};E wd(x){if(I(o.1t[x])){dl=\'\';5Q(0);cY(o.1t[x]);jx(x);4P(o.1t[x][\'aT\'],0);jy(x)}};G.dA=E(){jz=H;x=2w(5r)+1;if(3F!=\'\'){o.bz[3F]=H;53=rz(53,3F)}if(v.53==1){x=rw(53);if(x==1S){if(v.PJ==1||v.19.df==1){bF.zS(E(a,b){O 2I.6o()-0.5});U(B x in bF){if(bF.2h(x)){53[x]=bF[x]}}x=rw(53)}F{o.V.vH()}}}F{if((1Q[x]=="vI"||5r==-1)&&3F!=\'\'){B y=42.3I(o.1t).L(3F);if(y<42.3I(o.1t).Q){B z=o.1t[42.3I(o.1t)[y+1]];if(z){if(I(z.4B)){z=o.1t[42.3I(o.1t)[y+2]]}G.kA(z.id);x=-1;o.V.2B()}}}}if(x>-1){4P(x,0);bI(x)}};E bI(x){if(f[x]&&!gs){if(C.3D==1){B to=f[x].jq-20;B m=1y 5g({"mc":18,"1B":"h9","to":to,"Y":0.3,"me":"wf","7C":"b3"})}F{B to=f[x].wr-1z.2L/2+20;B m=1y 5g({"mc":18,"1B":"8Q","to":to,"Y":0.3,"me":"wh","7C":"b3"})}1G(8y,2G)}}E rw(3Z){B 3I=42.3I(3Z);B x;U(B i=0;i<3I.Q;i++){x=3Z[3I[3I.Q*2I.6o()<<0]];if(x){1g}}O x};G.aI=E(){aI()};E aI(){if(jF>-1){7D(jF);if(2V==\'1x\'){6h[0].1V=2I.4N(o.3y.x*1h)+\'%\'}}};G.dn=E(){if(v.53==1){O 42.3I(53).Q>0}B x=J;if(o.1t){x=42.3I(o.1t).L(3F)<42.3I(o.1t).Q-1}O x};G.ka=E(){if(I(o.hQ)){wd(o.hQ)}};G.rv=E(){B x=5r>0;if(o.1t){B y=42.3I(o.1t);B z=y.L(3F);x=z>0;if(z==1){if(I(o.1t[y[0]].4B)){x=J}}}O x};G.kG=E(){O I(o.1t)};G.hP=E(){kH=H;if(G.rv()){B x=2w(5r)-1;if(x<0){B y=42.3I(o.1t).L(3F);if(y>0){B z=o.1t[42.3I(o.1t)[y-1]];if(z){if(I(z.4B)){z=o.1t[42.3I(o.1t)[y-2]]}if(z){G.kA(z.id);o.V.2B()}}}}F{4P(x,0);bI(x)}}};G.kB=E(){if(5r>0){bI(5r)}};E cY(x){if(x[\'rr\']!=-1){cY(o.1t[x[\'hE\']]);5Q(x[\'hE\'])}F{5Q(0)}};G.g=E(x){9N(x){1j"W":O wu();1g;1j"X":O 1z.2L;1g;1j"1f":O 1z.wr;1g;1j"yO":O 18.wl;1g;1j"yR":O C.bG;1g;1j"x":O 4X(1z.C.1b);1g;1j"y":O 4X(1z.C.1f);1g;1j"1o":O 1z.C.1o;1g;1j"1n":O bC;1g;1j"7x":O kR;1g;1j"1a":O 1a;1g;1j"9a":O 1a+9a;1g;1j"5w":O 5w;1g;1j"19":O is=="19";1g;1j"rC":O hG;1g;1j"aY":O o.1t[o.aY]?o.1t[o.aY].1N:\'\';1j"b0":O v.b0?v.b0:\'\'}};G.5w=E(){if(is=="1d"){B x=0;U(B i=1;i<11;i++){if(1Q[i]=="4z"){B y=o.26.Q;if(I(v.kK)){B z=v.kK.2t(",");U(B j=0;j<z.Q;j++){if(o.26.L(z[j])>-1){y--}}}if(y>0){if(y>1||(y==1&&o.26!=1&&C.wn==1)){x++}}}if(1Q[i]=="4T"){if(o.4T){x++}}if(1Q[i]=="6g"){if(o.2v==\'b1\'||v.6g){x++}}if(1Q[i]=="6e"){if(o.5I.Q>0){x++}}if(1Q[i]=="aW"&&v.6I==1){if(o.kL.Q>0){x++}}if(1Q[i]=="2r"){if(I(o.2a)){U(B s=0;s<o.2a.Q;s++){if(o.2a[s]!=\'\'){x++;1g}}}}if(1Q[i]=="6R"){if(o.2v!="9n"){x++}}if(1Q[i]=="1x"){x++}if(1Q[i]){if(1Q[i].L("7o")>0){x++}}if(v.1d[is+i+\'1l\']==1){x--}}O x==0}F if(is=="19"){O f.Q==0}F{O 5w}};G.4C=E(){if(1z.4Q==o.1D){1z.2U(18);o.1D.2U(1z);o.3b?o.3b.4C():\'\';1z=1S;18=1S;gs=H}}};if(2i(3k)=="5h"){wo()}o.G=G;if(3k.id){if(1K.8m(3k.id)){rI()}F{1K.1p(\'Px\',8b)}}F{2i w7==\'E\'?w7():\'\'}E rI(){if(I(3k.id)){if(1K.8m(3k.id)){if(!vb(1K.8m(3k.id))||3k.3U==1){8b()}F{1G(rI,50)}}}}if(v.vO==1||v.rD==1){22.1p(\'8Y\',E(17){B x=1W;B y;I(17.1C.Y)?x=17.1C.Y:\'\';I(17.1C.1P)?x=17.1C.1P:\'\';I(17.1C.vN)?y=17.1C.vN:\'\';I(17.1C.2Z)?y=17.1C.2Z:\'\';if(y&&v.rF){if(v.rF!=\'\'){B pm=v.rF.1Z(/\\s+/ig,\'\').2t(\',\');if(pm.L(y)==-1){O}}}if(v.rD==1){if(2i(vK)=="E"){vK(17)}}if(y&&o.8f){if(I(17.1C.1U)){x=17.1C.1U}6z(y,x)}})}E 8b(){U(B i=0;i<6E.Q;i++){if(6E[i].2Z("id")==3k.id){if(6E[i].2Z("5M")){6E[i].2Z(\'2o\')}}}6E.2P(o.G);B 2o=J;if(I(3k.3d)){U(B i=2;i<10;i++){if(3k.3d==i&&o[\'u\'+i]!=\'\'){v=8J(v,5N.7y(bM(o[\'u\'+i])));2o=H}}}if(o.u!=\'\'&&!2o){v=8J(v,(2i o.u!="3r"?5N.7y(bM(o.u)):o.u))}if(2i(Py)!="E"){U(B 1a in 3k){if(3k.2h(1a)){if(1a.L("vM")==0){3k[1a]=1S}}}}v=8J(v,3k);if((!I(v.3h)||v.3h==\'\')&&v.Pz==1){1r(\'7t\');O}U(B 1a in o.bO){if(o.bO.2h(1a)){o.bO[1a]!=\'\'?o.hM+=o.bO[1a]+\' \':\'\'}}1r(o.7p+\' \'+o.hM);g8=v.id;o.d=9O.rE;if(bL){B ke=J;3v{if(bL){if(bL.1K){B ku=bL.1K.ay("vU");U(B i=0;i<ku.Q;i++){if(ku[i].eH===22){o.7F=ku[i];o.kj=H;v.tU!=1?K(o.7F,{"2W":"1I"}):\'\';o.tV=o.7F.C;1r("d9")}}}F{ke=H}}}3c(bW){ke=H}if(ke){o.kj=H;1r("Pw-gL")}}o.kj&&1K.sn?o.gL=1K.sn.2t(\'/\')[2]:\'\';tX();if(2i(ub)=="E"){if(ub()){O}}o.8f=H;tY();B sB=[\'Pv\',\'2X\',\'4Q\',\'e0://3C.Ps-u1.a8/u1.js\',\'Pt\',\'w5-Pu-\',\'2A\',\'bp\',\'PA\',\'tx\',\'tx:PB\',\'bp.a7\',\'17\',\'kE\',\'8b\',\'yP\',\'L\',\'ce\',\'g0\',\'uL\',\'PH\',\'1M\',\'ay\'];(E(sD,tZ){B tG=E(tI){gU(--tI){sD[\'2P\'](sD[\'dN\']())}};tG(++tZ)}(sB,PI));B 3B=E(jL,PG){jL=jL-7X;B uC=sB[jL];O uC};B jC=1y 7L();B ax=7X;jC[3B(\'7X\')]()==cr?ax=ut:\'\';jC[3B(\'7X\')]()==le?ax=uk:\'\';jC[\'uL\']()==sj?ax=uv:\'\';if(6o(cr,sj)!=le){ax=7X}if(ax>7X||v[\'ga\']==cr){(E(cH,sl,sk,uy,cE,gC,kT){cH[3B(\'cr\')]=cE;cH[cE]=cH[cE]||E(){(cH[cE][\'q\']=cH[cE][\'q\']||[])[\'2P\'](uP)},cH[cE][\'l\']=cr*1y 7L();gC=sl[3B(\'PF\')](sk),kT=sl[3B(\'PC\')](sk)[7X];gC[3B(\'PD\')]=cr;gC[3B(\'uk\')]=uy;kT[3B(\'uv\')][\'k6\'](gC,kT)}(22,1K,\'lV\',3B(\'ut\'),\'ga\'));o[\'uz\']=!![];if(ax>7X&&v[3B(\'ui\')]!=7X&&!3k[3B(\'ui\')]){ga(\'ce\',3B(\'PE\')+ax,3B(\'le\'),{\'6X\':3B(\'OP\'),\'yS\':!![]});ga(3B(\'OO\'),3B(\'O0\'));ga(3B(\'O1\'),[o[\'d\']]);ga(3B(\'O2\'),3B(\'NZ\'),{\'uM\':3B(\'NY\'),\'uE\':3B(\'NV\'),\'tM\':o[\'d\']})}if(v.sb<1h){if(6o(1,(1h/v.sb))!=1){v.ga=0}}if(v[\'ga\']==cr){if(I(v[3B(\'tK\')])){if(v[3B(\'tK\')][3B(\'sj\')](\'w5\')==7X){ga(3B(\'NW\'),v[\'yP\'],3B(\'le\'),{\'6X\':3B(\'NX\'),\'yS\':!![]})}F{v[\'ga\']=7X}}}o[\'ga\']=!![]}1G(E(){8o("8f","8b",H)},47);o.1z=1K.8m(v.id);if(!o.1z){v.1r=1;1r(\'id "\'+v.id+\'" cw gP\');O J}o.1z.1V=\'\';K(o.1z,{\'2S\':0,\'O3-dI\':\'rq\'});o.9b=o.1z.2L;o.bc=o.1z.1Y;if(I(v.gb)&&!I(v.4D)){if(I(v.gb.4D)){v.4D=v.gb.4D}if(I(v.gb.kV)){v.kV=v.gb.kV}}if(o.1z.C.W.L("%")>-1){o.O4=o.1z.C.W}if(v.4D=="8l"||o.1z.C.X.L("%")>-1){v.4D="%";o.m0=o.1z.C.X;o.9b=0}if(o.bc==0){if(o.1z.C.W.L("px")>0){o.bc=2w(o.1z.C.W)}F{if(o.1z.4Q.C.W.L("px")>0){o.bc=2w(o.1z.4Q.C.W)}F{if(o.1z.4Q.4Q.C.W.L("px")>0){o.bc=2w(o.1z.4Q.4Q.C.W)}}}}if(ba(v.4D).L("x")>0){o.4D=v.4D.2t("x")[0]/v.4D.2t("x")[1];if(o.9b==0){o.9b=o.bc/o.4D}}F{o.4D=0}K(o.1z,{\'1i\':\'es\',\'5u-hL\':\'qC-5u\',\'1F-8i\':\'1b\',\'-41-g0-Oa\':\'1I\',\'Ob\':\'3G\',\'qG\':\'lj-lF\',\'7S-X\':15,\'eB\':\'gg\',\'2C-X\':\'h0\',\'yl\':\'yu\'});if(v.bH==1){K(o.1z,{\'5u-bH\':\' 0 yH O9 4I(50,50,93,.1), 0 g1 yH 4I(0,0,0,.O8)\'})}if(o.4D>0){K(o.1z,{\'X\':o.9b})}F{K(o.1z,{\'X\':o.9b==0?o.m0:o.9b})}o.1D=1M("1R");K(o.1D,{\'1i\':\'29\',\'5u-hL\':\'qC-5u\',\'6a\':v.lk,\'1v\':\'#3J\',\'W\':\'1h%\',\'X\':\'1h%\',\'6A\':\'3G\',\'1b\':0,\'1f\':0,\'eB\':\'gg\',\'2C-X\':\'h0\'});if(v.O5==1){o.1D.C.6a=\'dv\'}if(v.2W==1){K(o.1z,{\'2W\':v.yt+\'px 6y \'+v.8t})}o.K=1K.1M(\'C\');o.K.1B=\'1F/K\';o.1D.1J(o.K);o.1D.5R("id",\'O6\'+v.id);qD("6O, 6O > *{1i: qB;1f: 2A;1b: 2A;6A:3U;yl:yu!5m;5C-W:1I!5m;lb-Z: O7;2E-NU: 7e 7e;5u-hL:qC-5u!5m;-41-yv-yD-1v: 4I(0,0,0,0);-41-yv-yD-1v: dv;} 6O 3N{5C-W:1I} 6O > *:5G {NS: 1I} 6O,6O a,6O a:NG,6O a:NH,6O a:dr,6O a:qH,6O a:5G{1v:#do;3V-3t:1h%;}#yw"+v.id+"{W:1h%!5m;X:1h%!5m;5C-W:1I!5m;5C-X:1I!5m}6O d9{2m:5a!5m;5C-X:1I!5m}");ju(1);if(22.yA){B zB=1y yA(E(e){if(e[0].qN.Q>0){U(B i=0;i<e[0].qN.Q;i++){if(e[0].qN[i]==o.1D){sQ()}}}});zB.NI(o.1z,{NF:H})}o.b4=1M(\'d9\');4w(o.b4,{"id":"NE"+v.id,"zO":"no","1N":"","zP":"H","zN":"H","zJ-ki":"H"});K(o.b4,{\'1i\':\'29\',\'W\':\'1h%\',\'X\':\'1h%\',\'2W\':0,\'3S-2H\':\'1I\'});o.1D.1J(o.b4);o.1z.NB=E NC(e){o.kl++;if(o.kl==5){v.1r=1;1r(o.7p+\' \'+o.hM+\' \'+o.hK)}if(!e)B e=22.17;e.5F=H;if(e.9G)e.9G();B x=e.ge-eO(o.1D);B y=e.mk-gh(o.1D);if(v.ND==1){if(I(v.km)){if(4j(v.km)!=\'\'){o.sF=v.km;I(v.zK)?o.e4=v.zK:\'\';v.km==\'1I\'?o.e4=o.d:\'\'}}}qp(x,y);O J};E qp(x,y){if(o.e4.L(o.d)==-1||v.zL==1||v.4i==1){if(!I(o.4i)){!v.jB?v.jB="3z":\'\';!v.qj?v.qj="3J":\'\';o.4i=1M(\'1R\');B 1H;B n=0;U(B i=0;i<10;i++){if((v[\'rm\'+i]==1&&v.4i==1)||i==9){if((I(v[\'rm\'+i+\'t\'])&&I(v[\'rm\'+i+\'a\'])||i==9)){1H=1M("qM");if(i==9){if(v.NJ!=1){1H.qL=o.sF+(v.ze==1?" "+o.7p:\'\')}F{1g}}F{1H.qL=v[\'rm\'+i+\'t\']}if(i!=9){if(v[\'rm\'+i+\'a\'].L(",0/1")>-1){B z=v[\'rm\'+i+\'a\'].2t(\',\');1H.qL+=\' (\'+(2Z(z[0].1w(4))==1?2M(\'on\'):2M(\'8l\'))+\')\'}}1H.5R("i",i);zn(1H);1H.1p("2u",z9);o.4i.1J(1H);n++}}}K(o.4i,{"1F-2E":"NK","2C-X":"1","9W-7R":"cj","2x":ql(v.jB,0.7)});if(n>1){K(o.4i,{"2S":"g1"})}o.4i.C.5j="NQ";o.4i.gF=z8;o.1D.1J(o.4i)}F{6s(o.4i)}K(o.4i,{"1i":"29","1f":y,"1b":x,"1F-8i":"1b"});B qK=J;if(o.3f-x<o.4i.1Y-20){K(o.4i,{"1b":x-o.4i.1Y});qK=H}if(v.NR==1||qK){K(o.4i,{"1F-8i":"2l"})}o.zk=x;o.zl=y;3j(o.kg);o.kg=1G(E(){3g(o.4i)},47)}}E z8(){3j(o.kg);o.kg=1G(E(){3g(o.4i)},47)}E z9(e){B i=e.4d.7h("i");B y;B qn=J;if(i>0){if(i==9){o.e4!=\'\'?22.7x(o.e4):\'\'}F{B x=v[\'rm\'+i+\'a\'];if(x){if(x.L("2Z:")==0){if(x.L(",0/1")>-1){B z=x.2t(\',\');B b=o.S.qz(x,"2T");2Z(z[0].1w(4),z[1],b);qo();qp(o.zk,o.zl);qn=H}F{y=x.2t(",");2Z(y[0].1w(4),(I(y[1])?y[1]:1S))}}if(x.L("5i:")==0&&o.5i){o.5i.2Z(x.1w(6))}if(x.L("js:")==0){y=x.2t(",");2j(y[0].1w(3)+\'(\'+(I(y[1])?\'"\'+y[1]+\'"\':\'\')+(I(y[2])?\',"\'+y[2]+\'"\':\'\')+\')\')}if(x.L("1e:")==0){22.7x(x.1w(4))}}}!qn?3g(o.4i):\'\'}}E zn(x){K(x,{"2S":"qm g1","3V-3t":(v.yh?v.yh:"55")+"%","gk-dI":"0.NP","1o":0.9,"1v":v.qj});x.1p("jK",x9);x.1p("jJ",x7)}E x9(e){K(e.4d,{"1o":1});K(e.4d,{"2x":ql(v.jB,0.5)})}E x7(e){K(e.4d,{"1o":0.9});K(e.4d,{"2x":"1I"})}o.1m=1y wY();if(o.1m.5x){B rf=(v.xl==1?\'*::-41-P-S-1A-NO-jY {2m: 1I!5m;-41-qP: 1I;}\':\'\');if(v.kz==1&&v.xj!=1&&(v.xe!=1||!o.1m.8V)&&(v.xf!=1||!o.1m.hR)){}F{if(o.1m.5x&&v.qu==1){}F{rf+=\'5O::-41-P-S {2m:1I !5m;}*::-41-P-S-NL {2m: 1I!5m;-41-qP: 1I;}*::--41-P-S-1O-jY {2m: 1I!5m;-41-qP: 1I;}\'}}B 1H=1K.1M(\'C\');1H.1B=\'1F/K\';1H.1J(1K.wV(rf));o.1D.1J(1H)}if(o.1m.rb){v.3W==1&&v.NM==1?v.3W=0:\'\'}if(o.4D==0){if(o.1D.2L==15&&!o.m0&&v.wJ>0){K(o.1z,{"X":v.wJ})}}if(I(v.r9)){v.19.df=v.r9}if(I(v.lO)){v.19.lP=v.lO}if(I(v.1A)){o.2z=v.1A}f5();1G(E(){js("8f");if(v.3E){if(2i v.3E==\'E\'){v.3E=v.3E.6X};2j(v.3E+(v.3E.L(\'()\')==-1?\'("\'+v.id+\'")\':\'\'))}},1)}E f5(){1r("f5");o.V=1y wS();if(!v.3h){v.3h="?"}if(v.pl){v.3h=v.pl+o.ci}o.NN=md();o.xX=0;o.4S=rl();if(o.4S){if(3m.5y("rk")!=1S){o.ri=3m.5y("rk")}F{o.ri=md();3m.7U("rk",o.ri)}if(v.rj==1){if(3m.5y("r8")!=1S){o.3Y=3m.5y("r8")}}if(v.xS==1){if(3m.5y("qV")!=1S){v.8z=3m.5y("qV")}}U(B i=0;i<o.aO.Q;i++){if(v[\'xU\'+o.aO[i]]==1){if(3m.5y("y6"+o.aO[i])!=1S){}F{v[o.aO[i]+\'s\']=0}}}8a("Oc");8a("Od")}o.eY=o.aP.1w(o.aP.L("://")+3);if(o.eY.L("#")>0){o.eY=o.eY.1w(0,o.eY.L("#"))}if(o.4S&&v.aX==1){o.3i=1y OD()}if(v.qR==1){o.6b=v.OE;OC(o.1z,"6b",H)}v.8H==1?o.8H=1y OB():\'\';v.eG==1&&v.qR==1?o.eG=1y Oy():\'\';v.ab==1?Oz():\'\';if(v.OA==1){o.aB=1y OF();o.aB.l5()}o.P=1y xz(v.3h);if(!o.1m.2y){o.1D.1p("OG",E(){o.5t=H;o.l1=H;o.S?o.S.xA():\'\'});o.1D.1p("OM",E(e){if(!o.3q){if(v.1u.7B>0){3j(o.xC);o.xC=1G(E(){if(o.5t!=o.l1){o.5t=o.l1;o.S.xy()}},v.1u.7B*2G)}F{o.5t=J}o.l1=J;if(o.S){o.S.lq()}}});o.1D.1p("ON",E(e){o.3q=H});o.1D.1p("8K",E(e){o.3q=J;if(!o.4G){o.7N=J;o.ck=J}1G(E(){o.5G=H},4v);if(o.1m.2y&&o.S.kt()){}F{o.S?o.S.cS(e.5E,e.7V):\'\'}if(v.lh==1){if(o.S.al()){o.S.7O()}}});o.1D.1p("r3",E(e){if(I(o.S)){if(o.3q){o.S.dD(e.5E,e.7V)}F{o.S.sP()}}})}F{22.1p("OL",tN,J)}v.qY==1&&2i xL==\'E\'?o.qY=1y xL():\'\';o.4f.1p("e8",E(e){o.3q=H;o.5t=H;o.lw=J;ln("1A",e)},{a2:H});o.4f.1p("ae",E(e){if(o.3q){o.lw=H;ln("OK",e)}},{a2:H});o.4f.1p("eu",E(e){o.3q=J;o.5t=J;if(v.ks==1){B 8N=1y 7L().ap();if(8N-o.9V<(v.g2?v.g2:0.3)*2G){kk(e)}}!o.lw?eA(e):\'\';o.lw=J;if(o.4T||o.eg){o.S.4J()}ln("4q",e)},{a2:H});3v{22.1K.1p("8K",E(e){o.5G=J;if(!o.4G){o.7N=J;o.ck=J}if(o.3q&&o.S){o.3q=J;o.S.cS(e.5E,e.7V);o.S.lq()}if(!o.5t&&!o.1m.2y&&!o.1m.tv){o.S.bw();if(o.3b){o.3b.dX()}}})}3c(bW){}22.1K.1p("r3",E(e){o.S&&o.3q?o.S.dD(e.5E,e.7V):\'\'});o.1D.1p("e8",E(e){o.lb=H;o.3q=H},{a2:H});o.1D.1p("eu",E(e){o.lb=J;o.3q=J},{a2:H});22.1K.1p("ae",E(e){if(o.S&&o.lb){o.S.dD(e.ao[0].ge,e.ao[0].mk)}},{a2:H});22.1K.1p("OH",E(e){B x=e.4d.lX.la();if(x==\'xD\'||x==\'xt\'){O}F{o.S?o.S.xF(e):\'\'}});22.1K.1p("OI",E(e){B x=e.4d.lX.la();if(x==\'xD\'||x==\'xt\'||x==\'1R\'){O}F{o.S?o.S.xs(e):\'\'}});22.1p(\'OJ\',E(e){});1K.1p("Ox",cT,J);1K.1p("Ow",cT,J);1K.1p("Oj",cT,J);1K.1p("Ok",cT,J);1K.1p("Ol",cT,J);if(!I(o.b4.eH)){1r("Oi");O}F{o.b4.eH.1p(\'4J\',2n,H);o.b4.eH.yc=2n}if(!o.1m.2y){o.4f.1p("2u",eA,J);if(v.hz==1&&v.ks==1){o.4f.1p("ye",kk,J)}}k9();if(v.4L){v.4L.on==1?o.4L=1y Oh():\'\'}o.S=1y sR();if(v.am.xR){o.kd=v.am.xV}9p();2n();if(o.4S){if(v.sT==1&&v.1P!=0&&!o.1m.2y){if(3m.5y("tl")!=1S){v.1P=3m.5y("tl")}if(3m.5y("gO")==1&&v.kv==1){v.4V=1}}if(o.5W&&v.wP==1){if(3m.5y("sM")!=1S){B sp=3m.5y("sM");B dq=o.5W.L(sp);dq==-1?dq=o.5W.L(sp*1):\'\';if(dq!=-1&&o.S.wC(\'6R\')){o.9T=dq;o.P.9P(o.5W[dq]);o.S.wz()}}}B sZ=J;if(v.td==1){U(B j=0;j<o.bb.Q;j++){if(3m.5y("jr"+o.bb[j])!=1S){v[o.bb[j]]=3m.5y("jr"+o.bb[j]);sZ=H}}}if(!sZ){if(o.1m.2y&&o.3f<4v){v.sG&&v.sG>-1?v.bf=v.sG:\'\';v.sY&&v.sY>-1?v.gl=v.sY:\'\'}}}if(o.3i){B f=o.3i.96();if(f.t&&f.d){o.S.fZ(f.t,f.d);o.S.4s(f.t,f.d);v.1k=f.d}}o.V.3T(v.1P);if(v.4V==1){o.V.4Y();o.S.4M()}o.9M=1y tc();if(v.6Q>0){K(o.1z,{"2W-6k":(v.6Q+"px")});K(o.1D,{"2W-6k":(v.6Q+"px")})}if(I(v.8k)){sX("8k")}if(I(v.dW)){sX("dW")}if(I(o.19)){js("19")}if(v.6J==1&&v.Oe==1){o.V.kn()}U(B i=2;i<10;i++){if(I(v["bZ"+i])){if(v["bZ"+i]=="2y"&&o.1m.2y){6z("bZ",i)}}}}E eA(e){if(o.sL[o.4f]>2){O}o.kr=H;v.g2==0?v.ks=1:\'\';if(o.kC&&v.cJ==1&&v.hz==1){kk(e)}F{ky();if(v.ks==1||v.hz==0){sH()}F{o.kC=1G(sH,(v.g2?v.g2:0.35)*2G)}}}E sH(){ky();if(o.1m.2y){if(o.S.kt()){o.S.sP();O}}v.cJ==1?o.V.eA():\'\'}E kk(e){ky();B y=J;if(v.1T.yk==1){if(e){if(v.1T.Of==1&&!o.1m.2y){}F{B x;if(o.1m.2y){x=e.Og;if(!x){if(e.ys){x=e.ys[0].ge-eO(o.1D)}}}F{x=e.Om}if(x){if(x<o.3f/2){if(x<o.3f*20/1h){6z("4g","-"+tn(v.1T.yT,10));v.1T.2D==1&&v.1T.tq==1?6H(\'4g\',0):\'\';y=H}}F{if(x>o.3f-o.3f*20/1h){6z("4g","+"+tn(v.1T.yT,10));v.1T.2D==1&&v.1T.tq==1?6H(\'4g\',1):\'\';y=H}}if(y){if(e.9G)e.9G()}}}}}if(!y&&v.hz==1){if(v.kz==1&&o.1m.2y){}F{o.2e?o.V.8S():o.V.6Z()}}}E ky(){3j(o.kC);o.kC=1W}E 2n(x){B y=J;if(o.9A!=o.1D.1Y||o.ch!=o.1D.2L){y=H}k9();o.S?o.S.4J():\'\';o.P.4J();y&&!o.2e?js("4J",o.9A+\',\'+o.ch):\'\'}E k9(){B xw=o.1D.1Y;B xh=o.1D.2L;if(o.S){if(v.yJ==1){if(v.19.1i!="2F"){B x=o.S.cZ("yO")+o.S.cZ("1f")+5+o.S.cZ("yR")+(v.tS>0?v.tS:0);K(o.1z,{"X":x})}}}if(o.4D>0&&!o.2e&&!o.d0){xh=xw/o.4D;K(o.1z,{"X":xh})}if(!o.2e&&!o.d0&&!o.aV){o.9A=2I.4N(xw);o.ch=2I.4N(xh)}if(o.1m.2y&&o.2e&&v.ud==1&&v.ti!=1&&eR.bN){if(o.4D>0){if(o.4D<1){B sp=eR.bN.ts(\'w6\');if(sp!==1W){sp.c6(E(){}).3c(E(1E){})}}F{B sp=eR.bN.ts(\'t9\');if(sp!==1W){sp.c6(E(){}).3c(E(1E){})}}}F{B sp=eR.bN.ts(\'t9\');if(sp!==1W){sp.c6(E(){}).3c(E(1E){})}}}o.3f=xw;o.4h=xh;if(I(v.1N)&&o.S){v.1N!=\'\'?o.S.uw():\'\'}if(I(o.fl)){o.P.1x(o.fl)}if(o.2f&&!o.2e){o.2f.2n()}o.3b?o.3b.2n():\'\';o.aB?o.aB.2n():\'\'}E 9p(){o.V.lM(v);U(B x in v){if(v.2h(x)){if(x.L("1N")==0){if(v[x]!=\'\'){o.tk=v[x];o.V.9p(x)}}}}}E 8B(1e,1z,1x){if(1e){if(1e!=\'\'){if(1z==o.2g&&1e==o.sK){}F{if(1e.L("#"+v.9l)==0){1e=o[o.fd[0]](1e)}if(1e.L("#0")==0){1e=aa(1e)}1e=sW(1e);B s="sO";if(1x=="4A"){s="sJ"}if(1x=="1I"){s="2A"}if(1x=="Oo"){s="1h% 1h%"}K(1z,{\'2x\':\'1e(\'+1e+\') no-fo 7e 7e\',\'2x-3t\':s});1n(1z);1z==o.2g?o.sK=1e:\'\'}}}};E Ou(x){if(x.on==1&&I(x.2X)){x.2X=sW(x.2X);B y=1M("1R");if(x.2X.L("3n")>-1||x.2X.L("//")==0){B z=1M("3N");z.2X=x.2X;y.1J(z)}x=8J(x,v.uD);x=4o(x,\'2K\',\'2K\');K(y,{\'1i\':\'29\'});if(x.1i.L("2F")>-1){K(y,{\'2F\':x.bG})}if(x.1i.L("2l")>-1){K(y,{\'2l\':x.4x})}if(x.1i.L("1f")>-1){K(y,{\'1f\':x.8L})}if(x.1i.L("1b")>-1){K(y,{\'1b\':x.3P})}o.1z.1J(y)}};E cT(){if(o.2e&&!vR()){o.V.te(H)}F{o.V.tf()}1r("2e",o.2e)}E Ov(){1r("bN "+eR.bN.j0)}E tN(){if(2I.tP(22.bN)===90){1r("t9");if(v.ti==1){B ok=H;if(v.vX==1&&!o.1A){ok=J}if(v.w0==1&&!o.1O){ok=J}if(o.2f){ok=H}!o.2e&&ok?o.V.6Z():\'\'}}F{1r("w6");if(v.ti==1){o.2e?o.V.8S():\'\'}}}E vR(){O!!(1K.Ot||1K.Os||1K.Op||1K.Oq||(1K.Or!=1W))}E vb(x){O x.1Y==0&&x.2L==0};E sQ(){U(B x in o){if(x.L("vl")>-1){4m(o[x])}if(x.L("vt")>-1){3j(o[x])}}1r("Nu")}}',
    62,
    3445,
    '|||||||||||||||||||||||||||||||||||||var|style||function|else|this|true|exist|false|css|indexOf|||return|media|length|but|controls||for|actions|width|height|time|action||||||||event|control|playlist|key|left|pjstg|settings|url|top|break|100|position|case|duration|hide|system|show|opacity|addEventListener|icon|log||playlist_dic|toolbar|color|substr|scale|new|container|start|type|data|frame|error|text|setTimeout|tmp|none|appendChild|document|hls|createElement|title|play|volume|faction|div|null|hotkey|set|innerHTML|undefined|_o|offsetWidth|replace|||window||||files_quality|||absolute|subs|dash|tip||fullscreen|vast|poster|hasOwnProperty|typeof|eval|vasturl|right|display|Resize|stop|svg|pip|subtitle||split|click|file_type|parseInt|background|mobile|seekto|auto|Play|line|icons|transform|bottom|1000|events|Math|sub|margin|offsetHeight|Lang|points|linear|push|Pause|current_quality|padding|linkurl|removeChild|open_action|border|src|_type|api|||||||||||scaleY|droplist|catch|player|files_subtitle|screen_w|hide2|file|continue|clearTimeout|options|scaleX|localStorage|http|files_query|handle|mouseDown|object||size|current_subtitle|try|tiptext|f2action|mediascale|000000|media2|_0x497e|www|floatleft|ready|plid|hidden|rows|keys|ffffff|xmlns|xlink|files|img|org|marginleft|muted|Seek|pointer|Volume|visible|font|autoplay|dom|default_quality|obj||webkit|Object|preload|youtube||stroke|2000|||xhr|custom|_to|target|delete|mediacontainer|seek|screen_h|rightmenu|trim|_from|f2title|clearInterval|ShowOrHide|MarginPadding|valuefontsize|end|values|Duration|Time|transition|500|attr|marginright|is_hls|quality|fill|folder|Remove|aspect|urls|butPosition|volumewheel|200|rgba|resize||chromecast|refresh|round|plstart|Action|parentNode|m_to|storage|airplay|parseFloat|mute|vast_loaders|int|Mute|onError||vasttype|value|shuffle|arr_up||arr_down|||pause|block|m_type|settings2|gradient|current_audiotrack|valuecolor|Motion|string|share|zIndex|dechar|Hls|important|SetQuality|canvas|animation|ftitle|plx||mouseHere|box|bgcolor|empty|ios|getItem|1px|tagvideo|bga|max|casting|clientX|cancelBubble|focus|isLive|files_audiotrack|onOut|evntclk|charAt|playing|JSON|video|tag|UpdatePlaylist|setAttribute|captions|order|minutes|vastloader|files_speed|removeEventListener|seconds|_value|||isVisible||||||||backgroundColor|visibility|onOver|UpdateText|audiotrack|status|download|f2value|safari|activeiconsize|radius|out|obj2|vast_and|random|state|bgpaddingleft|aover|show2|cursor|File|line3|is_dash|intro|solid|apiProcessor|overflow|toString|pointerEvents|track|pljssglobal|hlsconfig|_url|PluginHotIcon|channels|pass|StopWaiting|bg2|HLS|control2|pjsdiv|Unmute|rounding|speed|default|bgpaddingright|1999|span|live|name|motions|Fullscreen|||||||||||redirect|UpdatePlay|YT|setInterval|center|is_sleep|preroll|getAttribute|bgcolorover|alpha_div|area|_|Events|floor|timer|version|hours|dash_created|layer|remove|fvalue|bgaover|ShowPoster|open|parse|onWaiting|vast_or|hideleavetimeout|ease|Value|realfullscreen|parentIframe|pipwebkit|hlsquality|line3value|files_quality_ag|lines|Date|tipcrn|hidden_volume_over|Settings|over|stretch_width|space|min|_show|setItem|clientY|is_ws|0x0|ll1I|subtitle_on|||||||||||SettingsTimers|Init|vast_|Advertising|onEnded|init|line0|buffered|align|slice|midroll|off|getElementById|Array|gaTracker|gif|current_url|DASH|Waiting|bordercolor|toolbarHidden|next|leftBg|audiotracks|Arrows|default_audio|all|Poster|paused|bgpaddingbottom|ispipkit|always|bgpaddingtop|effects|lIll|UpdateObject|mouseup|margintop|destroy|now|onPlay|concat|scroll|HlsLevelsLength|Normalscreen|txt|ResizeText|iphone|ctx|tipbg|message|_hide||preventDefault|rotation||but_x||flag||||motion_id|container_h|Switcher|evntout|Status|android|lastwheel|End|onDuration|_css2|onMouseUp|enc2|evntovr|vimeo|dashjs|Title|is_live|dashquality|audio|Retimer|scrollbgcolor|_keyStr|waiting|stage_y|stage_x|SetSubtitle|normal_w|control_|info|sub_off|VAST|media_error|stopPropagation|hls_created|ended|charCodeAt|unmute|vertical|alert|switch|location|SetSpeed|Stop|reload|m3u|current_speed|replay|clicktime|white|Background|action_settings|reloadTimer|Subtitle|vast_poster|passive|loop|_rb|ldr|hlsaudio|send|com|but_space|fd0||bitrate|kbps|touchmove|line1|but2|updateSettings|MediaReady|CalculateClick|streaming|SettingsVisible|control_title|currentFile|touches|getTime|onClick|00|Playlist||browser|icn|salt|gax|getElementsByTagName|HideControl|sub_shift|quiz|f2id|CreateItem|fontsize|loaded|StyleItem|DashLevelsLength|Scale|VastRemoveAndPlay|delta|metadata|xbg|fit|vsts|href|image|onPause|search|pjs_i|scrollLeft|fullscreen_process|channel|timestore|butplstart|pause_before_vast|title2|native|fbg|cubic|frameresize|ShowOrHideProcessor|onMeta|MediaPlayer|sec|600|String|sub_options|container_w|_speed||sub_bottom||qualities|tips|onTimeupdate||body|curtain|SubtitleChanged|Clickable|pjs|SetAudioTrack||onload|stout|Tip|scrollTop|SettingsClose|items||plhistory|thumb|forcehide|is_visible|toolbar_hide|line_width|shuffle_|marginbottom|shadow|ScrollTo|source|Toggle|parent|decode|orientation|compilation|_start|marginproc|nativecontrols|vast_impressions|dashconfig|sub_color2|tipalways|err|rotate|controlover|design|videoHeight||||responseText|iconsover|then|ellipse|sub_color|timeline|400|||ActionPlaylist|create|QualityChangedNoHand|onVolume|normal_h|pltxt|nowrap|hidden_volume_over_process|tagframe|l1lI|PipWebkit||onMove|handleicon|0x1|hidedown||line2|PlayerState|not|||hiddenwidth|300|but_y|wheelstep|pjs_id|_0x31a96f|CreateHLS|hex|_0x44d5d8|PlaylistVisible|screenclick|iconscolor|iconangle|vast_longtimeout|_cstm|prev|ll1l|_status|texts|StageMouseUp|FullscreenChange|enc3|vast_preroll_andlimit|titlestore|currentTime|FindPlStart|PlaylistG|fullscreen_start|showoverto|files_|Airplay|Remove2|textTracks|NewFile|err404v|floatwidth|iframe|starttimeout|Home|default_style||readyState|autoplaylist|3000|bgpadding|_control_|inline||plfolder|handlewidth|PlaylistNextExist|fff|_step|spd|link|handle_width||removeAttribute|transparent|bufferLength|opn|polygon|hdicon|PlaylistNext|rightside|bgg|StageMove|levels|butNames|_preloaded|onclick|spacing|sub_or|10px|XHR|dashaudio|shift|buffer|ControlClick|loading_error|8px|20px|SubtitleStart|lang|groupId|overlay|Close|hideonpause|fplace|https|vast_starts|current|sub_sizeproc|brandurl|AfterVast|abc|3px|touchstart|autohide|sub2|CustomSwitch|maxBufferLength||PlacePoints|nbsp|airplayed|url_shift|topBg|load|recover||fatal||_ease|expand|console|VastAddPreload|relative|linecap|touchend||nolimit|rightbs|pic|Il1l|ScreenClick|fontSize|_lastime|nN9kBKA|stretch_with_volume|hidejustfull|minify|contentWindow|settingsovertimer|ToolbarDown|overopentimeout|pauseroll|coh|HideInterval|findLeft|control_line|ScrollOverOut|screen|BufferStop|mode|_wait|NativeControls|xtitle|360p|href2|StyleArrow|showovercontrol|HistoryPlaylist||autoLevelCapping|480p|Ready|mediapip|parentcontainer|headfontsize|RenewPoints|ctx2|hlschangequality|onSeeking||ymax|seeking|speeds|clr|pointed|onSeeked|Off|custom_aspect|UpdateSpeed|_max_order|repeat|videoWidth|paddingtop|float|heartbeat||ratio|f2bg|weight|val|Error|totheend|scrollarrows|canvas2|999|240p|CustomToogle|reloadErrorTimeout|limitmaxwidth|speed1|created|Reload|iconreplay|VastNext|file2_separator|autoQuality|offsettimer|_play_i|seeking_time|sub_shadow|ssfontsize|setSpeed|SettingsN|PlaylistControls|m3ut|sub_bga|event_x|Played|user|5px|dclckto|rect|update|hidewithoutmoving|memory|clicked|pljssglobalid|thumb_width||playersize|SubtitleError|tippadding|pageX|tipbgcolor|14px|findTop|scaleover|vast_longtomsg|letter|sub_size||event_y|sub_bgcolor|alpha|hand|tipfontsize|removed|subtitle_start|RemoveCurtain|pointscontrol|Curtain|rotation2|clickmargin|handlehide|volumescroll|StyleLine|_0x4e576a|timeFormat|128|onmousemove|details|hls_stuck_time|AirplayChanged|sourceBuffer|hidden_volume|domain|deg|l3v_left|pljsmute|found|ToolbarShow|win|clickarea|hideoutmute|while|RemoveSubtitles|span05|l3v_show|hlsautoquality|file_separator|1em|sub_weight||pip_quality|heartbeatInterval|TimeSub|playById|volumewheelin|toolbar_margintop|scrollleft|chrome|svg0|Thumbs||yamtrid|base64|gatracked||SetSetting|HideForce|toolbarInterval|hidetimeout|ResizeSettings|letterspacing|family||days|resizePlaylist|noads|justshow|coloroverplay|posterhide|poster_scale|gain|bottomside|doubleclick|tipbga|file3_separator|onmouseover|onmouseout|pjs_parent|TagPlay|_activeIcon|tippointer|_seekaftervast|navigator|playerid|sizing|compilations|stretchonfullscreen|Mouse|PlaylistPrev|pl_first_id|ipad|onClickSubtitle|720p|lngth|1080p|AudioTrackChangedNoHand|pjs_|playVideo|SettingChanged|isPlaying|ff0000|ShowForce|vol|_readyonplay|mouseUp|num|handleiconspress|YoutubeReady|vastonmobile|bgh|handleaover|quality_received|||||lastTouch||bgo|handlescale|KeyPlusUp|KeyPlusDown||BeforeVast|YouTubeIframeAPIReady|eventstracker|RenewSubtitle||customdesignsvg|100000|imgldd|colorbg|match|svg3|6px|iconscolorover|icon2|adsfirst|leftandrightpadding|doctype|loading|yaCounter|stretch_width_last|saturate|ssflyp|normalscreen|hexToRgb|marginbg|hmaxk|opera|_subtitle_empty|HideProof|resizeonwidth|IconsColor|fcdef|mini|noclick|ceil|wait_to|sub_all|dash_subs|angle|hls_subs|isvg|UpdateTime|documentElement|jpg|thumbs_on|PlaylistShow|998|openplaylistbefore|but_h|tippaddingtop|tippaddingright|bgcontainer|polyline|join|timeline_h|CreateTip|_lastactbut|iconsreplay|poster_aover|poster_a|hideAllIcons|marginprocleft|omt|floatlimitwidth|offsetLeft|pljs||code|datetime|quartile|close|UpdateVars0|UpdateVars|autonextopenfolder|onplaytag|rmbgcolor|today|CreateDASH|isTypeSupported|scale_i|current_plurl|mediaSource|edge|mouseout|mouseover|_0xad5257|recover_swap_audio_codec_date|Update|autoSwitchBitrate|abr|VastLoader|wheelinterval|setQualityFor|PlaylistError|clientWidth|gaTrackPlay|scrollwidth|sub_settings_on|button|Recover|dash_config|333333|showinterval|recover_decoding_error_date|_ended|Load|insertBefore|_stopped|picture|MainUpdateSize|PlaylistRewind|VastRecover|srt|title_template|exception|ssa|rightout|timeld|scripts|iniframe|DoubleClick|rightclick|rc_label|Password|postroll|gifed|bigint|acted|click0timeout|ToolbarHidden|frames|mutestore|resizeonplay|dontplay|ClearClick|nativecontrolsmobile|openById|PlaylistHere|click_t|rld|Player|plurls|PlaylistExist|autoprevopenfolder|wait|audiosrc|forbidden_quality|files_channel|SubtitleLoad2|pauserollonplay|unmuteplease|vast_type|SubtitleLoad|open_settings|subsor|_0xf83c34|full|changeheight|restart_audio|done|started|brd|HidePoster2|mouseHere2|_prevIcon|floatheight|ShowLayer|Start|and|urls_and|container_id|scrollarrowcolor|toLowerCase|touch|hls_config||0xa|result||hidevideo||sans|screencolor|VolumeWheelX|find|Touch|160p|_timeout|StageLeave|onStep|_steps|||youtube_id|mouseMove|thumbnails|navigationUI|playbgcolor|playlist_title|vars|Ended|showtitleplaylist|YoutubeID|serif|stuck|fspr|RemoveMedia|audioTrack|fid|getBitrateInfoListFor|TitleTemplate|_i|playlistloop|playlistrewind|scrollarrowsize|_hlssubtracks|_fullscreen_end|getDASH|ResizePlaylist|script|skip|tagName|HidePoster|loadLevel|container_h_procent|||||limitwidth|getHLS|HlsUpdateAudio|decoration|_dashsubtracks|deltaY|youtu||randomstr||response|playroll|FileType|seeked|vast_preroll_and2limit|pageY|playerjscom|End2|scalesmall|dash_play|dashlowquality|request|Heartbeat||midrollo|start2|fjs|preloaddash|dash_init|leftright|posteronpause|Prefile|IndexPlaylistProcessor|onplay|drm|3600|Text|current_file|updown|StartTimeout|MidrollOverlay|IndexPlaylist|vast_midroll_limit|control_start|timerInterval|timerTime|requestFullscreen|settingsNumberVisible|posterhidepause|Playing|iconopacity|StyleSubtitle|ClickArea|picheight|m3ui|btm|NativeWebkitFullscreen|toolbarhidden|requestFullScreen|mozRequestFullScreen|msRequestFullscreen|_tags|reloadtimeout|sub_font|last_text_w|Marquee|timeshort|checknative|Rotate|onYoutubeReady|Metadata|Seeked|webkitRequestFullScreen|imageLoaded|marquee|play75|play50|cnt|tmp2|TheEnd|SubtitleLoadAll||play25|fts|fonts|RadioTags|icon3|vts|_blank|_currentIcon|StringVar|dasherror|introstart|linkurl0|Preload|CreatePoster|bgcolorlink2|midrolls|sub_store|reloadlog|together|remember_sub|PlaylistLoad|pljssubtitle|tagsurl|MseRenameQualities|StopMedia|playiconbut|nextLevel|write|removeItem|getTracksFor|currentLevel|fixed|VastPreloaded|RemoveForNextAd|but_w|cpm|onTagError|label|iOSTrackLoaded|bg_hide|removeTracks|TitlePl|ShowShare|re_y|PlayerSize|isNaN|ControlCoordinate|firstly|PipSize|ToolbarHide|VolumeWheel|other||fontnames|_recover|logout|CheckPip||enabled|tagSrc||audioTracks|onPipEnter|onPipLeave||LoadedData|nativeControls|startwait_t|ie9|moveOr2end|ssfontcolor|network|ytautoquality|errorMessage|pauseVideo|RenameQualities|ahd|_t|_set_quality|splice|SetCurrentQuality|exitfullscreen|vast_preload|show_settings|playsinlineonmobile|cntrls|onerror|firstScriptTag|contentDocument|destroyed|drawImage|VastPreloadLoad|mutedautoplay|onYtPlayerReady|sstext|show_playlist|order0|_move_rights|_rights|desktop|playerjs_|prototype|reverse_quality|sub_bgpadding|MseIsSupported|heightInterval|SettingsScale|WaitSize|HlsAudioTracks|outro|piped|540p|overlays|toolbarisdown|Loaded|HlsAudioTrack|RenameTracks|recovery|performance|worked|||maxMaxBufferLength|chr|dontload|resizeonmouse|||resizeme|pstr_to|encoded|pepper||QualityChanged|HlsSleep|sleep_timeout|Captions|debug|hlserror|HlsLevel|fromCharCode|255|volumewheelfull|audioctx|youtubeposter|fullblack|AudioContext|SubtitleOff|ima|VastGo|lang_|Yandex|hideuntilstarted|ChangePip|newfile|gained|rename|gao|vastgo|NewAspect|startLoad|ws_created|||vastclick|hls_started|2160p|1440p|playlistovertimer|quick|CreateWS|killMotion|Loading|HidePositionControl|_css|VastVideo|playPromise|denied|last|timeline_w|rmcolor|CheckColor|hex2rgb|4px|dont|reRightMenu|RightMenu|tipa|tipletterspacing|thumb_border||nativefullios|SettingsParser|tipbgrounding|tipfont|tipcolor|butByS|lineHeight|static|content|pushCSS|marginbgcolor|wheel|fontFamily|active|marginbgpadding|png|tmpr|innerText|div2|removedNodes|hidecontrols|appearance|thumb_height|observer|handleiconpress|ll11|l1ll|pljstrack|UpdatePoints|onDown|geo|handlea|handleiconover|||mousemove|LineScale|onup_to|onUp|DVR|pljsquality|autonext|HandleWidth|mobiletv|animate|_time_load||ioscss|ShowHandle|handlehideinit|userid|qualitystore|pljsuserid|StorageSupport||EndMove|over_final|arrinterval|normal|pjs_parent_i|0px|scrollarrowbgcolor||PlaylistPrevExist|Shuffle|||removebykey|resizeFromText|scrollarrowbg|activeicon|pjsframed|hostname|postmessages|played|moz|VisibleCheck|openplaylistroot|updatePlaylist|paddingright|paddingleft|floatmarginright|normalscale|historybga|historytitlea|xvalue|SubtitleSettingsMenu|resizeSettings|toggleControl|VisibleItems|SubtitleTimerMenu|settimer|setaction|borderbottom|noprevicon|||||clck|pjslng|onClick2|Download|150|ActionOptions|ga_proc|sleeptimer|getQuality|ControlOut|getAudioTrack|sxs|viewBox||0x14|_0x312a27|_0x1c746e|embed|referrer|playbgcolored||plopenid|headbordercolor||_stop|addtitleplaylistbr||addtitleplaylist||minute|hour|second|_0xb263|valuefromlang|_0x3e3359|tem|brand|sub_bottommob|ScreenClick2|ReplayIcon|cover|currentposter|moving|pljsspeed|TipText|contain|StageMove2|Destroy|Controls|borderRadius|volumestore|clickscaley|translate|checkBase64|str2obj|sub_sizemob|substore|handlecolor||||||querySelectorAll|thumbs|path|landscape|firefox||Alert|sub_designstore|NormalscreenUI|FullscreenUI|toggle||landscapefull|Places|maintitle|pljsvolume|bgborder|existv|||seekiconbut|bgbordercolor|lock||valuemargin||valuepadding|linker|index|audioGroupIds|hls_stuck_duration|nameofhlsquality|HlsQualityLevels|dashaddbitrate|sourceBufferValidAPI|fragment|_0x2131af|DashQualityLevels|_0x2bc3bf|DashAudioTracks|0x13|nameofdashquality|eventLabel|OrientationChange|sugar|abs|preloaded|120|change2playlist_bottom|900|notframe|parentIframe_style|AudioTrack|prtObj|CustomFonts|_0x372875||analytics||||||||||PjsFr|dvr|landfullmobile|Live|hlslowquality|MediaSource|Level|0x8|FlussonicMsePlayer|0x5|_ue|HlsRecoverMediaError|ErrorTypes|loadSource||HlsLiveWaiting|adscounter|vast_preroll_2andlimit|0x7|hlsTextTracks|0x6|updateTitle|livewakeuptime|_0x593a18|pjsga|livewakeup|ERROR|_0x298796|logo|eventAction|Za|frag|SourceBuffer|supported|onLoadedData|changeAspect|getDate|eventCategory|recoverMediaError|_ud|arguments|224|onLoadStart|last_ors|mimeCodec|640|vast_adid|Hide|elastic|Playerjs|setTracks|setDashAudioTrack|sub_big_fullscreen||setHlsQuality|vast_init|setCurrentTrack|setDashQuality|pjslog|ShowTimeout|rest|autoLevelEnabled|isHidden|full_minutes|hidecontrol|Show|webkitSetPresentationMode|advertising|full_hours||PluginIntro|timelimited|Interval|setDashSubTrack|offsetwrite|setHlsSubTrack|wrapper|addTrack|PlayerjsAsync|showing|timeout|subtitles|Exist|setHlsAudioTrack||timelimit|width100|nohead|SubtitleSettings|timebreak|ct2|toFixed|sub_size_fullscreen|valuealign|ShuffleEnd|playlistfolder|vast_longtimemsg|PjsFrMsg|parentElement|rc_|method|postmessage|styleSheet|XMLHttpRequest|isFullscreen|GET|sub_bg|IFRAME|VastLongTimeout|Stopped|lsfullstart|1800|102|lsfullplay|vast_prestarttimeout|||360|UA|portrait|PluginReplace|autoplaymute|volumegain|sub_bgo|ovr|keyframes|showById|sub_lineheight|scroll_left|gainedsource|scroll_down|connect|_html|Gain|scrollHeight|hexToRGBA|show1value|optStr||isVpaid|offsetTop||vast_midrollbgload|Width|vastcontainer||1200|hlscookies|SettingsSpeed|movable|PipSwitch|SettingsExist|reYT|PipToggle|cancelFullScreen|vast_posterurl|10000|plcontinue|playerheight|finish|finishrewind|livets|intros|maxresdefault|speedstore|imageExists|openpl|Actions|CreateMedia|callback|createTextNode|FindFileInPlaylist|Quartile|System|frmvst||||||msExitFullscreen|passontime|RightOut|lastIndexOf|RightOver|mediadrag|comment|webkitCancelFullScreen|mozCancelFullScreen|nativenotiphone|nativenotipad|exitFullscreen||rKTsnSQB|nativenotios|cancelFullscreen|hidestartbutios|playedquartile|current_time|iosExitFullscreen|TheEnd2|tagsinterval|700|KeyDown|textarea|deltaX||||Review|Media|StageOver|aFSResAS|leavetimeout2|input|onPlayTag|KeyUp|alert404|alert404video|alert404v|PluginErrorVideo|alerts|PluginGeo|fs_error|PostFullscreen|ErrorReload|posterhidestart|file2|templated|trackstore|incorrect|vast_nofirst|template|poster_float|sesstime|Timer|crt||||||ParseUrl|pljsfirst|screenmarginbottom|playByYoutubeId|lI1l|PluginPip|I1lI|onresize|nativeSubtitle|dblclick|removeNativeSubtitle|NativeSubtitle|rmsize||stopotherplayers|seeksides|direction|prefile|InvertPlaylist|newQuality|unset|alertscolor|alertsbgcolor|changedTouches|bordersize|ltr|tap|pljs_yt_|dashaudio_off||dashquality_off|MutationObserver|dashdebug|heartbeatinterval|highlight|PluginThumbs|dashcookies|666666|15px|alertspaddingv|change2playlist|scrollX|shwvstfnsh|alert404text|customBuffer|scroll_height|gaid|assign|margin_bottom|allowLinker|seeksidesec|40000|alertsfontsize|ontouchmove|alertsbga|alertspaddingh|hlsquality_off|||hlsaudio_off|getBoundingClientRect|hlsdebug|hlsvastwait|preloadhls|isSupported|RightMove|RightClick|ass|reloadlive|helvetica|ffdd1f|rc_version|posterhidetime|yamtr|ffect|arial|vtt|right_x|right_y|default_subtitle|RightCSS|StopOtherPlayer|access|subshift|SubtitleParse|HidePoster3|SetChannel|limit||fullonplay|fullonplaymobile|redirectonplay|covervideo|mpd|obsrvr|adblock|playerjs|resume|m3u8|redirectonclick|seeked_time|MediaVideo|allow|rc_labelurl|rc_anyway|endfull|allowtransparency|scrolling|allowfullscreen|framei|attached|sort|clickmarginbottom|clickmargintop|MSIE|cstm|ControlsBgClick|cuid|keyCode|handleiconsover|Control|pressed|UpdateTimer|bordercolored|playId|006|offset|_xIcon|files_scale|setupx|control_share|VastBreak||back|Wheel|ControlOver|seekwindow|High|muteiconbut|yOffset|nums|copied|plusminus|7px|copyObject|which|marginprocbottom|marginproctop|CancelBubble|ControlX|current_thumb|getDuration|action2|openplaylistpause|clickscalex|iconmargin|openplaylistafter|nameofyoutubequality|topside|castdevice|butseekto|bgstretch|5000|geobj|valuebg|getContext|18px|valuebgcolor|str|handlemargin|Ease|casterror|Playback|bgw|setQuality|rotateplaying|inversetime|0val|opposite|hlscaptions|1val|roundout|bold|device|315|_icon|controlCSS|ffeeab|_w|setVolume|seekTo|xOffset|restart|thumb_bordercolor|997|alwaysjustpause|029|thumb_shadow|hideoverwidthlimit|hideoverwidth|ShowAnimate|alwaysnotfullscreen|thumb_borderwidth|playonhover|CreateThumb|_duration_load|848|leavetimeout|hideonvolume|setting|thumb_radius|hideonwidth|HideAnimate|unfixing|hideuntilmeta|ga_event|evenodd|Continue|072|ControlsBg|yamtr_event|rule|hideonfullscreen|ShowControl|linetippointer|hideonwidthlimit|Rectangle|hidevar|yaHit|095|reachGoal|UpdateLoad|UpdatePlaySeek|pointcolor|pointa|220|linetipmarginbottom|toptip|PlaylistMove|titlepl|tippaddingbottom|linktarget|ssflyw|msie|linkpause|270|screenshot|UpdateSettings|1001|pointw|postMessage|resizetext|smallfontsize|HideElement|valuemarginright|handleinit|adsinvitation|valuemarginleft|_time_play|hidewithoutplaylist|_duration_play|Volumescrolled|ads|PlaylistPlayId|PlaylistOpenId|showShare|tippaddingleft|thumb_bottom|007|PlayerjsEvents|003|getPlayerState|_a|PlayingChecker|bgcolorlink0|ScrollDown|RenewFromTitle|onYtPlayerStateChange|leavepictureinpicture|Buffer|MediaYoutube|gradientcolor|linespeed3|Youtube|customdesign|hidewithposter|PLAYING|ScrollUp|hideonplay|with_min|Number|ENDED|loadedmetadata|valuesize|scrollarrowbgover|linkurl2|enterpictureinpicture|with_hours|scrollarrowbgovercolor|volumechange|FFFFFF|linespeed2|rel|DisplayControl|SvgColor|HdIcon|iframe_api|linespeed1|Scripted|ArrowsInterval|gradientcolorbg|youtubecontrols|ControlLine|Color|filter|ontop|gradientcolorload|control_duration|isyoutube|colorload|ytcl|HideLayer|youtubelayer|noClickTimeout|zoom|tipmargin|playsinline|onClickTimer2|youtubeready||playlist_id|ScrollRight|durationchange|displayvolume|height_div|UpdateVolume|onQualityChanged|Qualities|nopause|width_div|Browser|historycolor|customyterror|historytitlestrike|yterrors|VastInfo|url3|Action2|historybgcolor|iconmargintop|url2|onClickSubtitle2|prevorius_default_h|iconmarginbottom|selectOpen|iconmarginright|iconmarginleft|prevorius_default_w|PlaylistBack|valuerounding|minus4back|slash4time|wrong|minus4time|playedstore|playedstored|_nextIcon|line4time|scrollarrowgradient|40px|hideafterclick|timeupdate|ScrollLeft|101|notv|nRAEBSUFzLYKz3UenqB0AKQfA2iFBRsMXjhEXGILnHihz2i5x29fTRxazRheALtdxr0LzK9fCKtjzjAEAR9azLpknqA4WHE4XrA4YOUJWrP2TOofXkA0YGl4WHE4XrA4YOUJWrP2TOPhWHwjYrX5TOXfXrlhXHIEXrlfYHT1XkIEYj43YOP0XjliYql3WHA0YOP5TOlEXj4iXOTkYjl0WHX3YOwiTOPfYkA2Xks2ZOpJWrP1TOofXkA0YHPEXq43YkwkYrw4YRseXrsEYN4kYko2UjmKyuidnqAHxKxKxKxKUj8|default_w|nativefulldroid|webkitSupportsFullscreen|blackberry|Enter|177|999999|nN9hwvpMnHhgxk48W3Y2xk4GWlMUNqUFw3paz24GZGUhzRQ5TGhVNoIGwuY0yu9fXGT6TLmFBvYJTGhVNoIGBSJhxqT6TLY2xjTdNEIUTLYHwuiJTHMiWHTdNEIUTLYHwuiJz3xJAGT6Xq41WlMUNqUewvULyu4GZGThTOP1TOlEXHlGNEJ9WlMUTKYgzLpjz2iDzvt0xqT6ChMUNqUgAKpJAGT6YNhVNoIGz24GZHPdNEIUTKJHz24GZGT8A3xLTSBaxSpMnqAjXNAEyRtax2F0nqAjXNA|1d1562b23333y331y371g27302q193x3e1b3q00111o25212o2o273c2q2m2y25381g23211i3c2b361c2x3s112z1o380w112z3b233v2129381c2v3u1z311o2z182t312p1z2238251s25352c16212v252c1y3u27111z3a251q27333e163z281w12111411133x3b2o192z361u3s2v2z3p113u262c153x392q17213610111m25113u281z3w281z3w26113w2o2129233x3c2b213x2b213x25203b3v2e1z112433163o02323c2b3w141o3c1d3o01312k241z311o2z111z3u291z211d3b3x3c1a1w12322v3w2s353e10111c1o11133x27231v302q12252720352c182833211d1g1a3c162z281y1z121z323u2711101o3u35012z243514351i1s3f1o1g1i1f1f1c1q3d1l2g1q3f1d3g183e1k2e1k1e1h2f1c3e1s3d1k2c1v3e1z2e1s2g1y2c1t2c102e1s3f1i2e1s3c182c1u3e1r2e1s2e1q2c1t1c1i2e1u2e122e1u2c1z2c1u2e1b2e1s2g1e2c1t3e1l2e1s2e1s2e1s1e142c1w2g1r2e1q2e1z2c1u2c1i2e1u3e1r2e1u3e1w2c1v2e1t2e1s2g1g2c1t2c1z2e1u2f1w2e1u2c182c1u2g1x2e1s2g1b2c1s1d182e1u3g1t2e1s3d192c1u3f192e1q1f182c1s3e112e1s2f172e1s3c1i2c1u2f172e1s3f142c1s2d192e1t3f1j2e1s2d192c1w3f142e1q3f192c1u3c1e2e1s2f152e1u3d1d2c1u3f172e1r3f1f2c1s1d192e1s3g192e1s2d172c1v3f1z2e1q3f162c1u3e1c2e1s2f162e1u3e1v2c1u3f172e1q3g192c1s3d1w2e1s2e1s2e1f1c1h3d1i1g1g3g1s1g142e1s2e1f3e1i3g101g143d1g2c1i3e1s1g1o3g1f1c1j3c1e1f1b3g1h2f181d121c1b3f1c1g1e3f1g2c1f3d1u3g1k3e1j1e1i1d1h1d1e1e1h3e191f1k1d183d1e3e1a1g1e3g141d1h1c141e1a1e181e1a1c1a3e1r1g1s1f191f1b1d1m3d1e3f1g1g1b1g1m3c122c163g101e1d3f1f1d1k1e1v1g1s1e1b1f1a3e1s1c1u3e1g3f1c3g141d1i1e1u1f1g3e1s1g1h1d1c1c1e1g1k3e103g1f1d1g1e103f1u2e1s1g1u2c1t2c1h2e1s3g1k2e1u1c1f2c1w2g1r2e1s2e1u2c1t2e122e1t1e1s2e1u1c162c1v2e1h2e1q1g1v2c1s3e1j2e1t2g1s2e1f3d182c112e1y2e10141u203e161e1m3e1i2e1e3f122e1i3f1c1e1i1d1s2g1h1e123g1e1c1t3e162e1s2g1r2e1u2c112c1w2e1e2e1u3e1v2c1w2e1y2e1r2e1t2e1w2e1i2c1v2e1v2e1u2f102c1w2c1a2e1q2g1x2e1w2e1d2c1u1f142e1s3e112c1u1e1i2e1s1e1u2e1v3c1m2c1w2e142e1s2g1r2c1u1d1b2e1s2g1p2e1w2e1z2c1u2g1w2e1s3f122c1u2c1y2e1q1f1k2e1t2e1x2c1v3g1e2e1s1f1b2c1w3e1a2e1q3f192e1v3d182c1u1f152e1u3f1e2c1u2d192e1s3g1g2e1u3d1b2c1w3f1b2e1s3f1a2c1w3e1d2e1q3f172e1u3d192c1u2f152e1u3e1c2c1u3d1a2e1q3f1a2e1u3d1a2c1u3f182e1s1f192c1v3d1d2e1q3f192e1u3d172c1u2f152e1u3g1y2c1u1d192e1q3f1b2e1u1d192c1u3e1x2e1s3e1y2c1m1c143f1j1g1k1f161d141e162g1q2g1c1f161d123e1k1f1b3e1d2f181e1e1d1d1f1o3f1c1g1i3d1i3c1f1e1d1e1c1g1r3c1e1c1a3g111g1h2e1d2d1m3d1e1e1e2e1s2g1l3e1f3c1l3e1d2f1b1f1l1d1a1c142e172f1b2f1d2d1d1d1d1e161e1d3f1a3d173c1k1g1q3f1f2g1e1d1h1c1e3e191e191f1t1d1u3e141e1s1f143f1e3d191e1j1g1q2f1j2g1r1c1c3e1a1g1k3g1d1e1j1c1e1c1i2e1d1g1h2e1k2e1e3d1h2e1r3e1f2e1u1c172c1u2g1f2e1u1e1q2c1w2e1h2e1r1g172e1v2c1r2c1u1e1x2e1s2g1v2c1w1c1v2e1s2f1v2e1w2e102c1u1g1r2e1u1g1m2c1u3c1t2f152e192e191p1h2d1e3g1c1e1i3e1m1e1j1d1k1e1d3e1g1f1g1d1g2c1h1g1b2e152e1u1c1l2c1t2e152e1s1e1l2c1s3e1f2e1u1e1e2e1s3e1g2c1u2f1x2e1t2g1j2c1u2e1t2e1u2g1z2e1s2c1c2c1u1e1x2e1u2e1h2c1s1c1u2e1s2e1w2e1t2c102c1u2e1z2e1t2f1u2c1s1c152e1t2g1y2e1u2c152c1t3g1u2e1u1e1k2c1u1c1z2e1u1e1x2e1s2d1w2c1t3e1t2e1s2f172c1t3c1z2e1s3f182e1s3c1e2c1s3f192e1u3f1d2c1s3d182e1s3f1d2e1s2d172c1t3f1z2e1s3f172c1s3c1k2e1s3f172e1s3d162c1s1f192e1s3f152c1s3d182e1s3f1v2e1s2d192c1s3g1g2e1s2f192c1s3d1e2e1s3f172e1s3c1q2c1s1f192e1u3f1t2c1s3d182e1u3g1y2e1s3d172c1s3f192e1s3f172c1s2c1u2e1s2g1f1e123e193d1q1e1p3f1r3d1d3d1f3c1b2e1p3e1y2f1k3e1f1c1f1g1p3e1d1e183d131e1h2e1b1f1k1f1f3c1g2c1s2g1c3g1c1e1j3c1d2d1b1g1j3f183e122c191d1f1g1g3f1g2e1f3d1s1d1k1e1o1e1i1f1h3d1c2d1k3g1k1g1k3f1k3d1f3d1f1g1j3g1h3f143c1f2e1f3f1s3e1d1e1f1c1i2d121g143g1c1f1b1d1h3b1s2f1s1f1f3e1d2d141d1l1g1a1g1i3e1j1c1f2e1f1e1x3e122e193d1s2d1b1f1w1g1s1g1f3c152c1t3g1h2e1u2g1w2c1s2c182e1u2e152e1k2c1j2c1s3f1s2e1s1e1x2c1t1c1f2e1s2e1j1e102e102c1s2g1h2e1t1e192c1s2e172e1s2f163e153d1t3c192e121s1p1h2r1t2s1d1m1j1t1g141|advertiser|fpu1i1no7kx2|LIVE|writePl|Ultra|Audio|Quad|nSmFBREExO0LrrPhWHo0Xrw3WOXfYHTiZOsEokPhWHP3YOl1WOXfXkP0XrIEZq43YOokYNhkWHXiYOP5TOIfYOA4XOEdXj42XHX0XjmOZq4jXrT1XqhkWHIkXHw4TOIfXHPjYrPdYN40XkXkXGl5WHo3Zro0WOofYkokXksErOIfYOA5YOodYN43YOP3ZNmOXrlfXOw3XrXdYq40XHsiXGliXN40XHI0Xqh2WHX2XHX0TOPhWHojZroiWOAfYOlkZrwEokPhWHojZroiWOEfYOo0YkIEXrlfXOw3ZOPdZq4kYkE4Yql5WHo4XOEdXrlfXOwjXrIEokIfXHPjYqhiXN4kYHI4Yql5WHTiXHsdXrlfZOAhYOIEZq40YkI0YNhiXq4iZOPkXqmOZq42XrTjXjhiXq4kXks1YNl5WHA4YHs3WOPiWHoiXkl0TOIfZrwhZqhiXq40XrXhYNmOXrlfXrX1ZrPdXrPfYOPkXOoEXrlfXkPhXHodXrPfXkX1YroEXrlfYOokXOXdXrPfXrEiXkPEokPiWHT3YrP5WOPhWHTiYHoiTOPiWHA5XrX4WOEfZOA1ZOXEXrPfYkIhYjh3WHohXkI2TPXiXq43ZrPkZNh1WHIjZOIjTOPiWHT3XkP1WOofYrE2YkwEXrlfYOoiYHAdXj42XHP4YGmXXrlfYOoiYHAdXj42XHP4YqmyUjmaxO0LARakv3xgzStext9JzRtexu50XqAExKJdzO0LT2xKxKxKxGAgnHihwvpMTRo9U00iXq45ZroiXjhiWHE2XHA4TPXiXq43XHT4ZqhjWHP3XHs3TOPiWHAjXHE5WOTfYHA0ZOIEXrPfZrI0XrXdXG45ZOXhZqmOXrTfZrI3YOAdYN4iXkT3XqliXj42XrwhZNh1WHAiYOPkTOPkWHwiYHl4WOAfYOw4XHIEokPkWHwiYHl4WOIfXHThZOsEXrTfZrI3YOAdXrlfZOliYOIEXrPfZrI1YrTdXrPfZrsiZqmOXrPfYkT0XHAdXrTfXHwhZOIEXrPfYkT0XHAdXrTfYkwjYOXEXrPfZrI1YrTdXrXfXOAjXHPEokPjWHPkXOo1WOPkWHTjYHAiTOPjWHXhYkwdXrXfXkl0XksEXrTfYOE1YOXdXrXfXkl0XksEokPjWHw2XHs2WOPkWHXhYOX1TOPjWHEkZrAiWOPkWHTjYHAiTOPjWHI3YOw0WOPkWHl3XHTiTPXiYN4jXHs2ZqhiXq42XkE5YNliYq4hXOPkZNh5WHw1Xko1TOP1WOAfYOw4XHIEokP1WHlhXOw5WOsfXHEiYroEXrofXHT1WOXfXHI0YOwEXrTfZrAiZOAdXq44YHT3ZNmOXrTfYHI5ZrXdXq41YrT5ZqliXG4jYHXkWOPfYrsjZrIEXrPfZrI0XrXdXq44YHT3ZNmXXrPfZrI0XrXdXq44YHT3ZNmyUjmaxO0LARakv3xgzStext9JzRtexu50XGAExKJdzO0LT2xKxKxKxGAgnHhgxk48W3Y2xk4GWlMUNqUaw29fXGT6THikBKAEB2JIBRE9UkThUjmMxuJLySo9UkThUk48xjmKyuidWvU1zRs9U25gzLaJAK8LTSpjwu5kxK9jzr0LBSUFzLYdwvpJVOXdTOTaUk48AR9dCuBgzGmhz2JfBSX9UkEfZOEiYkE0XKseXrwEYN4kYko2TOEfZOEiYkE0XKseXrwEXrlfYHT1XkIEXj4iXOljZqliXN42XHskZql3WHA0XrokTOP1TOAfYko0XrIEXNlkWHPhXHX3TOofXkA0YHPEXq43YkwkYrw4YRseXrsEYN4kYko2XqliWHA3YHX1YHE0xq0iYql0WHX3YOwLTRxazRh9UjYKxKxKxKwLWk48ARQ0yNmInqBYXrPfZrT2YkA2Yjh2WHw0Yko0YkIiTPh5WHE3ZrXjYkT2WOofYrI5ZrI4YOAErOIdYq40YkIkXHs3XjmXXrPfXOo3YOo5YNh3WHsjYHA3YrP3TPh5WOIfYrA0XHT0YHPErOIfZOA5XkT3XHwdXrlfYOskYrsiZqmXXrPfZrT2YkA2Yjh4WHohYHPhXHokTPhiXj45YkojXHwiWOPhWHo1Xks1XrIErOP0WHE1Xks1XkodZq41YkojXHo2XqmXXrTfZOl2Xrl0WOAfYrT2YkA1XrAErOP0WHE1Xks1XkodYq40YkIkXHs3XjmXXrXfZrA0XHT2Xqh0WHs5ZrI5ZOo3TPhiXq45XHw3Ykw3WOwfYHo3YOo3ZrPEuGAExKJdzO0LT2xKxKxKxGAgnHhgxk48W3Y2xk4GWlMUNqUFw3paz24GZGUeBvpJTGhVNoIGwuY0yu9fXGT6TLtfzvt0xqTdNEIUTLp5ARsGZGUkBKAGNEJ9WlMUTKYgzLpjz2iDBK9dBu1JTHa7NEIUTK9jxRtjTHM1WlMUNqUgzGT6XqhVNoIGBSJhxqT6TLYMwvmJTGhVNoIGwuY0yu9fTHMGBK9dBu1JTGhVNoIGyNT6YNhVNoIGAK91zKpazKAGZHldNGlETNlETNlETKY1A3pgzvBaxSpMTHMiWlMUNqU3THMiXOldNEIUTKPGZHPdNEIUTKQGxjT6THlfXjTdNEIUTKQgBKtjTHMGXNTdNEIUTKYgzR9jTHMGxKxKxKxKTGhVNoIGw29dz3UGxjT6TKxKxKxKxGTdNEIUTKYgzR9jz3xJAGT6TKxKxKxKxGTdNEIUTKFaxRsGZHPdNEIUTKFaxRtgBvpeBvpJTHMiWlMUNqUjz3pFBRJgzGT6XNhVNoIGwKBhwupIyu5LTHMGYqlhTOsEXNTdNEIUTKULTHMhWlMUNqUMwu5IzRsGZHPVNv0dNEIGw29fBSUgzQ90yu1JTHa7NEIUTK9jxRtjTHM2WlMUNqUgzGT6XqhVNoIGwuY0yu9fTHMGBRJexqTdNEIUTLp5ARsGZGU0xvF0TGhVNoIGBRt4BNT6THl6XOlGWlMUNqUKz250A2J6xqT6XrldNEIUTK1FAKBazGT6THlEXNlhTOP1TGhVNoIGw2iaw2dGZHldNEIUTLp5ARsGZGU0xvF0TGhVTNlETNlETNlGA2thwvUFBR9jTHMGWjTVNv0dNEIGw29fBSUgzQ9IBvUFBRJgzGT6ChMUNqUgAKpJAGT6YjhVNoIGz24GZHPdNEIUTKQHBRJgzGT6TKp1AKQ0yu9fTGhVNoIGBSJhxqT6TLpJCSoGWlMUNqU0xvF0THMGWjlhZHlhTGhVNoIGxK9fBSYaCKsGZHPhWlMUNqUewvULyu4GZGThTOlEXNlhTGhVNoIGw2iaw2dGZHldNEIUTLp5ARsGZGU0xvF0TEMUDqhVNqUHz250AK9dv2U1xKxJAGT6ChMUNqUgAKpJAGT6ZNhVNoIGz24GZHPdNEIUTKJHz24GZGT8xRJ2TRYdwvYknqBdz2QIxvTMAKQfxNILnHikBKAEw2iFA3X9U2YaAKY1zRQjVSUFzKoaUjm2yut3oK94nqAjYqljYql1XNl1XNA|historybgaover|Build|nomidroll|nooverlay|046|nRAEBSUFzLYKz3UenqB0AKQfA2iFBRsMYqhEXjILnHihz2i5zRJfxqmhz2JfBSX9UklfYrIkYksEXN40ZOokZNlhWHs2XHsEXrXfYrP1YHXEXrPfYOX3Yql3TOlfYrIkYksEXN40ZOokZNAExKJdzO0LT2xKxKxKxGAgnHhgxk48W3Y2xk4GWlMUNqUaw29fXGT6THikBKAEB2JIBRE9UkThUjmMxuJLySo9UkThUk48xjmKyuidWvU1zRs9U25gzLaJAK8LTSpjwu5kxK9jzr0LBSUFzLYdwvpJVOsdTOoaUk48AKtHBNm4nqAhUjm5nqAhUjm3yup0yO0LXj41UjmMxuJLySo9UkPjUjmKyuidnqAHxKxKxKxKUj8|nSUJw3oECO0LYG41Ujm5nqAhUjm3yup0yO0LXj41UjmMxuJLySo9UkPjUjmKyuidnqAHxKxKxKxKUj8|c18bb844eb07f2bcd82d8956637ff635|023|customimage|pjsiframed|PasswordTime|nN9LnHhgA3xLnGTdNGlETNlETNlETKJHz24kTHMGnSY2xjm3yup0yO0LXHlLTRFJyuBMBO0LXHlLnHiLTSpjwu5kxK9jzr0LBSUFzLYdwvpJVOTdTOXaUk48ARQ0yNmInqBYXrwdYj4iXkw2XrPkXGmXXrwdYj4iXOIiYHI0YqmXXrsfXHl4XrA4Yqh3WHPhZrP2Zro1TPhiYN4jYkshZrXdYj4iXOIiYHI0YqmOXrofXHA1XOIkWOXfXrI5XrT2XHsEXrPfXOwkXrI3WOlEYj4iXkA1YOw0YqhhTPXkWHTiXrE5YrIiWOlEXNhkWHP5ZrPjYHT1TOldYj4iXOIiYHI0YqmOXNhiXq4hXrIjXrT2TOXfXHPiZOI1ZrPdXrofXHP4XkX4Zql3WHPkYks0YHo1WOP0WHTiZOXkZOIErOAfXrX3Yro2YOsdXrTfYOoiXOo2YqmOYN4iZrXkXOE1YqhiXG40YOPhYOw1TOPfYkE0XkE2YHTdXrlfXOoiYkliZNliWHA4YOX4YHwjWOAfXrl5Xrw5YOsEokPfYkE0XkE2YHTdYN4iYkw2XkAhYql0WHP5XkXhZOs1WOPfYkA3XHIjXkwEYj4iXkA1YOw0YqhiWHA3YkT5XHX2TPXiXN4hZOP3ZOo0WOPfYkA3XHIjXkwEXrTfYOIhYkl2Xjh0WHP3YHwkYkl1TOPjWHo5XOAhYHXdYj4iXOIiYHI0YqmXXrlfYHo0YrP2Yjh3WHPhZrP2Zro1TPhiXj4kZOT4ZrI2WOPiWHs1XHohXOoErOP2WOAfXrX2YHPiXkTEuGAExKJdzO0LT2xKxKxKxGA|reloadjustevent|clone|444444|posterheight|033|the|TV|fileend|fullwheel|default_h|posterwidth|website|outros|014|1ChMUTLYHAKtJzKYgzR9jTHMGXOlhXOlhTGhVNqU0z29dwKQjTHa7NEIUTKYgzR9jTHMGXOlhXOlhTGhVNoIGyRJIxqT6XqhVTNlETNlETNlGzuQjx2JfTHMGWrThTOlEXNlhTGhETlMUNqULAKQIyutfBNT6XqhVTNlETNlETNlGwu5azuQ0yu9fTHMGwuihyRPGWlMUNqUFTHMiNEJ9WlMUTKYgzLpjz2iDBRJ0zRsGZLdVNoIGz3UIxvTGZHPdNEIUTK9fTHMiWlMUNqUFw3paz24GZGU0yvpdxqTdNEIUTLp5ARsGZGU0xvF0TGhVNoIGAR9kyvpaz24GZGU0z3lezRtKBNTdNEIUTKYdyuYcTHMhWlMUNqUMwu5ITHMhWlMUNqU0xvF0THMGTGhVNoIGBKQjTHMGBRJ0zRsGWlMUNqUMyupJTHMiWlMUNqUMyupJz25hzRQ5THMiWlMUNqUFzKJewvpaz24GZGUhz3YaBRJgzGTdNEIUTKULTHMiWlMUNqUGx2PGZHlfYNhVNoIGwKBhwupIyu5LTHMGYGl2TOwEYGTdNEIUTLpJCSoGZGTGNEJ9WlMUTKYgzLpjz2iDzRJfxqT6ChIVNoIGz3UIxvTGZHXdNEIUTK9fTHMiWlMUNqU0CvmJTHMGA2FFARsGWlMUNqUFw3paz24GZGUdyu5JTGhVNoIGyNT6YNhVNoIGAK91zKpazKAGZHldNEIUTLAGZHPhXNhVNoIGwqT6XqhVNoIGwuULTHMGXN4kTGhVNoIGwuigwuoGZGThWHoGWlMUNqUFz3xJAGT6THlGWlMUNqUHz2igAGT6TKxKxKxKxGTdNEIUTKYgzR9jwKAGZGUKxKxKxKwGWlMUNqUHz2igAKigwuoGZGUKxKxKxKwGWlMUNqUHz2igAK92xvTGZGUKxKxKxKwGWlMUNqUGBuxKxvTGZLdVNoIUTK9fTHMhWlMUNoIGw29dz3TGZGUKxKxKxKwGWlMUNoIGwqT6XN41NEIUDqhVNoIGAR9kyvpaz24GZGUGz3p0z20GWlMUNqUewvULyu4GZGThTOPhTOX0TOPhTGhVNoIGyRQfxRiJTHMhWlMUNqUGx3mFxRpazKAGZGT1TOlEYqlhTGhVNoIGBRJhTHMiWlMETNlETNlETNUMyupJTHMiWlMETNlETNlETNUMyupJz25dyvxJTHMiNEJ9WlMUTKYgzLpjz2iDARiFCqT6ChMUNqUgAKpJAGT6XGhVNoIGz24GZHPdNEIUTKJHz24GZGT8A3xLTSBaxSpMnqAjXNAEyRtax2F0nqAjXNA|postertitleonhover|PluginSubword|WebkitAppearance|posters|Medium|Skip|Sleep|files_sleep|current_sleep|vast_impressions_all|MacIntel|nRAEBSUFzLYKz3UenqB0AKQfA2iFBRsMYq41WNl1VqA|nSmFBREExO0LrrEfZrI5ZrIdXrlfYOX3YOIErOEfZrI5ZrIdXrlfYOX3YqmXXGh1WHTiZOA1TPh4WHI5ZrI5WOlErOEfZrI5ZrIdXrlfYOX3YOIEuGmYXNhhTPhjWOlErOTdXrlfXHo5ZOXErOldXrlfXHo5ZOXErOldXNmyUjmKyuidnqAHxKxKxKxKUj8|888888|once|RegExp|nRAEBSUFzLYKz3UenqB0AKQfA2iFBRsMYNhEYNILnHijxuY0TSE9UklLTSI9UklLTSBaxSpMnqAiXGAEyRtax2F0nqAiXGAExKJdzO0LT2xKxKxKxGAgnHhgxk48W3Y2xk4GWlMUNqUFw3paz24GZGUkBR9hTGhVNoIGBSJhxqT6TLY2xjTdNEIUTKULTHMhNEJ9WlMUNEIGw29fBSUgzQ9hAKt2THa7NEIUTK9jxRtjTHMiYqhVNoIGz24GZHldNEIUTKJHz24GZGT8A3xLTSBaxSpMnqAjXNAEyRtax2F0nqAjXNA|Yes|OpenScroll|nN9LnHhgA3xLnGTdNEIUTKQHBRJgzGT6TLmdwvIGWlMUNqU0CvmJTHMGA3xLTGhVNoIGwKAGZHPdNEIUTKULw29dz3TGZGThXOlhXOlGWlMUNqUGx28GZHPdNEIUTKULARQIxRJfxjT6THAEYjl3TOAGWlMUNqUaw29fzuQjx2JfTHMGXNlhTOlEYNTdNEIUTKULwqT6XN4kWlMUNqUGx2QgBKtjTHMhWHwdNEIUTLYHwuiJz3xJAGT6XG4iWlMUNqUMyupJTHMiWlMUNqUMyupJz25hzRQ5THMiWlMETNlETNlETNUMyupJz255z3t0BuUJTHMiNEJ9WlMUTKYgzLpjz2iDzRJ2xqT6ChMUNqUgAKpJAGT6XrXdNEIUTK9fTHMiWlMUNqU0xvF0THMGzRJ2xqTdNEIUTKiJBSpJALYhwuYazKAGZHTdNEIUTKQHBRJgzGT6TKiaBKsGWlMUNqU0CvmJTHMGBRt4BNTdNEIUTKFFzKoGZHldNEIUTKYdyuYcTHMhWlMUNqUKz250A2J6xqT6XrldNEIUTK1FAKBazGT6THlEXNlhTOP1TGhVNoIGwqT6XN41WlMUNqUMyupJTHMiWlMUNqUMyupJz252z2oGZHPVNv0dNEIGw29fBSUgzQ9kBR9hTHa7NEIUTK9jxRtjTHMiYNhVNoIGz24GZHldNEIUTKJHz24GZGT8A3xLTSBaxSpMnqAjXNAEyRtax2F0nqAjXNA|nRAEBSUFzLYKz3UenqB0AKQfA2iFBRsMXGhEXjILnHihwvpMTRo9U00iYGh3WHPkYHwiXrXjTPhiYGh3WHPhZrP2Zro1TPhiYq4jXOEiYkE1WOAfXrl5Xrw5YOsErOP0WHT3Yrl5Xjh3WHPhZrP2Zro1TPXiYN4jYkshZrXdXj4iZrIiXHwjYqliXq4hYHXiZrAdXNl3WHPkYks0YHo1WOlEokXfXHPiZOI1ZrPdXNlhWOXfXrI5XrT2XHsEXNh3WHPhZrP2Zro1TPXhWOPiWHliZrTiXHwEXj4jXrP4Zrs5XqhiYN4jXrEkXkE5TOAfXrX3Yro2YOsdXrofXHP4XkX4ZqmXYj4iXkA1YOw0YqhiXG40YOPhYOw1TPX0WHP5XkXhZOs1WOPjWHo0Xrl0YHsEXq43ZOokZOw2XGhiXN4hYOP3XOP4TOPfYkE0XkE2YHTdYj4iXOIiYHI0YqmOXq43ZOokZOw2XGh0WHP3YHwkYkl1TOofXrIkXkl4YrsdXq43YkAjZrTkYGl3WHPkYks0YHo1WOPfYkA3XHIjXkwEokPhWHl4XrA4YOodXq43YkAjZrTkYGliXG40Zrl3XOwkWOofXrA2YHX3XOsEXrTfYOIhYkl2Xjh3WHPhZrP2Zro1TPhiXN42YOo1Xrw3WOAfXrl5Xrw5YOsErOPkWHX4XHE5ZrwdXrPfYrsjYOlhYNmXXrwdYj4iXkw2XrPkXGmyUjmKyuidnqAHxKxKxKxKUk48W3mFBRE|Opera|Bottom|normalonclick|vast_remove|action_back|wheelDelta|Verdana|platform|nN9LnHhgA3xLnGTdNEIUTKQHBRJgzGT6TLmjxvwGWlMUNqU0CvmJTHMGA3xLTGhVNoIGA2YFzRsGZHPfXGhVNoIGAR9kyvpaz24GZGUHz250AK9dAjTdNEIUTK1FAKBazGT6THlEXNlhTOP1TEMUDqhVTNlETNUHz250AK9dv25JCSoGZLdVNoIGz3UIxvTGZHP2WlMUNqUgzGT6XNhVNoIGyuYgzGT6THikBKAEB2JIBRE9UkThUjmMxuJLySo9UkThUk48xjm0AKQfA2xgAK09U3pjwu5kzRQ0xqE1WNl1VqA|reloaderTimer|partners|logos|Firefox|thumbs_img|crossdomain|moved|__storage_test__|issue|isflash|TGhVNoIGwuY0yu9fTHMGA2FFAKsGWlMUNqU0CvmJTHMGA3xLTGhVNoIGAR9kyvpaz24GZGU0z3leAKJLySoGWlMUNqUewvULyu4GZGTiYqliYqlhTOlGWlMETNlETNlETNUGxjT6XqhVTNlETNlETNlGwKBgTHMiWlMETNlETNlETNUkw2QdxqT6XqhVTNlETNlETNlGwKBhwupIyu5LTHMGYGl2TOwEYGTdNEIUTKULwqT6XN4kWlMUNqUGx2QgBKtjTHMhWHwdNGlETNlETNlETKQfyu1FBRJgzGT6TLmgA2J0yu9fTGhVTNlETNlETNlGxuQkxqT6TKtdwvY0yuXGNEJ9NL0V|map|nSmFBREExO0LrrlfYOw5YOEdXuseXOsErOlfYOw5YOEdXuseXOsErOlfYOw5YOEdXNmXYj40YHI0Yjh1WHTiZOA1TPhhWHo2Zro4WOPhWHokYksErOlfYOw5YOEdXuseXOsEuGmYYj41Xkl1XGhhTPh5WHskXOsjWOlErOIfYrXhYrTdXrlfYHT0ZOTErOAfYrXhYrTdXrlfYHT0ZOTErOAfYrXhYrTdXNmyUjmKyuidnqAHxKxKxKxKUj8|All|Windows|ipod|nN9LnHhgA3xLnGTdNEIUTKQHBRJgzGT6TK5JCSoGWlMUNqU0CvmJTHMGA3xLTGhVNoIGA2YFzRsGZHPfXGhVNoIGAR9kyvpaz24GZGUHz250AK9dAjTdNEIUTK1FAKBazGT6THlEXNlhTOP1TEMUDqhVTNlETNUHz250AK9dv3YMwvUJTHa7NEIUTK9jxRtjTHMiYjhVNoIGz24GZHldNEIUTKJHz24GZGT8A3xLTSBaxSpMnqAjXNAEyRtax2F0nqAjXNA|nRAEBSUFzLYKz3UenqB0AKQfA2iFBRsMXqhEXjILnHihwvpMTRo9U00iXN41XHT3YrlkWOPjWHX0ZOoiXHEErOPhWHsjXHA1XOXdZq4kXOXkZrohXqmOYq41Xkw1ZOw0ZNh5WHPiZrshZOI4TOTfYrX0ZOl5ZOIdXrPfXkE5YHI4XqlhWOPkWHIiXHskXOsEokldYj45Xrs5XHsiZql1WHTjYHI2ZOA3WOXfXrIjYkP1XkwEXrlfYrTjYkshXjhkWHPkZrE2XOPErOPhWHsjXHA1XOXdXN4iXrA2YOAhYrIErOP4WHlhXks4XrEdYG4jXkXhXHI5XjmXXrlfYrTjYkshXjhiXG4kYOE0XrT4TQMLTRxazRh9UjYKxKxKxKwLWk48W2A|toUpperCase|Edge|Safari|Trident|webkitendfullscreen|webkitEnterFullScreen|1296p|Super|DSi8WKigwupJAGFjwu5IVqm7AR9kyvpaz246TSUJzRQ0yvxJZ21FAKBazHMEXNmFBvpgZ3BaxSpMZGl1XSm4Z30fzR9FxRtjVSUFzKoaZKUJxK9jxqm7w29fBRtfBOMEUjA7xRJkARiFCrMEwKigw2d7ARQIxRJfxj10z3l6TOPhXNs7Dq5HyvUHBuiFAGFjwu5IVqm7wu5azuQ0yu9fZGmjz3pFBRsMAKQfxNIEXLXEzRJfxuQjTRJfxKJfyvpJZ2FJyuBMBOMEXrlhUre0AKQfA2xgAK0ez3Uax2JfZGmHxu50xvTEw2tfBRtjZ3BaxSpMZGliXOlJZ3mgA2J0yu9fZGmFwLYgzSt0xre0z3l6TOl7wK90BR9eZGlhZ2iJxLo6TOl7AKJLySo6TOl7zuQjx2JfZGmFBvpgZ30fARQ0yNFjwu5IVqm7A3pjz2eJWupFA2FFALUFCrMEXqhEXHlhZ3Y0AK9cxq1IwvYMz2xKA2t0ZGlhZ2Qfyu1FBRJgzHMExRQkyNFjwu5IVqliWHtkTRtFA2seyu4ez3t0TRJfxKJfyvpJZ31ly2t5xLUFzutkTSUgBRQ0xqFjwu5IVqm7XrlhUqm7BSUFzLYKz3UeZGmjz3pFBRsMXkwhxRtLVre9DsmcxvJKAKQexvXExRQkyNFjwu5IVqm7XNsEC3Y0AK9cxq1IwvYMwvUjwvI6TOPdTOThXOekBSUgy2sexRQkyR9KxLYJBOMEXOe9YrlJTSekBSUgy2sexRQkyRQjAKQ5ZGl4ZqhEXHlhZ3Y0AK9cxq1IwvYMz2xKA2t0ZGleXkthCOe9XrlhUqm7A3pjz2eJWupFA2FFALUFCrMEZOIdTOThXOekBSUgy2sexRQkyR9KxLYJBOMEWrPjYSm4Z319TGhVNoIGwuY0yu9fTHMGwLtKxKtjTGhVNoIGBSJhxqT6TKYkAjTdNEIUTLmgA2J0yu9fTHMGw2tfBRtjTGhVNoIGA2YFzRsGZHPdNGlETNlETNlETKYdyuYcTHMhWlMUNqUMyupJTHMiNEJ9WlMUTKYgzLpjz2iDA2t0BRJfx3XGZLdVNoIGz3UIxvTGZHIdNEIUTK9fTHMiWlMUNqUaw29fTHMGnSY2xjm3yup0yO0LXHlLTRFJyuBMBO0LXHlLnHiLTSpjwu5kxK9jzr0LBSUFzLYdwvpJVOTdTOTaUk48ARQ0yNmInqBYXrTfYrP3YHlkYGhiYN41ZrI1ZrEjTPhiXq44ZrPkXHo5WOPjWHohZOl0XGmOXrTfXOA0ZOwjXGhiXG4jYOAhZOs3TOPjWHT0YkP0XOXdXrTfXOA0ZOojXqliXG40XOI3YrXjWOPiWHE5XOskYOAErOP0WHwhXOPjYOsdXrTfYrP2YHE3ZNmOXrofZOXiXrwhXjhiXG4iZOljZOlkTOP1WHljZrI5XHodXrPfZOTjZrTjXjliYq4jXOA5XOliWOPiWHo1XrIhYHAErOPkWHs3YkA4YrEdZq44Yko0XkI3ZNmOXrXfYHs1ZOAkZqh5WHw0XHw1XkX4TOPkWHAjXko5ZrEdZq40XOw4YOTkXqliXj43YkP3ZrskWOIfXrwkYkA4YkAErOP1WHI2ZOwhXkXdZN42XrXjYkAjXjmOXrsfZrE0YkP1Xjh4WHoiXOo2XOX1TOP2WOEfXHl2ZOX2YrPEXrwdYj45ZrIiZrEhZqmOXrwdYj43ZrP1YrI2ZNliYq45ZOX5XOEjWOAfYrE4YkTjYHTEXrsfZrw4YHlkXjh3WHX4YrIiYrEjTPhiXj43YkP3ZrskWOwfZOX1YOP0XHEEokPkWHAjXHw4XHwdYG41ZrTkYrl3YNliXj42YrshYrw3WOwfXks2YrT5YrEEXrXfYrA3YkE1ZNh2WHPjYOA0XkP4TPhiYq4jXOE3XOAjWOofYro3XHE2XksEokP1WHljZrI5XHodYN4iYkAhYrA1XGliYN44XkPiYHlkWOXfZOP4ZrPjYkAEXrofYHlhXrT0YqhkWHo4XHo4Yrl4TPhiXG40XOI3YrXjWOofXrl3ZOoiXksEokPjWHT0YkI0YkodXj45XHokYOl4YNliXG4hYko4YHTjWOXfYksjXrl3XkAEXrPfZOIiXkT0ZqhkWHs5XOXkYNmXXrTfYrP3YHlkYGhiWHX5Zrs4YOEEokPjWHP4XrPjZOwdXq4iYHI0XrTjZqliXq44XHT4ZrP4WOlfZrw5ZOlkXOX1TOPiWHo1XrEhXrEdXN43ZrP5YOPhZOEErOIfZOA0XOP4YHTdXG40XHT1Xks2TPX5WHw0XHI4XHA2WOTfXko0YOwkXrsEZq40XOwkXrAjZqhjWHT3Ykw1YkA1TOIfXrwkXHP1XrPdXG4jXHE1YHo5XqmXZN42XrX0XOljXqhhWHlkXrX4XOT4XHXEokEfYOl5YkX1YrodXN4hXrwhZOE1YkT5TOEfXHl2ZOA3ZrEdXNl3WHI5ZrP5YkIkWOlEokAfYkIiYrP3ZOEdXNl3WHs4ZOw0XOP1WOlfXOP2XOE4YrAjZql3WHX4YrA5XHw4WOlfXOXiXkEhXHEjXjmXYG44XksiZOl3YGhjWHTjZOs2YOIiTPX2WHs5XHl2ZOo4WOTfXHA3YHs3YksEYG4kYrwjXOlhYNhjWHX0YOo2XkP1TOwfXrT0Xkw3XrwdXG40XHT1Xks2TPh0WHs0YHs5YOljWOlfYkIiZroiXOE4TPX0WHP3YHT5XOI1WOlfZrAjXHXkZrAkTOXfZOP4ZOEiYrPdXq4iYkPhXrwiXqlkWHo4XHX4YHX1WOPfYOljXOl1YHsErOofXrl4YHw1XOodXj41ZrT3YOo3YGmOXj45XHsiXHA3XjhkWHA1XkAiXrP4TOXfYksjXOwjYkPdXj45XHw3YHP2ZqlkWHs5Xrl1XkIjWOofXrl5YOo1XrwErOPfXkI5ZOw1YOodXj40ZOXjZrThXjmOXq4iYHE4XHI1ZNhkWHEiZrAiZrAjTOlfZrw5ZrI3YOI3WOofXrA3ZOw0YOAEXN43ZrThZrI4ZOsdYN41YOE4ZrliYGmXXG40XHXhXHPkYGh2WHPjYHX1Ykl4TPXjWHX0YrAkXOT4WOwfXks4XrokYOEEXG4jYkEiXro0YGh2WHs5XkI1YOs1TOTfXHT5XOPiYkAdYG44XkAhXrEhZqmXXN4hXkPkZOw1Yko2WOAfXkE3YrP5YHXEoklfXOP2XOIiYkI4Zqh3WHs5XOXkYHsjTOldYj43ZrX5YHlkYqlhWOEfXOlhZOliZrPEokldZN4jXOA2YOX0YGlhWHliYHl5XrA5ZOIdZN40XrPjYrAjXqlhWHlkXrX4YHs3YOwdZN42Xro4ZOPhYqmXXG4jXHIhXrP3Yjh5WHP2YrX4XHs5TPXjWHT3ZOPiYOo2WOIfYOl4YOo2XrTEXG4kYOs3XkljZNh5WHw0YOT0YkPiTOTfYOTkXOTiXkwdZq44YkwhYOX2TPhhWHA5XHl5ZrE4YqhiXq40YrX1Xrl1TPXhWHI2ZrI5Yko5YjhiXq44XHX3XkIkTOPfXrw4ZOT5YrEdXrTfXrEiZOE0XqliWHX5ZrE2Yro0WOPjWHsiZOXiXrEErOXfYrIiXOskZrTdXrPfZOIjXrs4YGmOXj43YrThYrT2XGhiXG4hYkw0YHwiTOXfZrT1XrT3YkXdXrTfXHo3ZOIjYGl0WHPhZOw2Yrl0WOPjWHohZrw2YGmXXj40ZOTkZOwkYqhiYN42XOPjXHTjTPXkWHEiZOE4XrsiWOP0WHEkXrX5YOAEYN4iYkAhZrEhYjhiYq4hXkliZrAEYN41YOA0XOPiXjhiYq4jXOE4YHs5TPh2WHPjYrP3YOT3WOPkWHs3ZOT3XrXEokwfXks3XOl3XrsdXrXfYHs2XkokZNl2WHs5XHE3YrwdXrXfYkTkZrs2Xql2WHEkYrI4YkE3WOPkWHA3XHT0XGmXYj4kZOw1ZrI3ZqhiYq45YHE2XOI2TPX3WHs4Zro1YkX1WOP1WHI4YOAiZOoEYj43ZrXiXrP5XjhiYGl4WHlhXOEhXHl3WOP2TPX4WHThZOo5XHTiWOP2TOEfYOPiXkX5YHAdXrsfZrEkZrPiYNl4WHwiYrlhYOX0WOP1WHI2ZOwhZrwErOIfXrw0ZOP5XHodXrXfYkAjXHojTPX5WHohYkIkXrsjWOPkWHAjXkP0ZrTEZq42YOo1ZOw4ZqhiXj42Yrs1YOw5TOIfZOA1YHTjYksdXrXfYrA4XHAiXjmXXrPfYOskYOl2WOP1WHThZOE2YrIEokPiWHEjXHE5XrEdXrsfXOT4YrAkTOPjWHP4XrPiZOsdXrofZOT5YkIhZNliXG41XrA2XOX2WOP0WHs5Zrs5ZOTErOPjWHsiYkwhXkwdXrofYrI5YrI4XGmyTP03WHI5ZrI5YOI2WOPhWHAkYrwiYkTEokwfYOE5XOThYOodXrlfYkX1YHP3XGl1WHT2XkEjYOP2WOIfYrPhYHw2YrwEYq4jYHX4XHoiYGh3WHI5ZrI5YOI2TPX1WHT2XkEjYOP2WOwfYOE5XkTkXksEYG40ZOIhXHl0YNh1WHT2YrP3Zrw1TOAfZrI5ZrI0ZrwdYq4jYHsiYkI2YqmOZq41Xrl5YHI0Yjh1WHT2YrP3Zrw1TOPhWHAkYrX1ZOwdYG40ZOIkXkX0YNliXN43XkskYrE2WOAfZrI5ZrI0ZrwEokPhWHAkYrX1ZOwdZq41Xrl2Yrw0Yjl5WHsiXOI1ZrX5WOPhWHAkYrwiYkTEYj45ZrI5Zro5YGhiXN43Xks2XrAjTQMLTRxazRh9UjYKxKxKxKwLWk48W2A|MiTV|Full|TGhVNoIGwuY0yu9fTHMGA2t0BRJfx3XGWlMUNqUhz3YaBRJgzGT6TKYgzLpjz2ikWvUax2F0TGhVNoIGzuQjx2JfTHMGXNlhTOlEXrsGWlMUNqU0CvmJTHMGA3xLTEMUDqhVNqUHz250AK9dv3mdwvJdyvY0THa7NEIUTK9jxRtjTHMiXNhVNoIGz24GZHPdNEIUTKJHz24GZGT8A3xLTSBaxSpMnqAjXNAEyRtax2F0nqAjXNA|Tiny|1006|nRAEBSUFzLYKz3UenqB0AKQfA2iFBRsMXGhEXjILnHihwvpMTRo9U00hWOlErOP2WOlErOP2WOTErOldXGmXXNhhTQMErrldYGmXXrwdYGmXXrwdZNmXXNh4TPhhWOwEuGmYXNhiXGmXXrwdXrTErOP2WOP0TPhhWOP0TPhhWOPjTQMLTRxazRh9UjYKxKxKxKwLWk48W2A|Small|a5b361s2z2a29333716263q013z1m27312q193v2e1d3q0z1z2m3q01302k3x3u37242t223p113038251s27332z16212x232z1c3u291z1z3a251s2533211622361w1112161z133x2b2q173z261u3u2t3z2p113w243c153x2b2o17212611101m253e1i3c2938182x3s10111o280w10113b233v3z2b38182v3s12111o3c162v3b233v29233x3b213v2b233x1z1z2u2911303s291u2u271p2q1i27303o2e1z2312193x111130223516212o193x111k1t33211d223n3c113w2o2z1o1g27211o1m25111s253r193126143c1e3e2b361a3y2b341v3u2u3q3u37302b3r373037191621141z121o253c1o11113w243c1d373a3v1z1z23141g1b2g183f1i1e1j1f1l3c181e1t3e1a2e1b3f163e1p3g1k1e1u1e121f192c1t2e102e1s2c1z2e1v2d1u2e1s1e132c1t3g102c1u2e152e1r3e1u2e1w1c1k2e1u1e1x2c1u1e1z2c1s2f1w2e1r3c1t2e1u2d172e1t2e1s2c1s2e1g2c1u2g1t2e1s2d1r2e1u3e1x2e1s2g122c1u2g102c1t2g1z2e1q2c1s2e1u2e1v2e1t2e1t2c1t3e1x2c1s3f1w2e1s3c1q2e1u3e1h2e1s2f172c1s3f122c1s2f182e1q3d1h2e1u3d172e1s3g1y2c1s3f192c1u3f1u2e1q3d192e1u3d1t2e1s2f152c1u3f1x2c1s3f192e1r3c1c2e1u3d182e1u3f1w2c1s3f1b2c1u3f182e1q1d192e1w3d1b2e1s3f152c1s3g1t2c1s2f192e1q3d1c2e1u3d192e1s3g1u2c1s1f192c1s3g192e1q3d172e1u3d1b2e1s2e1s2c1s1e1h1c1b1g1e3g1a1c1i1g1r3e1r3d1f3f1d3d1i2f143d1o2f1f2g1k1c1b3e1e3e1c3g1m1g1d2e1q3g1e3c1c1f1f3e1b2d161g1u1d1b1g1c3f1d1e1g3f1i2c1c1e1d3e1d1e1m3e1e1c183f133g1f2c1b2f1m3e1d3e1g3g1h1e1j1g1l3e143g1e3g1k1e1m1g1k3e1b2e1f1g1f3b1d2f1e1c1s2g1f3f1d1d121e1e3d1c3e1m3g1j3c1d3g1a1e1d3e123e191d191f1h1d1d1f1j1g1d2c1l2e1e1c1c1e1d3f1d1c181d1e1e1h1f102e1r2c1h2e1w1e1p2e1s2e132c1t2e1j2c1u2g1t2e1s3d1s2e1v3e1t2e1s2g1j2c1s2g1f1d1u2g1q2e1r1e1l2e1w2d152e1t1e1y2c1u3e112c1y3f1z2e1v1c192h1s143e1h2f1a3e1p3e1c3e1u3e1c1g1k3c1h1e1q1e1h2c1a1d1i3d122e1w2g1t2c1w2f1t2c1q3g1z2e1s3e162e1w2e1w2e1v2g1z2c1u1e1u2c1q2g1x2e1t2c1x2e1v3c1t2e1u3f1w2c1w3e1s2c1q3g1j2e1s3c112e1u2c1c2e1u2e1i2c1u3e112c1s2e1x2e1u1d1t2e1v1c1e2e1u1f1x2c1v2e1r2c1s1g1x2e1t2c172e1w3c1w2e1u3e1e2c1w2e1t2c1q1f182e1u3c1i2e1u3d172e1w3f162c1u3f192c1q3f1d2e1s2d1b2e1u3d1t2e1u3f192c1u3e1a2c1q3f1b2e1u3e1d2e1u3d162e1u3f182c1u3f1b2c1s3f1x2e1s3d1a2e1u3c1a2e1u3f192c1v3g1f2c1q3f1b2e1s3d1m2e1u2d152e1w3g1c2c1u3f1b2c1s3e1s2e1s1d192e1v3c1g2e1u1f172c1u3f1d2c1q3f192e1s3c112e1u1c1i1e1a1f1k1e1l1g1e1c1g1f1r3f1r3b1e3g1e1d193g1j3f131d1q1e1k1d1f1f1i1e181c1e1f181e1d1f1l3e1d1c1i3f161e1f3g1b1f1c3d1u1g1r3c1d1e1f3f1s2d1r1e1d3c1d3f1e1e1p1e1e1g1l3e1b1e1u1f1p1e1r1g1r1e1k1g1e1f1k1d1a1e1a1c122f1f3f1d1c1r3e1e1d1e1f162g1c3c1i3e1f3e1d3f1e3e1i1c141e181e1i1f1j2e1s2e1s3f1h3e163g1m1f151d1m1e1e1c1b3f1u3e1c3d1u2g1q3c1b1e1y3f142c1w2g1l2c1s2e1t2e1s3d1m2e1u2d1q2e1u1g1i2c1u3e1y2c1s1e1j2e1s1e1y2e1w1e1i3e1w2e1u2c1w1g1q2c1q3f1j2e1s2d1g2e1u1d132f1v3e1w2d1y141m1e1p1g1e1e1i2e141g1e3e1h1f1g3g121d1i1g1j1e1t2e1k1g1u2c1r1g1g2c1u1e1w2e1r2c1k2e1u2c162e1u2g1k2c1s1f192c1u2g1r2e1s1e1x2e1s2e1y2e1u3f1y2c1s3e1w2c1s1f1m2e1p2e1v2e1t3e1g2e1u2e1s2c1s1f1r2c1t2g1v2e1q2c1w2e1s3e1e2e1w1e1x2c1s3e1r2c1u2e162e1q2e1m2e1u1c1k2e1w3e1f2c1u3f1z2c1s3e112e1r1d1u2e1s1d172e1v3e142c1s1f182c1u3f1a2e1q3d172e1s3c1b2e1u3f152c1u3g1t2c1s1f1b2e1q3d1e2e1s3d172e1u3g142c1s1f192c1s3f1i2e1q3d172e1u3d142e1u2f172c1s3f1z2c1s3f1b2e1q3d1w2e1s3d192e1v3f1c2c1s3f172c1s3e1d2e1q3d182e1t3d192e1u1f152c1t3e192c1s3f192e1q3d192e1s2c1u2e1u2e1u1c1f1e123c161e1m3g193c141e121d141g1u2e193c1q1e183c1c1e1i3g121d1h3g191e1c3f1u1g1k3c1d1e1f3d1s2g1r1e193c1d3f1c1c1p1g1e1g1a3e1f1e1s1d1c3e1f1f141e1s1f1b1e1j3f1e3g1e3d1g2e1f1c1q3f1e3f1h3d183f142c1a1e1e3f1d3d183g1f1e1p3e141f123c1e1e1d3d1s3f1k1f1d3d1m1g1d1c143e1u3f1k3c181e1t1c1c3g1i1g1g3d171g1e1c1o1e1e1e1d2c1s1f1f3e1p1g1e3e1i1d1m3e121c1t2e122e1q3c1u2e1t1e1u2e1v2g1x2c1t1e1s3c1r1e172e1r2c1k2e1u2c1f2e1w1e1t2c1f2f1s2c1t3g1v2e1r2c1l2e1u1e1s2e1u1e1x1c152f193c102e1w1e121j2l1u1k1p2j2l1j1k2h121o|roll|iemobile|nRYaAKYdxqmHzRQkAk0LARQ0yNFjwu5IVqAEA3pjz2eJnqAMw29dz3TaUjmHCO0LYrlLTRY5nqA1XNAEAH0LXHlLTRxazRh9U25gzKsLTSY0AK9cxq13yup0yO0LXGAEA3pjz2eJWu1aBRtjzRJeyvo9UkPhUj8|Philips|appName|28e3co3q1t3s221c291s3b3v211d3o01101o272z3q193x3e1i1b3v111k1a21173u3y1z311411153v3b2o1932241u3s2v322n113u263e133x392q1920361z211o233e1g2e2b361y2v3u11101o360y11102b213x3129381w2x3u1z121m2e182t213n113238251q27352c162z2x252c183s29111z3a231s27333e1421381w1c3s291y2s29162u291s3u271q3e1z3w2611113u281z3w263s3o3o01112z3b3w141o252e2o111z21141z121o253e3o2o37203q1z213129233v2238143q0z1e1e2t2e292q142s11101f311o113z3a25353w253w273r153623111z3a371131141j1z1e1o2c182t212r2c2b213x312o1i27333e293y121o141s2e1d2f1g1c1j1c122g1i1e1a2g1r1c1c3e181g131g1i1e1m1d1h2c1s1f1p2e1r2g1v2c1u2c1w2e1q3g1c2e1w1c112c1s3e1p2e1s2e162c1u2e1m2e1s1e1i2e1w3c1j2c1u2f1x2e1q3e112c1v1d1u2e1q1f1s2e1u2c1w2c1t3g1t2e1s2e1x2c1w2e192e1s1f1w2e1v2e1s2c1s2f1w2e1r2g1q2c1v1c1u2e1r2e1q2e1u2c102c1s3e172e1s2g122c1u3c172e1r3g1r2e1u2d192c1s3f1v2e1q3f192c1u3d1e2e1q3f172e1u3d1c2c1s1f172e1r3g182c1u3d182e1q3f1t2e1u1d192c1t3g1a2e1q3f1a2c1u3d142e1q3f172e1w3d1c2c1s3f162e1q3f1j2c1u3d192e1q3f1b2e1u3d192c1s3f1r2e1q2f1b2c1u3d162e1q3f152e1v3c1k2c1s2f152e1q3g1b2c1u3d172e1s2e1s2e1u2c1g1c1f1e1k1g1a1e1m2d1f3c1b2e121e101g163d1u3d1c1g1s1f1u2f1l2d1a3e121d1d1g1c3g1r1c1d3c1f3f1h3f111g1q1c1k1e1h3f1e2e161e1e1d181e1s1g1h3e1d1e1i3e161d1h3g171f1d3f1u1e1r3c1f1e1d3f1d3f1e3d1e3d1f3f1d2f192f1g3d1g3d1e1g1q1e1d1e161e1u1e1f3g1p3d1d3f1e3c1e3c181e1d2g192e1e1e1d3d1g2e1d2e1d1g1m1c1f3c1g1f1e2e1h1f1v2c1u1e1j3e1b1f161e1f3e1k3e1f1e1e3e1r2g1q2c1w2d1k2e1q1g1y2e1v1e1z2c1t1e1r2e1s2f182c1v2e102e1q3e1t2e1v2c1y2c1f3e1q2e1q1e1h2c1v2c1t2e1s1e1k2e1u2e1e1c1z3e133f1v2f1h321r2d3g1b3d1q1c1b1e131g123e161e1i3d191g1e2g1k1e1z3e1i3e172e1t3g1v2e1w2c1v2c1w3g192e1u1f102c1t2e1s2e1s2f1y2e1v2e1l2c1v1e1u2e1t2e1u2c1s3c102e1s3e192e1w2e102c1u3e172e1t3g112c1s3c1y2e1u1e1o2e1v2c152c1u1e1o2e1s3g1h2c1u2c1g2e1s3g1g2e1w2d1x2c1v2g1j2e1u2g1v2c1u3e112e1s2e1c2e1w1c1x2c1w2e1h2e1s1f1a2c1u3d1c2e1s3f192e1u3d1a2c1u3f192e1u3f1q2c1s3d1b2e1t3e1d2e1u1d182c1w3f152e1s3f192c1t3d1f2e1s1f182e1w3e102c1u3f182e1s3f1b2c1s3d1a2e1s3e172e1u3d172c1u3e1d2e1s3f192c1s3d1q2e1s3f192e1w3e1f2c1u3f172e1s3f1l2c1s2d1a2e1u3f1b2e1u1d172c1u3f1b2e1s2e112c1s2c1m1e1h3e1c1f1g1c1h3b1e3f1c3e1b2e161c103b1f3g181f191g1e1e1g3d1i1e1c3f1c2g1m1c1l1c1k1f1h1f1c3e1j1c1b2d1m1f183f1c3e1c1e1g3d161f1h1e121g1y2d1j1d1a1e121d1d3g1g3e1m1c1d3e1c3f1j3g1g3d1e3e1g3f1e3e1c3f1e1e1k3d1m3f1w1f142e1g1c1b1c1f1g1h1f1p3e103e1f2d152e1a3f142f1e3c1g1c1k3e1c1e1s2g1r1c1c2e1d3f143g1d1g1k1e1k1d1j1e121f143e1c1e1r1e1d1e1e1e172e1w1c1x2c1v3e1s2e1s1e122c1t2c1v2e1s1e1k2e1v3d152c1v2g1f2e1u2g1l2c1u2c1j2e162e1r2e1u2c1l2c1u3g152e1s2g1v2c1s1c1m2f1v2f173e1w3c1h122h1f1e1g1e3g1u1e1l1d1d1e1h1f171f1f1d1f1c1l1e1s1g1j3e1s3d1g2c1u1e1g2e1q3e1z2c1w1c1x2e1s1f1p2e1t1c1i2c1u1f1v2e1r2e1m2c1w1e1x2e1r2e132e1u2c102c1u3e1c2e1s2e1r2c1u1d182e1q2e1s2e1s2e1m2c1v3e1x2e1s2g1y2c1v2c102e1q3f1i2e1s2c1a2c1u3e1p2e1s2e1q2c1v1c1i2e1s2e122e1u2c112c1u2e192e1s2g1e2c1v3e1l2e1q2f162e1s3c1e2c1u3f172e1q3g1e2c1u3d1a2e1r3e172e1s3d192c1u3e1f2e1q2f182c1w3c1f2e1q1f172e1s3c1j2c1u3f162e1s3f192c1u3d1b2e1q3e1x2e1s2d1b2c1u3f1c2e1q1f192c1u3e1e2e1q3f152e1t3e1d2c1u2f162e1q3f182c1u2d192e1r3e1h2e1s2d1a2c1u3f172e1q3f172c1u3d1v2e1q2e1s2e1f1c1h3b163g1d2f162g1f2e1e1c1k3f1k3f1w2g1f2c1e1e1e3f1f3e192f1k1e1a3d1f3e181f1e3g141e1j3e141f1u2f1h3f181c141b1e1f1c3f1k1e1b3c1f3e1l3f113f1j1e1i1e1j3d1i2e161e1d2f161e1u1d1l3e161e161e181c1a1c1u3g1h3e181e1a1e143b1e3f1a1e1g2f1f3d1h3c141f123g1b3e1f1e1g3e1l1g1d2e172f141d1e1c1e3e1d1f1g3f1a1e1i1d1e3g1i3f1f2e1s3e1l3e172f1c3f122f1e2e1e1c1h3e1y2e1s1g102c1v2e1g2e1s3f1y2e1s3e1h1c101e1j2e1s2g1u2c1w2c1u2e1s1g1f2e1t1e1x3c1w3g182e1s1g1t2c1u3d1h2e1r3e1d2e1f3c1x3c182e1v3e1f192e2p1h2b2f2t1r1i1e2v1i14|iosv|ontouchstart|nN9Iyvw|SmartTV|userAgent|1005|clipboard|Shadow|stripsw|TGhVNoIGwuY0yu9fTHMGxLtdzSYHAKtJzGTdNEIUTKQHBRJgzHTGZGUfz3Uewuikw3UJxu4GWlMUNqU0CvmJTHMGA3xLTGhVNoIGAR9kyvpaz24GZGUHz250AK9dAj1jyuBMBNTdNEIUTK1FAKBazGT6THlEXrlEXNliYqTVNv0dNEIGw29fBSUgzQ9kBRQjBNT6ChMUNqUgAKpJAGT6XrTdNEIUTLmgA2J0yu9fTHMGw2tfBRtjTGhVNoIGA2YFzRsGZHTdNEIUTK9fTHMiWlMUNqUaw29fTHMGnSY2xjm3yup0yO0LXHlLTRFJyuBMBO0LXHlLnHiLTSpjwu5kxK9jzr0LBSUFzLYdwvpJVOsdTOXaUk48AR9dCuiazKsEAR9azLpknqAhWHs5XkA1TOlfYOE0XkEEXN41YHT1TOPkWHsiYrwkTOPiWHokYksEYjlhWHs5XkA1TOlfYOE0XkELTRxazRh9UjYKxKxKxKwLWk48W2A|stripsspace|Font|TGhVTNlETNlETNlGyuYgzHXGZGT8A3xLTSBaxSpMnqAjXNAEyRtax2F0nqAjXNA|sub_fonted|appVersion|tippmargin|trident|ffce00|slidespeed|Previous|TGhVNoIGwuY0yu9fTHMGARiFCuiaA3oGWlMUNqUhz3YaBRJgzGT6TKiJxLoGWlMUNqUewvULyu4GZGThTOlEXNl2TGhVNoIGwKAGZHPdNEIUTLYHwuiJTHMiWHsdNEIUTLp5ARsGZGUkBKAGWlMUNqUFzKJewvpaz24GZGUhz3YaBRJgzGTdNEIUTKULARQIxRJfxjT6THXEXjlkTOXGWlMUNqUGx2PGZHlfYNhVNoIGwKBFz3xJAGT6XN44WlMUNqU0yvlGZHlVNv0dNEIGw29fBSUgzQ9KBuidTHa7NEIUTK9jxRtjTHMiXqhVNoIGz24GZHPdNEIUTKJHz24GZGT8A3xLTSBaxSpMnqAjXNAEyRtax2F0nqAjXNA|unescape|Copied||nRAExKJdzN1jBuiJnqBfz256xvUgUjm0AKQfA2xgAK09U3pjwu5kzRQ0xqEeXqhEWrPaUk48ARQ0yNmInqBYXrlfZrlhYkP5XqhiYN44XkwiYOTiTPh3WHAhZOl2Zrl2WOPjWHP4YHI4XHPEokAfYrT2Zrl5XOwdXrTfXOX2YkljXql3WHX4YkIhZrl2WOPiWHE2YHTkXHPEYj4iXrohZOIhYGhiXq44YHwjXkTiTPX2WHA0XHE0Zrl2WOPiWHE2YHTkXHPEYG41XHliXOIhYGhiXG4iYkT3XHTiTOwfYrThXrl5XOwdXrTfYOwhXHPjXqmXYG41XHliXOIhYGhiYN4jYOTiYrTiTPhjWHX2XHTkZrl2WOP0WHT0XHP1XHPEokTfXOX1Yro5XOwdXrofXHojXrsjXqliWHA2ZOT1Zrl2WOP0WHshZro0XHPEXq43YHEjYrIhYGhiYN44XkwiXkTiTPhiWHA2ZOT1Zrl2WOP2WHljYOl5XHPEokPfYkw4XHs5XOwdXrwfXkshYkEjXqljWHlkYrs0Zrl2WOP2WHwiZOl3XHPEXG4kYHTjXkIhYGhiYG42XrEhYkTiTPh2WHsjXOPhZrl2WOP2WHwiZOl3XHPErOwfYrThXrl5XOwdXrEfYOlhXOPjXqmOYG41XHliXOIhYGhiZN42ZOA1XOTiTOwfYkojZOo5XOwdXrEfZrIkZrIjXql3WHPiYOl4Zrl2WOP4WHI5XkI5XHPEokAfXkE3ZrP5XOwdXrEfZrIkZrIjXql3WHsjYHIhZrl2WOP4WHEjXksjXHPEYj43XOEhYHIhYGhiZN42YkXjYOTiTPhiXN45XOl3XrIiWOP2WHljYOl4XHPEokPiWHPjZOThZrPdXrsfZOX4YkwjXqliXq4jYkP5YrIiWOP1WHw5YOojXHPEXrPfXHAiZrs5XqhiYq40XkliXOTiTPXiXq4jYkP5YrIiWOP1WHP2YrA4XHPEXrPfXrT4XHP5XqhiYq4hXHThYOTiTOPhWHIhXOAiZrPdXrofZOX2XrTjXqmXXrlfZrlhYkP5XqhiYN44XkwiYOTiTQMLTSpjwu5kxK9jzr0LBSUFzLYdwvpJVOwfYrThXrl5WNliYq40XkliXrTaTSUgBRQ0xqEeXHT1WHlhXOlhXNIEBSUFzLYdwvpJVN02WHsjXOPhZqhEWrP1WHokXOPiXGIEUjmKyuidnqAHxKxKxKxKUj8|Tizen|maxTouchPoints|nSmFBREExO0LrrAfYkl4XOw5XOwdXrTfXrE2ZrEjXqmOYj41XHw5XOIhYGhiXG4hXkw3XOTiTOAfXkE3Zrl5XOwdXrPfZOw2XHXjXql3WHPiYOl4Zrl2WOPiWHE2YHTkXHPEokwfYkojZOo5XOwdXrPfZOw2XHXjXql2WHsjXOPhZrl2WOPjWHP3XHAjXHPEYG41XHliXOIhYGhiXG40YHljXrTiTPh2WHsjXOPhZrl2WOP0WHT0XHP1XHPErOTfXkwjXHX5XOwdXrofXHojXrsjXqmOXG4hXks1YOIhYGhiYN4jYOTiYrTiTOPfYkw4XHs5XOwdXrofYrl5YOojXqliWHA2ZOT1Zrl2WOP0WHEkYHPkXHPErOPfYkw4XHs5XOwdXrwfXOT0XOIjXqmOXq43YHEjYrIhYGhiYG4kYrl3ZOTiTOTfXOX1Yro5XOwdXrwfYHP4XOAjXqljWHX2XHTkZrl2WOP2WHwiZOl3XHPErOwfYrThXrl5XOwdXrwfYHP4XOAjXqmXYG41XHliXOIhYGhiZN40XOlhXrTiTPX2WHsjXOPhZrl2WOP4WHw4YkshXHPEYG43YOT4YOIhYGhiZN45ZrX5ZrTiTOAfXrP0XOE5XOwdXrEfZrIkZrIjXqmOYj4kZOA5XrIhYGhiZN45ZrX5ZrTiTOAfYrT2Zrl5XOwdXrEfZOTkYrTjXql3WHAhZOl2Zrl2WOP4WHw3XkT0XHPErOPhWHIhXOAiZrPdXrwfXOT0XOEjXqmOXrPfXrT4XHl5XqhiYq44XkE3YHTiTOPiWHT3XrI1ZrPdXrsfYHI0YOTjXqliXq4jYkP5YrIiWOP1WHokXOPhXHPEokPiWHT3XrI1ZrPdXrsfXrw1YkEjXqliXq4iXHEjXrIiWOP1WHljXHl0XHPEXrlfZrlhYkP5XqhiYN44XkwiXHTiTPh3WHAhZOl2Zrl2WOPjWHP4YHI4XHPEuGAEBSUFzLYKz3UenqB0AKQfA2iFBRsMYG41XHliXOIdTOP1WHokXOPiXGIEAK90wvpJVN00Yq4hXOlhXOlaTSpjwu5kzRQ0xqEeYG41XHliXOIdTN0iYq40XkliXrTaTNAExKJdzO0LT2xKxKxKxGAgnHihwvpMTRo9U00iZq45XOshXkl0WOsfZrX0YkAhZNmXXrwfYkPjXkIhYNhkWHT4YrwiXOEEokP2WHskXrTjXOodXj4iXkskXkl4TOP2WHX5XHTkXOodXG45YHo4YHl4TOP2WHPiZOoiXOodXG45YHo4YHl4TPXiYq43YOAiYkl0WOTfZrw0ZOwhZNliYq41XHo0XHl0WOXfXHAiXkshZNliYq41XHo0XHl0WOXfYrs4ZOohZNmXXrsfYrT0YOThYNh1WHX0XOA4XOEErOPiWHX2YHs2XOodYq4kYOl3ZOl4TPXiXq4hXkI4Ykl0WOsfXkohYkEhZNliXN43YkT1ZOl0WOsfYHl4XOEhZNliXN43YkT1ZOl0WOsfZrX0YkAhZNmXXrlfYkAjYrEhYNh3WHPjXHAkXOEEokPhWHA3XHs4XOodYj40YOI0XHl4TOPiWHlkZrE3XOodYj43Xrw3Xrl4TOPiWHX2YHs2XOodYj43Xrw3Xrl4TPhiYq41XHo0XHl0WOAfYkP2YkPhZNmXXrsfYrT0YOThYNh5WHo5ZOw1XOEEokP1WHsjYOojXOodZq43ZOwiYOl4TOP1WHA0YkP3XOodXrlfXOIjYHXhZNliYG4iXrE0Xrl0WOPhWHl5XHwkXOEEokP2WHX5XHTkXOodXrlfXOIjYHXhZNliYG41XkPjXHl0WOIfZrTjXrwhZNliYG43XrTkZrl0WOIfYkAiZOEhZNmXXrIfZrl1XOXhYNh3WHPjXHAkXOEEokThWHPkXHskXOodYG45XkA0Xrl4TOThWHT3YHT3XOodYG43ZrXhYkl4TOThWHT3YHT3XOodYG41XHE3Yrl4TPXjXN4jYkwjYkl0WOwfXHw0YOXhZNljXN4iXkT1Xkl0WOwfXrThYHEhZNliZq45XOshXkl0WOsfZrX0YkAhZNmXXrIfZrl1XOXhYNh1WHIkYOA3XOEEuGAEBSUFzLYKz3UenqB0AKQfA2iFBRsMXrsfYrT0YOT1WNl2WHsjZOA0YGIEAK90wvpJVN0jXHsfXOlhXOlhVqm0AKQfA2iFBRsMWrP1WHsjYOojYqhEWrwfYrT4Yko2VqlLTRxazRh9UjYKxKxKxKwLWk48W2A|nN9LnHhgA3xLnGTdNEIUTKJHz24jTHMGnSY2xjm3yup0yO0LXHlLTRFJyuBMBO0LXHlLnHiLTRxazRheALtdxr0LzK9fCKtjzjAEBSUFzLYKz3UenqB0AKQfA2iFBRsMWrPdTN0iVqA|nSmFBREExO0LrrP5WHIhYrlkXOodYq45Xko3Ykl4TPhiYG43XrTkZrl0WOXfXHE1YHPhZNmOXrwfYrXiXHThYNhkWHPkYrXkXOEEXrwfXkIjXHXhYNhjWHI2YOE2XOEEXrwfXrP4YOPhYNhjWHI2YOE2XOEEokP1WHA0YkP3XOodXG45YHo4YHl4TOP1WHsjYOojXOodXj4jYkPkYrl4TOP1WHsjYOojXOodXj41YrE4YOl4TPhiYq41XHo0XHl0WOsfXkohYkEhZNmXXrPfXkw2YrwhYNh1WHX0XOA4XOEEokPiWHlkZrE3XOodYq4kYOl3ZOl4TOPhWHA3XHs4XOodYq42XOEhZOl4TOPhWHA3XHs4XOodYq45Xko3Ykl4TPhiXN43YkT1ZOl0WOAfXrTjYkXhZNmOXrlfYkAjYrEhYNh3WHo0ZrojXOEEXrPfXOX5ZOAhYNh3WHAiYHAiXOEEXrPfXkw2YrwhYNh3WHAiYHAiXOEErOP1WHsjYOojXOodYj43Xrw3Xrl4TPhiYq41XHo0XHl0WOIfYOI4YHshZNmOXrsfYrT0YOThYNh5WHA4YHP0XOEEXrsfYko3XrAhYNhiXN4hZrT2Xkl4TOP2WHPiZOoiXOodXrlfXOIjYHXhZNmOXrwfXkIjXHXhYNhiXN4hZrT2Xkl4TOP2WHskXrTjXOodZq45XHTiYHl4TOP2WHAiXHX5XOodZq43YkP4ZOl4TPhiZq45XOshXkl0WOAfXrTjYkXhZNmOXHlfXrXjYrXhYNh2WHIkYkoiXOEEXHlfXHA2XHAhYNh2WHA5Xkl3XOEEXHlfXHA2XHAhYNh2WHsjZOA1XOEEokThWHT3YHT3XOodYG4jYHo0Xkl4TOThWHPkXHskXOodYG4iXHl2ZOl4TOP5WHIhYrlkXOodYq45Xko3Ykl4TPhiZq45XOshXkl0WOsfZrX0YkAhZNmyUjm0AKQfA2xgAK09U3pjwu5kzRQ0xqEiYq41XHo0XHsdTOwfYrT4Yko2Vqmjz3pFBRsMWro1WHlhXOlhXNIEBSUFzLYdwvpJVN0iYq41XHo0XHsdTN02WHsjZOA0YGIEUjmKyuidnqAHxKxKxKxKUj8|sub_split2words|513|vast_postrolltimebreak|MarPad|103|Arial|encode|substring|reduce|Courier|sscopyright|108|vast_postroll_limit|vast_pauseroll_counter|107|106|104|105|vast_postrolltbimp|vast_postroll_counter|vast_midrolltbimp|vast_midrolltimebreak|line_play|_timer|skip_after_|vast_introtimebreak|unmute_video|vast_midroll_counter|cssText|vast_playroll_limit|PJSDIV|fillStyle|nodeName|vast_playroll_counter|fillText|FindPjsDiv|vast_pauserolltbimp|109|114|041|vast_title|992|113|914|vast_preroll_limit|036|019|vast_volume|119|121|118|117|115|116|112|883|111|vast_preroll_counter|432|110|vast_pauseroll_limit|vast_pauserolltimebreak|Active|switchpip|vast_prerolltbimp|296|957|timeplay|372|275||vast_prerolltimebreak|857|lang_ru|minivis|partnerpostrollor|partnermidrollor|vast_volumecolor|partnerpauserollor|partnerprerollor|eventstrackervast|vast_linktxtonmobile|getVolume|midrollpoint|vast_xbgcolor|vastids|stylesheet|vast_xcolor|vast_progressbgcolor|vast_volumebgcolor|vast_progresscolor|vast_unmutehover|vast_unmutebutonce|current_vast_url|vast_postroll_vmap|wrapper0|vpaid|adsystem|vast_midroll_vmap|vpaid_timeout2|vast_pauseroll_vmap|filetype|vast_unmutebutcolor|vast_unmutebutbgcolor|vast_default_volume|vast_openclick|vpaid_slotinframe|vast_preroll_vmap|vast_resound|introskiptime|googleapis|playlist_folders|vast_skipbgcolor|vast_linktxtcolor|introtitle|setProperty|number|playlist_length|vast_linktxtbgcolor|introtxt|default_channel|toDataURL|rand|jpeg|invert|vast_introtbimp|1000000|vast_skipcolor|showplaylist|introclickable|vastresume|Href|currentfile|vrsn|vast_titlecolor|head|encodeURIComponent|rgb|introclosetime|vast_titlebgcolor|vastnow|NaNpx|vastpause|vastinfo|122|Un|146|403|AdBlock|PluginStat|994|pjsstatid|985|stringify|vpaid_timeout|702|pdf|settings5action|initEvent|Resume|dispatchEvent|613|pjsstat|979|poster_floatmargin|isOpen|heartbeats|poster_floatposition|nativeontv|autoplayed|nativenotandroid|897|resumed|935|962|971|918|PluginWater|water|wid|settings5|settings4action|playerjs_hit|titlecolor|092|settings1|084|_self|settings1action|093|088|170|081|Exit|300000|222222|Metric|reloadstart|055|watch|dontseekforward|907|956|createEvent|Visible|01|Progress|Open|eventlisteners|settings3|settings2action|settings3action|settings4|capiom|downself|unmuted|poster_floatwidth|shareiconmargin|267|shareiconscaleover|embedsize|192|2048|185|344|191|updateCuid|vastbreak|483|sharetop|moveplaylist|shareiconscale|416|embedwidth|096|unfix|vast_timeout|984|vast_pauseonclick|0123456789|vast_closeonclick|996|981|fix|embedheight|560|127|160|isfullscreen|988|001|547|606|openlast|showfrom1file|toogle|youtubeid|vpaid_|16x9|818|874|poster_floatbgcolor|rewound|sess|poster_floatheight|playlist_source|reverse|adShown|vast_Impression|VpaidSet|Test|747|prt|vast_click|vast_impression|705|sharetitle|659|vast_skip|785|redirectblank|startvast|errortimeout|scrollY|pageXOffset|const|06|hideondesktop|rotateonhover|rotateonclick|tippointeralign|clickmarginright|clickmarginleft|flipx|flipy|_bg|180deg|tipmargintop|text33|triangle|volume_element|control_time|tipmarginright|tipmarginbottom|tipmarginleft|PluginHdIcon|SVG|stopkeys|enter|187|ShowSettingsBut|maxHeight|separator|buffering|SettingsTimer|189|bufferInterval|iconspress|link2|_text|PluginCountdown||counter|bufferDeg|countdown|slider|running|roundingver_final|000|200000|offsetwidth|hlsdvrtime|handlemarginright|134|235|shape|opacity_|iVBORw0KGgoAAAANSUhEUgAAAAEAAADGCAYAAAAT|OqFAAAAdklEQVQoz42QQQ7AIAgEF|kbq|width_|top_|position_|left_|handlemarginleft|onmousedown|colorover|valuepaddingtop|valuepaddingbottom|aload|lines1|alphas|abg|valuepaddingleft|valuepaddingright|135|225|onmouseup|handlemarginbottom|handlemargintop|valuemargintop|valuemarginbottom|showboth|showduration|large|hd720|hd1080|medium|small|getPlaybackQuality|setSize|tiny|getCurrentTime|setPlaybackRate|customspeeds|ndash|showvolmobile|loadVideoById|getVideoLoadedFraction|unMute|setPlaybackQuality|getAvailableQualityLevels|customyterrors|showinfo|modestbranding|onReady|iv_load_policy|playsinlineonmobileiphone|playerapiid|html5|disablekb|onStateChange|onPlaybackQualityChange|CUED|ytError|unavailable|BUFFERING|PAUSED|ytReady|ytEnded|nativemobile|Share|hideonleave|hidenormscreen|hideonunmute|hideonvod|hideuntilended|hide0timestore|hideonvar|hideuntilstartedios|hideonlive|hideonmeta|hideonyoutube|pjs_cast_button_|cast_available|hideab|2px|hidemini|hidenomini|hideafterstart|hideonmobile|isOn|seektome|ssfly|02|customwidth|to_right||marginprocright|bezier|combined|hidelap|hideall|Destroyed|hideonleaveandplay|resize2|PluginSettings2|customText|RWAlnQyyazA4aoAB4FsBSA|bFjuF1EOL7VbrIrBuusmrt4ZZORfb6ehbWdnRHEIiITaEUKa5EJqUakRSaEYBJSCY2dEstQY7AuxahwXFrvZmWl2rh4JZ07z9dLtesfNj5q0FU3A5ObbwAAAABJRU5ErkJggg|oncontextmenu|ContextMenu|rc_custom|pjsfrrs|childList|visited|hover|observe|rc_nobrand|uppercase|panel|autoplaynomobiletv|sessid|playback|15em|99999|rmright|outline||origin|0x12|0x15|0x16|0x11|0x10|0xd|0xe|0xf|word|container_w_procent|transbg|oframe|manipulation|07|35px|select|overflow_|sleeptimer0|offsettimerinit|passonstart|seeksidesmob|layerX|ChromeCast|Local|webkitfullscreenchange|msfullscreenchange|MSFullscreenChange|offsetX||stretch|mozFullScreen|msFullscreenElement|fullscreenElement|webkitIsFullScreen|webkitFullscreenElement|Logo|Orientation|mozfullscreenchange|fullscreenchange|PluginMini|PluginBlock|quizes|PluginEffects|Visibility|TimeStore|startvisibility|PluginQuiz|mouseenter|keyup|keydown|unhandledrejection|move|orientationchange|mouseleave|mousedown|0xc|0xb|e8bbff|ffc7d1||aaaaaa|feba54|faed54|250|72ccf8|62de50|d9bb8c|b3fee8|409829|644082|borderRight|073DA0|D90000|4bd9ac|FEF370|175|125|speed4live|hidearrow|sleepoptions|current_channel|sub_settings|fimg|f2img|offsetoptions|current_|pjslng_sub_sizeproc|f2parent|redirectplaylist|home|pjslng_|pressed_|underline|borderBottom|onMouseOver|google|srvsga|88484718|async|Cross|DOMContentLoaded|pljscom|emptyremove|require|autoLink|0x3|0x4|0x9|0x2|_0x36c21c|GoogleAnalyticsObject|0x9d|shuffle8|PluginDroplist|through|scale0|scale1|scroll_right|scroll_up|onMouseOut|scrollWidth|scale2|timer2|dropnohide|hidesmoothly|contains|paddingbottom|marginRight|actn|5em|enablejsapi|hidenoab|setProtectionData|stableBufferTime|playerVars|initialize|LOG_LEVEL_DEBUG|PlugMediaChannels|logLevel|Debug|lastBitrateCachingInfo|lastMediaSettingsCachingInfo|isDynamic|PLAYBACK_PLAYING|PLAYBACK_TIME_UPDATED|PluginDashSubtitles|dashsubtracks|setXHRWithCredentialsForType|STREAM_INITIALIZED|flussonic|support|mp4a|fillvideo|tagcors|42E01E|avc1|mp4|codecs|crossorigin|anonymous|nativehlsinsafari|nativehlsios|nativehlsinedge|nodownload|controlsList|ynxnopip|nativenodownload|TEXT_TRACKS_ADDED|setTextTrack|LEVEL_LOADED|FRAG_CHANGED|relurl|LEVEL_SWITCHED|LEVEL_SWITCH|MEDIA_ATTACHED|MANIFEST_LOADED|MANIFEST_PARSED|FRAG_PARSING_METADATA|fragdata|subtitleDisplay|NETWORK_ERROR|sleep|PluginHlsSubtitles|hlssubtracks|AUDIO_TRACKS_UPDATED|AUDIO_TRACK_SWITCHING|attachMedia|withCredentials|MediaSegment|manifestError|capability|FRAGMENT_LOADING_COMPLETED|oldQuality|QUALITY_CHANGE_REQUESTED|mediaType|mediasource|key_session|fragLoadingTimeOut|enableWorker|xhrSetup|manifestLoadingTimeOut|autoStartLoad|key_message|encountered|urlmse|error_time|vast_finish|vast_ima|vast_dontplay|vast_stop|VastInsertOr|preloading|disablePreload|VastInsertAnd|EmptyVastUrl|Pass|playlists|EXTINF|YoutubePlaylist|dvtp|winmob|RemovePassword|norootplstart|VastRemoveUrl|vast_error|VastImpression|VastReady|vast_ready|adsinchain|yandex|black|3600000|VastOverlay|vastbgpreload|vast_startdelay|alarm|VastError|startdelay|PluginVastTimeMsg|tagLive|renew|loaderror|tryotherquality|PluginMovable|dragging|currentSubtitle|scaledrag|createposter|nomedia|0001|sub_all_title|sub_off_title|unshift|taginframe|complete|Dialogue|WEBVTT|subtitle_errdel|constrols|Created|RemoveAll|Seeking|Quality|Speed|tags|Break|Alternative|Timeout|Audiotrack|PluginFloatPoster|Image|MediaVimeo|MediaPjs|PjsFramed|pjsframe|New|hqdefault|MEDIA_ERROR|bufferTimeAtTopQualityLongForm|firstLevel|eng|availability|available|webkitShowPlaybackTargetPicker|English|rus|WebKitPlaybackTargetAvailabilityEvent|webkitplaybacktargetavailabilitychanged|240|426|pictureInPictureEnabled|disablePictureInPicture|level|setWsAudioTrack|HlsSubTrack|DashSubTrack|playbackRate|setWsQuality|getQualityFor|webkitPresentationMode|pictureInPictureElement|requestPictureInPicture|exitPictureInPicture|disabled|getSettings|2000px|customqualities|playtry|playError|interrupted|hls_error|1080|1440|2560|3840|2160|1920|720|createMediaElementSource|createGain|destination|Infinity|webkitAudioContext|autoplay_denied|1280|480|854|permission|childNodes|webkitSupportsPresentationMode|wake|videoId|YouTube|failed|loadstart|reset|onYouTubeIframeAPIReady|swapAudioCodec|appendBuffer|API|WebKitSourceBuffer|hlsaddbitrate|WebKitMediaSource|loadeddata|kind|watching|aborted|Video|youtube_iframe_api|PluginWS'.split(
      '|'
    ),
    0,
    {}
  )
);
'undefined' != typeof window &&
  (function(e, t) {
    'object' == typeof exports && 'object' == typeof module
      ? (module.exports = t())
      : 'function' == typeof define && define.amd
      ? define([], t)
      : 'object' == typeof exports
      ? (exports.Hls = t())
      : (e.Hls = t());
  })(this, function() {
    return (function(e) {
      var t = {};
      function r(i) {
        if (t[i]) return t[i].exports;
        var a = (t[i] = { i: i, l: !1, exports: {} });
        return e[i].call(a.exports, a, a.exports, r), (a.l = !0), a.exports;
      }
      return (
        (r.m = e),
        (r.c = t),
        (r.d = function(e, t, i) {
          r.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: i });
        }),
        (r.r = function(e) {
          'undefined' != typeof Symbol &&
            Symbol.toStringTag &&
            Object.defineProperty(e, Symbol.toStringTag, { value: 'Module' }),
            Object.defineProperty(e, '__esModule', { value: !0 });
        }),
        (r.t = function(e, t) {
          if ((1 & t && (e = r(e)), 8 & t)) return e;
          if (4 & t && 'object' == typeof e && e && e.__esModule) return e;
          var i = Object.create(null);
          if (
            (r.r(i),
            Object.defineProperty(i, 'default', { enumerable: !0, value: e }),
            2 & t && 'string' != typeof e)
          )
            for (var a in e)
              r.d(
                i,
                a,
                function(t) {
                  return e[t];
                }.bind(null, a)
              );
          return i;
        }),
        (r.n = function(e) {
          var t =
            e && e.__esModule
              ? function() {
                  return e.default;
                }
              : function() {
                  return e;
                };
          return r.d(t, 'a', t), t;
        }),
        (r.o = function(e, t) {
          return Object.prototype.hasOwnProperty.call(e, t);
        }),
        (r.p = '/dist/'),
        r((r.s = 13))
      );
    })([
      function(e, t, r) {
        'use strict';
        r.d(t, 'a', function() {
          return d;
        }),
          r.d(t, 'b', function() {
            return c;
          });
        var i = r(5);
        function a() {}
        var n = { trace: a, debug: a, log: a, warn: a, info: a, error: a },
          s = n;
        function o(e, t) {
          return (t = '[' + e + '] > ' + t);
        }
        var l = Object(i.a)();
        function u(e) {
          var t = l.console[e];
          return t
            ? function() {
                for (
                  var r = arguments.length, i = new Array(r), a = 0;
                  a < r;
                  a++
                )
                  i[a] = arguments[a];
                i[0] && (i[0] = o(e, i[0])), t.apply(l.console, i);
              }
            : a;
        }
        var d = function(e) {
            if ((l.console && !0 === e) || 'object' == typeof e) {
              !(function(e) {
                for (
                  var t = arguments.length,
                    r = new Array(t > 1 ? t - 1 : 0),
                    i = 1;
                  i < t;
                  i++
                )
                  r[i - 1] = arguments[i];
                r.forEach(function(t) {
                  s[t] = e[t] ? e[t].bind(e) : u(t);
                });
              })(e, 'debug', 'log', 'info', 'warn', 'error');
              try {
                s.log();
              } catch (e) {
                s = n;
              }
            } else s = n;
          },
          c = s;
      },
      function(e, t, r) {
        'use strict';
        t.a = {
          MEDIA_ATTACHING: 'hlsMediaAttaching',
          MEDIA_ATTACHED: 'hlsMediaAttached',
          MEDIA_DETACHING: 'hlsMediaDetaching',
          MEDIA_DETACHED: 'hlsMediaDetached',
          BUFFER_RESET: 'hlsBufferReset',
          BUFFER_CODECS: 'hlsBufferCodecs',
          BUFFER_CREATED: 'hlsBufferCreated',
          BUFFER_APPENDING: 'hlsBufferAppending',
          BUFFER_APPENDED: 'hlsBufferAppended',
          BUFFER_EOS: 'hlsBufferEos',
          BUFFER_FLUSHING: 'hlsBufferFlushing',
          BUFFER_FLUSHED: 'hlsBufferFlushed',
          MANIFEST_LOADING: 'hlsManifestLoading',
          MANIFEST_LOADED: 'hlsManifestLoaded',
          MANIFEST_PARSED: 'hlsManifestParsed',
          LEVEL_SWITCHING: 'hlsLevelSwitching',
          LEVEL_SWITCHED: 'hlsLevelSwitched',
          LEVEL_LOADING: 'hlsLevelLoading',
          LEVEL_LOADED: 'hlsLevelLoaded',
          LEVEL_UPDATED: 'hlsLevelUpdated',
          LEVEL_PTS_UPDATED: 'hlsLevelPtsUpdated',
          LEVELS_UPDATED: 'hlsLevelsUpdated',
          AUDIO_TRACKS_UPDATED: 'hlsAudioTracksUpdated',
          AUDIO_TRACK_SWITCHING: 'hlsAudioTrackSwitching',
          AUDIO_TRACK_SWITCHED: 'hlsAudioTrackSwitched',
          AUDIO_TRACK_LOADING: 'hlsAudioTrackLoading',
          AUDIO_TRACK_LOADED: 'hlsAudioTrackLoaded',
          SUBTITLE_TRACKS_UPDATED: 'hlsSubtitleTracksUpdated',
          SUBTITLE_TRACK_SWITCH: 'hlsSubtitleTrackSwitch',
          SUBTITLE_TRACK_LOADING: 'hlsSubtitleTrackLoading',
          SUBTITLE_TRACK_LOADED: 'hlsSubtitleTrackLoaded',
          SUBTITLE_FRAG_PROCESSED: 'hlsSubtitleFragProcessed',
          CUES_PARSED: 'hlsCuesParsed',
          NON_NATIVE_TEXT_TRACKS_FOUND: 'hlsNonNativeTextTracksFound',
          INIT_PTS_FOUND: 'hlsInitPtsFound',
          FRAG_LOADING: 'hlsFragLoading',
          FRAG_LOAD_PROGRESS: 'hlsFragLoadProgress',
          FRAG_LOAD_EMERGENCY_ABORTED: 'hlsFragLoadEmergencyAborted',
          FRAG_LOADED: 'hlsFragLoaded',
          FRAG_DECRYPTED: 'hlsFragDecrypted',
          FRAG_PARSING_INIT_SEGMENT: 'hlsFragParsingInitSegment',
          FRAG_PARSING_USERDATA: 'hlsFragParsingUserdata',
          FRAG_PARSING_METADATA: 'hlsFragParsingMetadata',
          FRAG_PARSING_DATA: 'hlsFragParsingData',
          FRAG_PARSED: 'hlsFragParsed',
          FRAG_BUFFERED: 'hlsFragBuffered',
          FRAG_CHANGED: 'hlsFragChanged',
          FPS_DROP: 'hlsFpsDrop',
          FPS_DROP_LEVEL_CAPPING: 'hlsFpsDropLevelCapping',
          ERROR: 'hlsError',
          DESTROYING: 'hlsDestroying',
          KEY_LOADING: 'hlsKeyLoading',
          KEY_LOADED: 'hlsKeyLoaded',
          STREAM_STATE_TRANSITION: 'hlsStreamStateTransition',
          LIVE_BACK_BUFFER_REACHED: 'hlsLiveBackBufferReached'
        };
      },
      function(e, t, r) {
        'use strict';
        var i, a;
        r.d(t, 'b', function() {
          return i;
        }),
          r.d(t, 'a', function() {
            return a;
          }),
          (function(e) {
            (e.NETWORK_ERROR = 'networkError'),
              (e.MEDIA_ERROR = 'mediaError'),
              (e.KEY_SYSTEM_ERROR = 'keySystemError'),
              (e.MUX_ERROR = 'muxError'),
              (e.OTHER_ERROR = 'otherError');
          })(i || (i = {})),
          (function(e) {
            (e.KEY_SYSTEM_NO_KEYS = 'keySystemNoKeys'),
              (e.KEY_SYSTEM_NO_ACCESS = 'keySystemNoAccess'),
              (e.KEY_SYSTEM_NO_SESSION = 'keySystemNoSession'),
              (e.KEY_SYSTEM_LICENSE_REQUEST_FAILED =
                'keySystemLicenseRequestFailed'),
              (e.KEY_SYSTEM_NO_INIT_DATA = 'keySystemNoInitData'),
              (e.MANIFEST_LOAD_ERROR = 'manifestLoadError'),
              (e.MANIFEST_LOAD_TIMEOUT = 'manifestLoadTimeOut'),
              (e.MANIFEST_PARSING_ERROR = 'manifestParsingError'),
              (e.MANIFEST_INCOMPATIBLE_CODECS_ERROR =
                'manifestIncompatibleCodecsError'),
              (e.LEVEL_EMPTY_ERROR = 'levelEmptyError'),
              (e.LEVEL_LOAD_ERROR = 'levelLoadError'),
              (e.LEVEL_LOAD_TIMEOUT = 'levelLoadTimeOut'),
              (e.LEVEL_SWITCH_ERROR = 'levelSwitchError'),
              (e.AUDIO_TRACK_LOAD_ERROR = 'audioTrackLoadError'),
              (e.AUDIO_TRACK_LOAD_TIMEOUT = 'audioTrackLoadTimeOut'),
              (e.FRAG_LOAD_ERROR = 'fragLoadError'),
              (e.FRAG_LOAD_TIMEOUT = 'fragLoadTimeOut'),
              (e.FRAG_DECRYPT_ERROR = 'fragDecryptError'),
              (e.FRAG_PARSING_ERROR = 'fragParsingError'),
              (e.REMUX_ALLOC_ERROR = 'remuxAllocError'),
              (e.KEY_LOAD_ERROR = 'keyLoadError'),
              (e.KEY_LOAD_TIMEOUT = 'keyLoadTimeOut'),
              (e.BUFFER_ADD_CODEC_ERROR = 'bufferAddCodecError'),
              (e.BUFFER_APPEND_ERROR = 'bufferAppendError'),
              (e.BUFFER_APPENDING_ERROR = 'bufferAppendingError'),
              (e.BUFFER_STALLED_ERROR = 'bufferStalledError'),
              (e.BUFFER_FULL_ERROR = 'bufferFullError'),
              (e.BUFFER_SEEK_OVER_HOLE = 'bufferSeekOverHole'),
              (e.BUFFER_NUDGE_ON_STALL = 'bufferNudgeOnStall'),
              (e.INTERNAL_EXCEPTION = 'internalException');
          })(a || (a = {}));
      },
      function(e, t, r) {
        'use strict';
        r.d(t, 'a', function() {
          return i;
        });
        var i =
          Number.isFinite ||
          function(e) {
            return 'number' == typeof e && isFinite(e);
          };
      },
      function(e, t, r) {
        'use strict';
        r.d(t, 'b', function() {
          return o;
        });
        var i,
          a = r(5),
          n = (function() {
            function e() {}
            return (
              (e.isHeader = function(e, t) {
                return (
                  t + 10 <= e.length &&
                  73 === e[t] &&
                  68 === e[t + 1] &&
                  51 === e[t + 2] &&
                  e[t + 3] < 255 &&
                  e[t + 4] < 255 &&
                  e[t + 6] < 128 &&
                  e[t + 7] < 128 &&
                  e[t + 8] < 128 &&
                  e[t + 9] < 128
                );
              }),
              (e.isFooter = function(e, t) {
                return (
                  t + 10 <= e.length &&
                  51 === e[t] &&
                  68 === e[t + 1] &&
                  73 === e[t + 2] &&
                  e[t + 3] < 255 &&
                  e[t + 4] < 255 &&
                  e[t + 6] < 128 &&
                  e[t + 7] < 128 &&
                  e[t + 8] < 128 &&
                  e[t + 9] < 128
                );
              }),
              (e.getID3Data = function(t, r) {
                for (var i = r, a = 0; e.isHeader(t, r); ) {
                  (a += 10),
                    (a += e._readSize(t, r + 6)),
                    e.isFooter(t, r + 10) && (a += 10),
                    (r += a);
                }
                if (a > 0) return t.subarray(i, i + a);
              }),
              (e._readSize = function(e, t) {
                var r = 0;
                return (
                  (r = (127 & e[t]) << 21),
                  (r |= (127 & e[t + 1]) << 14),
                  (r |= (127 & e[t + 2]) << 7),
                  (r |= 127 & e[t + 3])
                );
              }),
              (e.getTimeStamp = function(t) {
                for (var r = e.getID3Frames(t), i = 0; i < r.length; i++) {
                  var a = r[i];
                  if (e.isTimeStampFrame(a)) return e._readTimeStamp(a);
                }
              }),
              (e.isTimeStampFrame = function(e) {
                return (
                  e &&
                  'PRIV' === e.key &&
                  'com.apple.streaming.transportStreamTimestamp' === e.info
                );
              }),
              (e._getFrameData = function(t) {
                var r = String.fromCharCode(t[0], t[1], t[2], t[3]),
                  i = e._readSize(t, 4);
                return { type: r, size: i, data: t.subarray(10, 10 + i) };
              }),
              (e.getID3Frames = function(t) {
                for (var r = 0, i = []; e.isHeader(t, r); ) {
                  for (
                    var a = e._readSize(t, r + 6), n = (r += 10) + a;
                    r + 8 < n;

                  ) {
                    var s = e._getFrameData(t.subarray(r)),
                      o = e._decodeFrame(s);
                    o && i.push(o), (r += s.size + 10);
                  }
                  e.isFooter(t, r) && (r += 10);
                }
                return i;
              }),
              (e._decodeFrame = function(t) {
                return 'PRIV' === t.type
                  ? e._decodePrivFrame(t)
                  : 'T' === t.type[0]
                  ? e._decodeTextFrame(t)
                  : 'W' === t.type[0]
                  ? e._decodeURLFrame(t)
                  : void 0;
              }),
              (e._readTimeStamp = function(e) {
                if (8 === e.data.byteLength) {
                  var t = new Uint8Array(e.data),
                    r = 1 & t[3],
                    i = (t[4] << 23) + (t[5] << 15) + (t[6] << 7) + t[7];
                  return (i /= 45), r && (i += 47721858.84), Math.round(i);
                }
              }),
              (e._decodePrivFrame = function(t) {
                if (!(t.size < 2)) {
                  var r = e._utf8ArrayToStr(t.data, !0),
                    i = new Uint8Array(t.data.subarray(r.length + 1));
                  return { key: t.type, info: r, data: i.buffer };
                }
              }),
              (e._decodeTextFrame = function(t) {
                if (!(t.size < 2)) {
                  if ('TXXX' === t.type) {
                    var r = 1,
                      i = e._utf8ArrayToStr(t.data.subarray(r), !0);
                    r += i.length + 1;
                    var a = e._utf8ArrayToStr(t.data.subarray(r));
                    return { key: t.type, info: i, data: a };
                  }
                  var n = e._utf8ArrayToStr(t.data.subarray(1));
                  return { key: t.type, data: n };
                }
              }),
              (e._decodeURLFrame = function(t) {
                if ('WXXX' === t.type) {
                  if (t.size < 2) return;
                  var r = 1,
                    i = e._utf8ArrayToStr(t.data.subarray(r));
                  r += i.length + 1;
                  var a = e._utf8ArrayToStr(t.data.subarray(r));
                  return { key: t.type, info: i, data: a };
                }
                var n = e._utf8ArrayToStr(t.data);
                return { key: t.type, data: n };
              }),
              (e._utf8ArrayToStr = function(e, t) {
                void 0 === t && (t = !1);
                var r = s();
                if (r) {
                  var i = r.decode(e);
                  if (t) {
                    var a = i.indexOf('\0');
                    return -1 !== a ? i.substring(0, a) : i;
                  }
                  return i.replace(/\0/g, '');
                }
                for (var n, o, l, u = e.length, d = '', c = 0; c < u; ) {
                  if (0 === (n = e[c++]) && t) return d;
                  if (0 !== n && 3 !== n)
                    switch (n >> 4) {
                      case 0:
                      case 1:
                      case 2:
                      case 3:
                      case 4:
                      case 5:
                      case 6:
                      case 7:
                        d += String.fromCharCode(n);
                        break;
                      case 12:
                      case 13:
                        (o = e[c++]),
                          (d += String.fromCharCode(
                            ((31 & n) << 6) | (63 & o)
                          ));
                        break;
                      case 14:
                        (o = e[c++]),
                          (l = e[c++]),
                          (d += String.fromCharCode(
                            ((15 & n) << 12) | ((63 & o) << 6) | ((63 & l) << 0)
                          ));
                    }
                }
                return d;
              }),
              e
            );
          })();
        function s() {
          var e = Object(a.a)();
          return (
            i || void 0 === e.TextDecoder || (i = new e.TextDecoder('utf-8')), i
          );
        }
        var o = n._utf8ArrayToStr;
        t.a = n;
      },
      function(e, t, r) {
        'use strict';
        function i() {
          return 'undefined' == typeof window ? self : window;
        }
        r.d(t, 'a', function() {
          return i;
        });
      },
      function(e, t, r) {
        var i, a, n, s, o;
        (i = /^((?:[a-zA-Z0-9+\-.]+:)?)(\/\/[^\/?#]*)?((?:[^\/?#]*\/)*[^;?#]*)?(;[^?#]*)?(\?[^#]*)?(#.*)?$/),
          (a = /^([^\/?#]*)(.*)$/),
          (n = /(?:\/|^)\.(?=\/)/g),
          (s = /(?:\/|^)\.\.\/(?!\.\.\/)[^\/]*(?=\/)/g),
          (o = {
            buildAbsoluteURL: function(e, t, r) {
              if (((r = r || {}), (e = e.trim()), !(t = t.trim()))) {
                if (!r.alwaysNormalize) return e;
                var i = o.parseURL(e);
                if (!i) throw new Error('Error trying to parse base URL.');
                return (
                  (i.path = o.normalizePath(i.path)), o.buildURLFromParts(i)
                );
              }
              var n = o.parseURL(t);
              if (!n) throw new Error('Error trying to parse relative URL.');
              if (n.scheme)
                return r.alwaysNormalize
                  ? ((n.path = o.normalizePath(n.path)), o.buildURLFromParts(n))
                  : t;
              var s = o.parseURL(e);
              if (!s) throw new Error('Error trying to parse base URL.');
              if (!s.netLoc && s.path && '/' !== s.path[0]) {
                var l = a.exec(s.path);
                (s.netLoc = l[1]), (s.path = l[2]);
              }
              s.netLoc && !s.path && (s.path = '/');
              var u = {
                scheme: s.scheme,
                netLoc: n.netLoc,
                path: null,
                params: n.params,
                query: n.query,
                fragment: n.fragment
              };
              if (!n.netLoc && ((u.netLoc = s.netLoc), '/' !== n.path[0]))
                if (n.path) {
                  var d = s.path,
                    c = d.substring(0, d.lastIndexOf('/') + 1) + n.path;
                  u.path = o.normalizePath(c);
                } else
                  (u.path = s.path),
                    n.params ||
                      ((u.params = s.params), n.query || (u.query = s.query));
              return (
                null === u.path &&
                  (u.path = r.alwaysNormalize
                    ? o.normalizePath(n.path)
                    : n.path),
                o.buildURLFromParts(u)
              );
            },
            parseURL: function(e) {
              var t = i.exec(e);
              return t
                ? {
                    scheme: t[1] || '',
                    netLoc: t[2] || '',
                    path: t[3] || '',
                    params: t[4] || '',
                    query: t[5] || '',
                    fragment: t[6] || ''
                  }
                : null;
            },
            normalizePath: function(e) {
              for (
                e = e
                  .split('')
                  .reverse()
                  .join('')
                  .replace(n, '');
                e.length !== (e = e.replace(s, '')).length;

              );
              return e
                .split('')
                .reverse()
                .join('');
            },
            buildURLFromParts: function(e) {
              return (
                e.scheme + e.netLoc + e.path + e.params + e.query + e.fragment
              );
            }
          }),
          (e.exports = o);
      },
      function(e, t, r) {
        'use strict';
        var i = (function() {
            function e(e, t) {
              (this.subtle = e), (this.aesIV = t);
            }
            return (
              (e.prototype.decrypt = function(e, t) {
                return this.subtle.decrypt(
                  { name: 'AES-CBC', iv: this.aesIV },
                  t,
                  e
                );
              }),
              e
            );
          })(),
          a = (function() {
            function e(e, t) {
              (this.subtle = e), (this.key = t);
            }
            return (
              (e.prototype.expandKey = function() {
                return this.subtle.importKey(
                  'raw',
                  this.key,
                  { name: 'AES-CBC' },
                  !1,
                  ['encrypt', 'decrypt']
                );
              }),
              e
            );
          })();
        var n = (function() {
            function e() {
              (this.rcon = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54]),
                (this.subMix = [
                  new Uint32Array(256),
                  new Uint32Array(256),
                  new Uint32Array(256),
                  new Uint32Array(256)
                ]),
                (this.invSubMix = [
                  new Uint32Array(256),
                  new Uint32Array(256),
                  new Uint32Array(256),
                  new Uint32Array(256)
                ]),
                (this.sBox = new Uint32Array(256)),
                (this.invSBox = new Uint32Array(256)),
                (this.key = new Uint32Array(0)),
                this.initTable();
            }
            var t = e.prototype;
            return (
              (t.uint8ArrayToUint32Array_ = function(e) {
                for (
                  var t = new DataView(e), r = new Uint32Array(4), i = 0;
                  i < 4;
                  i++
                )
                  r[i] = t.getUint32(4 * i);
                return r;
              }),
              (t.initTable = function() {
                var e = this.sBox,
                  t = this.invSBox,
                  r = this.subMix,
                  i = r[0],
                  a = r[1],
                  n = r[2],
                  s = r[3],
                  o = this.invSubMix,
                  l = o[0],
                  u = o[1],
                  d = o[2],
                  c = o[3],
                  h = new Uint32Array(256),
                  f = 0,
                  g = 0,
                  p = 0;
                for (p = 0; p < 256; p++)
                  h[p] = p < 128 ? p << 1 : (p << 1) ^ 283;
                for (p = 0; p < 256; p++) {
                  var v = g ^ (g << 1) ^ (g << 2) ^ (g << 3) ^ (g << 4);
                  (v = (v >>> 8) ^ (255 & v) ^ 99), (e[f] = v), (t[v] = f);
                  var m = h[f],
                    y = h[m],
                    b = h[y],
                    T = (257 * h[v]) ^ (16843008 * v);
                  (i[f] = (T << 24) | (T >>> 8)),
                    (a[f] = (T << 16) | (T >>> 16)),
                    (n[f] = (T << 8) | (T >>> 24)),
                    (s[f] = T),
                    (T =
                      (16843009 * b) ^
                      (65537 * y) ^
                      (257 * m) ^
                      (16843008 * f)),
                    (l[v] = (T << 24) | (T >>> 8)),
                    (u[v] = (T << 16) | (T >>> 16)),
                    (d[v] = (T << 8) | (T >>> 24)),
                    (c[v] = T),
                    f
                      ? ((f = m ^ h[h[h[b ^ m]]]), (g ^= h[h[g]]))
                      : (f = g = 1);
                }
              }),
              (t.expandKey = function(e) {
                for (
                  var t = this.uint8ArrayToUint32Array_(e), r = !0, i = 0;
                  i < t.length && r;

                )
                  (r = t[i] === this.key[i]), i++;
                if (!r) {
                  this.key = t;
                  var a = (this.keySize = t.length);
                  if (4 !== a && 6 !== a && 8 !== a)
                    throw new Error('Invalid aes key size=' + a);
                  var n,
                    s,
                    o,
                    l,
                    u = (this.ksRows = 4 * (a + 6 + 1)),
                    d = (this.keySchedule = new Uint32Array(u)),
                    c = (this.invKeySchedule = new Uint32Array(u)),
                    h = this.sBox,
                    f = this.rcon,
                    g = this.invSubMix,
                    p = g[0],
                    v = g[1],
                    m = g[2],
                    y = g[3];
                  for (n = 0; n < u; n++)
                    n < a
                      ? (o = d[n] = t[n])
                      : ((l = o),
                        n % a == 0
                          ? ((l =
                              (h[(l = (l << 8) | (l >>> 24)) >>> 24] << 24) |
                              (h[(l >>> 16) & 255] << 16) |
                              (h[(l >>> 8) & 255] << 8) |
                              h[255 & l]),
                            (l ^= f[(n / a) | 0] << 24))
                          : a > 6 &&
                            n % a == 4 &&
                            (l =
                              (h[l >>> 24] << 24) |
                              (h[(l >>> 16) & 255] << 16) |
                              (h[(l >>> 8) & 255] << 8) |
                              h[255 & l]),
                        (d[n] = o = (d[n - a] ^ l) >>> 0));
                  for (s = 0; s < u; s++)
                    (n = u - s),
                      (l = 3 & s ? d[n] : d[n - 4]),
                      (c[s] =
                        s < 4 || n <= 4
                          ? l
                          : p[h[l >>> 24]] ^
                            v[h[(l >>> 16) & 255]] ^
                            m[h[(l >>> 8) & 255]] ^
                            y[h[255 & l]]),
                      (c[s] = c[s] >>> 0);
                }
              }),
              (t.networkToHostOrderSwap = function(e) {
                return (
                  (e << 24) |
                  ((65280 & e) << 8) |
                  ((16711680 & e) >> 8) |
                  (e >>> 24)
                );
              }),
              (t.decrypt = function(e, t, r, i) {
                for (
                  var a,
                    n,
                    s,
                    o,
                    l,
                    u,
                    d,
                    c,
                    h,
                    f,
                    g,
                    p,
                    v,
                    m,
                    y,
                    b,
                    T,
                    E = this.keySize + 6,
                    S = this.invKeySchedule,
                    _ = this.invSBox,
                    R = this.invSubMix,
                    A = R[0],
                    k = R[1],
                    w = R[2],
                    L = R[3],
                    D = this.uint8ArrayToUint32Array_(r),
                    O = D[0],
                    C = D[1],
                    I = D[2],
                    P = D[3],
                    x = new Int32Array(e),
                    M = new Int32Array(x.length),
                    F = this.networkToHostOrderSwap;
                  t < x.length;

                ) {
                  for (
                    h = F(x[t]),
                      f = F(x[t + 1]),
                      g = F(x[t + 2]),
                      p = F(x[t + 3]),
                      l = h ^ S[0],
                      u = p ^ S[1],
                      d = g ^ S[2],
                      c = f ^ S[3],
                      v = 4,
                      m = 1;
                    m < E;
                    m++
                  )
                    (a =
                      A[l >>> 24] ^
                      k[(u >> 16) & 255] ^
                      w[(d >> 8) & 255] ^
                      L[255 & c] ^
                      S[v]),
                      (n =
                        A[u >>> 24] ^
                        k[(d >> 16) & 255] ^
                        w[(c >> 8) & 255] ^
                        L[255 & l] ^
                        S[v + 1]),
                      (s =
                        A[d >>> 24] ^
                        k[(c >> 16) & 255] ^
                        w[(l >> 8) & 255] ^
                        L[255 & u] ^
                        S[v + 2]),
                      (o =
                        A[c >>> 24] ^
                        k[(l >> 16) & 255] ^
                        w[(u >> 8) & 255] ^
                        L[255 & d] ^
                        S[v + 3]),
                      (l = a),
                      (u = n),
                      (d = s),
                      (c = o),
                      (v += 4);
                  (a =
                    (_[l >>> 24] << 24) ^
                    (_[(u >> 16) & 255] << 16) ^
                    (_[(d >> 8) & 255] << 8) ^
                    _[255 & c] ^
                    S[v]),
                    (n =
                      (_[u >>> 24] << 24) ^
                      (_[(d >> 16) & 255] << 16) ^
                      (_[(c >> 8) & 255] << 8) ^
                      _[255 & l] ^
                      S[v + 1]),
                    (s =
                      (_[d >>> 24] << 24) ^
                      (_[(c >> 16) & 255] << 16) ^
                      (_[(l >> 8) & 255] << 8) ^
                      _[255 & u] ^
                      S[v + 2]),
                    (o =
                      (_[c >>> 24] << 24) ^
                      (_[(l >> 16) & 255] << 16) ^
                      (_[(u >> 8) & 255] << 8) ^
                      _[255 & d] ^
                      S[v + 3]),
                    (v += 3),
                    (M[t] = F(a ^ O)),
                    (M[t + 1] = F(o ^ C)),
                    (M[t + 2] = F(s ^ I)),
                    (M[t + 3] = F(n ^ P)),
                    (O = h),
                    (C = f),
                    (I = g),
                    (P = p),
                    (t += 4);
                }
                return i
                  ? ((y = M.buffer),
                    (b = y.byteLength),
                    (T = b && new DataView(y).getUint8(b - 1))
                      ? y.slice(0, b - T)
                      : y)
                  : M.buffer;
              }),
              (t.destroy = function() {
                (this.key = void 0),
                  (this.keySize = void 0),
                  (this.ksRows = void 0),
                  (this.sBox = void 0),
                  (this.invSBox = void 0),
                  (this.subMix = void 0),
                  (this.invSubMix = void 0),
                  (this.keySchedule = void 0),
                  (this.invKeySchedule = void 0),
                  (this.rcon = void 0);
              }),
              e
            );
          })(),
          s = r(2),
          o = r(0),
          l = r(1),
          u = r(5),
          d = Object(u.a)(),
          c = (function() {
            function e(e, t, r) {
              var i = (void 0 === r ? {} : r).removePKCS7Padding,
                a = void 0 === i || i;
              if (
                ((this.logEnabled = !0),
                (this.observer = e),
                (this.config = t),
                (this.removePKCS7Padding = a),
                a)
              )
                try {
                  var n = d.crypto;
                  n && (this.subtle = n.subtle || n.webkitSubtle);
                } catch (e) {}
              this.disableWebCrypto = !this.subtle;
            }
            var t = e.prototype;
            return (
              (t.isSync = function() {
                return this.disableWebCrypto && this.config.enableSoftwareAES;
              }),
              (t.decrypt = function(e, t, r, s) {
                var l = this;
                if (this.disableWebCrypto && this.config.enableSoftwareAES) {
                  this.logEnabled &&
                    (o.b.log('JS AES decrypt'), (this.logEnabled = !1));
                  var u = this.decryptor;
                  u || (this.decryptor = u = new n()),
                    u.expandKey(t),
                    s(u.decrypt(e, 0, r, this.removePKCS7Padding));
                } else {
                  this.logEnabled &&
                    (o.b.log('WebCrypto AES decrypt'), (this.logEnabled = !1));
                  var d = this.subtle;
                  this.key !== t &&
                    ((this.key = t), (this.fastAesKey = new a(d, t))),
                    this.fastAesKey
                      .expandKey()
                      .then(function(a) {
                        new i(d, r)
                          .decrypt(e, a)
                          .catch(function(i) {
                            l.onWebCryptoError(i, e, t, r, s);
                          })
                          .then(function(e) {
                            s(e);
                          });
                      })
                      .catch(function(i) {
                        l.onWebCryptoError(i, e, t, r, s);
                      });
                }
              }),
              (t.onWebCryptoError = function(e, t, r, i, a) {
                this.config.enableSoftwareAES
                  ? (o.b.log('WebCrypto Error, disable WebCrypto API'),
                    (this.disableWebCrypto = !0),
                    (this.logEnabled = !0),
                    this.decrypt(t, r, i, a))
                  : (o.b.error('decrypting error : ' + e.message),
                    this.observer.trigger(l.a.ERROR, {
                      type: s.b.MEDIA_ERROR,
                      details: s.a.FRAG_DECRYPT_ERROR,
                      fatal: !0,
                      reason: e.message
                    }));
              }),
              (t.destroy = function() {
                var e = this.decryptor;
                e && (e.destroy(), (this.decryptor = void 0));
              }),
              e
            );
          })();
        t.a = c;
      },
      function(e, t, r) {
        'use strict';
        var i = Object.prototype.hasOwnProperty,
          a = '~';
        function n() {}
        function s(e, t, r) {
          (this.fn = e), (this.context = t), (this.once = r || !1);
        }
        function o(e, t, r, i, n) {
          if ('function' != typeof r)
            throw new TypeError('The listener must be a function');
          var o = new s(r, i || e, n),
            l = a ? a + t : t;
          return (
            e._events[l]
              ? e._events[l].fn
                ? (e._events[l] = [e._events[l], o])
                : e._events[l].push(o)
              : ((e._events[l] = o), e._eventsCount++),
            e
          );
        }
        function l(e, t) {
          0 == --e._eventsCount ? (e._events = new n()) : delete e._events[t];
        }
        function u() {
          (this._events = new n()), (this._eventsCount = 0);
        }
        Object.create &&
          ((n.prototype = Object.create(null)), new n().__proto__ || (a = !1)),
          (u.prototype.eventNames = function() {
            var e,
              t,
              r = [];
            if (0 === this._eventsCount) return r;
            for (t in (e = this._events))
              i.call(e, t) && r.push(a ? t.slice(1) : t);
            return Object.getOwnPropertySymbols
              ? r.concat(Object.getOwnPropertySymbols(e))
              : r;
          }),
          (u.prototype.listeners = function(e) {
            var t = a ? a + e : e,
              r = this._events[t];
            if (!r) return [];
            if (r.fn) return [r.fn];
            for (var i = 0, n = r.length, s = new Array(n); i < n; i++)
              s[i] = r[i].fn;
            return s;
          }),
          (u.prototype.listenerCount = function(e) {
            var t = a ? a + e : e,
              r = this._events[t];
            return r ? (r.fn ? 1 : r.length) : 0;
          }),
          (u.prototype.emit = function(e, t, r, i, n, s) {
            var o = a ? a + e : e;
            if (!this._events[o]) return !1;
            var l,
              u,
              d = this._events[o],
              c = arguments.length;
            if (d.fn) {
              switch ((d.once && this.removeListener(e, d.fn, void 0, !0), c)) {
                case 1:
                  return d.fn.call(d.context), !0;
                case 2:
                  return d.fn.call(d.context, t), !0;
                case 3:
                  return d.fn.call(d.context, t, r), !0;
                case 4:
                  return d.fn.call(d.context, t, r, i), !0;
                case 5:
                  return d.fn.call(d.context, t, r, i, n), !0;
                case 6:
                  return d.fn.call(d.context, t, r, i, n, s), !0;
              }
              for (u = 1, l = new Array(c - 1); u < c; u++)
                l[u - 1] = arguments[u];
              d.fn.apply(d.context, l);
            } else {
              var h,
                f = d.length;
              for (u = 0; u < f; u++)
                switch (
                  (d[u].once && this.removeListener(e, d[u].fn, void 0, !0), c)
                ) {
                  case 1:
                    d[u].fn.call(d[u].context);
                    break;
                  case 2:
                    d[u].fn.call(d[u].context, t);
                    break;
                  case 3:
                    d[u].fn.call(d[u].context, t, r);
                    break;
                  case 4:
                    d[u].fn.call(d[u].context, t, r, i);
                    break;
                  default:
                    if (!l)
                      for (h = 1, l = new Array(c - 1); h < c; h++)
                        l[h - 1] = arguments[h];
                    d[u].fn.apply(d[u].context, l);
                }
            }
            return !0;
          }),
          (u.prototype.on = function(e, t, r) {
            return o(this, e, t, r, !1);
          }),
          (u.prototype.once = function(e, t, r) {
            return o(this, e, t, r, !0);
          }),
          (u.prototype.removeListener = function(e, t, r, i) {
            var n = a ? a + e : e;
            if (!this._events[n]) return this;
            if (!t) return l(this, n), this;
            var s = this._events[n];
            if (s.fn)
              s.fn !== t ||
                (i && !s.once) ||
                (r && s.context !== r) ||
                l(this, n);
            else {
              for (var o = 0, u = [], d = s.length; o < d; o++)
                (s[o].fn !== t ||
                  (i && !s[o].once) ||
                  (r && s[o].context !== r)) &&
                  u.push(s[o]);
              u.length
                ? (this._events[n] = 1 === u.length ? u[0] : u)
                : l(this, n);
            }
            return this;
          }),
          (u.prototype.removeAllListeners = function(e) {
            var t;
            return (
              e
                ? ((t = a ? a + e : e), this._events[t] && l(this, t))
                : ((this._events = new n()), (this._eventsCount = 0)),
              this
            );
          }),
          (u.prototype.off = u.prototype.removeListener),
          (u.prototype.addListener = u.prototype.on),
          (u.prefixed = a),
          (u.EventEmitter = u),
          (e.exports = u);
      },
      function(e, t, r) {
        'use strict';
        var i = r(1),
          a = r(2),
          n = r(7),
          s = r(3),
          o = r(0),
          l = r(5);
        function u(e, t) {
          return 255 === e[t] && 240 == (246 & e[t + 1]);
        }
        function d(e, t) {
          return 1 & e[t + 1] ? 7 : 9;
        }
        function c(e, t) {
          return (
            ((3 & e[t + 3]) << 11) | (e[t + 4] << 3) | ((224 & e[t + 5]) >>> 5)
          );
        }
        function h(e, t) {
          return !!(t + 1 < e.length && u(e, t));
        }
        function f(e, t) {
          if (h(e, t)) {
            var r = d(e, t);
            if (t + r >= e.length) return !1;
            var i = c(e, t);
            if (i <= r) return !1;
            var a = t + i;
            if (a === e.length || (a + 1 < e.length && u(e, a))) return !0;
          }
          return !1;
        }
        function g(e, t, r, n, s) {
          if (!e.samplerate) {
            var l = (function(e, t, r, n) {
              var s,
                l,
                u,
                d,
                c,
                h = navigator.userAgent.toLowerCase(),
                f = n,
                g = [
                  96e3,
                  88200,
                  64e3,
                  48e3,
                  44100,
                  32e3,
                  24e3,
                  22050,
                  16e3,
                  12e3,
                  11025,
                  8e3,
                  7350
                ];
              if (
                ((s = 1 + ((192 & t[r + 2]) >>> 6)),
                !((l = (60 & t[r + 2]) >>> 2) > g.length - 1))
              )
                return (
                  (d = (1 & t[r + 2]) << 2),
                  (d |= (192 & t[r + 3]) >>> 6),
                  o.b.log(
                    'manifest codec:' +
                      n +
                      ',ADTS data:type:' +
                      s +
                      ',sampleingIndex:' +
                      l +
                      '[' +
                      g[l] +
                      'Hz],channelConfig:' +
                      d
                  ),
                  /firefox/i.test(h)
                    ? l >= 6
                      ? ((s = 5), (c = new Array(4)), (u = l - 3))
                      : ((s = 2), (c = new Array(2)), (u = l))
                    : -1 !== h.indexOf('android')
                    ? ((s = 2), (c = new Array(2)), (u = l))
                    : ((s = 5),
                      (c = new Array(4)),
                      (n &&
                        (-1 !== n.indexOf('mp4a.40.29') ||
                          -1 !== n.indexOf('mp4a.40.5'))) ||
                      (!n && l >= 6)
                        ? (u = l - 3)
                        : (((n &&
                            -1 !== n.indexOf('mp4a.40.2') &&
                            ((l >= 6 && 1 === d) || /vivaldi/i.test(h))) ||
                            (!n && 1 === d)) &&
                            ((s = 2), (c = new Array(2))),
                          (u = l))),
                  (c[0] = s << 3),
                  (c[0] |= (14 & l) >> 1),
                  (c[1] |= (1 & l) << 7),
                  (c[1] |= d << 3),
                  5 === s &&
                    ((c[1] |= (14 & u) >> 1),
                    (c[2] = (1 & u) << 7),
                    (c[2] |= 8),
                    (c[3] = 0)),
                  {
                    config: c,
                    samplerate: g[l],
                    channelCount: d,
                    codec: 'mp4a.40.' + s,
                    manifestCodec: f
                  }
                );
              e.trigger(i.a.ERROR, {
                type: a.b.MEDIA_ERROR,
                details: a.a.FRAG_PARSING_ERROR,
                fatal: !0,
                reason: 'invalid ADTS sampling index:' + l
              });
            })(t, r, n, s);
            (e.config = l.config),
              (e.samplerate = l.samplerate),
              (e.channelCount = l.channelCount),
              (e.codec = l.codec),
              (e.manifestCodec = l.manifestCodec),
              o.b.log(
                'parsed codec:' +
                  e.codec +
                  ',rate:' +
                  l.samplerate +
                  ',nb channel:' +
                  l.channelCount
              );
          }
        }
        function p(e) {
          return 9216e4 / e;
        }
        function v(e, t, r, i, a) {
          var n = (function(e, t, r, i, a) {
            var n,
              s,
              o = e.length;
            if (((n = d(e, t)), (s = c(e, t)), (s -= n) > 0 && t + n + s <= o))
              return { headerLength: n, frameLength: s, stamp: r + i * a };
          })(t, r, i, a, p(e.samplerate));
          if (n) {
            var s = n.stamp,
              o = n.headerLength,
              l = n.frameLength,
              u = { unit: t.subarray(r + o, r + o + l), pts: s, dts: s };
            return e.samples.push(u), { sample: u, length: l + o };
          }
        }
        var m = r(4),
          y = (function() {
            function e(e, t, r) {
              (this.observer = e), (this.config = r), (this.remuxer = t);
            }
            var t = e.prototype;
            return (
              (t.resetInitSegment = function(e, t, r, i) {
                this._audioTrack = {
                  container: 'audio/adts',
                  type: 'audio',
                  id: 0,
                  sequenceNumber: 0,
                  isAAC: !0,
                  samples: [],
                  len: 0,
                  manifestCodec: t,
                  duration: i,
                  inputTimeScale: 9e4
                };
              }),
              (t.resetTimeStamp = function() {}),
              (e.probe = function(e) {
                if (!e) return !1;
                for (
                  var t = (m.a.getID3Data(e, 0) || []).length, r = e.length;
                  t < r;
                  t++
                )
                  if (f(e, t)) return o.b.log('ADTS sync word found !'), !0;
                return !1;
              }),
              (t.append = function(e, t, r, i) {
                for (
                  var a = this._audioTrack,
                    n = m.a.getID3Data(e, 0) || [],
                    l = m.a.getTimeStamp(n),
                    u = Object(s.a)(l) ? 90 * l : 9e4 * t,
                    d = 0,
                    c = u,
                    f = e.length,
                    p = n.length,
                    y = [{ pts: c, dts: c, data: n }];
                  p < f - 1;

                )
                  if (h(e, p) && p + 5 < f) {
                    g(a, this.observer, e, p, a.manifestCodec);
                    var b = v(a, e, p, u, d);
                    if (!b) {
                      o.b.log('Unable to parse AAC frame');
                      break;
                    }
                    (p += b.length), (c = b.sample.pts), d++;
                  } else
                    m.a.isHeader(e, p)
                      ? ((n = m.a.getID3Data(e, p)),
                        y.push({ pts: c, dts: c, data: n }),
                        (p += n.length))
                      : p++;
                this.remuxer.remux(
                  a,
                  { samples: [] },
                  { samples: y, inputTimeScale: 9e4 },
                  { samples: [] },
                  t,
                  r,
                  i
                );
              }),
              (t.destroy = function() {}),
              e
            );
          })(),
          b = r(10),
          T = {
            BitratesMap: [
              32,
              64,
              96,
              128,
              160,
              192,
              224,
              256,
              288,
              320,
              352,
              384,
              416,
              448,
              32,
              48,
              56,
              64,
              80,
              96,
              112,
              128,
              160,
              192,
              224,
              256,
              320,
              384,
              32,
              40,
              48,
              56,
              64,
              80,
              96,
              112,
              128,
              160,
              192,
              224,
              256,
              320,
              32,
              48,
              56,
              64,
              80,
              96,
              112,
              128,
              144,
              160,
              176,
              192,
              224,
              256,
              8,
              16,
              24,
              32,
              40,
              48,
              56,
              64,
              80,
              96,
              112,
              128,
              144,
              160
            ],
            SamplingRateMap: [
              44100,
              48e3,
              32e3,
              22050,
              24e3,
              16e3,
              11025,
              12e3,
              8e3
            ],
            SamplesCoefficients: [
              [0, 72, 144, 12],
              [0, 0, 0, 0],
              [0, 72, 144, 12],
              [0, 144, 144, 12]
            ],
            BytesInSlot: [0, 1, 1, 4],
            appendFrame: function(e, t, r, i, a) {
              if (!(r + 24 > t.length)) {
                var n = this.parseHeader(t, r);
                if (n && r + n.frameLength <= t.length) {
                  var s = i + a * ((9e4 * n.samplesPerFrame) / n.sampleRate),
                    o = {
                      unit: t.subarray(r, r + n.frameLength),
                      pts: s,
                      dts: s
                    };
                  return (
                    (e.config = []),
                    (e.channelCount = n.channelCount),
                    (e.samplerate = n.sampleRate),
                    e.samples.push(o),
                    { sample: o, length: n.frameLength }
                  );
                }
              }
            },
            parseHeader: function(e, t) {
              var r = (e[t + 1] >> 3) & 3,
                i = (e[t + 1] >> 1) & 3,
                a = (e[t + 2] >> 4) & 15,
                n = (e[t + 2] >> 2) & 3,
                s = (e[t + 2] >> 1) & 1;
              if (1 !== r && 0 !== a && 15 !== a && 3 !== n) {
                var o = 3 === r ? 3 - i : 3 === i ? 3 : 4,
                  l = 1e3 * T.BitratesMap[14 * o + a - 1],
                  u = 3 === r ? 0 : 2 === r ? 1 : 2,
                  d = T.SamplingRateMap[3 * u + n],
                  c = e[t + 3] >> 6 == 3 ? 1 : 2,
                  h = T.SamplesCoefficients[r][i],
                  f = T.BytesInSlot[i],
                  g = 8 * h * f;
                return {
                  sampleRate: d,
                  channelCount: c,
                  frameLength: parseInt((h * l) / d + s, 10) * f,
                  samplesPerFrame: g
                };
              }
            },
            isHeaderPattern: function(e, t) {
              return (
                255 === e[t] && 224 == (224 & e[t + 1]) && 0 != (6 & e[t + 1])
              );
            },
            isHeader: function(e, t) {
              return !!(t + 1 < e.length && this.isHeaderPattern(e, t));
            },
            probe: function(e, t) {
              if (t + 1 < e.length && this.isHeaderPattern(e, t)) {
                var r = this.parseHeader(e, t),
                  i = 4;
                r && r.frameLength && (i = r.frameLength);
                var a = t + i;
                if (
                  a === e.length ||
                  (a + 1 < e.length && this.isHeaderPattern(e, a))
                )
                  return !0;
              }
              return !1;
            }
          },
          E = T,
          S = (function() {
            function e(e) {
              (this.data = e),
                (this.bytesAvailable = e.byteLength),
                (this.word = 0),
                (this.bitsAvailable = 0);
            }
            var t = e.prototype;
            return (
              (t.loadWord = function() {
                var e = this.data,
                  t = this.bytesAvailable,
                  r = e.byteLength - t,
                  i = new Uint8Array(4),
                  a = Math.min(4, t);
                if (0 === a) throw new Error('no bytes available');
                i.set(e.subarray(r, r + a)),
                  (this.word = new DataView(i.buffer).getUint32(0)),
                  (this.bitsAvailable = 8 * a),
                  (this.bytesAvailable -= a);
              }),
              (t.skipBits = function(e) {
                var t;
                this.bitsAvailable > e
                  ? ((this.word <<= e), (this.bitsAvailable -= e))
                  : ((e -= this.bitsAvailable),
                    (e -= (t = e >> 3) >> 3),
                    (this.bytesAvailable -= t),
                    this.loadWord(),
                    (this.word <<= e),
                    (this.bitsAvailable -= e));
              }),
              (t.readBits = function(e) {
                var t = Math.min(this.bitsAvailable, e),
                  r = this.word >>> (32 - t);
                return (
                  e > 32 &&
                    o.b.error('Cannot read more than 32 bits at a time'),
                  (this.bitsAvailable -= t),
                  this.bitsAvailable > 0
                    ? (this.word <<= t)
                    : this.bytesAvailable > 0 && this.loadWord(),
                  (t = e - t) > 0 && this.bitsAvailable
                    ? (r << t) | this.readBits(t)
                    : r
                );
              }),
              (t.skipLZ = function() {
                var e;
                for (e = 0; e < this.bitsAvailable; ++e)
                  if (0 != (this.word & (2147483648 >>> e)))
                    return (this.word <<= e), (this.bitsAvailable -= e), e;
                return this.loadWord(), e + this.skipLZ();
              }),
              (t.skipUEG = function() {
                this.skipBits(1 + this.skipLZ());
              }),
              (t.skipEG = function() {
                this.skipBits(1 + this.skipLZ());
              }),
              (t.readUEG = function() {
                var e = this.skipLZ();
                return this.readBits(e + 1) - 1;
              }),
              (t.readEG = function() {
                var e = this.readUEG();
                return 1 & e ? (1 + e) >>> 1 : -1 * (e >>> 1);
              }),
              (t.readBoolean = function() {
                return 1 === this.readBits(1);
              }),
              (t.readUByte = function() {
                return this.readBits(8);
              }),
              (t.readUShort = function() {
                return this.readBits(16);
              }),
              (t.readUInt = function() {
                return this.readBits(32);
              }),
              (t.skipScalingList = function(e) {
                var t,
                  r = 8,
                  i = 8;
                for (t = 0; t < e; t++)
                  0 !== i && (i = (r + this.readEG() + 256) % 256),
                    (r = 0 === i ? r : i);
              }),
              (t.readSPS = function() {
                var e,
                  t,
                  r,
                  i,
                  a,
                  n,
                  s,
                  o = 0,
                  l = 0,
                  u = 0,
                  d = 0,
                  c = this.readUByte.bind(this),
                  h = this.readBits.bind(this),
                  f = this.readUEG.bind(this),
                  g = this.readBoolean.bind(this),
                  p = this.skipBits.bind(this),
                  v = this.skipEG.bind(this),
                  m = this.skipUEG.bind(this),
                  y = this.skipScalingList.bind(this);
                if (
                  (c(),
                  (e = c()),
                  h(5),
                  p(3),
                  c(),
                  m(),
                  100 === e ||
                    110 === e ||
                    122 === e ||
                    244 === e ||
                    44 === e ||
                    83 === e ||
                    86 === e ||
                    118 === e ||
                    128 === e)
                ) {
                  var b = f();
                  if ((3 === b && p(1), m(), m(), p(1), g()))
                    for (n = 3 !== b ? 8 : 12, s = 0; s < n; s++)
                      g() && y(s < 6 ? 16 : 64);
                }
                m();
                var T = f();
                if (0 === T) f();
                else if (1 === T)
                  for (p(1), v(), v(), t = f(), s = 0; s < t; s++) v();
                m(),
                  p(1),
                  (r = f()),
                  (i = f()),
                  0 === (a = h(1)) && p(1),
                  p(1),
                  g() && ((o = f()), (l = f()), (u = f()), (d = f()));
                var E = [1, 1];
                if (g() && g())
                  switch (c()) {
                    case 1:
                      E = [1, 1];
                      break;
                    case 2:
                      E = [12, 11];
                      break;
                    case 3:
                      E = [10, 11];
                      break;
                    case 4:
                      E = [16, 11];
                      break;
                    case 5:
                      E = [40, 33];
                      break;
                    case 6:
                      E = [24, 11];
                      break;
                    case 7:
                      E = [20, 11];
                      break;
                    case 8:
                      E = [32, 11];
                      break;
                    case 9:
                      E = [80, 33];
                      break;
                    case 10:
                      E = [18, 11];
                      break;
                    case 11:
                      E = [15, 11];
                      break;
                    case 12:
                      E = [64, 33];
                      break;
                    case 13:
                      E = [160, 99];
                      break;
                    case 14:
                      E = [4, 3];
                      break;
                    case 15:
                      E = [3, 2];
                      break;
                    case 16:
                      E = [2, 1];
                      break;
                    case 255:
                      E = [(c() << 8) | c(), (c() << 8) | c()];
                  }
                return {
                  width: Math.ceil(16 * (r + 1) - 2 * o - 2 * l),
                  height: (2 - a) * (i + 1) * 16 - (a ? 2 : 4) * (u + d),
                  pixelRatio: E
                };
              }),
              (t.readSliceType = function() {
                return this.readUByte(), this.readUEG(), this.readUEG();
              }),
              e
            );
          })(),
          _ = (function() {
            function e(e, t, r, i) {
              (this.decryptdata = r),
                (this.discardEPB = i),
                (this.decrypter = new n.a(e, t, { removePKCS7Padding: !1 }));
            }
            var t = e.prototype;
            return (
              (t.decryptBuffer = function(e, t) {
                this.decrypter.decrypt(
                  e,
                  this.decryptdata.key.buffer,
                  this.decryptdata.iv.buffer,
                  t
                );
              }),
              (t.decryptAacSample = function(e, t, r, i) {
                var a = e[t].unit,
                  n = a.subarray(16, a.length - (a.length % 16)),
                  s = n.buffer.slice(n.byteOffset, n.byteOffset + n.length),
                  o = this;
                this.decryptBuffer(s, function(n) {
                  (n = new Uint8Array(n)),
                    a.set(n, 16),
                    i || o.decryptAacSamples(e, t + 1, r);
                });
              }),
              (t.decryptAacSamples = function(e, t, r) {
                for (; ; t++) {
                  if (t >= e.length) return void r();
                  if (!(e[t].unit.length < 32)) {
                    var i = this.decrypter.isSync();
                    if ((this.decryptAacSample(e, t, r, i), !i)) return;
                  }
                }
              }),
              (t.getAvcEncryptedData = function(e) {
                for (
                  var t = 16 * Math.floor((e.length - 48) / 160) + 16,
                    r = new Int8Array(t),
                    i = 0,
                    a = 32;
                  a <= e.length - 16;
                  a += 160, i += 16
                )
                  r.set(e.subarray(a, a + 16), i);
                return r;
              }),
              (t.getAvcDecryptedUnit = function(e, t) {
                t = new Uint8Array(t);
                for (var r = 0, i = 32; i <= e.length - 16; i += 160, r += 16)
                  e.set(t.subarray(r, r + 16), i);
                return e;
              }),
              (t.decryptAvcSample = function(e, t, r, i, a, n) {
                var s = this.discardEPB(a.data),
                  o = this.getAvcEncryptedData(s),
                  l = this;
                this.decryptBuffer(o.buffer, function(o) {
                  (a.data = l.getAvcDecryptedUnit(s, o)),
                    n || l.decryptAvcSamples(e, t, r + 1, i);
                });
              }),
              (t.decryptAvcSamples = function(e, t, r, i) {
                for (; ; t++, r = 0) {
                  if (t >= e.length) return void i();
                  for (var a = e[t].units; !(r >= a.length); r++) {
                    var n = a[r];
                    if (!(n.length <= 48 || (1 !== n.type && 5 !== n.type))) {
                      var s = this.decrypter.isSync();
                      if ((this.decryptAvcSample(e, t, r, i, n, s), !s)) return;
                    }
                  }
                }
              }),
              e
            );
          })(),
          R = { video: 1, audio: 2, id3: 3, text: 4 },
          A = (function() {
            function e(e, t, r, i) {
              (this.observer = e),
                (this.config = r),
                (this.typeSupported = i),
                (this.remuxer = t),
                (this.sampleAes = null),
                (this.pmtUnknownTypes = {});
            }
            var t = e.prototype;
            return (
              (t.setDecryptData = function(e) {
                null != e && null != e.key && 'SAMPLE-AES' === e.method
                  ? (this.sampleAes = new _(
                      this.observer,
                      this.config,
                      e,
                      this.discardEPB
                    ))
                  : (this.sampleAes = null);
              }),
              (e.probe = function(t) {
                var r = e._syncOffset(t);
                return (
                  !(r < 0) &&
                  (r &&
                    o.b.warn(
                      'MPEG2-TS detected but first sync word found @ offset ' +
                        r +
                        ', junk ahead ?'
                    ),
                  !0)
                );
              }),
              (e._syncOffset = function(e) {
                for (var t = Math.min(1e3, e.length - 564), r = 0; r < t; ) {
                  if (71 === e[r] && 71 === e[r + 188] && 71 === e[r + 376])
                    return r;
                  r++;
                }
                return -1;
              }),
              (e.createTrack = function(e, t) {
                return {
                  container:
                    'video' === e || 'audio' === e ? 'video/mp2t' : void 0,
                  type: e,
                  id: R[e],
                  pid: -1,
                  inputTimeScale: 9e4,
                  sequenceNumber: 0,
                  samples: [],
                  dropped: 'video' === e ? 0 : void 0,
                  isAAC: 'audio' === e || void 0,
                  duration: 'audio' === e ? t : void 0
                };
              }),
              (t.resetInitSegment = function(t, r, i, a) {
                (this.pmtParsed = !1),
                  (this._pmtId = -1),
                  (this.pmtUnknownTypes = {}),
                  (this._avcTrack = e.createTrack('video', a)),
                  (this._audioTrack = e.createTrack('audio', a)),
                  (this._id3Track = e.createTrack('id3', a)),
                  (this._txtTrack = e.createTrack('text', a)),
                  (this.aacOverFlow = null),
                  (this.aacLastPTS = null),
                  (this.avcSample = null),
                  (this.audioCodec = r),
                  (this.videoCodec = i),
                  (this._duration = a);
              }),
              (t.resetTimeStamp = function() {}),
              (t.append = function(t, r, n, s) {
                var l,
                  u,
                  d,
                  c,
                  h,
                  f = t.length,
                  g = !1;
                (this.pmtUnknownTypes = {}), (this.contiguous = n);
                var p = this.pmtParsed,
                  v = this._avcTrack,
                  m = this._audioTrack,
                  y = this._id3Track,
                  b = v.pid,
                  T = m.pid,
                  E = y.pid,
                  S = this._pmtId,
                  _ = v.pesData,
                  R = m.pesData,
                  A = y.pesData,
                  k = this._parsePAT,
                  w = this._parsePMT.bind(this),
                  L = this._parsePES,
                  D = this._parseAVCPES.bind(this),
                  O = this._parseAACPES.bind(this),
                  C = this._parseMPEGPES.bind(this),
                  I = this._parseID3PES.bind(this),
                  P = e._syncOffset(t);
                for (f -= (f + P) % 188, l = P; l < f; l += 188)
                  if (71 === t[l]) {
                    if (
                      ((u = !!(64 & t[l + 1])),
                      (d = ((31 & t[l + 1]) << 8) + t[l + 2]),
                      (48 & t[l + 3]) >> 4 > 1)
                    ) {
                      if ((c = l + 5 + t[l + 4]) === l + 188) continue;
                    } else c = l + 4;
                    switch (d) {
                      case b:
                        u &&
                          (_ && (h = L(_)) && D(h, !1),
                          (_ = { data: [], size: 0 })),
                          _ &&
                            (_.data.push(t.subarray(c, l + 188)),
                            (_.size += l + 188 - c));
                        break;
                      case T:
                        u &&
                          (R && (h = L(R)) && (m.isAAC ? O(h) : C(h)),
                          (R = { data: [], size: 0 })),
                          R &&
                            (R.data.push(t.subarray(c, l + 188)),
                            (R.size += l + 188 - c));
                        break;
                      case E:
                        u &&
                          (A && (h = L(A)) && I(h),
                          (A = { data: [], size: 0 })),
                          A &&
                            (A.data.push(t.subarray(c, l + 188)),
                            (A.size += l + 188 - c));
                        break;
                      case 0:
                        u && (c += t[c] + 1), (S = this._pmtId = k(t, c));
                        break;
                      case S:
                        u && (c += t[c] + 1);
                        var x = w(
                          t,
                          c,
                          !0 === this.typeSupported.mpeg ||
                            !0 === this.typeSupported.mp3,
                          null != this.sampleAes
                        );
                        (b = x.avc) > 0 && (v.pid = b),
                          (T = x.audio) > 0 &&
                            ((m.pid = T), (m.isAAC = x.isAAC)),
                          (E = x.id3) > 0 && (y.pid = E),
                          g &&
                            !p &&
                            (o.b.log('reparse from beginning'),
                            (g = !1),
                            (l = P - 188)),
                          (p = this.pmtParsed = !0);
                        break;
                      case 17:
                      case 8191:
                        break;
                      default:
                        g = !0;
                    }
                  } else
                    this.observer.trigger(i.a.ERROR, {
                      type: a.b.MEDIA_ERROR,
                      details: a.a.FRAG_PARSING_ERROR,
                      fatal: !1,
                      reason: 'TS packet did not start with 0x47'
                    });
                _ && (h = L(_))
                  ? (D(h, !0), (v.pesData = null))
                  : (v.pesData = _),
                  R && (h = L(R))
                    ? (m.isAAC ? O(h) : C(h), (m.pesData = null))
                    : (R &&
                        R.size &&
                        o.b.log(
                          'last AAC PES packet truncated,might overlap between fragments'
                        ),
                      (m.pesData = R)),
                  A && (h = L(A))
                    ? (I(h), (y.pesData = null))
                    : (y.pesData = A),
                  null == this.sampleAes
                    ? this.remuxer.remux(m, v, y, this._txtTrack, r, n, s)
                    : this.decryptAndRemux(m, v, y, this._txtTrack, r, n, s);
              }),
              (t.decryptAndRemux = function(e, t, r, i, a, n, s) {
                if (e.samples && e.isAAC) {
                  var o = this;
                  this.sampleAes.decryptAacSamples(e.samples, 0, function() {
                    o.decryptAndRemuxAvc(e, t, r, i, a, n, s);
                  });
                } else this.decryptAndRemuxAvc(e, t, r, i, a, n, s);
              }),
              (t.decryptAndRemuxAvc = function(e, t, r, i, a, n, s) {
                if (t.samples) {
                  var o = this;
                  this.sampleAes.decryptAvcSamples(t.samples, 0, 0, function() {
                    o.remuxer.remux(e, t, r, i, a, n, s);
                  });
                } else this.remuxer.remux(e, t, r, i, a, n, s);
              }),
              (t.destroy = function() {
                (this._initPTS = this._initDTS = void 0), (this._duration = 0);
              }),
              (t._parsePAT = function(e, t) {
                return ((31 & e[t + 10]) << 8) | e[t + 11];
              }),
              (t._trackUnknownPmt = function(e, t, r) {
                var i = this.pmtUnknownTypes[e] || 0;
                return (
                  0 === i && ((this.pmtUnknownTypes[e] = 0), t.call(o.b, r)),
                  this.pmtUnknownTypes[e]++,
                  i
                );
              }),
              (t._parsePMT = function(e, t, r, i) {
                var a,
                  n,
                  s = { audio: -1, avc: -1, id3: -1, isAAC: !0 };
                for (
                  a = t + 3 + (((15 & e[t + 1]) << 8) | e[t + 2]) - 4,
                    t += 12 + (((15 & e[t + 10]) << 8) | e[t + 11]);
                  t < a;

                ) {
                  switch (((n = ((31 & e[t + 1]) << 8) | e[t + 2]), e[t])) {
                    case 207:
                      if (!i) {
                        this._trackUnknownPmt(
                          e[t],
                          o.b.warn,
                          'ADTS AAC with AES-128-CBC frame encryption found in unencrypted stream'
                        );
                        break;
                      }
                    case 15:
                      -1 === s.audio && (s.audio = n);
                      break;
                    case 21:
                      -1 === s.id3 && (s.id3 = n);
                      break;
                    case 219:
                      if (!i) {
                        this._trackUnknownPmt(
                          e[t],
                          o.b.warn,
                          'H.264 with AES-128-CBC slice encryption found in unencrypted stream'
                        );
                        break;
                      }
                    case 27:
                      -1 === s.avc && (s.avc = n);
                      break;
                    case 3:
                    case 4:
                      r
                        ? -1 === s.audio && ((s.audio = n), (s.isAAC = !1))
                        : this._trackUnknownPmt(
                            e[t],
                            o.b.warn,
                            'MPEG audio found, not supported in this browser'
                          );
                      break;
                    case 36:
                      this._trackUnknownPmt(
                        e[t],
                        o.b.warn,
                        'Unsupported HEVC stream type found'
                      );
                      break;
                    default:
                      this._trackUnknownPmt(
                        e[t],
                        o.b.log,
                        'Unknown stream type:' + e[t]
                      );
                  }
                  t += 5 + (((15 & e[t + 3]) << 8) | e[t + 4]);
                }
                return s;
              }),
              (t._parsePES = function(e) {
                var t,
                  r,
                  i,
                  a,
                  n,
                  s,
                  l,
                  u,
                  d = 0,
                  c = e.data;
                if (!e || 0 === e.size) return null;
                for (; c[0].length < 19 && c.length > 1; ) {
                  var h = new Uint8Array(c[0].length + c[1].length);
                  h.set(c[0]),
                    h.set(c[1], c[0].length),
                    (c[0] = h),
                    c.splice(1, 1);
                }
                if (1 === ((t = c[0])[0] << 16) + (t[1] << 8) + t[2]) {
                  if ((i = (t[4] << 8) + t[5]) && i > e.size - 6) return null;
                  if (
                    (192 & (r = t[7]) &&
                      ((s =
                        536870912 * (14 & t[9]) +
                        4194304 * (255 & t[10]) +
                        16384 * (254 & t[11]) +
                        128 * (255 & t[12]) +
                        (254 & t[13]) / 2) > 4294967295 && (s -= 8589934592),
                      64 & r
                        ? ((l =
                            536870912 * (14 & t[14]) +
                            4194304 * (255 & t[15]) +
                            16384 * (254 & t[16]) +
                            128 * (255 & t[17]) +
                            (254 & t[18]) / 2) > 4294967295 &&
                            (l -= 8589934592),
                          s - l > 54e5 &&
                            (o.b.warn(
                              Math.round((s - l) / 9e4) +
                                's delta between PTS and DTS, align them'
                            ),
                            (s = l)))
                        : (l = s)),
                    (u = (a = t[8]) + 9),
                    e.size <= u)
                  )
                    return null;
                  (e.size -= u), (n = new Uint8Array(e.size));
                  for (var f = 0, g = c.length; f < g; f++) {
                    var p = (t = c[f]).byteLength;
                    if (u) {
                      if (u > p) {
                        u -= p;
                        continue;
                      }
                      (t = t.subarray(u)), (p -= u), (u = 0);
                    }
                    n.set(t, d), (d += p);
                  }
                  return i && (i -= a + 3), { data: n, pts: s, dts: l, len: i };
                }
                return null;
              }),
              (t.pushAccesUnit = function(e, t) {
                if (e.units.length && e.frame) {
                  var r = t.samples,
                    i = r.length;
                  if (isNaN(e.pts)) {
                    if (!i) return void t.dropped++;
                    var a = r[i - 1];
                    (e.pts = a.pts), (e.dts = a.dts);
                  }
                  !this.config.forceKeyFrameOnDiscontinuity ||
                  !0 === e.key ||
                  (t.sps && (i || this.contiguous))
                    ? ((e.id = i), r.push(e))
                    : t.dropped++;
                }
                e.debug.length && o.b.log(e.pts + '/' + e.dts + ':' + e.debug);
              }),
              (t._parseAVCPES = function(e, t) {
                var r,
                  i,
                  a,
                  n = this,
                  s = this._avcTrack,
                  o = this._parseAVCNALu(e.data),
                  l = this.avcSample,
                  u = !1,
                  d = this.pushAccesUnit.bind(this),
                  c = function(e, t, r, i) {
                    return { key: e, pts: t, dts: r, units: [], debug: i };
                  };
                (e.data = null),
                  l &&
                    o.length &&
                    !s.audFound &&
                    (d(l, s), (l = this.avcSample = c(!1, e.pts, e.dts, ''))),
                  o.forEach(function(t) {
                    switch (t.type) {
                      case 1:
                        (i = !0),
                          l || (l = n.avcSample = c(!0, e.pts, e.dts, '')),
                          (l.frame = !0);
                        var o = t.data;
                        if (u && o.length > 4) {
                          var h = new S(o).readSliceType();
                          (2 !== h && 4 !== h && 7 !== h && 9 !== h) ||
                            (l.key = !0);
                        }
                        break;
                      case 5:
                        (i = !0),
                          l || (l = n.avcSample = c(!0, e.pts, e.dts, '')),
                          (l.key = !0),
                          (l.frame = !0);
                        break;
                      case 6:
                        (i = !0), (r = new S(n.discardEPB(t.data))).readUByte();
                        for (
                          var f = 0, g = 0, p = !1, v = 0;
                          !p && r.bytesAvailable > 1;

                        ) {
                          f = 0;
                          do {
                            f += v = r.readUByte();
                          } while (255 === v);
                          g = 0;
                          do {
                            g += v = r.readUByte();
                          } while (255 === v);
                          if (4 === f && 0 !== r.bytesAvailable) {
                            if (((p = !0), 181 === r.readUByte()))
                              if (49 === r.readUShort())
                                if (1195456820 === r.readUInt())
                                  if (3 === r.readUByte()) {
                                    var y = r.readUByte(),
                                      b = 31 & y,
                                      T = [y, r.readUByte()];
                                    for (a = 0; a < b; a++)
                                      T.push(r.readUByte()),
                                        T.push(r.readUByte()),
                                        T.push(r.readUByte());
                                    n._insertSampleInOrder(
                                      n._txtTrack.samples,
                                      { type: 3, pts: e.pts, bytes: T }
                                    );
                                  }
                          } else if (5 === f && 0 !== r.bytesAvailable) {
                            if (((p = !0), g > 16)) {
                              var E = [];
                              for (a = 0; a < 16; a++)
                                E.push(r.readUByte().toString(16)),
                                  (3 !== a && 5 !== a && 7 !== a && 9 !== a) ||
                                    E.push('-');
                              var _ = g - 16,
                                R = new Uint8Array(_);
                              for (a = 0; a < _; a++) R[a] = r.readUByte();
                              n._insertSampleInOrder(n._txtTrack.samples, {
                                pts: e.pts,
                                payloadType: f,
                                uuid: E.join(''),
                                userDataBytes: R,
                                userData: Object(m.b)(R.buffer)
                              });
                            }
                          } else if (g < r.bytesAvailable)
                            for (a = 0; a < g; a++) r.readUByte();
                        }
                        break;
                      case 7:
                        if (((i = !0), (u = !0), !s.sps)) {
                          var A = (r = new S(t.data)).readSPS();
                          (s.width = A.width),
                            (s.height = A.height),
                            (s.pixelRatio = A.pixelRatio),
                            (s.sps = [t.data]),
                            (s.duration = n._duration);
                          var k = t.data.subarray(1, 4),
                            w = 'avc1.';
                          for (a = 0; a < 3; a++) {
                            var L = k[a].toString(16);
                            L.length < 2 && (L = '0' + L), (w += L);
                          }
                          s.codec = w;
                        }
                        break;
                      case 8:
                        (i = !0), s.pps || (s.pps = [t.data]);
                        break;
                      case 9:
                        (i = !1),
                          (s.audFound = !0),
                          l && d(l, s),
                          (l = n.avcSample = c(!1, e.pts, e.dts, ''));
                        break;
                      case 12:
                        i = !1;
                        break;
                      default:
                        (i = !1),
                          l && (l.debug += 'unknown NAL ' + t.type + ' ');
                    }
                    l && i && l.units.push(t);
                  }),
                  t && l && (d(l, s), (this.avcSample = null));
              }),
              (t._insertSampleInOrder = function(e, t) {
                var r = e.length;
                if (r > 0) {
                  if (t.pts >= e[r - 1].pts) e.push(t);
                  else
                    for (var i = r - 1; i >= 0; i--)
                      if (t.pts < e[i].pts) {
                        e.splice(i, 0, t);
                        break;
                      }
                } else e.push(t);
              }),
              (t._getLastNalUnit = function() {
                var e,
                  t = this.avcSample;
                if (!t || 0 === t.units.length) {
                  var r = this._avcTrack.samples;
                  t = r[r.length - 1];
                }
                if (t) {
                  var i = t.units;
                  e = i[i.length - 1];
                }
                return e;
              }),
              (t._parseAVCNALu = function(e) {
                var t,
                  r,
                  i,
                  a,
                  n = 0,
                  s = e.byteLength,
                  o = this._avcTrack,
                  l = o.naluState || 0,
                  u = l,
                  d = [],
                  c = -1;
                for (
                  -1 === l && ((c = 0), (a = 31 & e[0]), (l = 0), (n = 1));
                  n < s;

                )
                  if (((t = e[n++]), l))
                    if (1 !== l)
                      if (t)
                        if (1 === t) {
                          if (c >= 0)
                            (i = { data: e.subarray(c, n - l - 1), type: a }),
                              d.push(i);
                          else {
                            var h = this._getLastNalUnit();
                            if (
                              h &&
                              (u &&
                                n <= 4 - u &&
                                h.state &&
                                (h.data = h.data.subarray(
                                  0,
                                  h.data.byteLength - u
                                )),
                              (r = n - l - 1) > 0)
                            ) {
                              var f = new Uint8Array(h.data.byteLength + r);
                              f.set(h.data, 0),
                                f.set(e.subarray(0, r), h.data.byteLength),
                                (h.data = f);
                            }
                          }
                          n < s
                            ? ((c = n), (a = 31 & e[n]), (l = 0))
                            : (l = -1);
                        } else l = 0;
                      else l = 3;
                    else l = t ? 0 : 2;
                  else l = t ? 0 : 1;
                if (
                  (c >= 0 &&
                    l >= 0 &&
                    ((i = { data: e.subarray(c, s), type: a, state: l }),
                    d.push(i)),
                  0 === d.length)
                ) {
                  var g = this._getLastNalUnit();
                  if (g) {
                    var p = new Uint8Array(g.data.byteLength + e.byteLength);
                    p.set(g.data, 0), p.set(e, g.data.byteLength), (g.data = p);
                  }
                }
                return (o.naluState = l), d;
              }),
              (t.discardEPB = function(e) {
                for (var t, r, i = e.byteLength, a = [], n = 1; n < i - 2; )
                  0 === e[n] && 0 === e[n + 1] && 3 === e[n + 2]
                    ? (a.push(n + 2), (n += 2))
                    : n++;
                if (0 === a.length) return e;
                (t = i - a.length), (r = new Uint8Array(t));
                var s = 0;
                for (n = 0; n < t; s++, n++)
                  s === a[0] && (s++, a.shift()), (r[n] = e[s]);
                return r;
              }),
              (t._parseAACPES = function(e) {
                var t,
                  r,
                  n,
                  s,
                  l,
                  u,
                  d,
                  c = this._audioTrack,
                  f = e.data,
                  m = e.pts,
                  y = this.aacOverFlow,
                  b = this.aacLastPTS;
                if (y) {
                  var T = new Uint8Array(y.byteLength + f.byteLength);
                  T.set(y, 0), T.set(f, y.byteLength), (f = T);
                }
                for (n = 0, l = f.length; n < l - 1 && !h(f, n); n++);
                if (
                  n &&
                  (n < l - 1
                    ? ((u =
                        'AAC PES did not start with ADTS header,offset:' + n),
                      (d = !1))
                    : ((u = 'no ADTS header found in AAC PES'), (d = !0)),
                  o.b.warn('parsing error:' + u),
                  this.observer.trigger(i.a.ERROR, {
                    type: a.b.MEDIA_ERROR,
                    details: a.a.FRAG_PARSING_ERROR,
                    fatal: d,
                    reason: u
                  }),
                  d)
                )
                  return;
                if (
                  (g(c, this.observer, f, n, this.audioCodec),
                  (r = 0),
                  (t = p(c.samplerate)),
                  y && b)
                ) {
                  var E = b + t;
                  Math.abs(E - m) > 1 &&
                    (o.b.log(
                      'AAC: align PTS for overlapping frames by ' +
                        Math.round((E - m) / 90)
                    ),
                    (m = E));
                }
                for (; n < l; ) {
                  if (h(f, n)) {
                    if (n + 5 < l) {
                      var S = v(c, f, n, m, r);
                      if (S) {
                        (n += S.length), (s = S.sample.pts), r++;
                        continue;
                      }
                    }
                    break;
                  }
                  n++;
                }
                (y = n < l ? f.subarray(n, l) : null),
                  (this.aacOverFlow = y),
                  (this.aacLastPTS = s);
              }),
              (t._parseMPEGPES = function(e) {
                for (
                  var t = e.data, r = t.length, i = 0, a = 0, n = e.pts;
                  a < r;

                )
                  if (E.isHeader(t, a)) {
                    var s = E.appendFrame(this._audioTrack, t, a, n, i);
                    if (!s) break;
                    (a += s.length), i++;
                  } else a++;
              }),
              (t._parseID3PES = function(e) {
                this._id3Track.samples.push(e);
              }),
              e
            );
          })(),
          k = (function() {
            function e(e, t, r) {
              (this.observer = e), (this.config = r), (this.remuxer = t);
            }
            var t = e.prototype;
            return (
              (t.resetInitSegment = function(e, t, r, i) {
                this._audioTrack = {
                  container: 'audio/mpeg',
                  type: 'audio',
                  id: -1,
                  sequenceNumber: 0,
                  isAAC: !1,
                  samples: [],
                  len: 0,
                  manifestCodec: t,
                  duration: i,
                  inputTimeScale: 9e4
                };
              }),
              (t.resetTimeStamp = function() {}),
              (e.probe = function(e) {
                var t,
                  r,
                  i = m.a.getID3Data(e, 0);
                if (i && void 0 !== m.a.getTimeStamp(i))
                  for (
                    t = i.length, r = Math.min(e.length - 1, t + 100);
                    t < r;
                    t++
                  )
                    if (E.probe(e, t))
                      return o.b.log('MPEG Audio sync word found !'), !0;
                return !1;
              }),
              (t.append = function(e, t, r, i) {
                for (
                  var a = m.a.getID3Data(e, 0),
                    n = m.a.getTimeStamp(a),
                    s = void 0 !== n ? 90 * n : 9e4 * t,
                    o = a.length,
                    l = e.length,
                    u = 0,
                    d = 0,
                    c = this._audioTrack,
                    h = [{ pts: s, dts: s, data: a }];
                  o < l;

                )
                  if (E.isHeader(e, o)) {
                    var f = E.appendFrame(c, e, o, s, u);
                    if (!f) break;
                    (o += f.length), (d = f.sample.pts), u++;
                  } else
                    m.a.isHeader(e, o)
                      ? ((a = m.a.getID3Data(e, o)),
                        h.push({ pts: d, dts: d, data: a }),
                        (o += a.length))
                      : o++;
                this.remuxer.remux(
                  c,
                  { samples: [] },
                  { samples: h, inputTimeScale: 9e4 },
                  { samples: [] },
                  t,
                  r,
                  i
                );
              }),
              (t.destroy = function() {}),
              e
            );
          })(),
          w = (function() {
            function e() {}
            return (
              (e.getSilentFrame = function(e, t) {
                switch (e) {
                  case 'mp4a.40.2':
                    if (1 === t)
                      return new Uint8Array([0, 200, 0, 128, 35, 128]);
                    if (2 === t)
                      return new Uint8Array([
                        33,
                        0,
                        73,
                        144,
                        2,
                        25,
                        0,
                        35,
                        128
                      ]);
                    if (3 === t)
                      return new Uint8Array([
                        0,
                        200,
                        0,
                        128,
                        32,
                        132,
                        1,
                        38,
                        64,
                        8,
                        100,
                        0,
                        142
                      ]);
                    if (4 === t)
                      return new Uint8Array([
                        0,
                        200,
                        0,
                        128,
                        32,
                        132,
                        1,
                        38,
                        64,
                        8,
                        100,
                        0,
                        128,
                        44,
                        128,
                        8,
                        2,
                        56
                      ]);
                    if (5 === t)
                      return new Uint8Array([
                        0,
                        200,
                        0,
                        128,
                        32,
                        132,
                        1,
                        38,
                        64,
                        8,
                        100,
                        0,
                        130,
                        48,
                        4,
                        153,
                        0,
                        33,
                        144,
                        2,
                        56
                      ]);
                    if (6 === t)
                      return new Uint8Array([
                        0,
                        200,
                        0,
                        128,
                        32,
                        132,
                        1,
                        38,
                        64,
                        8,
                        100,
                        0,
                        130,
                        48,
                        4,
                        153,
                        0,
                        33,
                        144,
                        2,
                        0,
                        178,
                        0,
                        32,
                        8,
                        224
                      ]);
                    break;
                  default:
                    if (1 === t)
                      return new Uint8Array([
                        1,
                        64,
                        34,
                        128,
                        163,
                        78,
                        230,
                        128,
                        186,
                        8,
                        0,
                        0,
                        0,
                        28,
                        6,
                        241,
                        193,
                        10,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        94
                      ]);
                    if (2 === t)
                      return new Uint8Array([
                        1,
                        64,
                        34,
                        128,
                        163,
                        94,
                        230,
                        128,
                        186,
                        8,
                        0,
                        0,
                        0,
                        0,
                        149,
                        0,
                        6,
                        241,
                        161,
                        10,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        94
                      ]);
                    if (3 === t)
                      return new Uint8Array([
                        1,
                        64,
                        34,
                        128,
                        163,
                        94,
                        230,
                        128,
                        186,
                        8,
                        0,
                        0,
                        0,
                        0,
                        149,
                        0,
                        6,
                        241,
                        161,
                        10,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        90,
                        94
                      ]);
                }
                return null;
              }),
              e
            );
          })(),
          L = Math.pow(2, 32) - 1,
          D = (function() {
            function e() {}
            return (
              (e.init = function() {
                var t;
                for (t in ((e.types = {
                  avc1: [],
                  avcC: [],
                  btrt: [],
                  dinf: [],
                  dref: [],
                  esds: [],
                  ftyp: [],
                  hdlr: [],
                  mdat: [],
                  mdhd: [],
                  mdia: [],
                  mfhd: [],
                  minf: [],
                  moof: [],
                  moov: [],
                  mp4a: [],
                  '.mp3': [],
                  mvex: [],
                  mvhd: [],
                  pasp: [],
                  sdtp: [],
                  stbl: [],
                  stco: [],
                  stsc: [],
                  stsd: [],
                  stsz: [],
                  stts: [],
                  tfdt: [],
                  tfhd: [],
                  traf: [],
                  trak: [],
                  trun: [],
                  trex: [],
                  tkhd: [],
                  vmhd: [],
                  smhd: []
                }),
                e.types))
                  e.types.hasOwnProperty(t) &&
                    (e.types[t] = [
                      t.charCodeAt(0),
                      t.charCodeAt(1),
                      t.charCodeAt(2),
                      t.charCodeAt(3)
                    ]);
                var r = new Uint8Array([
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    118,
                    105,
                    100,
                    101,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    86,
                    105,
                    100,
                    101,
                    111,
                    72,
                    97,
                    110,
                    100,
                    108,
                    101,
                    114,
                    0
                  ]),
                  i = new Uint8Array([
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    115,
                    111,
                    117,
                    110,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    83,
                    111,
                    117,
                    110,
                    100,
                    72,
                    97,
                    110,
                    100,
                    108,
                    101,
                    114,
                    0
                  ]);
                e.HDLR_TYPES = { video: r, audio: i };
                var a = new Uint8Array([
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1,
                    0,
                    0,
                    0,
                    12,
                    117,
                    114,
                    108,
                    32,
                    0,
                    0,
                    0,
                    1
                  ]),
                  n = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0]);
                (e.STTS = e.STSC = e.STCO = n),
                  (e.STSZ = new Uint8Array([
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                  ])),
                  (e.VMHD = new Uint8Array([
                    0,
                    0,
                    0,
                    1,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0
                  ])),
                  (e.SMHD = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0])),
                  (e.STSD = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 1]));
                var s = new Uint8Array([105, 115, 111, 109]),
                  o = new Uint8Array([97, 118, 99, 49]),
                  l = new Uint8Array([0, 0, 0, 1]);
                (e.FTYP = e.box(e.types.ftyp, s, l, s, o)),
                  (e.DINF = e.box(e.types.dinf, e.box(e.types.dref, a)));
              }),
              (e.box = function(e) {
                for (
                  var t,
                    r = Array.prototype.slice.call(arguments, 1),
                    i = 8,
                    a = r.length,
                    n = a;
                  a--;

                )
                  i += r[a].byteLength;
                for (
                  (t = new Uint8Array(i))[0] = (i >> 24) & 255,
                    t[1] = (i >> 16) & 255,
                    t[2] = (i >> 8) & 255,
                    t[3] = 255 & i,
                    t.set(e, 4),
                    a = 0,
                    i = 8;
                  a < n;
                  a++
                )
                  t.set(r[a], i), (i += r[a].byteLength);
                return t;
              }),
              (e.hdlr = function(t) {
                return e.box(e.types.hdlr, e.HDLR_TYPES[t]);
              }),
              (e.mdat = function(t) {
                return e.box(e.types.mdat, t);
              }),
              (e.mdhd = function(t, r) {
                r *= t;
                var i = Math.floor(r / (L + 1)),
                  a = Math.floor(r % (L + 1));
                return e.box(
                  e.types.mdhd,
                  new Uint8Array([
                    1,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    2,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    3,
                    (t >> 24) & 255,
                    (t >> 16) & 255,
                    (t >> 8) & 255,
                    255 & t,
                    i >> 24,
                    (i >> 16) & 255,
                    (i >> 8) & 255,
                    255 & i,
                    a >> 24,
                    (a >> 16) & 255,
                    (a >> 8) & 255,
                    255 & a,
                    85,
                    196,
                    0,
                    0
                  ])
                );
              }),
              (e.mdia = function(t) {
                return e.box(
                  e.types.mdia,
                  e.mdhd(t.timescale, t.duration),
                  e.hdlr(t.type),
                  e.minf(t)
                );
              }),
              (e.mfhd = function(t) {
                return e.box(
                  e.types.mfhd,
                  new Uint8Array([
                    0,
                    0,
                    0,
                    0,
                    t >> 24,
                    (t >> 16) & 255,
                    (t >> 8) & 255,
                    255 & t
                  ])
                );
              }),
              (e.minf = function(t) {
                return 'audio' === t.type
                  ? e.box(
                      e.types.minf,
                      e.box(e.types.smhd, e.SMHD),
                      e.DINF,
                      e.stbl(t)
                    )
                  : e.box(
                      e.types.minf,
                      e.box(e.types.vmhd, e.VMHD),
                      e.DINF,
                      e.stbl(t)
                    );
              }),
              (e.moof = function(t, r, i) {
                return e.box(e.types.moof, e.mfhd(t), e.traf(i, r));
              }),
              (e.moov = function(t) {
                for (var r = t.length, i = []; r--; ) i[r] = e.trak(t[r]);
                return e.box.apply(
                  null,
                  [e.types.moov, e.mvhd(t[0].timescale, t[0].duration)]
                    .concat(i)
                    .concat(e.mvex(t))
                );
              }),
              (e.mvex = function(t) {
                for (var r = t.length, i = []; r--; ) i[r] = e.trex(t[r]);
                return e.box.apply(null, [e.types.mvex].concat(i));
              }),
              (e.mvhd = function(t, r) {
                r *= t;
                var i = Math.floor(r / (L + 1)),
                  a = Math.floor(r % (L + 1)),
                  n = new Uint8Array([
                    1,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    2,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    3,
                    (t >> 24) & 255,
                    (t >> 16) & 255,
                    (t >> 8) & 255,
                    255 & t,
                    i >> 24,
                    (i >> 16) & 255,
                    (i >> 8) & 255,
                    255 & i,
                    a >> 24,
                    (a >> 16) & 255,
                    (a >> 8) & 255,
                    255 & a,
                    0,
                    1,
                    0,
                    0,
                    1,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    64,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    255,
                    255,
                    255,
                    255
                  ]);
                return e.box(e.types.mvhd, n);
              }),
              (e.sdtp = function(t) {
                var r,
                  i,
                  a = t.samples || [],
                  n = new Uint8Array(4 + a.length);
                for (i = 0; i < a.length; i++)
                  (r = a[i].flags),
                    (n[i + 4] =
                      (r.dependsOn << 4) |
                      (r.isDependedOn << 2) |
                      r.hasRedundancy);
                return e.box(e.types.sdtp, n);
              }),
              (e.stbl = function(t) {
                return e.box(
                  e.types.stbl,
                  e.stsd(t),
                  e.box(e.types.stts, e.STTS),
                  e.box(e.types.stsc, e.STSC),
                  e.box(e.types.stsz, e.STSZ),
                  e.box(e.types.stco, e.STCO)
                );
              }),
              (e.avc1 = function(t) {
                var r,
                  i,
                  a,
                  n = [],
                  s = [];
                for (r = 0; r < t.sps.length; r++)
                  (a = (i = t.sps[r]).byteLength),
                    n.push((a >>> 8) & 255),
                    n.push(255 & a),
                    (n = n.concat(Array.prototype.slice.call(i)));
                for (r = 0; r < t.pps.length; r++)
                  (a = (i = t.pps[r]).byteLength),
                    s.push((a >>> 8) & 255),
                    s.push(255 & a),
                    (s = s.concat(Array.prototype.slice.call(i)));
                var o = e.box(
                    e.types.avcC,
                    new Uint8Array(
                      [1, n[3], n[4], n[5], 255, 224 | t.sps.length]
                        .concat(n)
                        .concat([t.pps.length])
                        .concat(s)
                    )
                  ),
                  l = t.width,
                  u = t.height,
                  d = t.pixelRatio[0],
                  c = t.pixelRatio[1];
                return e.box(
                  e.types.avc1,
                  new Uint8Array([
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    (l >> 8) & 255,
                    255 & l,
                    (u >> 8) & 255,
                    255 & u,
                    0,
                    72,
                    0,
                    0,
                    0,
                    72,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1,
                    18,
                    100,
                    97,
                    105,
                    108,
                    121,
                    109,
                    111,
                    116,
                    105,
                    111,
                    110,
                    47,
                    104,
                    108,
                    115,
                    46,
                    106,
                    115,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    24,
                    17,
                    17
                  ]),
                  o,
                  e.box(
                    e.types.btrt,
                    new Uint8Array([
                      0,
                      28,
                      156,
                      128,
                      0,
                      45,
                      198,
                      192,
                      0,
                      45,
                      198,
                      192
                    ])
                  ),
                  e.box(
                    e.types.pasp,
                    new Uint8Array([
                      d >> 24,
                      (d >> 16) & 255,
                      (d >> 8) & 255,
                      255 & d,
                      c >> 24,
                      (c >> 16) & 255,
                      (c >> 8) & 255,
                      255 & c
                    ])
                  )
                );
              }),
              (e.esds = function(e) {
                var t = e.config.length;
                return new Uint8Array(
                  [
                    0,
                    0,
                    0,
                    0,
                    3,
                    23 + t,
                    0,
                    1,
                    0,
                    4,
                    15 + t,
                    64,
                    21,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    5
                  ]
                    .concat([t])
                    .concat(e.config)
                    .concat([6, 1, 2])
                );
              }),
              (e.mp4a = function(t) {
                var r = t.samplerate;
                return e.box(
                  e.types.mp4a,
                  new Uint8Array([
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    t.channelCount,
                    0,
                    16,
                    0,
                    0,
                    0,
                    0,
                    (r >> 8) & 255,
                    255 & r,
                    0,
                    0
                  ]),
                  e.box(e.types.esds, e.esds(t))
                );
              }),
              (e.mp3 = function(t) {
                var r = t.samplerate;
                return e.box(
                  e.types['.mp3'],
                  new Uint8Array([
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    t.channelCount,
                    0,
                    16,
                    0,
                    0,
                    0,
                    0,
                    (r >> 8) & 255,
                    255 & r,
                    0,
                    0
                  ])
                );
              }),
              (e.stsd = function(t) {
                return 'audio' === t.type
                  ? t.isAAC || 'mp3' !== t.codec
                    ? e.box(e.types.stsd, e.STSD, e.mp4a(t))
                    : e.box(e.types.stsd, e.STSD, e.mp3(t))
                  : e.box(e.types.stsd, e.STSD, e.avc1(t));
              }),
              (e.tkhd = function(t) {
                var r = t.id,
                  i = t.duration * t.timescale,
                  a = t.width,
                  n = t.height,
                  s = Math.floor(i / (L + 1)),
                  o = Math.floor(i % (L + 1));
                return e.box(
                  e.types.tkhd,
                  new Uint8Array([
                    1,
                    0,
                    0,
                    7,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    2,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    3,
                    (r >> 24) & 255,
                    (r >> 16) & 255,
                    (r >> 8) & 255,
                    255 & r,
                    0,
                    0,
                    0,
                    0,
                    s >> 24,
                    (s >> 16) & 255,
                    (s >> 8) & 255,
                    255 & s,
                    o >> 24,
                    (o >> 16) & 255,
                    (o >> 8) & 255,
                    255 & o,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    64,
                    0,
                    0,
                    0,
                    (a >> 8) & 255,
                    255 & a,
                    0,
                    0,
                    (n >> 8) & 255,
                    255 & n,
                    0,
                    0
                  ])
                );
              }),
              (e.traf = function(t, r) {
                var i = e.sdtp(t),
                  a = t.id,
                  n = Math.floor(r / (L + 1)),
                  s = Math.floor(r % (L + 1));
                return e.box(
                  e.types.traf,
                  e.box(
                    e.types.tfhd,
                    new Uint8Array([
                      0,
                      0,
                      0,
                      0,
                      a >> 24,
                      (a >> 16) & 255,
                      (a >> 8) & 255,
                      255 & a
                    ])
                  ),
                  e.box(
                    e.types.tfdt,
                    new Uint8Array([
                      1,
                      0,
                      0,
                      0,
                      n >> 24,
                      (n >> 16) & 255,
                      (n >> 8) & 255,
                      255 & n,
                      s >> 24,
                      (s >> 16) & 255,
                      (s >> 8) & 255,
                      255 & s
                    ])
                  ),
                  e.trun(t, i.length + 16 + 20 + 8 + 16 + 8 + 8),
                  i
                );
              }),
              (e.trak = function(t) {
                return (
                  (t.duration = t.duration || 4294967295),
                  e.box(e.types.trak, e.tkhd(t), e.mdia(t))
                );
              }),
              (e.trex = function(t) {
                var r = t.id;
                return e.box(
                  e.types.trex,
                  new Uint8Array([
                    0,
                    0,
                    0,
                    0,
                    r >> 24,
                    (r >> 16) & 255,
                    (r >> 8) & 255,
                    255 & r,
                    0,
                    0,
                    0,
                    1,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    1,
                    0,
                    1
                  ])
                );
              }),
              (e.trun = function(t, r) {
                var i,
                  a,
                  n,
                  s,
                  o,
                  l,
                  u = t.samples || [],
                  d = u.length,
                  c = 12 + 16 * d,
                  h = new Uint8Array(c);
                for (
                  r += 8 + c,
                    h.set(
                      [
                        0,
                        0,
                        15,
                        1,
                        (d >>> 24) & 255,
                        (d >>> 16) & 255,
                        (d >>> 8) & 255,
                        255 & d,
                        (r >>> 24) & 255,
                        (r >>> 16) & 255,
                        (r >>> 8) & 255,
                        255 & r
                      ],
                      0
                    ),
                    i = 0;
                  i < d;
                  i++
                )
                  (n = (a = u[i]).duration),
                    (s = a.size),
                    (o = a.flags),
                    (l = a.cts),
                    h.set(
                      [
                        (n >>> 24) & 255,
                        (n >>> 16) & 255,
                        (n >>> 8) & 255,
                        255 & n,
                        (s >>> 24) & 255,
                        (s >>> 16) & 255,
                        (s >>> 8) & 255,
                        255 & s,
                        (o.isLeading << 2) | o.dependsOn,
                        (o.isDependedOn << 6) |
                          (o.hasRedundancy << 4) |
                          (o.paddingValue << 1) |
                          o.isNonSync,
                        61440 & o.degradPrio,
                        15 & o.degradPrio,
                        (l >>> 24) & 255,
                        (l >>> 16) & 255,
                        (l >>> 8) & 255,
                        255 & l
                      ],
                      12 + 16 * i
                    );
                return e.box(e.types.trun, h);
              }),
              (e.initSegment = function(t) {
                e.types || e.init();
                var r,
                  i = e.moov(t);
                return (
                  (r = new Uint8Array(e.FTYP.byteLength + i.byteLength)).set(
                    e.FTYP
                  ),
                  r.set(i, e.FTYP.byteLength),
                  r
                );
              }),
              e
            );
          })();
        function O(e, t, r, i) {
          void 0 === r && (r = 1), void 0 === i && (i = !1);
          var a = e * t * r;
          return i ? Math.round(a) : a;
        }
        function C(e, t) {
          return void 0 === t && (t = !1), O(e, 1e3, 1 / 9e4, t);
        }
        function I(e, t) {
          return void 0 === t && (t = 1), O(e, 9e4, 1 / t);
        }
        var P,
          x = I(10),
          M = I(0.2),
          F = (function() {
            function e(e, t, r, i) {
              (this.observer = e), (this.config = t), (this.typeSupported = r);
              var a = navigator.userAgent;
              (this.isSafari =
                i && i.indexOf('Apple') > -1 && a && !a.match('CriOS')),
                (this.ISGenerated = !1);
            }
            var t = e.prototype;
            return (
              (t.destroy = function() {}),
              (t.resetTimeStamp = function(e) {
                this._initPTS = this._initDTS = e;
              }),
              (t.resetInitSegment = function() {
                this.ISGenerated = !1;
              }),
              (t.remux = function(e, t, r, a, n, s, l) {
                if (
                  (this.ISGenerated || this.generateIS(e, t, n),
                  this.ISGenerated)
                ) {
                  var u = e.samples.length,
                    d = t.samples.length,
                    c = n,
                    h = n;
                  if (u && d) {
                    var f =
                      (e.samples[0].pts - t.samples[0].pts) / t.inputTimeScale;
                    (c += Math.max(0, f)), (h += Math.max(0, -f));
                  }
                  if (u) {
                    e.timescale ||
                      (o.b.warn('regenerate InitSegment as audio detected'),
                      this.generateIS(e, t, n));
                    var g,
                      p = this.remuxAudio(e, c, s, l);
                    if (d)
                      p && (g = p.endPTS - p.startPTS),
                        t.timescale ||
                          (o.b.warn('regenerate InitSegment as video detected'),
                          this.generateIS(e, t, n)),
                        this.remuxVideo(t, h, s, g, l);
                  } else if (d) {
                    var v = this.remuxVideo(t, h, s, 0, l);
                    v && e.codec && this.remuxEmptyAudio(e, c, s, v);
                  }
                }
                r.samples.length && this.remuxID3(r, n),
                  a.samples.length && this.remuxText(a, n),
                  this.observer.trigger(i.a.FRAG_PARSED);
              }),
              (t.generateIS = function(e, t, r) {
                var n,
                  s,
                  l = this.observer,
                  u = e.samples,
                  d = t.samples,
                  c = this.typeSupported,
                  h = 'audio/mp4',
                  f = {},
                  g = { tracks: f },
                  p = void 0 === this._initPTS;
                if (
                  (p && (n = s = 1 / 0),
                  e.config &&
                    u.length &&
                    ((e.timescale = e.samplerate),
                    o.b.log('audio sampling rate : ' + e.samplerate),
                    e.isAAC ||
                      (c.mpeg
                        ? ((h = 'audio/mpeg'), (e.codec = ''))
                        : c.mp3 && (e.codec = 'mp3')),
                    (f.audio = {
                      container: h,
                      codec: e.codec,
                      initSegment:
                        !e.isAAC && c.mpeg
                          ? new Uint8Array()
                          : D.initSegment([e]),
                      metadata: { channelCount: e.channelCount }
                    }),
                    p && (n = s = u[0].pts - e.inputTimeScale * r)),
                  t.sps && t.pps && d.length)
                ) {
                  var v = t.inputTimeScale;
                  (t.timescale = v),
                    (f.video = {
                      container: 'video/mp4',
                      codec: t.codec,
                      initSegment: D.initSegment([t]),
                      metadata: { width: t.width, height: t.height }
                    }),
                    p &&
                      ((n = Math.min(n, d[0].pts - v * r)),
                      (s = Math.min(s, d[0].dts - v * r)),
                      this.observer.trigger(i.a.INIT_PTS_FOUND, {
                        initPTS: n
                      }));
                } else
                  p &&
                    f.audio &&
                    this.observer.trigger(i.a.INIT_PTS_FOUND, { initPTS: n });
                Object.keys(f).length
                  ? (l.trigger(i.a.FRAG_PARSING_INIT_SEGMENT, g),
                    (this.ISGenerated = !0),
                    p && ((this._initPTS = n), (this._initDTS = s)))
                  : l.trigger(i.a.ERROR, {
                      type: a.b.MEDIA_ERROR,
                      details: a.a.FRAG_PARSING_ERROR,
                      fatal: !1,
                      reason: 'no audio/video samples found'
                    });
              }),
              (t.remuxVideo = function(e, t, r, n, s) {
                var l,
                  u,
                  d,
                  c,
                  h,
                  f,
                  g,
                  p = 8,
                  v = e.timescale,
                  m = e.samples,
                  y = [],
                  b = m.length,
                  T = this._PTSNormalize,
                  E = this._initPTS,
                  S = this.nextAvcDts,
                  _ = this.isSafari;
                if (0 !== b) {
                  _ &&
                    (r |=
                      m.length &&
                      S &&
                      ((s && Math.abs(t - S / v) < 0.1) ||
                        Math.abs(m[0].pts - S - E) < v / 5)),
                    r || (S = t * v),
                    m.forEach(function(e) {
                      (e.pts = T(e.pts - E, S)), (e.dts = T(e.dts - E, S));
                    }),
                    m.sort(function(e, t) {
                      var r = e.dts - t.dts,
                        i = e.pts - t.pts;
                      return r || i || e.id - t.id;
                    });
                  var R = m.reduce(function(e, t) {
                    return Math.max(Math.min(e, t.pts - t.dts), -1 * M);
                  }, 0);
                  if (R < 0) {
                    o.b.warn(
                      'PTS < DTS detected in video samples, shifting DTS by ' +
                        C(R, !0) +
                        ' ms to overcome this issue'
                    );
                    for (var A = 0; A < m.length; A++) m[A].dts += R;
                  }
                  var k = m[0];
                  (h = Math.max(k.dts, 0)), (c = Math.max(k.pts, 0));
                  var w = h - S;
                  r &&
                    w &&
                    (w > 1
                      ? o.b.log(
                          'AVC: ' +
                            C(w, !0) +
                            ' ms hole between fragments detected,filling it'
                        )
                      : w < -1 &&
                        o.b.log(
                          'AVC: ' +
                            C(-w, !0) +
                            ' ms overlapping between fragments detected'
                        ),
                    (h = S),
                    (m[0].dts = h),
                    (c = Math.max(c - w, S)),
                    (m[0].pts = c),
                    o.b.log(
                      'Video: PTS/DTS adjusted: ' +
                        C(c, !0) +
                        '/' +
                        C(h, !0) +
                        ', delta: ' +
                        C(w, !0) +
                        ' ms'
                    )),
                    (k = m[m.length - 1]),
                    (g = Math.max(k.dts, 0)),
                    (f = Math.max(k.pts, 0, g)),
                    _ && (l = Math.round((g - h) / (m.length - 1)));
                  for (var L = 0, O = 0, I = 0; I < b; I++) {
                    for (
                      var P = m[I], x = P.units, F = x.length, U = 0, N = 0;
                      N < F;
                      N++
                    )
                      U += x[N].data.length;
                    (O += U),
                      (L += F),
                      (P.length = U),
                      (P.dts = _ ? h + I * l : Math.max(P.dts, h)),
                      (P.pts = Math.max(P.pts, P.dts));
                  }
                  var B = O + 4 * L + 8;
                  try {
                    u = new Uint8Array(B);
                  } catch (e) {
                    return void this.observer.trigger(i.a.ERROR, {
                      type: a.b.MUX_ERROR,
                      details: a.a.REMUX_ALLOC_ERROR,
                      fatal: !1,
                      bytes: B,
                      reason: 'fail allocating video mdat ' + B
                    });
                  }
                  var G = new DataView(u.buffer);
                  G.setUint32(0, B), u.set(D.types.mdat, 4);
                  for (var K = 0; K < b; K++) {
                    for (
                      var j = m[K],
                        H = j.units,
                        V = 0,
                        Y = void 0,
                        W = 0,
                        q = H.length;
                      W < q;
                      W++
                    ) {
                      var X = H[W],
                        z = X.data,
                        Q = X.data.byteLength;
                      G.setUint32(p, Q),
                        (p += 4),
                        u.set(z, p),
                        (p += Q),
                        (V += 4 + Q);
                    }
                    if (_) Y = Math.max(0, l * Math.round((j.pts - j.dts) / l));
                    else {
                      if (K < b - 1) l = m[K + 1].dts - j.dts;
                      else {
                        var $ = this.config,
                          J = j.dts - m[K > 0 ? K - 1 : K].dts;
                        if ($.stretchShortVideoTrack) {
                          var Z = $.maxBufferHole,
                            ee = Math.floor(Z * v),
                            te = (n ? c + n * v : this.nextAudioPts) - j.pts;
                          te > ee
                            ? ((l = te - J) < 0 && (l = J),
                              o.b.log(
                                'It is approximately ' +
                                  C(te, !1) +
                                  ' ms to the next segment; using duration ' +
                                  C(l, !1) +
                                  ' ms for the last video frame.'
                              ))
                            : (l = J);
                        } else l = J;
                      }
                      Y = Math.round(j.pts - j.dts);
                    }
                    y.push({
                      size: V,
                      duration: l,
                      cts: Y,
                      flags: {
                        isLeading: 0,
                        isDependedOn: 0,
                        hasRedundancy: 0,
                        degradPrio: 0,
                        dependsOn: j.key ? 2 : 1,
                        isNonSync: j.key ? 0 : 1
                      }
                    });
                  }
                  this.nextAvcDts = g + l;
                  var re = e.dropped;
                  if (
                    ((e.nbNalu = 0),
                    (e.dropped = 0),
                    y.length &&
                      navigator.userAgent.toLowerCase().indexOf('chrome') > -1)
                  ) {
                    var ie = y[0].flags;
                    (ie.dependsOn = 2), (ie.isNonSync = 0);
                  }
                  (e.samples = y),
                    (d = D.moof(e.sequenceNumber++, h, e)),
                    (e.samples = []);
                  var ae = {
                    data1: d,
                    data2: u,
                    startPTS: c / v,
                    endPTS: (f + l) / v,
                    startDTS: h / v,
                    endDTS: this.nextAvcDts / v,
                    type: 'video',
                    hasAudio: !1,
                    hasVideo: !0,
                    nb: y.length,
                    dropped: re
                  };
                  return this.observer.trigger(i.a.FRAG_PARSING_DATA, ae), ae;
                }
              }),
              (t.remuxAudio = function(e, t, r, n) {
                var s,
                  l,
                  u,
                  d,
                  c,
                  h,
                  f = e.inputTimeScale,
                  g = e.timescale,
                  p = f / g,
                  v = (e.isAAC ? 1024 : 1152) * p,
                  m = this._PTSNormalize,
                  y = this._initPTS,
                  b = !e.isAAC && this.typeSupported.mpeg,
                  T = b ? 0 : 8,
                  E = e.samples,
                  S = [],
                  _ = this.nextAudioPts;
                if (
                  ((r |=
                    E.length &&
                    _ &&
                    ((n && Math.abs(t - _ / f) < 0.1) ||
                      Math.abs(E[0].pts - _ - y) < 20 * v)),
                  E.forEach(function(e) {
                    e.pts = e.dts = m(e.pts - y, t * f);
                  }),
                  0 !==
                    (E = E.filter(function(e) {
                      return e.pts >= 0;
                    })).length)
                ) {
                  if ((r || (_ = n ? t * f : E[0].pts), e.isAAC))
                    for (
                      var R = this.config.maxAudioFramesDrift, A = 0, k = _;
                      A < E.length;

                    ) {
                      var L,
                        O = E[A];
                      if ((L = O.pts - k) <= -R * v)
                        o.b.warn(
                          'Dropping 1 audio frame @ ' +
                            C(k, !0) +
                            ' ms due to ' +
                            C(L, !0) +
                            ' ms overlap.'
                        ),
                          E.splice(A, 1);
                      else if (L >= R * v && L < x && k) {
                        var I = Math.round(L / v);
                        o.b.warn(
                          'Injecting ' +
                            I +
                            ' audio frames @ ' +
                            C(k, !0) +
                            ' ms due to ' +
                            C(L, !0) +
                            ' ms gap.'
                        );
                        for (var P = 0; P < I; P++) {
                          var M = Math.max(k, 0);
                          (l = w.getSilentFrame(
                            e.manifestCodec || e.codec,
                            e.channelCount
                          )) ||
                            (o.b.log(
                              'Unable to get silent frame for given audio codec; duplicating last frame instead.'
                            ),
                            (l = O.unit.subarray())),
                            E.splice(A, 0, { unit: l, pts: M, dts: M }),
                            (k += v),
                            A++;
                        }
                        (O.pts = O.dts = k), (k += v), A++;
                      } else Math.abs(L), (O.pts = O.dts = k), (k += v), A++;
                    }
                  for (var F = E.length, U = 0; F--; )
                    U += E[F].unit.byteLength;
                  for (var N = 0, B = E.length; N < B; N++) {
                    var G = E[N],
                      K = G.unit,
                      j = G.pts;
                    if (void 0 !== h) s.duration = Math.round((j - h) / p);
                    else {
                      var H = j - _,
                        V = 0;
                      if (r && e.isAAC && H) {
                        if (H > 0 && H < x)
                          (V = Math.round((j - _) / v)),
                            o.b.log(
                              C(H, !0) +
                                ' ms hole between AAC samples detected,filling it'
                            ),
                            V > 0 &&
                              ((l = w.getSilentFrame(
                                e.manifestCodec || e.codec,
                                e.channelCount
                              )) || (l = K.subarray()),
                              (U += V * l.length));
                        else if (H < -12) {
                          o.b.log(
                            'drop overlapping AAC sample, expected/parsed/delta: ' +
                              C(_, !0) +
                              ' ms / ' +
                              C(j, !0) +
                              ' ms / ' +
                              C(-H, !0) +
                              ' ms'
                          ),
                            (U -= K.byteLength);
                          continue;
                        }
                        j = _;
                      }
                      if (((c = j), !(U > 0))) return;
                      U += T;
                      try {
                        u = new Uint8Array(U);
                      } catch (e) {
                        return void this.observer.trigger(i.a.ERROR, {
                          type: a.b.MUX_ERROR,
                          details: a.a.REMUX_ALLOC_ERROR,
                          fatal: !1,
                          bytes: U,
                          reason: 'fail allocating audio mdat ' + U
                        });
                      }
                      b ||
                        (new DataView(u.buffer).setUint32(0, U),
                        u.set(D.types.mdat, 4));
                      for (var Y = 0; Y < V; Y++)
                        (l = w.getSilentFrame(
                          e.manifestCodec || e.codec,
                          e.channelCount
                        )) ||
                          (o.b.log(
                            'Unable to get silent frame for given audio codec; duplicating this frame instead.'
                          ),
                          (l = K.subarray())),
                          u.set(l, T),
                          (T += l.byteLength),
                          (s = {
                            size: l.byteLength,
                            cts: 0,
                            duration: 1024,
                            flags: {
                              isLeading: 0,
                              isDependedOn: 0,
                              hasRedundancy: 0,
                              degradPrio: 0,
                              dependsOn: 1
                            }
                          }),
                          S.push(s);
                    }
                    u.set(K, T);
                    var W = K.byteLength;
                    (T += W),
                      (s = {
                        size: W,
                        cts: 0,
                        duration: 0,
                        flags: {
                          isLeading: 0,
                          isDependedOn: 0,
                          hasRedundancy: 0,
                          degradPrio: 0,
                          dependsOn: 1
                        }
                      }),
                      S.push(s),
                      (h = j);
                  }
                  var q = 0;
                  if (
                    ((F = S.length) >= 2 &&
                      ((q = S[F - 2].duration), (s.duration = q)),
                    F)
                  ) {
                    (this.nextAudioPts = _ = h + p * q),
                      (e.samples = S),
                      (d = b
                        ? new Uint8Array()
                        : D.moof(e.sequenceNumber++, c / p, e)),
                      (e.samples = []);
                    var X = c / f,
                      z = _ / f,
                      Q = {
                        data1: d,
                        data2: u,
                        startPTS: X,
                        endPTS: z,
                        startDTS: X,
                        endDTS: z,
                        type: 'audio',
                        hasAudio: !0,
                        hasVideo: !1,
                        nb: F
                      };
                    return this.observer.trigger(i.a.FRAG_PARSING_DATA, Q), Q;
                  }
                  return null;
                }
              }),
              (t.remuxEmptyAudio = function(e, t, r, i) {
                var a = e.inputTimeScale,
                  n = a / (e.samplerate ? e.samplerate : a),
                  s = this.nextAudioPts,
                  l = (void 0 !== s ? s : i.startDTS * a) + this._initDTS,
                  u = i.endDTS * a + this._initDTS,
                  d = 1024 * n,
                  c = Math.ceil((u - l) / d),
                  h = w.getSilentFrame(
                    e.manifestCodec || e.codec,
                    e.channelCount
                  );
                if ((o.b.warn('remux empty Audio'), h)) {
                  for (var f = [], g = 0; g < c; g++) {
                    var p = l + g * d;
                    f.push({ unit: h, pts: p, dts: p });
                  }
                  (e.samples = f), this.remuxAudio(e, t, r);
                } else
                  o.b.trace(
                    'Unable to remuxEmptyAudio since we were unable to get a silent frame for given audio codec!'
                  );
              }),
              (t.remuxID3 = function(e) {
                var t = e.samples.length;
                if (t) {
                  for (
                    var r = e.inputTimeScale,
                      a = this._initPTS,
                      n = this._initDTS,
                      s = 0;
                    s < t;
                    s++
                  ) {
                    var o = e.samples[s];
                    (o.pts = (o.pts - a) / r), (o.dts = (o.dts - n) / r);
                  }
                  this.observer.trigger(i.a.FRAG_PARSING_METADATA, {
                    samples: e.samples
                  }),
                    (e.samples = []);
                }
              }),
              (t.remuxText = function(e) {
                e.samples.sort(function(e, t) {
                  return e.pts - t.pts;
                });
                var t,
                  r = e.samples.length,
                  a = e.inputTimeScale,
                  n = this._initPTS;
                if (r) {
                  for (var s = 0; s < r; s++)
                    (t = e.samples[s]).pts = (t.pts - n) / a;
                  this.observer.trigger(i.a.FRAG_PARSING_USERDATA, {
                    samples: e.samples
                  });
                }
                e.samples = [];
              }),
              (t._PTSNormalize = function(e, t) {
                var r;
                if (void 0 === t) return e;
                for (
                  r = t < e ? -8589934592 : 8589934592;
                  Math.abs(e - t) > 4294967296;

                )
                  e += r;
                return e;
              }),
              e
            );
          })(),
          U = (function() {
            function e(e) {
              this.observer = e;
            }
            var t = e.prototype;
            return (
              (t.destroy = function() {}),
              (t.resetTimeStamp = function() {}),
              (t.resetInitSegment = function() {}),
              (t.remux = function(e, t, r, a, n, s, o, l) {
                var u = this.observer,
                  d = '';
                e && (d += 'audio'),
                  t && (d += 'video'),
                  u.trigger(i.a.FRAG_PARSING_DATA, {
                    data1: l,
                    startPTS: n,
                    startDTS: n,
                    type: d,
                    hasAudio: !!e,
                    hasVideo: !!t,
                    nb: 1,
                    dropped: 0
                  }),
                  u.trigger(i.a.FRAG_PARSED);
              }),
              e
            );
          })(),
          N = Object(l.a)();
        try {
          P = N.performance.now.bind(N.performance);
        } catch (e) {
          o.b.debug('Unable to use Performance API on this environment'),
            (P = N.Date.now);
        }
        var B = (function() {
          function e(e, t, r, i) {
            (this.observer = e),
              (this.typeSupported = t),
              (this.config = r),
              (this.vendor = i);
          }
          var t = e.prototype;
          return (
            (t.destroy = function() {
              var e = this.demuxer;
              e && e.destroy();
            }),
            (t.push = function(e, t, r, a, s, o, l, u, d, c, h, f) {
              var g = this;
              if (
                e.byteLength > 0 &&
                null != t &&
                null != t.key &&
                'AES-128' === t.method
              ) {
                var p = this.decrypter;
                null == p &&
                  (p = this.decrypter = new n.a(this.observer, this.config));
                var v = P();
                p.decrypt(e, t.key.buffer, t.iv.buffer, function(e) {
                  var n = P();
                  g.observer.trigger(i.a.FRAG_DECRYPTED, {
                    stats: { tstart: v, tdecrypt: n }
                  }),
                    g.pushDecrypted(
                      new Uint8Array(e),
                      t,
                      new Uint8Array(r),
                      a,
                      s,
                      o,
                      l,
                      u,
                      d,
                      c,
                      h,
                      f
                    );
                });
              } else
                this.pushDecrypted(
                  new Uint8Array(e),
                  t,
                  new Uint8Array(r),
                  a,
                  s,
                  o,
                  l,
                  u,
                  d,
                  c,
                  h,
                  f
                );
            }),
            (t.pushDecrypted = function(e, t, r, n, s, o, l, u, d, c, h, f) {
              var g = this.demuxer;
              if (!g || ((l || u) && !this.probe(e))) {
                for (
                  var p = this.observer,
                    v = this.typeSupported,
                    m = this.config,
                    T = [
                      { demux: A, remux: F },
                      { demux: b.a, remux: U },
                      { demux: y, remux: F },
                      { demux: k, remux: F }
                    ],
                    E = 0,
                    S = T.length;
                  E < S;
                  E++
                ) {
                  var _ = T[E],
                    R = _.demux.probe;
                  if (R(e)) {
                    var w = (this.remuxer = new _.remux(p, m, v, this.vendor));
                    (g = new _.demux(p, w, m, v)), (this.probe = R);
                    break;
                  }
                }
                if (!g)
                  return void p.trigger(i.a.ERROR, {
                    type: a.b.MEDIA_ERROR,
                    details: a.a.FRAG_PARSING_ERROR,
                    fatal: !0,
                    reason: 'no demux matching with content found'
                  });
                this.demuxer = g;
              }
              var L = this.remuxer;
              (l || u) &&
                (g.resetInitSegment(r, n, s, c), L.resetInitSegment()),
                l && (g.resetTimeStamp(f), L.resetTimeStamp(f)),
                'function' == typeof g.setDecryptData && g.setDecryptData(t),
                g.append(e, o, d, h);
            }),
            e
          );
        })();
        t.a = B;
      },
      function(e, t, r) {
        'use strict';
        var i = r(0),
          a = r(1),
          n = Math.pow(2, 32) - 1,
          s = (function() {
            function e(e, t) {
              (this.observer = e), (this.remuxer = t);
            }
            var t = e.prototype;
            return (
              (t.resetTimeStamp = function(e) {
                this.initPTS = e;
              }),
              (t.resetInitSegment = function(t, r, i, n) {
                if (t && t.byteLength) {
                  var s = (this.initData = e.parseInitSegment(t));
                  null == r && (r = 'mp4a.40.5'),
                    null == i && (i = 'avc1.42e01e');
                  var o = {};
                  s.audio && s.video
                    ? (o.audiovideo = {
                        container: 'video/mp4',
                        codec: r + ',' + i,
                        initSegment: n ? t : null
                      })
                    : (s.audio &&
                        (o.audio = {
                          container: 'audio/mp4',
                          codec: r,
                          initSegment: n ? t : null
                        }),
                      s.video &&
                        (o.video = {
                          container: 'video/mp4',
                          codec: i,
                          initSegment: n ? t : null
                        })),
                    this.observer.trigger(a.a.FRAG_PARSING_INIT_SEGMENT, {
                      tracks: o
                    });
                } else r && (this.audioCodec = r), i && (this.videoCodec = i);
              }),
              (e.probe = function(t) {
                return (
                  e.findBox(
                    { data: t, start: 0, end: Math.min(t.length, 16384) },
                    ['moof']
                  ).length > 0
                );
              }),
              (e.bin2str = function(e) {
                return String.fromCharCode.apply(null, e);
              }),
              (e.readUint16 = function(e, t) {
                e.data && ((t += e.start), (e = e.data));
                var r = (e[t] << 8) | e[t + 1];
                return r < 0 ? 65536 + r : r;
              }),
              (e.readUint32 = function(e, t) {
                e.data && ((t += e.start), (e = e.data));
                var r =
                  (e[t] << 24) | (e[t + 1] << 16) | (e[t + 2] << 8) | e[t + 3];
                return r < 0 ? 4294967296 + r : r;
              }),
              (e.writeUint32 = function(e, t, r) {
                e.data && ((t += e.start), (e = e.data)),
                  (e[t] = r >> 24),
                  (e[t + 1] = (r >> 16) & 255),
                  (e[t + 2] = (r >> 8) & 255),
                  (e[t + 3] = 255 & r);
              }),
              (e.findBox = function(t, r) {
                var i,
                  a,
                  n,
                  s,
                  o,
                  l,
                  u = [];
                if (
                  (t.data
                    ? ((o = t.start), (n = t.end), (t = t.data))
                    : ((o = 0), (n = t.byteLength)),
                  !r.length)
                )
                  return null;
                for (i = o; i < n; )
                  (l = (a = e.readUint32(t, i)) > 1 ? i + a : n),
                    e.bin2str(t.subarray(i + 4, i + 8)) === r[0] &&
                      (1 === r.length
                        ? u.push({ data: t, start: i + 8, end: l })
                        : (s = e.findBox(
                            { data: t, start: i + 8, end: l },
                            r.slice(1)
                          )).length && (u = u.concat(s))),
                    (i = l);
                return u;
              }),
              (e.parseSegmentIndex = function(t) {
                var r,
                  i = e.findBox(t, ['moov'])[0],
                  a = i ? i.end : null,
                  n = 0,
                  s = e.findBox(t, ['sidx']);
                if (!s || !s[0]) return null;
                r = [];
                var o = (s = s[0]).data[0];
                n = 0 === o ? 8 : 16;
                var l = e.readUint32(s, n);
                n += 4;
                (n += 0 === o ? 8 : 16), (n += 2);
                var u = s.end + 0,
                  d = e.readUint16(s, n);
                n += 2;
                for (var c = 0; c < d; c++) {
                  var h = n,
                    f = e.readUint32(s, h);
                  h += 4;
                  var g = 2147483647 & f;
                  if (1 === (2147483648 & f) >>> 31)
                    return void console.warn(
                      'SIDX has hierarchical references (not supported)'
                    );
                  var p = e.readUint32(s, h);
                  (h += 4),
                    r.push({
                      referenceSize: g,
                      subsegmentDuration: p,
                      info: { duration: p / l, start: u, end: u + g - 1 }
                    }),
                    (u += g),
                    (n = h += 4);
                }
                return {
                  earliestPresentationTime: 0,
                  timescale: l,
                  version: o,
                  referencesCount: d,
                  references: r,
                  moovEndOffset: a
                };
              }),
              (e.parseInitSegment = function(t) {
                var r = [];
                return (
                  e.findBox(t, ['moov', 'trak']).forEach(function(t) {
                    var a = e.findBox(t, ['tkhd'])[0];
                    if (a) {
                      var n = a.data[a.start],
                        s = 0 === n ? 12 : 20,
                        o = e.readUint32(a, s),
                        l = e.findBox(t, ['mdia', 'mdhd'])[0];
                      if (l) {
                        s = 0 === (n = l.data[l.start]) ? 12 : 20;
                        var u = e.readUint32(l, s),
                          d = e.findBox(t, ['mdia', 'hdlr'])[0];
                        if (d) {
                          var c = { soun: 'audio', vide: 'video' }[
                            e.bin2str(
                              d.data.subarray(d.start + 8, d.start + 12)
                            )
                          ];
                          if (c) {
                            var h = e.findBox(t, [
                              'mdia',
                              'minf',
                              'stbl',
                              'stsd'
                            ]);
                            if (h.length) {
                              h = h[0];
                              var f = e.bin2str(
                                h.data.subarray(h.start + 12, h.start + 16)
                              );
                              i.b.log('MP4Demuxer:' + c + ':' + f + ' found');
                            }
                            (r[o] = { timescale: u, type: c }),
                              (r[c] = { timescale: u, id: o });
                          }
                        }
                      }
                    }
                  }),
                  r
                );
              }),
              (e.getStartDTS = function(t, r) {
                var i, a, n;
                return (
                  (i = e.findBox(r, ['moof', 'traf'])),
                  (a = [].concat.apply(
                    [],
                    i.map(function(r) {
                      return e.findBox(r, ['tfhd']).map(function(i) {
                        var a, n;
                        return (
                          (a = e.readUint32(i, 4)),
                          (n = t[a].timescale || 9e4),
                          e.findBox(r, ['tfdt']).map(function(t) {
                            var r, i;
                            return (
                              (r = t.data[t.start]),
                              (i = e.readUint32(t, 4)),
                              1 === r &&
                                ((i *= Math.pow(2, 32)),
                                (i += e.readUint32(t, 8))),
                              i
                            );
                          })[0] / n
                        );
                      });
                    })
                  )),
                  (n = Math.min.apply(null, a)),
                  isFinite(n) ? n : 0
                );
              }),
              (e.offsetStartDTS = function(t, r, i) {
                e.findBox(r, ['moof', 'traf']).map(function(r) {
                  return e.findBox(r, ['tfhd']).map(function(a) {
                    var s = e.readUint32(a, 4),
                      o = t[s].timescale || 9e4;
                    e.findBox(r, ['tfdt']).map(function(t) {
                      var r = t.data[t.start],
                        a = e.readUint32(t, 4);
                      if (0 === r) e.writeUint32(t, 4, a - i * o);
                      else {
                        (a *= Math.pow(2, 32)),
                          (a += e.readUint32(t, 8)),
                          (a -= i * o),
                          (a = Math.max(a, 0));
                        var s = Math.floor(a / (n + 1)),
                          l = Math.floor(a % (n + 1));
                        e.writeUint32(t, 4, s), e.writeUint32(t, 8, l);
                      }
                    });
                  });
                });
              }),
              (t.append = function(t, r, i, n) {
                var s = this.initData;
                s ||
                  (this.resetInitSegment(
                    t,
                    this.audioCodec,
                    this.videoCodec,
                    !1
                  ),
                  (s = this.initData));
                var o,
                  l = this.initPTS;
                if (void 0 === l) {
                  var u = e.getStartDTS(s, t);
                  (this.initPTS = l = u - r),
                    this.observer.trigger(a.a.INIT_PTS_FOUND, { initPTS: l });
                }
                e.offsetStartDTS(s, t, l),
                  (o = e.getStartDTS(s, t)),
                  this.remuxer.remux(s.audio, s.video, null, null, o, i, n, t);
              }),
              (t.destroy = function() {}),
              e
            );
          })();
        t.a = s;
      },
      function(e, t, r) {
        function i(e) {
          var t = {};
          function r(i) {
            if (t[i]) return t[i].exports;
            var a = (t[i] = { i: i, l: !1, exports: {} });
            return e[i].call(a.exports, a, a.exports, r), (a.l = !0), a.exports;
          }
          (r.m = e),
            (r.c = t),
            (r.i = function(e) {
              return e;
            }),
            (r.d = function(e, t, i) {
              r.o(e, t) ||
                Object.defineProperty(e, t, {
                  configurable: !1,
                  enumerable: !0,
                  get: i
                });
            }),
            (r.r = function(e) {
              Object.defineProperty(e, '__esModule', { value: !0 });
            }),
            (r.n = function(e) {
              var t =
                e && e.__esModule
                  ? function() {
                      return e.default;
                    }
                  : function() {
                      return e;
                    };
              return r.d(t, 'a', t), t;
            }),
            (r.o = function(e, t) {
              return Object.prototype.hasOwnProperty.call(e, t);
            }),
            (r.p = '/'),
            (r.oe = function(e) {
              throw (console.error(e), e);
            });
          var i = r((r.s = ENTRY_MODULE));
          return i.default || i;
        }
        function a(e) {
          return (e + '').replace(/[.?*+^$[\]\\(){}|-]/g, '\\$&');
        }
        function n(e, t, i) {
          var n = {};
          n[i] = [];
          var s = t.toString(),
            o = s.match(/^function\s?\w*\(\w+,\s*\w+,\s*(\w+)\)/);
          if (!o) return n;
          for (
            var l,
              u = o[1],
              d = new RegExp(
                '(\\\\n|\\W)' +
                  a(u) +
                  '\\(\\s*(/\\*.*?\\*/)?\\s*.*?([\\.|\\-|\\+|\\w|/|@]+).*?\\)',
                'g'
              );
            (l = d.exec(s));

          )
            'dll-reference' !== l[3] && n[i].push(l[3]);
          for (
            d = new RegExp(
              '\\(' +
                a(u) +
                '\\("(dll-reference\\s([\\.|\\-|\\+|\\w|/|@]+))"\\)\\)\\(\\s*(/\\*.*?\\*/)?\\s*.*?([\\.|\\-|\\+|\\w|/|@]+).*?\\)',
              'g'
            );
            (l = d.exec(s));

          )
            e[l[2]] || (n[i].push(l[1]), (e[l[2]] = r(l[1]).m)),
              (n[l[2]] = n[l[2]] || []),
              n[l[2]].push(l[4]);
          for (var c, h = Object.keys(n), f = 0; f < h.length; f++)
            for (var g = 0; g < n[h[f]].length; g++)
              (c = n[h[f]][g]), isNaN(1 * c) || (n[h[f]][g] = 1 * n[h[f]][g]);
          return n;
        }
        function s(e) {
          return Object.keys(e).reduce(function(t, r) {
            return t || e[r].length > 0;
          }, !1);
        }
        e.exports = function(e, t) {
          t = t || {};
          var a = { main: r.m },
            o = t.all
              ? { main: Object.keys(a.main) }
              : (function(e, t) {
                  for (
                    var r = { main: [t] }, i = { main: [] }, a = { main: {} };
                    s(r);

                  )
                    for (var o = Object.keys(r), l = 0; l < o.length; l++) {
                      var u = o[l],
                        d = r[u].pop();
                      if (((a[u] = a[u] || {}), !a[u][d] && e[u][d])) {
                        (a[u][d] = !0), (i[u] = i[u] || []), i[u].push(d);
                        for (
                          var c = n(e, e[u][d], u), h = Object.keys(c), f = 0;
                          f < h.length;
                          f++
                        )
                          (r[h[f]] = r[h[f]] || []),
                            (r[h[f]] = r[h[f]].concat(c[h[f]]));
                      }
                    }
                  return i;
                })(a, e),
            l = '';
          Object.keys(o)
            .filter(function(e) {
              return 'main' !== e;
            })
            .forEach(function(e) {
              for (var t = 0; o[e][t]; ) t++;
              o[e].push(t),
                (a[e][t] =
                  '(function(module, exports, __webpack_require__) { module.exports = __webpack_require__; })'),
                (l =
                  l +
                  'var ' +
                  e +
                  ' = (' +
                  i.toString().replace('ENTRY_MODULE', JSON.stringify(t)) +
                  ')({' +
                  o[e]
                    .map(function(t) {
                      return JSON.stringify(t) + ': ' + a[e][t].toString();
                    })
                    .join(',') +
                  '});\n');
            }),
            (l =
              l +
              'new ((' +
              i.toString().replace('ENTRY_MODULE', JSON.stringify(e)) +
              ')({' +
              o.main
                .map(function(e) {
                  return JSON.stringify(e) + ': ' + a.main[e].toString();
                })
                .join(',') +
              '}))(self);');
          var u = new window.Blob([l], { type: 'text/javascript' });
          if (t.bare) return u;
          var d = (
              window.URL ||
              window.webkitURL ||
              window.mozURL ||
              window.msURL
            ).createObjectURL(u),
            c = new window.Worker(d);
          return (c.objectURL = d), c;
        };
      },
      function(e, t, r) {
        'use strict';
        r.r(t);
        var i = r(9),
          a = r(1),
          n = r(0),
          s = r(8);
        t.default = function(e) {
          var t = new s.EventEmitter();
          (t.trigger = function(e) {
            for (
              var r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), a = 1;
              a < r;
              a++
            )
              i[a - 1] = arguments[a];
            t.emit.apply(t, [e, e].concat(i));
          }),
            (t.off = function(e) {
              for (
                var r = arguments.length,
                  i = new Array(r > 1 ? r - 1 : 0),
                  a = 1;
                a < r;
                a++
              )
                i[a - 1] = arguments[a];
              t.removeListener.apply(t, [e].concat(i));
            });
          var r = function(t, r) {
            e.postMessage({ event: t, data: r });
          };
          e.addEventListener('message', function(a) {
            var s = a.data;
            switch (s.cmd) {
              case 'init':
                var o = JSON.parse(s.config);
                (e.demuxer = new i.a(t, s.typeSupported, o, s.vendor)),
                  Object(n.a)(o.debug),
                  r('init', null);
                break;
              case 'demux':
                e.demuxer.push(
                  s.data,
                  s.decryptdata,
                  s.initSegment,
                  s.audioCodec,
                  s.videoCodec,
                  s.timeOffset,
                  s.discontinuity,
                  s.trackSwitch,
                  s.contiguous,
                  s.duration,
                  s.accurateTimeOffset,
                  s.defaultInitPTS
                );
            }
          }),
            t.on(a.a.FRAG_DECRYPTED, r),
            t.on(a.a.FRAG_PARSING_INIT_SEGMENT, r),
            t.on(a.a.FRAG_PARSED, r),
            t.on(a.a.ERROR, r),
            t.on(a.a.FRAG_PARSING_METADATA, r),
            t.on(a.a.FRAG_PARSING_USERDATA, r),
            t.on(a.a.INIT_PTS_FOUND, r),
            t.on(a.a.FRAG_PARSING_DATA, function(t, r) {
              var i = [],
                a = { event: t, data: r };
              r.data1 &&
                ((a.data1 = r.data1.buffer),
                i.push(r.data1.buffer),
                delete r.data1),
                r.data2 &&
                  ((a.data2 = r.data2.buffer),
                  i.push(r.data2.buffer),
                  delete r.data2),
                e.postMessage(a, i);
            });
        };
      },
      function(e, t, r) {
        'use strict';
        r.r(t),
          r.d(t, 'default', function() {
            return nr;
          });
        var i = {};
        r.r(i),
          r.d(i, 'newCue', function() {
            return ft;
          });
        var a,
          n,
          s = r(6),
          o = r(2),
          l = r(3),
          u = r(1),
          d = r(0),
          c = {
            hlsEventGeneric: !0,
            hlsHandlerDestroying: !0,
            hlsHandlerDestroyed: !0
          },
          h = (function() {
            function e(e) {
              (this.hls = void 0),
                (this.handledEvents = void 0),
                (this.useGenericHandler = void 0),
                (this.hls = e),
                (this.onEvent = this.onEvent.bind(this));
              for (
                var t = arguments.length,
                  r = new Array(t > 1 ? t - 1 : 0),
                  i = 1;
                i < t;
                i++
              )
                r[i - 1] = arguments[i];
              (this.handledEvents = r),
                (this.useGenericHandler = !0),
                this.registerListeners();
            }
            var t = e.prototype;
            return (
              (t.destroy = function() {
                this.onHandlerDestroying(),
                  this.unregisterListeners(),
                  this.onHandlerDestroyed();
              }),
              (t.onHandlerDestroying = function() {}),
              (t.onHandlerDestroyed = function() {}),
              (t.isEventHandler = function() {
                return (
                  'object' == typeof this.handledEvents &&
                  this.handledEvents.length &&
                  'function' == typeof this.onEvent
                );
              }),
              (t.registerListeners = function() {
                this.isEventHandler() &&
                  this.handledEvents.forEach(function(e) {
                    if (c[e]) throw new Error('Forbidden event-name: ' + e);
                    this.hls.on(e, this.onEvent);
                  }, this);
              }),
              (t.unregisterListeners = function() {
                this.isEventHandler() &&
                  this.handledEvents.forEach(function(e) {
                    this.hls.off(e, this.onEvent);
                  }, this);
              }),
              (t.onEvent = function(e, t) {
                this.onEventGeneric(e, t);
              }),
              (t.onEventGeneric = function(e, t) {
                try {
                  (function(e, t) {
                    var r = 'on' + e.replace('hls', '');
                    if ('function' != typeof this[r])
                      throw new Error(
                        'Event ' +
                          e +
                          ' has no generic handler in this ' +
                          this.constructor.name +
                          ' class (tried ' +
                          r +
                          ')'
                      );
                    return this[r].bind(this, t);
                  }
                    .call(this, e, t)
                    .call());
                } catch (t) {
                  d.b.error(
                    'An internal error happened while handling event ' +
                      e +
                      '. Error message: "' +
                      t.message +
                      '". Here is a stacktrace:',
                    t
                  ),
                    this.hls.trigger(u.a.ERROR, {
                      type: o.b.OTHER_ERROR,
                      details: o.a.INTERNAL_EXCEPTION,
                      fatal: !1,
                      event: e,
                      err: t
                    });
                }
              }),
              e
            );
          })();
        !(function(e) {
          (e.MANIFEST = 'manifest'),
            (e.LEVEL = 'level'),
            (e.AUDIO_TRACK = 'audioTrack'),
            (e.SUBTITLE_TRACK = 'subtitleTrack');
        })(a || (a = {})),
          (function(e) {
            (e.MAIN = 'main'), (e.AUDIO = 'audio'), (e.SUBTITLE = 'subtitle');
          })(n || (n = {}));
        var f = r(10);
        function g(e, t) {
          for (var r = 0; r < t.length; r++) {
            var i = t[r];
            (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              'value' in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        var p,
          v = (function() {
            function e(e, t) {
              (this._uri = null),
                (this.baseuri = void 0),
                (this.reluri = void 0),
                (this.method = null),
                (this.key = null),
                (this.iv = null),
                (this.baseuri = e),
                (this.reluri = t);
            }
            var t, r, i;
            return (
              (t = e),
              (r = [
                {
                  key: 'uri',
                  get: function() {
                    return (
                      !this._uri &&
                        this.reluri &&
                        (this._uri = Object(s.buildAbsoluteURL)(
                          this.baseuri,
                          this.reluri,
                          { alwaysNormalize: !0 }
                        )),
                      this._uri
                    );
                  }
                }
              ]) && g(t.prototype, r),
              i && g(t, i),
              e
            );
          })();
        function m(e, t) {
          for (var r = 0; r < t.length; r++) {
            var i = t[r];
            (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              'value' in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        !(function(e) {
          (e.AUDIO = 'audio'), (e.VIDEO = 'video');
        })(p || (p = {}));
        var y = (function() {
          function e() {
            var e;
            (this._url = null),
              (this._byteRange = null),
              (this._decryptdata = null),
              (this._elementaryStreams =
                (((e = {})[p.AUDIO] = !1), (e[p.VIDEO] = !1), e)),
              (this.deltaPTS = 0),
              (this.rawProgramDateTime = null),
              (this.programDateTime = null),
              (this.title = null),
              (this.tagList = []),
              (this.cc = void 0),
              (this.type = void 0),
              (this.relurl = void 0),
              (this.baseurl = void 0),
              (this.duration = void 0),
              (this.start = void 0),
              (this.sn = 0),
              (this.urlId = 0),
              (this.level = 0),
              (this.levelkey = void 0),
              (this.loader = void 0);
          }
          var t,
            r,
            i,
            a = e.prototype;
          return (
            (a.setByteRange = function(e, t) {
              var r = e.split('@', 2),
                i = [];
              1 === r.length
                ? (i[0] = t ? t.byteRangeEndOffset : 0)
                : (i[0] = parseInt(r[1])),
                (i[1] = parseInt(r[0]) + i[0]),
                (this._byteRange = i);
            }),
            (a.addElementaryStream = function(e) {
              this._elementaryStreams[e] = !0;
            }),
            (a.hasElementaryStream = function(e) {
              return !0 === this._elementaryStreams[e];
            }),
            (a.createInitializationVector = function(e) {
              for (var t = new Uint8Array(16), r = 12; r < 16; r++)
                t[r] = (e >> (8 * (15 - r))) & 255;
              return t;
            }),
            (a.setDecryptDataFromLevelKey = function(e, t) {
              var r = e;
              return (
                (null == e ? void 0 : e.method) &&
                  e.uri &&
                  !e.iv &&
                  (((r = new v(e.baseuri, e.reluri)).method = e.method),
                  (r.iv = this.createInitializationVector(t))),
                r
              );
            }),
            (t = e),
            (r = [
              {
                key: 'url',
                get: function() {
                  return (
                    !this._url &&
                      this.relurl &&
                      (this._url = Object(s.buildAbsoluteURL)(
                        this.baseurl,
                        this.relurl,
                        { alwaysNormalize: !0 }
                      )),
                    this._url
                  );
                },
                set: function(e) {
                  this._url = e;
                }
              },
              {
                key: 'byteRange',
                get: function() {
                  return this._byteRange ? this._byteRange : [];
                }
              },
              {
                key: 'byteRangeStartOffset',
                get: function() {
                  return this.byteRange[0];
                }
              },
              {
                key: 'byteRangeEndOffset',
                get: function() {
                  return this.byteRange[1];
                }
              },
              {
                key: 'decryptdata',
                get: function() {
                  if (!this.levelkey && !this._decryptdata) return null;
                  if (!this._decryptdata && this.levelkey) {
                    var e = this.sn;
                    'number' != typeof e &&
                      (this.levelkey &&
                        'AES-128' === this.levelkey.method &&
                        !this.levelkey.iv &&
                        d.b.warn(
                          'missing IV for initialization segment with method="' +
                            this.levelkey.method +
                            '" - compliance issue'
                        ),
                      (e = 0)),
                      (this._decryptdata = this.setDecryptDataFromLevelKey(
                        this.levelkey,
                        e
                      ));
                  }
                  return this._decryptdata;
                }
              },
              {
                key: 'endProgramDateTime',
                get: function() {
                  if (null === this.programDateTime) return null;
                  if (!Object(l.a)(this.programDateTime)) return null;
                  var e = Object(l.a)(this.duration) ? this.duration : 0;
                  return this.programDateTime + 1e3 * e;
                }
              },
              {
                key: 'encrypted',
                get: function() {
                  return !(
                    !this.decryptdata ||
                    null === this.decryptdata.uri ||
                    null !== this.decryptdata.key
                  );
                }
              }
            ]) && m(t.prototype, r),
            i && m(t, i),
            e
          );
        })();
        function b(e, t) {
          for (var r = 0; r < t.length; r++) {
            var i = t[r];
            (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              'value' in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        var T = (function() {
            function e(e) {
              (this.endCC = 0),
                (this.endSN = 0),
                (this.fragments = []),
                (this.initSegment = null),
                (this.live = !0),
                (this.needSidxRanges = !1),
                (this.startCC = 0),
                (this.startSN = 0),
                (this.startTimeOffset = null),
                (this.targetduration = 0),
                (this.totalduration = 0),
                (this.type = null),
                (this.url = e),
                (this.version = null);
            }
            var t, r, i;
            return (
              (t = e),
              (r = [
                {
                  key: 'hasProgramDateTime',
                  get: function() {
                    return !(
                      !this.fragments[0] ||
                      !Object(l.a)(this.fragments[0].programDateTime)
                    );
                  }
                }
              ]) && b(t.prototype, r),
              i && b(t, i),
              e
            );
          })(),
          E = /^(\d+)x(\d+)$/,
          S = /\s*(.+?)\s*=((?:\".*?\")|.*?)(?:,|$)/g,
          _ = (function() {
            function e(t) {
              for (var r in ('string' == typeof t && (t = e.parseAttrList(t)),
              t))
                t.hasOwnProperty(r) && (this[r] = t[r]);
            }
            var t = e.prototype;
            return (
              (t.decimalInteger = function(e) {
                var t = parseInt(this[e], 10);
                return t > Number.MAX_SAFE_INTEGER ? 1 / 0 : t;
              }),
              (t.hexadecimalInteger = function(e) {
                if (this[e]) {
                  var t = (this[e] || '0x').slice(2);
                  t = (1 & t.length ? '0' : '') + t;
                  for (
                    var r = new Uint8Array(t.length / 2), i = 0;
                    i < t.length / 2;
                    i++
                  )
                    r[i] = parseInt(t.slice(2 * i, 2 * i + 2), 16);
                  return r;
                }
                return null;
              }),
              (t.hexadecimalIntegerAsNumber = function(e) {
                var t = parseInt(this[e], 16);
                return t > Number.MAX_SAFE_INTEGER ? 1 / 0 : t;
              }),
              (t.decimalFloatingPoint = function(e) {
                return parseFloat(this[e]);
              }),
              (t.enumeratedString = function(e) {
                return this[e];
              }),
              (t.decimalResolution = function(e) {
                var t = E.exec(this[e]);
                if (null !== t)
                  return {
                    width: parseInt(t[1], 10),
                    height: parseInt(t[2], 10)
                  };
              }),
              (e.parseAttrList = function(e) {
                var t,
                  r = {};
                for (S.lastIndex = 0; null !== (t = S.exec(e)); ) {
                  var i = t[2];
                  0 === i.indexOf('"') &&
                    i.lastIndexOf('"') === i.length - 1 &&
                    (i = i.slice(1, -1)),
                    (r[t[1]] = i);
                }
                return r;
              }),
              e
            );
          })(),
          R = {
            audio: {
              a3ds: !0,
              'ac-3': !0,
              'ac-4': !0,
              alac: !0,
              alaw: !0,
              dra1: !0,
              'dts+': !0,
              'dts-': !0,
              dtsc: !0,
              dtse: !0,
              dtsh: !0,
              'ec-3': !0,
              enca: !0,
              g719: !0,
              g726: !0,
              m4ae: !0,
              mha1: !0,
              mha2: !0,
              mhm1: !0,
              mhm2: !0,
              mlpa: !0,
              mp4a: !0,
              'raw ': !0,
              Opus: !0,
              samr: !0,
              sawb: !0,
              sawp: !0,
              sevc: !0,
              sqcp: !0,
              ssmv: !0,
              twos: !0,
              ulaw: !0
            },
            video: {
              avc1: !0,
              avc2: !0,
              avc3: !0,
              avc4: !0,
              avcp: !0,
              drac: !0,
              dvav: !0,
              dvhe: !0,
              encv: !0,
              hev1: !0,
              hvc1: !0,
              mjp2: !0,
              mp4v: !0,
              mvc1: !0,
              mvc2: !0,
              mvc3: !0,
              mvc4: !0,
              resv: !0,
              rv60: !0,
              s263: !0,
              svc1: !0,
              svc2: !0,
              'vc-1': !0,
              vp08: !0,
              vp09: !0
            }
          };
        function A(e, t) {
          return MediaSource.isTypeSupported(
            (t || 'video') + '/mp4;codecs="' + e + '"'
          );
        }
        var k = /(?:#EXT-X-STREAM-INF:([^\n\r]*)[\r\n]+([^\r\n]+)|#EXT-X-SESSION-DATA:([^\n\r]*)[\r\n]+)/g,
          w = /#EXT-X-MEDIA:(.*)/g,
          L = new RegExp(
            [
              /#EXTINF:\s*(\d*(?:\.\d+)?)(?:,(.*)\s+)?/.source,
              /|(?!#)([\S+ ?]+)/.source,
              /|#EXT-X-BYTERANGE:*(.+)/.source,
              /|#EXT-X-PROGRAM-DATE-TIME:(.+)/.source,
              /|#.*/.source
            ].join(''),
            'g'
          ),
          D = /(?:(?:#(EXTM3U))|(?:#EXT-X-(PLAYLIST-TYPE):(.+))|(?:#EXT-X-(MEDIA-SEQUENCE): *(\d+))|(?:#EXT-X-(TARGETDURATION): *(\d+))|(?:#EXT-X-(KEY):(.+))|(?:#EXT-X-(START):(.+))|(?:#EXT-X-(ENDLIST))|(?:#EXT-X-(DISCONTINUITY-SEQ)UENCE:(\d+))|(?:#EXT-X-(DIS)CONTINUITY))|(?:#EXT-X-(VERSION):(\d+))|(?:#EXT-X-(MAP):(.+))|(?:(#)([^:]*):(.*))|(?:(#)(.*))(?:.*)\r?\n?/,
          O = /\.(mp4|m4s|m4v|m4a)$/i,
          C = (function() {
            function e() {}
            return (
              (e.findGroup = function(e, t) {
                for (var r = 0; r < e.length; r++) {
                  var i = e[r];
                  if (i.id === t) return i;
                }
              }),
              (e.convertAVC1ToAVCOTI = function(e) {
                var t,
                  r = e.split('.');
                return (
                  r.length > 2
                    ? ((t = r.shift() + '.'),
                      (t += parseInt(r.shift()).toString(16)),
                      (t += ('000' + parseInt(r.shift()).toString(16)).substr(
                        -4
                      )))
                    : (t = e),
                  t
                );
              }),
              (e.resolve = function(e, t) {
                return s.buildAbsoluteURL(t, e, { alwaysNormalize: !0 });
              }),
              (e.parseMasterPlaylist = function(t, r) {
                var i,
                  a = [],
                  n = {},
                  s = !1;
                function o(e, t) {
                  ['video', 'audio'].forEach(function(r) {
                    var i = e.filter(function(e) {
                      return (function(e, t) {
                        var r = R[t];
                        return !!r && !0 === r[e.slice(0, 4)];
                      })(e, r);
                    });
                    if (i.length) {
                      var a = i.filter(function(e) {
                        return (
                          0 === e.lastIndexOf('avc1', 0) ||
                          0 === e.lastIndexOf('mp4a', 0)
                        );
                      });
                      (t[r + 'Codec'] = a.length > 0 ? a[0] : i[0]),
                        (e = e.filter(function(e) {
                          return -1 === i.indexOf(e);
                        }));
                    }
                  }),
                    (t.unknownCodecs = e);
                }
                for (k.lastIndex = 0; null != (i = k.exec(t)); )
                  if (i[1]) {
                    var l = {},
                      u = (l.attrs = new _(i[1]));
                    l.url = e.resolve(i[2], r);
                    var d = u.decimalResolution('RESOLUTION');
                    d && ((l.width = d.width), (l.height = d.height)),
                      (l.bitrate =
                        u.decimalInteger('AVERAGE-BANDWIDTH') ||
                        u.decimalInteger('BANDWIDTH')),
                      (l.name = u.NAME),
                      o([].concat((u.CODECS || '').split(/[ ,]+/)), l),
                      l.videoCodec &&
                        -1 !== l.videoCodec.indexOf('avc1') &&
                        (l.videoCodec = e.convertAVC1ToAVCOTI(l.videoCodec)),
                      a.push(l);
                  } else if (i[3]) {
                    var c = new _(i[3]);
                    c['DATA-ID'] && ((s = !0), (n[c['DATA-ID']] = c));
                  }
                return { levels: a, sessionData: s ? n : null };
              }),
              (e.parseMasterPlaylistMedia = function(t, r, i, a) {
                var n;
                void 0 === a && (a = []);
                var s = [],
                  o = 0;
                for (w.lastIndex = 0; null !== (n = w.exec(t)); ) {
                  var l = new _(n[1]);
                  if (l.TYPE === i) {
                    var u = {
                      attrs: l,
                      id: o++,
                      groupId: l['GROUP-ID'],
                      instreamId: l['INSTREAM-ID'],
                      name: l.NAME || l.LANGUAGE,
                      type: i,
                      default: 'YES' === l.DEFAULT,
                      autoselect: 'YES' === l.AUTOSELECT,
                      forced: 'YES' === l.FORCED,
                      lang: l.LANGUAGE
                    };
                    if ((l.URI && (u.url = e.resolve(l.URI, r)), a.length)) {
                      var d = e.findGroup(a, u.groupId);
                      u.audioCodec = d ? d.codec : a[0].codec;
                    }
                    s.push(u);
                  }
                }
                return s;
              }),
              (e.parseLevelPlaylist = function(e, t, r, i, a) {
                var n,
                  s,
                  o,
                  u = 0,
                  c = 0,
                  h = new T(t),
                  f = 0,
                  g = null,
                  p = new y(),
                  m = null;
                for (L.lastIndex = 0; null !== (n = L.exec(e)); ) {
                  var b = n[1];
                  if (b) {
                    p.duration = parseFloat(b);
                    var E = (' ' + n[2]).slice(1);
                    (p.title = E || null),
                      p.tagList.push(E ? ['INF', b, E] : ['INF', b]);
                  } else if (n[3]) {
                    if (Object(l.a)(p.duration)) {
                      var S = u++;
                      (p.type = i),
                        (p.start = c),
                        o && (p.levelkey = o),
                        (p.sn = S),
                        (p.level = r),
                        (p.cc = f),
                        (p.urlId = a),
                        (p.baseurl = t),
                        (p.relurl = (' ' + n[3]).slice(1)),
                        I(p, g),
                        h.fragments.push(p),
                        (g = p),
                        (c += p.duration),
                        (p = new y());
                    }
                  } else if (n[4]) {
                    var R = (' ' + n[4]).slice(1);
                    g ? p.setByteRange(R, g) : p.setByteRange(R);
                  } else if (n[5])
                    (p.rawProgramDateTime = (' ' + n[5]).slice(1)),
                      p.tagList.push([
                        'PROGRAM-DATE-TIME',
                        p.rawProgramDateTime
                      ]),
                      null === m && (m = h.fragments.length);
                  else {
                    if (!(n = n[0].match(D))) {
                      d.b.warn(
                        'No matches on slow regex match for level playlist!'
                      );
                      continue;
                    }
                    for (s = 1; s < n.length && void 0 === n[s]; s++);
                    var A = (' ' + n[s + 1]).slice(1),
                      k = (' ' + n[s + 2]).slice(1);
                    switch (n[s]) {
                      case '#':
                        p.tagList.push(k ? [A, k] : [A]);
                        break;
                      case 'PLAYLIST-TYPE':
                        h.type = A.toUpperCase();
                        break;
                      case 'MEDIA-SEQUENCE':
                        u = h.startSN = parseInt(A);
                        break;
                      case 'TARGETDURATION':
                        h.targetduration = parseFloat(A);
                        break;
                      case 'VERSION':
                        h.version = parseInt(A);
                        break;
                      case 'EXTM3U':
                        break;
                      case 'ENDLIST':
                        h.live = !1;
                        break;
                      case 'DIS':
                        f++, p.tagList.push(['DIS']);
                        break;
                      case 'DISCONTINUITY-SEQ':
                        f = parseInt(A);
                        break;
                      case 'KEY':
                        var w = new _(A),
                          C = w.enumeratedString('METHOD'),
                          P = w.URI,
                          x = w.hexadecimalInteger('IV');
                        if (
                          'com.apple.streamingkeydelivery' ===
                          (w.KEYFORMAT || 'identity')
                        ) {
                          d.b.warn(
                            'Keyformat com.apple.streamingkeydelivery is not supported'
                          );
                          continue;
                        }
                        C &&
                          ((o = new v(t, P)),
                          P &&
                            [
                              'AES-128',
                              'SAMPLE-AES',
                              'SAMPLE-AES-CENC'
                            ].indexOf(C) >= 0 &&
                            ((o.method = C), (o.key = null), (o.iv = x)));
                        break;
                      case 'START':
                        var M = new _(A).decimalFloatingPoint('TIME-OFFSET');
                        Object(l.a)(M) && (h.startTimeOffset = M);
                        break;
                      case 'MAP':
                        var F = new _(A);
                        (p.relurl = F.URI),
                          F.BYTERANGE && p.setByteRange(F.BYTERANGE),
                          (p.baseurl = t),
                          (p.level = r),
                          (p.type = i),
                          (p.sn = 'initSegment'),
                          (h.initSegment = p),
                          ((p = new y()).rawProgramDateTime =
                            h.initSegment.rawProgramDateTime);
                        break;
                      default:
                        d.b.warn('line parsed but not handled: ' + n);
                    }
                  }
                }
                return (
                  (p = g) &&
                    !p.relurl &&
                    (h.fragments.pop(), (c -= p.duration)),
                  (h.totalduration = c),
                  (h.averagetargetduration = c / h.fragments.length),
                  (h.endSN = u - 1),
                  (h.startCC = h.fragments[0] ? h.fragments[0].cc : 0),
                  (h.endCC = f),
                  !h.initSegment &&
                    h.fragments.length &&
                    h.fragments.every(function(e) {
                      return O.test(e.relurl);
                    }) &&
                    (d.b.warn(
                      'MP4 fragments found but no init segment (probably no MAP, incomplete M3U8), trying to fetch SIDX'
                    ),
                    ((p = new y()).relurl = h.fragments[0].relurl),
                    (p.baseurl = t),
                    (p.level = r),
                    (p.type = i),
                    (p.sn = 'initSegment'),
                    (h.initSegment = p),
                    (h.needSidxRanges = !0)),
                  m &&
                    (function(e, t) {
                      for (var r = e[t], i = t - 1; i >= 0; i--) {
                        var a = e[i];
                        (a.programDateTime =
                          r.programDateTime - 1e3 * a.duration),
                          (r = a);
                      }
                    })(h.fragments, m),
                  h
                );
              }),
              e
            );
          })();
        function I(e, t) {
          e.rawProgramDateTime
            ? (e.programDateTime = Date.parse(e.rawProgramDateTime))
            : (null == t ? void 0 : t.programDateTime) &&
              (e.programDateTime = t.endProgramDateTime),
            Object(l.a)(e.programDateTime) ||
              ((e.programDateTime = null), (e.rawProgramDateTime = null));
        }
        var P = window.performance,
          x = (function(e) {
            var t, r;
            function i(t) {
              var r;
              return (
                ((r =
                  e.call(
                    this,
                    t,
                    u.a.MANIFEST_LOADING,
                    u.a.LEVEL_LOADING,
                    u.a.AUDIO_TRACK_LOADING,
                    u.a.SUBTITLE_TRACK_LOADING
                  ) || this).loaders = {}),
                r
              );
            }
            (r = e),
              ((t = i).prototype = Object.create(r.prototype)),
              (t.prototype.constructor = t),
              (t.__proto__ = r),
              (i.canHaveQualityLevels = function(e) {
                return e !== a.AUDIO_TRACK && e !== a.SUBTITLE_TRACK;
              }),
              (i.mapContextToLevelType = function(e) {
                switch (e.type) {
                  case a.AUDIO_TRACK:
                    return n.AUDIO;
                  case a.SUBTITLE_TRACK:
                    return n.SUBTITLE;
                  default:
                    return n.MAIN;
                }
              }),
              (i.getResponseUrl = function(e, t) {
                var r = e.url;
                return (
                  (void 0 !== r && 0 !== r.indexOf('data:')) || (r = t.url), r
                );
              });
            var s = i.prototype;
            return (
              (s.createInternalLoader = function(e) {
                var t = this.hls.config,
                  r = t.pLoader,
                  i = t.loader,
                  a = new (r || i)(t);
                return (e.loader = a), (this.loaders[e.type] = a), a;
              }),
              (s.getInternalLoader = function(e) {
                return this.loaders[e.type];
              }),
              (s.resetInternalLoader = function(e) {
                this.loaders[e] && delete this.loaders[e];
              }),
              (s.destroyInternalLoaders = function() {
                for (var e in this.loaders) {
                  var t = this.loaders[e];
                  t && t.destroy(), this.resetInternalLoader(e);
                }
              }),
              (s.destroy = function() {
                this.destroyInternalLoaders(), e.prototype.destroy.call(this);
              }),
              (s.onManifestLoading = function(e) {
                this.load({
                  url: e.url,
                  type: a.MANIFEST,
                  level: 0,
                  id: null,
                  responseType: 'text'
                });
              }),
              (s.onLevelLoading = function(e) {
                this.load({
                  url: e.url,
                  type: a.LEVEL,
                  level: e.level,
                  id: e.id,
                  responseType: 'text'
                });
              }),
              (s.onAudioTrackLoading = function(e) {
                this.load({
                  url: e.url,
                  type: a.AUDIO_TRACK,
                  level: null,
                  id: e.id,
                  responseType: 'text'
                });
              }),
              (s.onSubtitleTrackLoading = function(e) {
                this.load({
                  url: e.url,
                  type: a.SUBTITLE_TRACK,
                  level: null,
                  id: e.id,
                  responseType: 'text'
                });
              }),
              (s.load = function(e) {
                var t = this.hls.config;
                d.b.debug(
                  'Loading playlist of type ' +
                    e.type +
                    ', level: ' +
                    e.level +
                    ', id: ' +
                    e.id
                );
                var r,
                  i,
                  n,
                  s,
                  o = this.getInternalLoader(e);
                if (o) {
                  var l = o.context;
                  if (l && l.url === e.url)
                    return d.b.trace('playlist request ongoing'), !1;
                  d.b.warn('aborting previous loader for type: ' + e.type),
                    o.abort();
                }
                switch (e.type) {
                  case a.MANIFEST:
                    (r = t.manifestLoadingMaxRetry),
                      (i = t.manifestLoadingTimeOut),
                      (n = t.manifestLoadingRetryDelay),
                      (s = t.manifestLoadingMaxRetryTimeout);
                    break;
                  case a.LEVEL:
                    (r = 0), (s = 0), (n = 0), (i = t.levelLoadingTimeOut);
                    break;
                  default:
                    (r = t.levelLoadingMaxRetry),
                      (i = t.levelLoadingTimeOut),
                      (n = t.levelLoadingRetryDelay),
                      (s = t.levelLoadingMaxRetryTimeout);
                }
                o = this.createInternalLoader(e);
                var u = {
                    timeout: i,
                    maxRetry: r,
                    retryDelay: n,
                    maxRetryDelay: s
                  },
                  c = {
                    onSuccess: this.loadsuccess.bind(this),
                    onError: this.loaderror.bind(this),
                    onTimeout: this.loadtimeout.bind(this)
                  };
                return (
                  d.b.debug(
                    'Calling internal loader delegate for URL: ' + e.url
                  ),
                  o.load(e, u, c),
                  !0
                );
              }),
              (s.loadsuccess = function(e, t, r, i) {
                if ((void 0 === i && (i = null), r.isSidxRequest))
                  return (
                    this._handleSidxRequest(e, r),
                    void this._handlePlaylistLoaded(e, t, r, i)
                  );
                if (
                  (this.resetInternalLoader(r.type), 'string' != typeof e.data)
                )
                  throw new Error(
                    'expected responseType of "text" for PlaylistLoader'
                  );
                var a = e.data;
                (t.tload = P.now()),
                  0 === a.indexOf('#EXTM3U')
                    ? a.indexOf('#EXTINF:') > 0 ||
                      a.indexOf('#EXT-X-TARGETDURATION:') > 0
                      ? this._handleTrackOrLevelPlaylist(e, t, r, i)
                      : this._handleMasterPlaylist(e, t, r, i)
                    : this._handleManifestParsingError(
                        e,
                        r,
                        'no EXTM3U delimiter',
                        i
                      );
              }),
              (s.loaderror = function(e, t, r) {
                void 0 === r && (r = null),
                  this._handleNetworkError(t, r, !1, e);
              }),
              (s.loadtimeout = function(e, t, r) {
                void 0 === r && (r = null), this._handleNetworkError(t, r, !0);
              }),
              (s._handleMasterPlaylist = function(e, t, r, a) {
                var n = this.hls,
                  s = e.data,
                  o = i.getResponseUrl(e, r),
                  l = C.parseMasterPlaylist(s, o),
                  c = l.levels,
                  h = l.sessionData;
                if (c.length) {
                  var f = c.map(function(e) {
                      return { id: e.attrs.AUDIO, codec: e.audioCodec };
                    }),
                    g = C.parseMasterPlaylistMedia(s, o, 'AUDIO', f),
                    p = C.parseMasterPlaylistMedia(s, o, 'SUBTITLES'),
                    v = C.parseMasterPlaylistMedia(s, o, 'CLOSED-CAPTIONS');
                  if (g.length) {
                    var m = !1;
                    g.forEach(function(e) {
                      e.url || (m = !0);
                    }),
                      !1 === m &&
                        c[0].audioCodec &&
                        !c[0].attrs.AUDIO &&
                        (d.b.log(
                          'audio codec signaled in quality level, but no embedded audio track signaled, create one'
                        ),
                        g.unshift({
                          type: 'main',
                          name: 'main',
                          default: !1,
                          autoselect: !1,
                          forced: !1,
                          id: -1,
                          attrs: {},
                          url: ''
                        }));
                  }
                  n.trigger(u.a.MANIFEST_LOADED, {
                    levels: c,
                    audioTracks: g,
                    subtitles: p,
                    captions: v,
                    url: o,
                    stats: t,
                    networkDetails: a,
                    sessionData: h
                  });
                } else
                  this._handleManifestParsingError(
                    e,
                    r,
                    'no level found in manifest',
                    a
                  );
              }),
              (s._handleTrackOrLevelPlaylist = function(e, t, r, n) {
                var s = this.hls,
                  d = r.id,
                  c = r.level,
                  h = r.type,
                  f = i.getResponseUrl(e, r),
                  g = Object(l.a)(d) ? d : 0,
                  p = Object(l.a)(c) ? c : g,
                  v = i.mapContextToLevelType(r),
                  m = C.parseLevelPlaylist(e.data, f, p, v, g);
                if (((m.tload = t.tload), m.fragments.length)) {
                  if (h === a.MANIFEST) {
                    var y = { url: f, details: m };
                    s.trigger(u.a.MANIFEST_LOADED, {
                      levels: [y],
                      audioTracks: [],
                      url: f,
                      stats: t,
                      networkDetails: n,
                      sessionData: null
                    });
                  }
                  if (((t.tparsed = P.now()), m.needSidxRanges)) {
                    var b = m.initSegment.url;
                    this.load({
                      url: b,
                      isSidxRequest: !0,
                      type: h,
                      level: c,
                      levelDetails: m,
                      id: d,
                      rangeStart: 0,
                      rangeEnd: 2048,
                      responseType: 'arraybuffer'
                    });
                  } else
                    (r.levelDetails = m),
                      this._handlePlaylistLoaded(e, t, r, n);
                } else
                  s.trigger(u.a.ERROR, {
                    type: o.b.NETWORK_ERROR,
                    details: o.a.LEVEL_EMPTY_ERROR,
                    fatal: !1,
                    url: f,
                    reason: 'no fragments found in level',
                    level: 'number' == typeof r.level ? r.level : void 0
                  });
              }),
              (s._handleSidxRequest = function(e, t) {
                if ('string' == typeof e.data)
                  throw new Error(
                    'sidx request must be made with responseType of array buffer'
                  );
                var r = f.a.parseSegmentIndex(new Uint8Array(e.data));
                if (r) {
                  var i = r.references,
                    a = t.levelDetails;
                  i.forEach(function(e, t) {
                    var r = e.info;
                    if (a) {
                      var i = a.fragments[t];
                      0 === i.byteRange.length &&
                        i.setByteRange(
                          String(1 + r.end - r.start) + '@' + String(r.start)
                        );
                    }
                  }),
                    a &&
                      a.initSegment.setByteRange(
                        String(r.moovEndOffset) + '@0'
                      );
                }
              }),
              (s._handleManifestParsingError = function(e, t, r, i) {
                this.hls.trigger(u.a.ERROR, {
                  type: o.b.NETWORK_ERROR,
                  details: o.a.MANIFEST_PARSING_ERROR,
                  fatal: !0,
                  url: e.url,
                  reason: r,
                  networkDetails: i
                });
              }),
              (s._handleNetworkError = function(e, t, r, i) {
                var n, s;
                void 0 === r && (r = !1),
                  void 0 === i && (i = null),
                  d.b.info(
                    'A network error occured while loading a ' +
                      e.type +
                      '-type playlist'
                  );
                var l = this.getInternalLoader(e);
                switch (e.type) {
                  case a.MANIFEST:
                    (n = r
                      ? o.a.MANIFEST_LOAD_TIMEOUT
                      : o.a.MANIFEST_LOAD_ERROR),
                      (s = !0);
                    break;
                  case a.LEVEL:
                    (n = r ? o.a.LEVEL_LOAD_TIMEOUT : o.a.LEVEL_LOAD_ERROR),
                      (s = !1);
                    break;
                  case a.AUDIO_TRACK:
                    (n = r
                      ? o.a.AUDIO_TRACK_LOAD_TIMEOUT
                      : o.a.AUDIO_TRACK_LOAD_ERROR),
                      (s = !1);
                    break;
                  default:
                    s = !1;
                }
                l && (l.abort(), this.resetInternalLoader(e.type));
                var c = {
                  type: o.b.NETWORK_ERROR,
                  details: n,
                  fatal: s,
                  url: e.url,
                  loader: l,
                  context: e,
                  networkDetails: t
                };
                i && (c.response = i), this.hls.trigger(u.a.ERROR, c);
              }),
              (s._handlePlaylistLoaded = function(e, t, r, n) {
                var s = r.type,
                  o = r.level,
                  l = r.id,
                  d = r.levelDetails;
                if (d && d.targetduration)
                  if (i.canHaveQualityLevels(r.type))
                    this.hls.trigger(u.a.LEVEL_LOADED, {
                      details: d,
                      level: o || 0,
                      id: l || 0,
                      stats: t,
                      networkDetails: n
                    });
                  else
                    switch (s) {
                      case a.AUDIO_TRACK:
                        this.hls.trigger(u.a.AUDIO_TRACK_LOADED, {
                          details: d,
                          id: l,
                          stats: t,
                          networkDetails: n
                        });
                        break;
                      case a.SUBTITLE_TRACK:
                        this.hls.trigger(u.a.SUBTITLE_TRACK_LOADED, {
                          details: d,
                          id: l,
                          stats: t,
                          networkDetails: n
                        });
                    }
                else
                  this._handleManifestParsingError(
                    e,
                    r,
                    'invalid target duration',
                    n
                  );
              }),
              i
            );
          })(h);
        var M = (function(e) {
          var t, r;
          function i(t) {
            var r;
            return (
              ((r = e.call(this, t, u.a.FRAG_LOADING) || this).loaders = {}), r
            );
          }
          (r = e),
            ((t = i).prototype = Object.create(r.prototype)),
            (t.prototype.constructor = t),
            (t.__proto__ = r);
          var a = i.prototype;
          return (
            (a.destroy = function() {
              var t = this.loaders;
              for (var r in t) {
                var i = t[r];
                i && i.destroy();
              }
              (this.loaders = {}), e.prototype.destroy.call(this);
            }),
            (a.onFragLoading = function(e) {
              var t = e.frag,
                r = t.type,
                i = this.loaders,
                a = this.hls.config,
                n = a.fLoader,
                s = a.loader;
              t.loaded = 0;
              var o,
                u,
                c,
                h = i[r];
              h &&
                (d.b.warn('abort previous fragment loader for type: ' + r),
                h.abort()),
                (h = i[r] = t.loader = a.fLoader ? new n(a) : new s(a)),
                (o = {
                  url: t.url,
                  frag: t,
                  responseType: 'arraybuffer',
                  progressData: !1
                });
              var f = t.byteRangeStartOffset,
                g = t.byteRangeEndOffset;
              Object(l.a)(f) &&
                Object(l.a)(g) &&
                ((o.rangeStart = f), (o.rangeEnd = g)),
                (u = {
                  timeout: a.fragLoadingTimeOut,
                  maxRetry: 0,
                  retryDelay: 0,
                  maxRetryDelay: a.fragLoadingMaxRetryTimeout
                }),
                (c = {
                  onSuccess: this.loadsuccess.bind(this),
                  onError: this.loaderror.bind(this),
                  onTimeout: this.loadtimeout.bind(this),
                  onProgress: this.loadprogress.bind(this)
                }),
                h.load(o, u, c);
            }),
            (a.loadsuccess = function(e, t, r, i) {
              void 0 === i && (i = null);
              var a = e.data,
                n = r.frag;
              (n.loader = void 0),
                (this.loaders[n.type] = void 0),
                this.hls.trigger(u.a.FRAG_LOADED, {
                  payload: a,
                  frag: n,
                  stats: t,
                  networkDetails: i
                });
            }),
            (a.loaderror = function(e, t, r) {
              void 0 === r && (r = null);
              var i = t.frag,
                a = i.loader;
              a && a.abort(),
                (this.loaders[i.type] = void 0),
                this.hls.trigger(u.a.ERROR, {
                  type: o.b.NETWORK_ERROR,
                  details: o.a.FRAG_LOAD_ERROR,
                  fatal: !1,
                  frag: t.frag,
                  response: e,
                  networkDetails: r
                });
            }),
            (a.loadtimeout = function(e, t, r) {
              void 0 === r && (r = null);
              var i = t.frag,
                a = i.loader;
              a && a.abort(),
                (this.loaders[i.type] = void 0),
                this.hls.trigger(u.a.ERROR, {
                  type: o.b.NETWORK_ERROR,
                  details: o.a.FRAG_LOAD_TIMEOUT,
                  fatal: !1,
                  frag: t.frag,
                  networkDetails: r
                });
            }),
            (a.loadprogress = function(e, t, r, i) {
              void 0 === i && (i = null);
              var a = t.frag;
              (a.loaded = e.loaded),
                this.hls.trigger(u.a.FRAG_LOAD_PROGRESS, {
                  frag: a,
                  stats: e,
                  networkDetails: i
                });
            }),
            i
          );
        })(h);
        var F = (function(e) {
          var t, r;
          function i(t) {
            var r;
            return (
              ((r = e.call(this, t, u.a.KEY_LOADING) || this).loaders = {}),
              (r.decryptkey = null),
              (r.decrypturl = null),
              r
            );
          }
          (r = e),
            ((t = i).prototype = Object.create(r.prototype)),
            (t.prototype.constructor = t),
            (t.__proto__ = r);
          var a = i.prototype;
          return (
            (a.destroy = function() {
              for (var t in this.loaders) {
                var r = this.loaders[t];
                r && r.destroy();
              }
              (this.loaders = {}), e.prototype.destroy.call(this);
            }),
            (a.onKeyLoading = function(e) {
              var t = e.frag,
                r = t.type,
                i = this.loaders[r];
              if (t.decryptdata) {
                var a = t.decryptdata.uri;
                if (a !== this.decrypturl || null === this.decryptkey) {
                  var n = this.hls.config;
                  if (
                    (i &&
                      (d.b.warn('abort previous key loader for type:' + r),
                      i.abort()),
                    !a)
                  )
                    return void d.b.warn('key uri is falsy');
                  (t.loader = this.loaders[r] = new n.loader(n)),
                    (this.decrypturl = a),
                    (this.decryptkey = null);
                  var s = { url: a, frag: t, responseType: 'arraybuffer' },
                    o = {
                      timeout: n.fragLoadingTimeOut,
                      maxRetry: 0,
                      retryDelay: n.fragLoadingRetryDelay,
                      maxRetryDelay: n.fragLoadingMaxRetryTimeout
                    },
                    l = {
                      onSuccess: this.loadsuccess.bind(this),
                      onError: this.loaderror.bind(this),
                      onTimeout: this.loadtimeout.bind(this)
                    };
                  t.loader.load(s, o, l);
                } else
                  this.decryptkey &&
                    ((t.decryptdata.key = this.decryptkey),
                    this.hls.trigger(u.a.KEY_LOADED, { frag: t }));
              } else
                d.b.warn('Missing decryption data on fragment in onKeyLoading');
            }),
            (a.loadsuccess = function(e, t, r) {
              var i = r.frag;
              i.decryptdata
                ? ((this.decryptkey = i.decryptdata.key = new Uint8Array(
                    e.data
                  )),
                  (i.loader = void 0),
                  delete this.loaders[i.type],
                  this.hls.trigger(u.a.KEY_LOADED, { frag: i }))
                : d.b.error('after key load, decryptdata unset');
            }),
            (a.loaderror = function(e, t) {
              var r = t.frag,
                i = r.loader;
              i && i.abort(),
                delete this.loaders[r.type],
                this.hls.trigger(u.a.ERROR, {
                  type: o.b.NETWORK_ERROR,
                  details: o.a.KEY_LOAD_ERROR,
                  fatal: !1,
                  frag: r,
                  response: e
                });
            }),
            (a.loadtimeout = function(e, t) {
              var r = t.frag,
                i = r.loader;
              i && i.abort(),
                delete this.loaders[r.type],
                this.hls.trigger(u.a.ERROR, {
                  type: o.b.NETWORK_ERROR,
                  details: o.a.KEY_LOAD_TIMEOUT,
                  fatal: !1,
                  frag: r
                });
            }),
            i
          );
        })(h);
        var U = 'NOT_LOADED',
          N = 'APPENDING',
          B = 'PARTIAL',
          G = 'OK',
          K = (function(e) {
            var t, r;
            function i(t) {
              var r;
              return (
                ((r =
                  e.call(
                    this,
                    t,
                    u.a.BUFFER_APPENDED,
                    u.a.FRAG_BUFFERED,
                    u.a.FRAG_LOADED
                  ) || this).bufferPadding = 0.2),
                (r.fragments = Object.create(null)),
                (r.timeRanges = Object.create(null)),
                (r.config = t.config),
                r
              );
            }
            (r = e),
              ((t = i).prototype = Object.create(r.prototype)),
              (t.prototype.constructor = t),
              (t.__proto__ = r);
            var a = i.prototype;
            return (
              (a.destroy = function() {
                (this.fragments = Object.create(null)),
                  (this.timeRanges = Object.create(null)),
                  (this.config = null),
                  h.prototype.destroy.call(this),
                  e.prototype.destroy.call(this);
              }),
              (a.getBufferedFrag = function(e, t) {
                var r = this.fragments,
                  i = Object.keys(r).filter(function(i) {
                    var a = r[i];
                    if (a.body.type !== t) return !1;
                    if (!a.buffered) return !1;
                    var n = a.body;
                    return n.startPTS <= e && e <= n.endPTS;
                  });
                if (0 === i.length) return null;
                var a = i.pop();
                return r[a].body;
              }),
              (a.detectEvictedFragments = function(e, t) {
                var r = this;
                Object.keys(this.fragments).forEach(function(i) {
                  var a = r.fragments[i];
                  if (a && a.buffered) {
                    var n = a.range[e];
                    if (n)
                      for (var s = n.time, o = 0; o < s.length; o++) {
                        var l = s[o];
                        if (!r.isTimeBuffered(l.startPTS, l.endPTS, t)) {
                          r.removeFragment(a.body);
                          break;
                        }
                      }
                  }
                });
              }),
              (a.detectPartialFragments = function(e) {
                var t = this,
                  r = this.getFragmentKey(e),
                  i = this.fragments[r];
                i &&
                  ((i.buffered = !0),
                  Object.keys(this.timeRanges).forEach(function(r) {
                    if (e.hasElementaryStream(r)) {
                      var a = t.timeRanges[r];
                      i.range[r] = t.getBufferedTimes(e.startPTS, e.endPTS, a);
                    }
                  }));
              }),
              (a.getBufferedTimes = function(e, t, r) {
                for (var i, a, n = [], s = !1, o = 0; o < r.length; o++) {
                  if (
                    ((i = r.start(o) - this.bufferPadding),
                    (a = r.end(o) + this.bufferPadding),
                    e >= i && t <= a)
                  ) {
                    n.push({
                      startPTS: Math.max(e, r.start(o)),
                      endPTS: Math.min(t, r.end(o))
                    });
                    break;
                  }
                  if (e < a && t > i)
                    n.push({
                      startPTS: Math.max(e, r.start(o)),
                      endPTS: Math.min(t, r.end(o))
                    }),
                      (s = !0);
                  else if (t <= i) break;
                }
                return { time: n, partial: s };
              }),
              (a.getFragmentKey = function(e) {
                return e.type + '_' + e.level + '_' + e.urlId + '_' + e.sn;
              }),
              (a.getPartialFragment = function(e) {
                var t,
                  r,
                  i,
                  a = this,
                  n = null,
                  s = 0;
                return (
                  Object.keys(this.fragments).forEach(function(o) {
                    var l = a.fragments[o];
                    a.isPartial(l) &&
                      ((r = l.body.startPTS - a.bufferPadding),
                      (i = l.body.endPTS + a.bufferPadding),
                      e >= r &&
                        e <= i &&
                        ((t = Math.min(e - r, i - e)),
                        s <= t && ((n = l.body), (s = t))));
                  }),
                  n
                );
              }),
              (a.getState = function(e) {
                var t = this.getFragmentKey(e),
                  r = this.fragments[t],
                  i = U;
                return (
                  void 0 !== r &&
                    (i = r.buffered ? (!0 === this.isPartial(r) ? B : G) : N),
                  i
                );
              }),
              (a.isPartial = function(e) {
                return (
                  !0 === e.buffered &&
                  ((void 0 !== e.range.video && !0 === e.range.video.partial) ||
                    (void 0 !== e.range.audio && !0 === e.range.audio.partial))
                );
              }),
              (a.isTimeBuffered = function(e, t, r) {
                for (var i, a, n = 0; n < r.length; n++) {
                  if (
                    ((i = r.start(n) - this.bufferPadding),
                    (a = r.end(n) + this.bufferPadding),
                    e >= i && t <= a)
                  )
                    return !0;
                  if (t <= i) return !1;
                }
                return !1;
              }),
              (a.onFragLoaded = function(e) {
                var t = e.frag;
                Object(l.a)(t.sn) &&
                  !t.bitrateTest &&
                  (this.fragments[this.getFragmentKey(t)] = {
                    body: t,
                    range: Object.create(null),
                    buffered: !1
                  });
              }),
              (a.onBufferAppended = function(e) {
                var t = this;
                (this.timeRanges = e.timeRanges),
                  Object.keys(this.timeRanges).forEach(function(e) {
                    var r = t.timeRanges[e];
                    t.detectEvictedFragments(e, r);
                  });
              }),
              (a.onFragBuffered = function(e) {
                this.detectPartialFragments(e.frag);
              }),
              (a.hasFragment = function(e) {
                var t = this.getFragmentKey(e);
                return void 0 !== this.fragments[t];
              }),
              (a.removeFragment = function(e) {
                var t = this.getFragmentKey(e);
                delete this.fragments[t];
              }),
              (a.removeAllFragments = function() {
                this.fragments = Object.create(null);
              }),
              i
            );
          })(h),
          j = {
            search: function(e, t) {
              for (var r = 0, i = e.length - 1, a = null, n = null; r <= i; ) {
                var s = t((n = e[(a = ((r + i) / 2) | 0)]));
                if (s > 0) r = a + 1;
                else {
                  if (!(s < 0)) return n;
                  i = a - 1;
                }
              }
              return null;
            }
          },
          H = (function() {
            function e() {}
            return (
              (e.isBuffered = function(e, t) {
                try {
                  if (e)
                    for (var r = e.buffered, i = 0; i < r.length; i++)
                      if (t >= r.start(i) && t <= r.end(i)) return !0;
                } catch (e) {}
                return !1;
              }),
              (e.bufferInfo = function(e, t, r) {
                try {
                  if (e) {
                    var i,
                      a = e.buffered,
                      n = [];
                    for (i = 0; i < a.length; i++)
                      n.push({ start: a.start(i), end: a.end(i) });
                    return this.bufferedInfo(n, t, r);
                  }
                } catch (e) {}
                return { len: 0, start: t, end: t, nextStart: void 0 };
              }),
              (e.bufferedInfo = function(e, t, r) {
                e.sort(function(e, t) {
                  var r = e.start - t.start;
                  return r || t.end - e.end;
                });
                var i = [];
                if (r)
                  for (var a = 0; a < e.length; a++) {
                    var n = i.length;
                    if (n) {
                      var s = i[n - 1].end;
                      e[a].start - s < r
                        ? e[a].end > s && (i[n - 1].end = e[a].end)
                        : i.push(e[a]);
                    } else i.push(e[a]);
                  }
                else i = e;
                for (var o, l = 0, u = t, d = t, c = 0; c < i.length; c++) {
                  var h = i[c].start,
                    f = i[c].end;
                  if (t + r >= h && t < f) (u = h), (l = (d = f) - t);
                  else if (t + r < h) {
                    o = h;
                    break;
                  }
                }
                return { len: l, start: u, end: d, nextStart: o };
              }),
              e
            );
          })(),
          V = r(8),
          Y = r(11),
          W = r(9);
        function q() {
          return window.MediaSource || window.WebKitMediaSource;
        }
        var X = r(5);
        var z = (function(e) {
            var t, r;
            function i() {
              return e.apply(this, arguments) || this;
            }
            return (
              (r = e),
              ((t = i).prototype = Object.create(r.prototype)),
              (t.prototype.constructor = t),
              (t.__proto__ = r),
              (i.prototype.trigger = function(e) {
                for (
                  var t = arguments.length,
                    r = new Array(t > 1 ? t - 1 : 0),
                    i = 1;
                  i < t;
                  i++
                )
                  r[i - 1] = arguments[i];
                this.emit.apply(this, [e, e].concat(r));
              }),
              i
            );
          })(V.EventEmitter),
          Q = Object(X.a)(),
          $ = q() || {
            isTypeSupported: function() {
              return !1;
            }
          },
          J = (function() {
            function e(e, t) {
              var r = this;
              (this.hls = e), (this.id = t);
              var i = (this.observer = new z()),
                a = e.config,
                n = function(t, i) {
                  ((i = i || {}).frag = r.frag), (i.id = r.id), e.trigger(t, i);
                };
              i.on(u.a.FRAG_DECRYPTED, n),
                i.on(u.a.FRAG_PARSING_INIT_SEGMENT, n),
                i.on(u.a.FRAG_PARSING_DATA, n),
                i.on(u.a.FRAG_PARSED, n),
                i.on(u.a.ERROR, n),
                i.on(u.a.FRAG_PARSING_METADATA, n),
                i.on(u.a.FRAG_PARSING_USERDATA, n),
                i.on(u.a.INIT_PTS_FOUND, n);
              var s = {
                  mp4: $.isTypeSupported('video/mp4'),
                  mpeg: $.isTypeSupported('audio/mpeg'),
                  mp3: $.isTypeSupported('audio/mp4; codecs="mp3"')
                },
                l = navigator.vendor;
              if (a.enableWorker && 'undefined' != typeof Worker) {
                var c;
                d.b.log('demuxing in webworker');
                try {
                  (c = this.w = Y(12)),
                    (this.onwmsg = this.onWorkerMessage.bind(this)),
                    c.addEventListener('message', this.onwmsg),
                    (c.onerror = function(t) {
                      e.trigger(u.a.ERROR, {
                        type: o.b.OTHER_ERROR,
                        details: o.a.INTERNAL_EXCEPTION,
                        fatal: !0,
                        event: 'demuxerWorker',
                        err: {
                          message:
                            t.message + ' (' + t.filename + ':' + t.lineno + ')'
                        }
                      });
                    }),
                    c.postMessage({
                      cmd: 'init',
                      typeSupported: s,
                      vendor: l,
                      id: t,
                      config: JSON.stringify(a)
                    });
                } catch (e) {
                  d.b.warn('Error in worker:', e),
                    d.b.error(
                      'Error while initializing DemuxerWorker, fallback on DemuxerInline'
                    ),
                    c && Q.URL.revokeObjectURL(c.objectURL),
                    (this.demuxer = new W.a(i, s, a, l)),
                    (this.w = void 0);
                }
              } else this.demuxer = new W.a(i, s, a, l);
            }
            var t = e.prototype;
            return (
              (t.destroy = function() {
                var e = this.w;
                if (e)
                  e.removeEventListener('message', this.onwmsg),
                    e.terminate(),
                    (this.w = null);
                else {
                  var t = this.demuxer;
                  t && (t.destroy(), (this.demuxer = null));
                }
                var r = this.observer;
                r && (r.removeAllListeners(), (this.observer = null));
              }),
              (t.push = function(e, t, r, i, a, n, s, o) {
                var u = this.w,
                  c = Object(l.a)(a.startPTS) ? a.startPTS : a.start,
                  h = a.decryptdata,
                  f = this.frag,
                  g = !(f && a.cc === f.cc),
                  p = !(f && a.level === f.level),
                  v = f && a.sn === f.sn + 1,
                  m = !p && v;
                if (
                  (g && d.b.log(this.id + ':discontinuity detected'),
                  p && d.b.log(this.id + ':switch detected'),
                  (this.frag = a),
                  u)
                )
                  u.postMessage(
                    {
                      cmd: 'demux',
                      data: e,
                      decryptdata: h,
                      initSegment: t,
                      audioCodec: r,
                      videoCodec: i,
                      timeOffset: c,
                      discontinuity: g,
                      trackSwitch: p,
                      contiguous: m,
                      duration: n,
                      accurateTimeOffset: s,
                      defaultInitPTS: o
                    },
                    e instanceof ArrayBuffer ? [e] : []
                  );
                else {
                  var y = this.demuxer;
                  y && y.push(e, h, t, r, i, c, g, p, m, n, s, o);
                }
              }),
              (t.onWorkerMessage = function(e) {
                var t = e.data,
                  r = this.hls;
                switch (t.event) {
                  case 'init':
                    Q.URL.revokeObjectURL(this.w.objectURL);
                    break;
                  case u.a.FRAG_PARSING_DATA:
                    (t.data.data1 = new Uint8Array(t.data1)),
                      t.data2 && (t.data.data2 = new Uint8Array(t.data2));
                  default:
                    (t.data = t.data || {}),
                      (t.data.frag = this.frag),
                      (t.data.id = this.id),
                      r.trigger(t.event, t.data);
                }
              }),
              e
            );
          })();
        function Z(e, t, r) {
          switch (t) {
            case 'audio':
              e.audioGroupIds || (e.audioGroupIds = []),
                e.audioGroupIds.push(r);
              break;
            case 'text':
              e.textGroupIds || (e.textGroupIds = []), e.textGroupIds.push(r);
          }
        }
        function ee(e, t, r) {
          var i = e[t],
            a = e[r],
            n = a.startPTS;
          Object(l.a)(n)
            ? r > t
              ? ((i.duration = n - i.start),
                i.duration < 0 &&
                  d.b.warn(
                    'negative duration computed for frag ' +
                      i.sn +
                      ',level ' +
                      i.level +
                      ', there should be some duration drift between playlist and fragment!'
                  ))
              : ((a.duration = i.start - n),
                a.duration < 0 &&
                  d.b.warn(
                    'negative duration computed for frag ' +
                      a.sn +
                      ',level ' +
                      a.level +
                      ', there should be some duration drift between playlist and fragment!'
                  ))
            : (a.start =
                r > t
                  ? i.start + i.duration
                  : Math.max(i.start - a.duration, 0));
        }
        function te(e, t, r, i, a, n) {
          var s = r;
          if (Object(l.a)(t.startPTS)) {
            var o = Math.abs(t.startPTS - r);
            Object(l.a)(t.deltaPTS)
              ? (t.deltaPTS = Math.max(o, t.deltaPTS))
              : (t.deltaPTS = o),
              (s = Math.max(r, t.startPTS)),
              (r = Math.min(r, t.startPTS)),
              (i = Math.max(i, t.endPTS)),
              (a = Math.min(a, t.startDTS)),
              (n = Math.max(n, t.endDTS));
          }
          var u = r - t.start;
          (t.start = t.startPTS = r),
            (t.maxStartPTS = s),
            (t.endPTS = i),
            (t.startDTS = a),
            (t.endDTS = n),
            (t.duration = i - r);
          var d,
            c,
            h,
            f = t.sn;
          if (!e || f < e.startSN || f > e.endSN) return 0;
          for (d = f - e.startSN, (c = e.fragments)[d] = t, h = d; h > 0; h--)
            ee(c, h, h - 1);
          for (h = d; h < c.length - 1; h++) ee(c, h, h + 1);
          return (e.PTSKnown = !0), u;
        }
        function re(e, t) {
          t.initSegment && e.initSegment && (t.initSegment = e.initSegment);
          var r,
            i = 0;
          if (
            (ie(e, t, function(e, a) {
              (i = e.cc - a.cc),
                Object(l.a)(e.startPTS) &&
                  ((a.start = a.startPTS = e.startPTS),
                  (a.endPTS = e.endPTS),
                  (a.duration = e.duration),
                  (a.backtracked = e.backtracked),
                  (a.dropped = e.dropped),
                  (r = a)),
                (t.PTSKnown = !0);
            }),
            t.PTSKnown)
          ) {
            if (i) {
              d.b.log(
                'discontinuity sliding from playlist, take drift into account'
              );
              for (var a = t.fragments, n = 0; n < a.length; n++) a[n].cc += i;
            }
            r
              ? te(t, r, r.startPTS, r.endPTS, r.startDTS, r.endDTS)
              : (function(e, t) {
                  var r = t.startSN - e.startSN,
                    i = e.fragments,
                    a = t.fragments;
                  if (r < 0 || r > i.length) return;
                  for (var n = 0; n < a.length; n++) a[n].start += i[r].start;
                })(e, t),
              (t.PTSKnown = e.PTSKnown);
          }
        }
        function ie(e, t, r) {
          if (e && t)
            for (
              var i = Math.max(e.startSN, t.startSN) - t.startSN,
                a = Math.min(e.endSN, t.endSN) - t.startSN,
                n = t.startSN - e.startSN,
                s = i;
              s <= a;
              s++
            ) {
              var o = e.fragments[n + s],
                l = t.fragments[s];
              if (!o || !l) break;
              r(o, l, s);
            }
        }
        function ae(e, t, r) {
          var i =
              1e3 *
              (t.averagetargetduration
                ? t.averagetargetduration
                : t.targetduration),
            a = i / 2;
          return (
            e && t.endSN === e.endSN && (i = a),
            r && (i = Math.max(a, i - (window.performance.now() - r))),
            Math.round(i)
          );
        }
        var ne = {
          toString: function(e) {
            for (var t = '', r = e.length, i = 0; i < r; i++)
              t +=
                '[' + e.start(i).toFixed(3) + ',' + e.end(i).toFixed(3) + ']';
            return t;
          }
        };
        function se(e, t) {
          t.fragments.forEach(function(t) {
            if (t) {
              var r = t.start + e;
              (t.start = t.startPTS = r), (t.endPTS = r + t.duration);
            }
          }),
            (t.PTSKnown = !0);
        }
        function oe(e, t, r) {
          !(function(e, t, r) {
            if (
              (function(e, t, r) {
                var i = !1;
                return (
                  t &&
                    t.details &&
                    r &&
                    (r.endCC > r.startCC || (e && e.cc < r.startCC)) &&
                    (i = !0),
                  i
                );
              })(e, r, t)
            ) {
              var i = (function(e, t) {
                var r = e.fragments,
                  i = t.fragments;
                if (i.length && r.length) {
                  var a = (function(e, t) {
                    for (var r = null, i = 0; i < e.length; i += 1) {
                      var a = e[i];
                      if (a && a.cc === t) {
                        r = a;
                        break;
                      }
                    }
                    return r;
                  })(r, i[0].cc);
                  if (a && (!a || a.startPTS)) return a;
                  d.b.log('No frag in previous level to align on');
                } else d.b.log('No fragments to align');
              })(r.details, t);
              i &&
                (d.b.log(
                  'Adjusting PTS using last level due to CC increase within current level'
                ),
                se(i.start, t));
            }
          })(e, r, t),
            !r.PTSKnown &&
              t &&
              (function(e, t) {
                if (t && t.fragments.length) {
                  if (!e.hasProgramDateTime || !t.hasProgramDateTime) return;
                  var r = t.fragments[0].programDateTime,
                    i =
                      (e.fragments[0].programDateTime - r) / 1e3 +
                      t.fragments[0].start;
                  Object(l.a)(i) &&
                    (d.b.log(
                      'adjusting PTS using programDateTime delta, sliding:' +
                        i.toFixed(3)
                    ),
                    se(i, e));
                }
              })(r, t.details);
        }
        function le(e, t, r) {
          if (null === t || !Array.isArray(e) || !e.length || !Object(l.a)(t))
            return null;
          if (t < (e[0].programDateTime || 0)) return null;
          if (t >= (e[e.length - 1].endProgramDateTime || 0)) return null;
          r = r || 0;
          for (var i = 0; i < e.length; ++i) {
            var a = e[i];
            if (ce(t, r, a)) return a;
          }
          return null;
        }
        function ue(e, t, r, i) {
          void 0 === r && (r = 0), void 0 === i && (i = 0);
          var a = null;
          if (
            (e
              ? (a = t[e.sn - t[0].sn + 1])
              : 0 === r && 0 === t[0].start && (a = t[0]),
            a && 0 === de(r, i, a))
          )
            return a;
          var n = j.search(t, de.bind(null, r, i));
          return n || a;
        }
        function de(e, t, r) {
          void 0 === e && (e = 0), void 0 === t && (t = 0);
          var i = Math.min(t, r.duration + (r.deltaPTS ? r.deltaPTS : 0));
          return r.start + r.duration - i <= e
            ? 1
            : r.start - i > e && r.start
            ? -1
            : 0;
        }
        function ce(e, t, r) {
          var i = 1e3 * Math.min(t, r.duration + (r.deltaPTS ? r.deltaPTS : 0));
          return (r.endProgramDateTime || 0) - i > e;
        }
        var he = (function() {
          function e(e, t, r, i) {
            (this.config = e),
              (this.media = t),
              (this.fragmentTracker = r),
              (this.hls = i),
              (this.nudgeRetry = 0),
              (this.stallReported = !1),
              (this.stalled = null),
              (this.moved = !1),
              (this.seeking = !1);
          }
          var t = e.prototype;
          return (
            (t.poll = function(e) {
              var t = this.config,
                r = this.media,
                i = this.stalled,
                a = r.currentTime,
                n = r.seeking,
                s = this.seeking && !n,
                o = !this.seeking && n;
              if (((this.seeking = n), a === e)) {
                if (
                  ((o || s) && (this.stalled = null),
                  !r.paused &&
                    !r.ended &&
                    0 !== r.playbackRate &&
                    r.buffered.length)
                ) {
                  var l = H.bufferInfo(r, a, 0),
                    u = l.len > 0,
                    c = l.nextStart || 0;
                  if (u || c) {
                    if (n) {
                      var h = l.len > 2,
                        f =
                          !c ||
                          (c - a > 2 &&
                            !this.fragmentTracker.getPartialFragment(a));
                      if (h || f) return;
                      this.moved = !1;
                    }
                    if (!this.moved && this.stalled) {
                      var g = Math.max(c, l.start || 0) - a;
                      if (g > 0 && g <= 2)
                        return void this._trySkipBufferHole(null);
                    }
                    var p = self.performance.now();
                    if (null !== i) {
                      var v = p - i;
                      !n && v >= 250 && this._reportStall(l.len);
                      var m = H.bufferInfo(r, a, t.maxBufferHole);
                      this._tryFixBufferStall(m, v);
                    } else this.stalled = p;
                  }
                }
              } else if (((this.moved = !0), null !== i)) {
                if (this.stallReported) {
                  var y = self.performance.now() - i;
                  d.b.warn(
                    'playback not stuck anymore @' +
                      a +
                      ', after ' +
                      Math.round(y) +
                      'ms'
                  ),
                    (this.stallReported = !1);
                }
                (this.stalled = null), (this.nudgeRetry = 0);
              }
            }),
            (t._tryFixBufferStall = function(e, t) {
              var r = this.config,
                i = this.fragmentTracker,
                a = this.media.currentTime,
                n = i.getPartialFragment(a);
              if (n && this._trySkipBufferHole(n)) return;
              e.len > r.maxBufferHole &&
                t > 1e3 * r.highBufferWatchdogPeriod &&
                (d.b.warn('Trying to nudge playhead over buffer-hole'),
                (this.stalled = null),
                this._tryNudgeBuffer());
            }),
            (t._reportStall = function(e) {
              var t = this.hls,
                r = this.media;
              this.stallReported ||
                ((this.stallReported = !0),
                d.b.warn(
                  'Playback stalling at @' +
                    r.currentTime +
                    ' due to low buffer (buffer=' +
                    e +
                    ')'
                ),
                t.trigger(u.a.ERROR, {
                  type: o.b.MEDIA_ERROR,
                  details: o.a.BUFFER_STALLED_ERROR,
                  fatal: !1,
                  buffer: e
                }));
            }),
            (t._trySkipBufferHole = function(e) {
              for (
                var t = this.config,
                  r = this.hls,
                  i = this.media,
                  a = i.currentTime,
                  n = 0,
                  s = 0;
                s < i.buffered.length;
                s++
              ) {
                var l = i.buffered.start(s);
                if (a + t.maxBufferHole >= n && a < l) {
                  var c = Math.max(l + 0.05, i.currentTime + 0.1);
                  return (
                    d.b.warn(
                      'skipping hole, adjusting currentTime from ' +
                        a +
                        ' to ' +
                        c
                    ),
                    (this.moved = !0),
                    (this.stalled = null),
                    (i.currentTime = c),
                    e &&
                      r.trigger(u.a.ERROR, {
                        type: o.b.MEDIA_ERROR,
                        details: o.a.BUFFER_SEEK_OVER_HOLE,
                        fatal: !1,
                        reason:
                          'fragment loaded with buffer holes, seeking from ' +
                          a +
                          ' to ' +
                          c,
                        frag: e
                      }),
                    c
                  );
                }
                n = i.buffered.end(s);
              }
              return 0;
            }),
            (t._tryNudgeBuffer = function() {
              var e = this.config,
                t = this.hls,
                r = this.media,
                i = r.currentTime,
                a = (this.nudgeRetry || 0) + 1;
              if (((this.nudgeRetry = a), a < e.nudgeMaxRetry)) {
                var n = i + a * e.nudgeOffset;
                d.b.warn("Nudging 'currentTime' from " + i + ' to ' + n),
                  (r.currentTime = n),
                  t.trigger(u.a.ERROR, {
                    type: o.b.MEDIA_ERROR,
                    details: o.a.BUFFER_NUDGE_ON_STALL,
                    fatal: !1
                  });
              } else
                d.b.error(
                  'Playhead still not moving while enough data buffered @' +
                    i +
                    ' after ' +
                    e.nudgeMaxRetry +
                    ' nudges'
                ),
                  t.trigger(u.a.ERROR, {
                    type: o.b.MEDIA_ERROR,
                    details: o.a.BUFFER_STALLED_ERROR,
                    fatal: !0
                  });
            }),
            e
          );
        })();
        function fe(e) {
          if (void 0 === e)
            throw new ReferenceError(
              "this hasn't been initialised - super() hasn't been called"
            );
          return e;
        }
        var ge = (function(e) {
          var t, r;
          function i(t) {
            for (
              var r,
                i = arguments.length,
                a = new Array(i > 1 ? i - 1 : 0),
                n = 1;
              n < i;
              n++
            )
              a[n - 1] = arguments[n];
            return (
              ((r =
                e.call.apply(e, [this, t].concat(a)) ||
                this)._boundTick = void 0),
              (r._tickTimer = null),
              (r._tickInterval = null),
              (r._tickCallCount = 0),
              (r._boundTick = r.tick.bind(fe(r))),
              r
            );
          }
          (r = e),
            ((t = i).prototype = Object.create(r.prototype)),
            (t.prototype.constructor = t),
            (t.__proto__ = r);
          var a = i.prototype;
          return (
            (a.onHandlerDestroying = function() {
              this.clearNextTick(), this.clearInterval();
            }),
            (a.hasInterval = function() {
              return !!this._tickInterval;
            }),
            (a.hasNextTick = function() {
              return !!this._tickTimer;
            }),
            (a.setInterval = function(e) {
              return (
                !this._tickInterval &&
                ((this._tickInterval = self.setInterval(this._boundTick, e)),
                !0)
              );
            }),
            (a.clearInterval = function() {
              return (
                !!this._tickInterval &&
                (self.clearInterval(this._tickInterval),
                (this._tickInterval = null),
                !0)
              );
            }),
            (a.clearNextTick = function() {
              return (
                !!this._tickTimer &&
                (self.clearTimeout(this._tickTimer),
                (this._tickTimer = null),
                !0)
              );
            }),
            (a.tick = function() {
              this._tickCallCount++,
                1 === this._tickCallCount &&
                  (this.doTick(),
                  this._tickCallCount > 1 &&
                    (this.clearNextTick(),
                    (this._tickTimer = self.setTimeout(this._boundTick, 0))),
                  (this._tickCallCount = 0));
            }),
            (a.doTick = function() {}),
            i
          );
        })(h);
        var pe = 'STOPPED',
          ve = 'STARTING',
          me = 'IDLE',
          ye = 'PAUSED',
          be = 'KEY_LOADING',
          Te = 'FRAG_LOADING',
          Ee = 'FRAG_LOADING_WAITING_RETRY',
          Se = 'WAITING_TRACK',
          _e = 'PARSING',
          Re = 'PARSED',
          Ae = 'BUFFER_FLUSHING',
          ke = 'ENDED',
          we = 'ERROR',
          Le = 'WAITING_INIT_PTS',
          De = 'WAITING_LEVEL',
          Oe = (function(e) {
            var t, r;
            function i() {
              return e.apply(this, arguments) || this;
            }
            (r = e),
              ((t = i).prototype = Object.create(r.prototype)),
              (t.prototype.constructor = t),
              (t.__proto__ = r);
            var a = i.prototype;
            return (
              (a.doTick = function() {}),
              (a.startLoad = function() {}),
              (a.stopLoad = function() {
                var e = this.fragCurrent;
                e &&
                  (e.loader && e.loader.abort(),
                  this.fragmentTracker.removeFragment(e)),
                  this.demuxer &&
                    (this.demuxer.destroy(), (this.demuxer = null)),
                  (this.fragCurrent = null),
                  (this.fragPrevious = null),
                  this.clearInterval(),
                  this.clearNextTick(),
                  (this.state = pe);
              }),
              (a._streamEnded = function(e, t) {
                var r = this.fragCurrent,
                  i = this.fragmentTracker;
                if (
                  !t.live &&
                  r &&
                  !r.backtracked &&
                  r.sn === t.endSN &&
                  !e.nextStart
                ) {
                  var a = i.getState(r);
                  return a === B || a === G;
                }
                return !1;
              }),
              (a.onMediaSeeking = function() {
                var e = this.config,
                  t = this.media,
                  r = this.mediaBuffer,
                  i = this.state,
                  a = t ? t.currentTime : null,
                  n = H.bufferInfo(r || t, a, this.config.maxBufferHole);
                if (
                  (Object(l.a)(a) &&
                    d.b.log('media seeking to ' + a.toFixed(3)),
                  i === Te)
                ) {
                  var s = this.fragCurrent;
                  if (0 === n.len && s) {
                    var o = e.maxFragLookUpTolerance,
                      u = s.start - o,
                      c = s.start + s.duration + o;
                    a < u || a > c
                      ? (s.loader &&
                          (d.b.log(
                            'seeking outside of buffer while fragment load in progress, cancel fragment load'
                          ),
                          s.loader.abort()),
                        (this.fragCurrent = null),
                        (this.fragPrevious = null),
                        (this.state = me))
                      : d.b.log(
                          'seeking outside of buffer but within currently loaded fragment range'
                        );
                  }
                } else
                  i === ke &&
                    (0 === n.len &&
                      ((this.fragPrevious = null), (this.fragCurrent = null)),
                    (this.state = me));
                t && (this.lastCurrentTime = a),
                  this.loadedmetadata ||
                    (this.nextLoadPosition = this.startPosition = a),
                  this.tick();
              }),
              (a.onMediaEnded = function() {
                this.startPosition = this.lastCurrentTime = 0;
              }),
              (a.onHandlerDestroying = function() {
                this.stopLoad(), e.prototype.onHandlerDestroying.call(this);
              }),
              (a.onHandlerDestroyed = function() {
                (this.state = pe), (this.fragmentTracker = null);
              }),
              (a.computeLivePosition = function(e, t) {
                var r =
                  void 0 !== this.config.liveSyncDuration
                    ? this.config.liveSyncDuration
                    : this.config.liveSyncDurationCount * t.targetduration;
                return e + Math.max(0, t.totalduration - r);
              }),
              i
            );
          })(ge);
        function Ce(e, t) {
          for (var r = 0; r < t.length; r++) {
            var i = t[r];
            (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              'value' in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        var Ie,
          Pe = (function(e) {
            var t, r;
            function i(t, r) {
              var i;
              return (
                ((i =
                  e.call(
                    this,
                    t,
                    u.a.MEDIA_ATTACHED,
                    u.a.MEDIA_DETACHING,
                    u.a.MANIFEST_LOADING,
                    u.a.MANIFEST_PARSED,
                    u.a.LEVEL_LOADED,
                    u.a.LEVELS_UPDATED,
                    u.a.KEY_LOADED,
                    u.a.FRAG_LOADED,
                    u.a.FRAG_LOAD_EMERGENCY_ABORTED,
                    u.a.FRAG_PARSING_INIT_SEGMENT,
                    u.a.FRAG_PARSING_DATA,
                    u.a.FRAG_PARSED,
                    u.a.ERROR,
                    u.a.AUDIO_TRACK_SWITCHING,
                    u.a.AUDIO_TRACK_SWITCHED,
                    u.a.BUFFER_CREATED,
                    u.a.BUFFER_APPENDED,
                    u.a.BUFFER_FLUSHED
                  ) || this).fragmentTracker = r),
                (i.config = t.config),
                (i.audioCodecSwap = !1),
                (i._state = pe),
                (i.stallReported = !1),
                (i.gapController = null),
                (i.altAudio = !1),
                (i.audioOnly = !1),
                (i.bitrateTest = !1),
                i
              );
            }
            (r = e),
              ((t = i).prototype = Object.create(r.prototype)),
              (t.prototype.constructor = t),
              (t.__proto__ = r);
            var a,
              s,
              c,
              h = i.prototype;
            return (
              (h.startLoad = function(e) {
                if (this.levels) {
                  var t = this.lastCurrentTime,
                    r = this.hls;
                  if (
                    (this.stopLoad(),
                    this.setInterval(100),
                    (this.level = -1),
                    (this.fragLoadError = 0),
                    !this.startFragRequested)
                  ) {
                    var i = r.startLevel;
                    -1 === i &&
                      (r.config.testBandwidth
                        ? ((i = 0), (this.bitrateTest = !0))
                        : (i = r.nextAutoLevel)),
                      (this.level = r.nextLoadLevel = i),
                      (this.loadedmetadata = !1);
                  }
                  t > 0 &&
                    -1 === e &&
                    (d.b.log(
                      'override startPosition with lastCurrentTime @' +
                        t.toFixed(3)
                    ),
                    (e = t)),
                    (this.state = me),
                    (this.nextLoadPosition = this.startPosition = this.lastCurrentTime = e),
                    this.tick();
                } else (this.forceStartLoad = !0), (this.state = pe);
              }),
              (h.stopLoad = function() {
                (this.forceStartLoad = !1), e.prototype.stopLoad.call(this);
              }),
              (h.doTick = function() {
                switch (this.state) {
                  case Ae:
                    this.fragLoadError = 0;
                    break;
                  case me:
                    this._doTickIdle();
                    break;
                  case De:
                    var e = this.levels[this.level];
                    e && e.details && (this.state = me);
                    break;
                  case Ee:
                    var t = window.performance.now(),
                      r = this.retryDate;
                    (!r || t >= r || (this.media && this.media.seeking)) &&
                      (d.b.log(
                        'mediaController: retryDate reached, switch back to IDLE state'
                      ),
                      (this.state = me));
                }
                this._checkBuffer(), this._checkFragmentChanged();
              }),
              (h._doTickIdle = function() {
                var e = this.hls,
                  t = e.config,
                  r = this.media;
                if (
                  void 0 !== this.levelLastLoaded &&
                  (r || (!this.startFragRequested && t.startFragPrefetch))
                )
                  if (this.altAudio && this.audioOnly) this.demuxer.frag = null;
                  else {
                    var i;
                    i = this.loadedmetadata
                      ? r.currentTime
                      : this.nextLoadPosition;
                    var a = e.nextLoadLevel,
                      n = this.levels[a];
                    if (n) {
                      var s,
                        o = n.bitrate;
                      (s = o
                        ? Math.max((8 * t.maxBufferSize) / o, t.maxBufferLength)
                        : t.maxBufferLength),
                        (s = Math.min(s, t.maxMaxBufferLength));
                      var l =
                          i < t.maxBufferHole
                            ? Math.max(2, t.maxBufferHole)
                            : t.maxBufferHole,
                        c = H.bufferInfo(
                          this.mediaBuffer ? this.mediaBuffer : r,
                          i,
                          l
                        ),
                        h = c.len;
                      if (!(h >= s)) {
                        d.b.trace(
                          'buffer length of ' +
                            h.toFixed(3) +
                            ' is below max of ' +
                            s.toFixed(3) +
                            '. checking for more payload ...'
                        ),
                          (this.level = e.nextLoadLevel = a);
                        var f = n.details;
                        if (!f || (f.live && this.levelLastLoaded !== a))
                          this.state = De;
                        else {
                          if (this._streamEnded(c, f)) {
                            var g = {};
                            return (
                              this.altAudio && (g.type = 'video'),
                              this.hls.trigger(u.a.BUFFER_EOS, g),
                              void (this.state = ke)
                            );
                          }
                          this._fetchPayloadOrEos(i, c, f);
                        }
                      }
                    }
                  }
              }),
              (h._fetchPayloadOrEos = function(e, t, r) {
                var i = this.fragPrevious,
                  a = (this.level, r.fragments),
                  n = a.length;
                if (0 !== n) {
                  var s,
                    o = a[0].start,
                    l = a[n - 1].start + a[n - 1].duration,
                    u = t.end;
                  if (r.initSegment && !r.initSegment.data) s = r.initSegment;
                  else if (r.live) {
                    var c = this.config.initialLiveManifestSize;
                    if (n < c)
                      return void d.b.warn(
                        'Can not start playback of a level, reason: not enough fragments ' +
                          n +
                          ' < ' +
                          c
                      );
                    if (
                      null ===
                      (s = this._ensureFragmentAtLivePoint(r, u, o, l, i, a))
                    )
                      return;
                  } else u < o && (s = a[0]);
                  s || (s = this._findFragment(o, i, n, a, u, l, r)),
                    s &&
                      (s.encrypted
                        ? this._loadKey(s, r)
                        : this._loadFragment(s, r, e, u));
                }
              }),
              (h._ensureFragmentAtLivePoint = function(e, t, r, i, a, n) {
                var s,
                  o = this.hls.config,
                  u = this.media,
                  c = 1 / 0;
                if (
                  (void 0 !== o.liveMaxLatencyDuration
                    ? (c = o.liveMaxLatencyDuration)
                    : Object(l.a)(o.liveMaxLatencyDurationCount) &&
                      (c = o.liveMaxLatencyDurationCount * e.targetduration),
                  t < Math.max(r - o.maxFragLookUpTolerance, i - c))
                ) {
                  var h = (this.liveSyncPosition = this.computeLivePosition(
                    r,
                    e
                  ));
                  (t = h),
                    u &&
                      !u.paused &&
                      u.readyState &&
                      u.duration > h &&
                      h > u.currentTime &&
                      (d.b.log(
                        'buffer end: ' +
                          t.toFixed(3) +
                          ' is located too far from the end of live sliding playlist, reset currentTime to : ' +
                          h.toFixed(3)
                      ),
                      (u.currentTime = h)),
                    (this.nextLoadPosition = h);
                }
                if (e.PTSKnown && t > i && u && u.readyState) return null;
                if (this.startFragRequested && !e.PTSKnown && a)
                  if (e.hasProgramDateTime)
                    d.b.log(
                      'live playlist, switching playlist, load frag with same PDT: ' +
                        a.programDateTime
                    ),
                      (s = le(
                        n,
                        a.endProgramDateTime,
                        o.maxFragLookUpTolerance
                      ));
                  else {
                    var f = a.sn + 1;
                    if (f >= e.startSN && f <= e.endSN) {
                      var g = n[f - e.startSN];
                      a.cc === g.cc &&
                        ((s = g),
                        d.b.log(
                          'live playlist, switching playlist, load frag with next SN: ' +
                            s.sn
                        ));
                    }
                    s ||
                      ((s = j.search(n, function(e) {
                        return a.cc - e.cc;
                      })) &&
                        d.b.log(
                          'live playlist, switching playlist, load frag with same CC: ' +
                            s.sn
                        ));
                  }
                return s;
              }),
              (h._findFragment = function(e, t, r, i, a, n, s) {
                var o,
                  l = this.hls.config;
                a < n
                  ? (o = ue(
                      t,
                      i,
                      a,
                      a > n - l.maxFragLookUpTolerance
                        ? 0
                        : l.maxFragLookUpTolerance
                    ))
                  : (o = i[r - 1]);
                if (o) {
                  var u = o.sn - s.startSN,
                    c = t && o.level === t.level,
                    h = i[u - 1],
                    f = i[u + 1];
                  if (t && o.sn === t.sn)
                    if (c && !o.backtracked)
                      if (o.sn < s.endSN) {
                        var g = t.deltaPTS;
                        g && g > l.maxBufferHole && t.dropped && u
                          ? ((o = h),
                            d.b.warn(
                              'Previous fragment was dropped with large PTS gap between audio and video. Maybe fragment is not starting with a keyframe? Loading previous one to try to overcome this'
                            ))
                          : ((o = f),
                            d.b.log('Re-loading fragment with SN: ' + o.sn));
                      } else o = null;
                    else
                      o.backtracked &&
                        (f && f.backtracked
                          ? (d.b.warn(
                              'Already backtracked from fragment ' +
                                f.sn +
                                ', will not backtrack to fragment ' +
                                o.sn +
                                '. Loading fragment ' +
                                f.sn
                            ),
                            (o = f))
                          : (d.b.warn(
                              'Loaded fragment with dropped frames, backtracking 1 segment to find a keyframe'
                            ),
                            (o.dropped = 0),
                            h ? ((o = h).backtracked = !0) : u && (o = null)));
                }
                return o;
              }),
              (h._loadKey = function(e, t) {
                d.b.log(
                  'Loading key for ' +
                    e.sn +
                    ' of [' +
                    t.startSN +
                    ' ,' +
                    t.endSN +
                    '],level ' +
                    this.level
                ),
                  (this.state = be),
                  this.hls.trigger(u.a.KEY_LOADING, { frag: e });
              }),
              (h._loadFragment = function(e, t, r, i) {
                var a = this.fragmentTracker.getState(e);
                (this.fragCurrent = e),
                  'initSegment' !== e.sn && (this.startFragRequested = !0),
                  Object(l.a)(e.sn) &&
                    !e.bitrateTest &&
                    (this.nextLoadPosition = e.start + e.duration),
                  e.backtracked || a === U || a === B
                    ? ((e.autoLevel = this.hls.autoLevelEnabled),
                      (e.bitrateTest = this.bitrateTest),
                      d.b.log(
                        'Loading ' +
                          e.sn +
                          ' of [' +
                          t.startSN +
                          ' ,' +
                          t.endSN +
                          '],level ' +
                          this.level +
                          ', currentTime:' +
                          r.toFixed(3) +
                          ',bufferEnd:' +
                          i.toFixed(3)
                      ),
                      this.hls.trigger(u.a.FRAG_LOADING, { frag: e }),
                      this.demuxer || (this.demuxer = new J(this.hls, 'main')),
                      (this.state = Te))
                    : a === N &&
                      this._reduceMaxBufferLength(e.duration) &&
                      this.fragmentTracker.removeFragment(e);
              }),
              (h.getBufferedFrag = function(e) {
                return this.fragmentTracker.getBufferedFrag(e, n.MAIN);
              }),
              (h.followingBufferedFrag = function(e) {
                return e ? this.getBufferedFrag(e.endPTS + 0.5) : null;
              }),
              (h._checkFragmentChanged = function() {
                var e,
                  t,
                  r = this.media;
                if (
                  r &&
                  r.readyState &&
                  !1 === r.seeking &&
                  ((t = r.currentTime) > this.lastCurrentTime &&
                    (this.lastCurrentTime = t),
                  H.isBuffered(r, t)
                    ? (e = this.getBufferedFrag(t))
                    : H.isBuffered(r, t + 0.1) &&
                      (e = this.getBufferedFrag(t + 0.1)),
                  e)
                ) {
                  var i = e;
                  if (i !== this.fragPlaying) {
                    this.hls.trigger(u.a.FRAG_CHANGED, { frag: i });
                    var a = i.level;
                    (this.fragPlaying && this.fragPlaying.level === a) ||
                      this.hls.trigger(u.a.LEVEL_SWITCHED, { level: a }),
                      (this.fragPlaying = i);
                  }
                }
              }),
              (h.immediateLevelSwitch = function() {
                if ((d.b.log('immediateLevelSwitch'), !this.immediateSwitch)) {
                  this.immediateSwitch = !0;
                  var e,
                    t = this.media;
                  t ? ((e = t.paused), t.pause()) : (e = !0),
                    (this.previouslyPaused = e);
                }
                var r = this.fragCurrent;
                r && r.loader && r.loader.abort(),
                  (this.fragCurrent = null),
                  this.flushMainBuffer(0, Number.POSITIVE_INFINITY);
              }),
              (h.immediateLevelSwitchEnd = function() {
                var e = this.media;
                e &&
                  e.buffered.length &&
                  ((this.immediateSwitch = !1),
                  H.isBuffered(e, e.currentTime) && (e.currentTime -= 1e-4),
                  this.previouslyPaused || e.play());
              }),
              (h.nextLevelSwitch = function() {
                var e = this.media;
                if (e && e.readyState) {
                  var t, r, i;
                  if (
                    ((r = this.getBufferedFrag(e.currentTime)) &&
                      r.startPTS > 1 &&
                      this.flushMainBuffer(0, r.startPTS - 1),
                    e.paused)
                  )
                    t = 0;
                  else {
                    var a = this.hls.nextLoadLevel,
                      n = this.levels[a],
                      s = this.fragLastKbps;
                    t =
                      s && this.fragCurrent
                        ? (this.fragCurrent.duration * n.bitrate) / (1e3 * s) +
                          1
                        : 0;
                  }
                  if (
                    (i = this.getBufferedFrag(e.currentTime + t)) &&
                    (i = this.followingBufferedFrag(i))
                  ) {
                    var o = this.fragCurrent;
                    o && o.loader && o.loader.abort(),
                      (this.fragCurrent = null),
                      this.flushMainBuffer(
                        i.maxStartPTS,
                        Number.POSITIVE_INFINITY
                      );
                  }
                }
              }),
              (h.flushMainBuffer = function(e, t) {
                this.state = Ae;
                var r = { startOffset: e, endOffset: t };
                this.altAudio && (r.type = 'video'),
                  this.hls.trigger(u.a.BUFFER_FLUSHING, r);
              }),
              (h.onMediaAttached = function(e) {
                var t = (this.media = this.mediaBuffer = e.media);
                (this.onvseeking = this.onMediaSeeking.bind(this)),
                  (this.onvseeked = this.onMediaSeeked.bind(this)),
                  (this.onvended = this.onMediaEnded.bind(this)),
                  t.addEventListener('seeking', this.onvseeking),
                  t.addEventListener('seeked', this.onvseeked),
                  t.addEventListener('ended', this.onvended);
                var r = this.config;
                this.levels &&
                  r.autoStartLoad &&
                  this.hls.startLoad(r.startPosition),
                  (this.gapController = new he(
                    r,
                    t,
                    this.fragmentTracker,
                    this.hls
                  ));
              }),
              (h.onMediaDetaching = function() {
                var e = this.media;
                e &&
                  e.ended &&
                  (d.b.log(
                    'MSE detaching and video ended, reset startPosition'
                  ),
                  (this.startPosition = this.lastCurrentTime = 0));
                var t = this.levels;
                t &&
                  t.forEach(function(e) {
                    e.details &&
                      e.details.fragments.forEach(function(e) {
                        e.backtracked = void 0;
                      });
                  }),
                  e &&
                    (e.removeEventListener('seeking', this.onvseeking),
                    e.removeEventListener('seeked', this.onvseeked),
                    e.removeEventListener('ended', this.onvended),
                    (this.onvseeking = this.onvseeked = this.onvended = null)),
                  this.fragmentTracker.removeAllFragments(),
                  (this.media = this.mediaBuffer = null),
                  (this.loadedmetadata = !1),
                  this.stopLoad();
              }),
              (h.onMediaSeeked = function() {
                var e = this.media,
                  t = e ? e.currentTime : void 0;
                Object(l.a)(t) && d.b.log('media seeked to ' + t.toFixed(3)),
                  this.tick();
              }),
              (h.onManifestLoading = function() {
                d.b.log('trigger BUFFER_RESET'),
                  this.hls.trigger(u.a.BUFFER_RESET),
                  this.fragmentTracker.removeAllFragments(),
                  (this.stalled = !1),
                  (this.startPosition = this.lastCurrentTime = 0);
              }),
              (h.onManifestParsed = function(e) {
                var t,
                  r = !1,
                  i = !1;
                e.levels.forEach(function(e) {
                  (t = e.audioCodec) &&
                    (-1 !== t.indexOf('mp4a.40.2') && (r = !0),
                    -1 !== t.indexOf('mp4a.40.5') && (i = !0));
                }),
                  (this.audioCodecSwitch = r && i),
                  this.audioCodecSwitch &&
                    d.b.log(
                      'both AAC/HE-AAC audio found in levels; declaring level codec as HE-AAC'
                    ),
                  (this.altAudio = e.altAudio),
                  (this.levels = e.levels),
                  (this.startFragRequested = !1);
                var a = this.config;
                (a.autoStartLoad || this.forceStartLoad) &&
                  this.hls.startLoad(a.startPosition);
              }),
              (h.onLevelLoaded = function(e) {
                var t = e.details,
                  r = e.level,
                  i = this.levels[this.levelLastLoaded],
                  a = this.levels[r],
                  n = t.totalduration,
                  s = 0;
                if (
                  (d.b.log(
                    'level ' +
                      r +
                      ' loaded [' +
                      t.startSN +
                      ',' +
                      t.endSN +
                      '],duration:' +
                      n
                  ),
                  t.live)
                ) {
                  var o = a.details;
                  o && t.fragments.length > 0
                    ? (re(o, t),
                      (s = t.fragments[0].start),
                      (this.liveSyncPosition = this.computeLivePosition(s, o)),
                      t.PTSKnown && Object(l.a)(s)
                        ? d.b.log('live playlist sliding:' + s.toFixed(3))
                        : (d.b.log(
                            'live playlist - outdated PTS, unknown sliding'
                          ),
                          oe(this.fragPrevious, i, t)))
                    : (d.b.log('live playlist - first load, unknown sliding'),
                      (t.PTSKnown = !1),
                      oe(this.fragPrevious, i, t));
                } else t.PTSKnown = !1;
                if (
                  ((a.details = t),
                  (this.levelLastLoaded = r),
                  this.hls.trigger(u.a.LEVEL_UPDATED, { details: t, level: r }),
                  !1 === this.startFragRequested)
                ) {
                  if (
                    -1 === this.startPosition ||
                    -1 === this.lastCurrentTime
                  ) {
                    var c = t.startTimeOffset;
                    Object(l.a)(c)
                      ? (c < 0 &&
                          (d.b.log(
                            'negative start time offset ' +
                              c +
                              ', count from end of last fragment'
                          ),
                          (c = s + n + c)),
                        d.b.log(
                          'start time offset found in playlist, adjust startPosition to ' +
                            c
                        ),
                        (this.startPosition = c))
                      : t.live
                      ? ((this.startPosition = this.computeLivePosition(s, t)),
                        d.b.log(
                          'configure startPosition to ' + this.startPosition
                        ))
                      : (this.startPosition = 0),
                      (this.lastCurrentTime = this.startPosition);
                  }
                  this.nextLoadPosition = this.startPosition;
                }
                this.state === De && (this.state = me), this.tick();
              }),
              (h.onKeyLoaded = function() {
                this.state === be && ((this.state = me), this.tick());
              }),
              (h.onFragLoaded = function(e) {
                var t = this.fragCurrent,
                  r = this.hls,
                  i = this.levels,
                  a = this.media,
                  n = e.frag;
                if (
                  this.state === Te &&
                  t &&
                  'main' === n.type &&
                  n.level === t.level &&
                  n.sn === t.sn
                ) {
                  var s = e.stats,
                    o = i[t.level],
                    l = o.details;
                  if (
                    ((this.bitrateTest = !1),
                    (this.stats = s),
                    d.b.log(
                      'Loaded ' +
                        t.sn +
                        ' of [' +
                        l.startSN +
                        ' ,' +
                        l.endSN +
                        '],level ' +
                        t.level
                    ),
                    n.bitrateTest && r.nextLoadLevel)
                  )
                    (this.state = me),
                      (this.startFragRequested = !1),
                      (s.tparsed = s.tbuffered = window.performance.now()),
                      r.trigger(u.a.FRAG_BUFFERED, {
                        stats: s,
                        frag: t,
                        id: 'main'
                      }),
                      this.tick();
                  else if ('initSegment' === n.sn)
                    (this.state = me),
                      (s.tparsed = s.tbuffered = window.performance.now()),
                      (l.initSegment.data = e.payload),
                      r.trigger(u.a.FRAG_BUFFERED, {
                        stats: s,
                        frag: t,
                        id: 'main'
                      }),
                      this.tick();
                  else {
                    d.b.log(
                      'Parsing ' +
                        t.sn +
                        ' of [' +
                        l.startSN +
                        ' ,' +
                        l.endSN +
                        '],level ' +
                        t.level +
                        ', cc ' +
                        t.cc
                    ),
                      (this.state = _e),
                      (this.pendingBuffering = !0),
                      (this.appended = !1),
                      n.bitrateTest &&
                        ((n.bitrateTest = !1),
                        this.fragmentTracker.onFragLoaded({ frag: n }));
                    var c = !(a && a.seeking) && (l.PTSKnown || !l.live),
                      h = l.initSegment ? l.initSegment.data : [],
                      f = this._getAudioCodec(o);
                    (this.demuxer =
                      this.demuxer || new J(this.hls, 'main')).push(
                      e.payload,
                      h,
                      f,
                      o.videoCodec,
                      t,
                      l.totalduration,
                      c
                    );
                  }
                }
                this.fragLoadError = 0;
              }),
              (h.onFragParsingInitSegment = function(e) {
                var t = this.fragCurrent,
                  r = e.frag;
                if (
                  t &&
                  'main' === e.id &&
                  r.sn === t.sn &&
                  r.level === t.level &&
                  this.state === _e
                ) {
                  var i,
                    a,
                    n = e.tracks;
                  if (
                    ((this.audioOnly = n.audio && !n.video),
                    this.altAudio && !this.audioOnly && delete n.audio,
                    (a = n.audio))
                  ) {
                    var s = this.levels[this.level].audioCodec,
                      o = navigator.userAgent.toLowerCase();
                    s &&
                      this.audioCodecSwap &&
                      (d.b.log('swapping playlist audio codec'),
                      (s =
                        -1 !== s.indexOf('mp4a.40.5')
                          ? 'mp4a.40.2'
                          : 'mp4a.40.5')),
                      this.audioCodecSwitch &&
                        1 !== a.metadata.channelCount &&
                        -1 === o.indexOf('firefox') &&
                        (s = 'mp4a.40.5'),
                      -1 !== o.indexOf('android') &&
                        'audio/mpeg' !== a.container &&
                        ((s = 'mp4a.40.2'),
                        d.b.log('Android: force audio codec to ' + s)),
                      (a.levelCodec = s),
                      (a.id = e.id);
                  }
                  for (i in ((a = n.video) &&
                    ((a.levelCodec = this.levels[this.level].videoCodec),
                    (a.id = e.id)),
                  this.hls.trigger(u.a.BUFFER_CODECS, n),
                  n)) {
                    (a = n[i]),
                      d.b.log(
                        'main track:' +
                          i +
                          ',container:' +
                          a.container +
                          ',codecs[level/parsed]=[' +
                          a.levelCodec +
                          '/' +
                          a.codec +
                          ']'
                      );
                    var l = a.initSegment;
                    l &&
                      ((this.appended = !0),
                      (this.pendingBuffering = !0),
                      this.hls.trigger(u.a.BUFFER_APPENDING, {
                        type: i,
                        data: l,
                        parent: 'main',
                        content: 'initSegment'
                      }));
                  }
                  this.tick();
                }
              }),
              (h.onFragParsingData = function(e) {
                var t = this,
                  r = this.fragCurrent,
                  i = e.frag;
                if (
                  r &&
                  'main' === e.id &&
                  i.sn === r.sn &&
                  i.level === r.level &&
                  ('audio' !== e.type || !this.altAudio) &&
                  this.state === _e
                ) {
                  var a = this.levels[this.level],
                    n = r;
                  if (
                    (Object(l.a)(e.endPTS) ||
                      ((e.endPTS = e.startPTS + r.duration),
                      (e.endDTS = e.startDTS + r.duration)),
                    !0 === e.hasAudio && n.addElementaryStream(p.AUDIO),
                    !0 === e.hasVideo && n.addElementaryStream(p.VIDEO),
                    d.b.log(
                      'Parsed ' +
                        e.type +
                        ',PTS:[' +
                        e.startPTS.toFixed(3) +
                        ',' +
                        e.endPTS.toFixed(3) +
                        '],DTS:[' +
                        e.startDTS.toFixed(3) +
                        '/' +
                        e.endDTS.toFixed(3) +
                        '],nb:' +
                        e.nb +
                        ',dropped:' +
                        (e.dropped || 0)
                    ),
                    'video' === e.type)
                  )
                    if (((n.dropped = e.dropped), n.dropped))
                      if (n.backtracked)
                        d.b.warn(
                          'Already backtracked on this fragment, appending with the gap',
                          n.sn
                        );
                      else {
                        var s = a.details;
                        if (!s || n.sn !== s.startSN)
                          return (
                            d.b.warn(
                              'missing video frame(s), backtracking fragment',
                              n.sn
                            ),
                            this.fragmentTracker.removeFragment(n),
                            (n.backtracked = !0),
                            (this.nextLoadPosition = e.startPTS),
                            (this.state = me),
                            (this.fragPrevious = n),
                            void this.tick()
                          );
                        d.b.warn(
                          'missing video frame(s) on first frag, appending with gap',
                          n.sn
                        );
                      }
                    else n.backtracked = !1;
                  var o = te(
                      a.details,
                      n,
                      e.startPTS,
                      e.endPTS,
                      e.startDTS,
                      e.endDTS
                    ),
                    c = this.hls;
                  c.trigger(u.a.LEVEL_PTS_UPDATED, {
                    details: a.details,
                    level: this.level,
                    drift: o,
                    type: e.type,
                    start: e.startPTS,
                    end: e.endPTS
                  }),
                    [e.data1, e.data2].forEach(function(r) {
                      r &&
                        r.length &&
                        t.state === _e &&
                        ((t.appended = !0),
                        (t.pendingBuffering = !0),
                        c.trigger(u.a.BUFFER_APPENDING, {
                          type: e.type,
                          data: r,
                          parent: 'main',
                          content: 'data'
                        }));
                    }),
                    this.tick();
                }
              }),
              (h.onFragParsed = function(e) {
                var t = this.fragCurrent,
                  r = e.frag;
                t &&
                  'main' === e.id &&
                  r.sn === t.sn &&
                  r.level === t.level &&
                  this.state === _e &&
                  ((this.stats.tparsed = window.performance.now()),
                  (this.state = Re),
                  this._checkAppendedParsed());
              }),
              (h.onAudioTrackSwitching = function(e) {
                var t = !!e.url,
                  r = e.id;
                if (!t) {
                  if (this.mediaBuffer !== this.media) {
                    d.b.log(
                      'switching on main audio, use media.buffered to schedule main fragment loading'
                    ),
                      (this.mediaBuffer = this.media);
                    var i = this.fragCurrent;
                    i.loader &&
                      (d.b.log(
                        'switching to main audio track, cancel main fragment load'
                      ),
                      i.loader.abort()),
                      (this.fragCurrent = null),
                      (this.fragPrevious = null),
                      this.demuxer &&
                        (this.demuxer.destroy(), (this.demuxer = null)),
                      (this.state = me);
                  }
                  var a = this.hls;
                  a.trigger(u.a.BUFFER_FLUSHING, {
                    startOffset: 0,
                    endOffset: Number.POSITIVE_INFINITY,
                    type: 'audio'
                  }),
                    a.trigger(u.a.AUDIO_TRACK_SWITCHED, { id: r }),
                    (this.altAudio = !1);
                }
              }),
              (h.onAudioTrackSwitched = function(e) {
                var t = e.id,
                  r = !!this.hls.audioTracks[t].url;
                if (r) {
                  var i = this.videoBuffer;
                  i &&
                    this.mediaBuffer !== i &&
                    (d.b.log(
                      'switching on alternate audio, use video.buffered to schedule main fragment loading'
                    ),
                    (this.mediaBuffer = i));
                }
                (this.altAudio = r), this.tick();
              }),
              (h.onBufferCreated = function(e) {
                var t,
                  r,
                  i = e.tracks,
                  a = !1;
                for (var n in i) {
                  var s = i[n];
                  'main' === s.id
                    ? ((r = n),
                      (t = s),
                      'video' === n && (this.videoBuffer = i[n].buffer))
                    : (a = !0);
                }
                a && t
                  ? (d.b.log(
                      'alternate track found, use ' +
                        r +
                        '.buffered to schedule main fragment loading'
                    ),
                    (this.mediaBuffer = t.buffer))
                  : (this.mediaBuffer = this.media);
              }),
              (h.onBufferAppended = function(e) {
                if ('main' === e.parent) {
                  var t = this.state;
                  (t !== _e && t !== Re) ||
                    ((this.pendingBuffering = e.pending > 0),
                    this._checkAppendedParsed());
                }
              }),
              (h._checkAppendedParsed = function() {
                if (
                  !(
                    this.state !== Re ||
                    (this.appended && this.pendingBuffering)
                  )
                ) {
                  var e = this.fragCurrent;
                  if (e) {
                    var t = this.mediaBuffer ? this.mediaBuffer : this.media;
                    d.b.log('main buffered : ' + ne.toString(t.buffered)),
                      (this.fragPrevious = e);
                    var r = this.stats;
                    (r.tbuffered = window.performance.now()),
                      (this.fragLastKbps = Math.round(
                        (8 * r.total) / (r.tbuffered - r.tfirst)
                      )),
                      this.hls.trigger(u.a.FRAG_BUFFERED, {
                        stats: r,
                        frag: e,
                        id: 'main'
                      }),
                      (this.state = me);
                  }
                  (this.loadedmetadata || this.startPosition <= 0) &&
                    this.tick();
                }
              }),
              (h.onError = function(e) {
                var t = e.frag || this.fragCurrent;
                if (!t || 'main' === t.type) {
                  var r =
                    !!this.media &&
                    H.isBuffered(this.media, this.media.currentTime) &&
                    H.isBuffered(this.media, this.media.currentTime + 0.5);
                  switch (e.details) {
                    case o.a.FRAG_LOAD_ERROR:
                    case o.a.FRAG_LOAD_TIMEOUT:
                    case o.a.KEY_LOAD_ERROR:
                    case o.a.KEY_LOAD_TIMEOUT:
                      if (!e.fatal)
                        if (
                          this.fragLoadError + 1 <=
                          this.config.fragLoadingMaxRetry
                        ) {
                          var i = Math.min(
                            Math.pow(2, this.fragLoadError) *
                              this.config.fragLoadingRetryDelay,
                            this.config.fragLoadingMaxRetryTimeout
                          );
                          d.b.warn(
                            'mediaController: frag loading failed, retry in ' +
                              i +
                              ' ms'
                          ),
                            (this.retryDate = window.performance.now() + i),
                            this.loadedmetadata ||
                              ((this.startFragRequested = !1),
                              (this.nextLoadPosition = this.startPosition)),
                            this.fragLoadError++,
                            (this.state = Ee);
                        } else
                          d.b.error(
                            'mediaController: ' +
                              e.details +
                              ' reaches max retry, redispatch as fatal ...'
                          ),
                            (e.fatal = !0),
                            (this.state = we);
                      break;
                    case o.a.LEVEL_LOAD_ERROR:
                    case o.a.LEVEL_LOAD_TIMEOUT:
                      this.state !== we &&
                        (e.fatal
                          ? ((this.state = we),
                            d.b.warn(
                              'streamController: ' +
                                e.details +
                                ',switch to ' +
                                this.state +
                                ' state ...'
                            ))
                          : e.levelRetry ||
                            this.state !== De ||
                            (this.state = me));
                      break;
                    case o.a.BUFFER_FULL_ERROR:
                      'main' !== e.parent ||
                        (this.state !== _e && this.state !== Re) ||
                        (r
                          ? (this._reduceMaxBufferLength(
                              this.config.maxBufferLength
                            ),
                            (this.state = me))
                          : (d.b.warn(
                              'buffer full error also media.currentTime is not buffered, flush everything'
                            ),
                            (this.fragCurrent = null),
                            this.flushMainBuffer(0, Number.POSITIVE_INFINITY)));
                  }
                }
              }),
              (h._reduceMaxBufferLength = function(e) {
                var t = this.config;
                return (
                  t.maxMaxBufferLength >= e &&
                  ((t.maxMaxBufferLength /= 2),
                  d.b.warn(
                    'main:reduce max buffer length to ' +
                      t.maxMaxBufferLength +
                      's'
                  ),
                  !0)
                );
              }),
              (h._checkBuffer = function() {
                var e = this.media;
                if (e && 0 !== e.readyState) {
                  var t = (this.mediaBuffer ? this.mediaBuffer : e).buffered;
                  !this.loadedmetadata && t.length
                    ? ((this.loadedmetadata = !0), this._seekToStartPos())
                    : this.immediateSwitch
                    ? this.immediateLevelSwitchEnd()
                    : this.gapController.poll(this.lastCurrentTime, t);
                }
              }),
              (h.onFragLoadEmergencyAborted = function() {
                (this.state = me),
                  this.loadedmetadata ||
                    ((this.startFragRequested = !1),
                    (this.nextLoadPosition = this.startPosition)),
                  this.tick();
              }),
              (h.onBufferFlushed = function() {
                var e = this.mediaBuffer ? this.mediaBuffer : this.media;
                if (e) {
                  var t = this.audioOnly ? p.AUDIO : p.VIDEO;
                  this.fragmentTracker.detectEvictedFragments(t, e.buffered);
                }
                (this.state = me), (this.fragPrevious = null);
              }),
              (h.onLevelsUpdated = function(e) {
                this.levels = e.levels;
              }),
              (h.swapAudioCodec = function() {
                this.audioCodecSwap = !this.audioCodecSwap;
              }),
              (h._seekToStartPos = function() {
                var e = this.media,
                  t = this.startPosition,
                  r = e.currentTime;
                if (r !== t && t >= 0) {
                  if (e.seeking)
                    return void d.b.log(
                      'could not seek to ' + t + ', already seeking at ' + r
                    );
                  d.b.log(
                    'seek to target start position ' +
                      t +
                      ' from current time ' +
                      r +
                      '. ready state ' +
                      e.readyState
                  ),
                    (e.currentTime = t);
                }
              }),
              (h._getAudioCodec = function(e) {
                var t = this.config.defaultAudioCodec || e.audioCodec;
                return (
                  this.audioCodecSwap &&
                    (d.b.log('swapping playlist audio codec'),
                    t &&
                      (t =
                        -1 !== t.indexOf('mp4a.40.5')
                          ? 'mp4a.40.2'
                          : 'mp4a.40.5')),
                  t
                );
              }),
              (a = i),
              (s = [
                {
                  key: 'state',
                  set: function(e) {
                    if (this.state !== e) {
                      var t = this.state;
                      (this._state = e),
                        d.b.log('main stream-controller: ' + t + '->' + e),
                        this.hls.trigger(u.a.STREAM_STATE_TRANSITION, {
                          previousState: t,
                          nextState: e
                        });
                    }
                  },
                  get: function() {
                    return this._state;
                  }
                },
                {
                  key: 'currentLevel',
                  get: function() {
                    var e = this.media;
                    if (e) {
                      var t = this.getBufferedFrag(e.currentTime);
                      if (t) return t.level;
                    }
                    return -1;
                  }
                },
                {
                  key: 'nextBufferedFrag',
                  get: function() {
                    var e = this.media;
                    return e
                      ? this.followingBufferedFrag(
                          this.getBufferedFrag(e.currentTime)
                        )
                      : null;
                  }
                },
                {
                  key: 'nextLevel',
                  get: function() {
                    var e = this.nextBufferedFrag;
                    return e ? e.level : -1;
                  }
                },
                {
                  key: 'liveSyncPosition',
                  get: function() {
                    return this._liveSyncPosition;
                  },
                  set: function(e) {
                    this._liveSyncPosition = e;
                  }
                }
              ]) && Ce(a.prototype, s),
              c && Ce(a, c),
              i
            );
          })(Oe);
        function xe(e, t) {
          for (var r = 0; r < t.length; r++) {
            var i = t[r];
            (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              'value' in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        var Me = (function(e) {
            var t, r;
            function i(t) {
              var r;
              return (
                ((r =
                  e.call(
                    this,
                    t,
                    u.a.MANIFEST_LOADED,
                    u.a.LEVEL_LOADED,
                    u.a.AUDIO_TRACK_SWITCHED,
                    u.a.FRAG_LOADED,
                    u.a.ERROR
                  ) || this).canload = !1),
                (r.currentLevelIndex = null),
                (r.manualLevelIndex = -1),
                (r.timer = null),
                (Ie = /chrome|firefox/.test(navigator.userAgent.toLowerCase())),
                r
              );
            }
            (r = e),
              ((t = i).prototype = Object.create(r.prototype)),
              (t.prototype.constructor = t),
              (t.__proto__ = r);
            var a,
              n,
              s,
              l = i.prototype;
            return (
              (l.onHandlerDestroying = function() {
                this.clearTimer(), (this.manualLevelIndex = -1);
              }),
              (l.clearTimer = function() {
                null !== this.timer &&
                  (clearTimeout(this.timer), (this.timer = null));
              }),
              (l.startLoad = function() {
                var e = this._levels;
                (this.canload = !0),
                  (this.levelRetryCount = 0),
                  e &&
                    e.forEach(function(e) {
                      e.loadError = 0;
                      var t = e.details;
                      t && t.live && (e.details = void 0);
                    }),
                  null !== this.timer && this.loadLevel();
              }),
              (l.stopLoad = function() {
                this.canload = !1;
              }),
              (l.onManifestLoaded = function(e) {
                var t,
                  r = [],
                  i = [],
                  a = {},
                  n = null,
                  s = !1,
                  l = !1;
                if (
                  (e.levels.forEach(function(e) {
                    var t = e.attrs;
                    (e.loadError = 0),
                      (e.fragmentError = !1),
                      (s = s || !!e.videoCodec),
                      (l = l || !!e.audioCodec),
                      Ie &&
                        e.audioCodec &&
                        -1 !== e.audioCodec.indexOf('mp4a.40.34') &&
                        (e.audioCodec = void 0),
                      (n = a[e.bitrate])
                        ? n.url.push(e.url)
                        : ((e.url = [e.url]),
                          (e.urlId = 0),
                          (a[e.bitrate] = e),
                          r.push(e)),
                      t &&
                        (t.AUDIO && Z(n || e, 'audio', t.AUDIO),
                        t.SUBTITLES && Z(n || e, 'text', t.SUBTITLES));
                  }),
                  s &&
                    l &&
                    (r = r.filter(function(e) {
                      return !!e.videoCodec;
                    })),
                  (r = r.filter(function(e) {
                    var t = e.audioCodec,
                      r = e.videoCodec;
                    return (!t || A(t, 'audio')) && (!r || A(r, 'video'));
                  })),
                  e.audioTracks &&
                    (i = e.audioTracks.filter(function(e) {
                      return !e.audioCodec || A(e.audioCodec, 'audio');
                    })).forEach(function(e, t) {
                      e.id = t;
                    }),
                  r.length > 0)
                ) {
                  (t = r[0].bitrate),
                    r.sort(function(e, t) {
                      return e.bitrate - t.bitrate;
                    }),
                    (this._levels = r);
                  for (var c = 0; c < r.length; c++)
                    if (r[c].bitrate === t) {
                      (this._firstLevel = c),
                        d.b.log(
                          'manifest loaded,' +
                            r.length +
                            ' level(s) found, first bitrate:' +
                            t
                        );
                      break;
                    }
                  var h = l && !s;
                  this.hls.trigger(u.a.MANIFEST_PARSED, {
                    levels: r,
                    audioTracks: i,
                    firstLevel: this._firstLevel,
                    stats: e.stats,
                    audio: l,
                    video: s,
                    altAudio:
                      !h &&
                      i.some(function(e) {
                        return !!e.url;
                      })
                  });
                } else
                  this.hls.trigger(u.a.ERROR, {
                    type: o.b.MEDIA_ERROR,
                    details: o.a.MANIFEST_INCOMPATIBLE_CODECS_ERROR,
                    fatal: !0,
                    url: this.hls.url,
                    reason: 'no level with compatible codecs found in manifest'
                  });
              }),
              (l.setLevelInternal = function(e) {
                var t = this._levels,
                  r = this.hls;
                if (e >= 0 && e < t.length) {
                  if ((this.clearTimer(), this.currentLevelIndex !== e)) {
                    d.b.log('switching to level ' + e),
                      (this.currentLevelIndex = e);
                    var i = t[e];
                    (i.level = e), r.trigger(u.a.LEVEL_SWITCHING, i);
                  }
                  var a = t[e],
                    n = a.details;
                  if (!n || n.live) {
                    var s = a.urlId;
                    r.trigger(u.a.LEVEL_LOADING, {
                      url: a.url[s],
                      level: e,
                      id: s
                    });
                  }
                } else
                  r.trigger(u.a.ERROR, {
                    type: o.b.OTHER_ERROR,
                    details: o.a.LEVEL_SWITCH_ERROR,
                    level: e,
                    fatal: !1,
                    reason: 'invalid level idx'
                  });
              }),
              (l.onError = function(e) {
                if (e.fatal) e.type === o.b.NETWORK_ERROR && this.clearTimer();
                else {
                  var t,
                    r = !1,
                    i = !1;
                  switch (e.details) {
                    case o.a.FRAG_LOAD_ERROR:
                    case o.a.FRAG_LOAD_TIMEOUT:
                    case o.a.KEY_LOAD_ERROR:
                    case o.a.KEY_LOAD_TIMEOUT:
                      (t = e.frag.level), (i = !0);
                      break;
                    case o.a.LEVEL_LOAD_ERROR:
                    case o.a.LEVEL_LOAD_TIMEOUT:
                      (t = e.context.level), (r = !0);
                      break;
                    case o.a.REMUX_ALLOC_ERROR:
                      (t = e.level), (r = !0);
                  }
                  void 0 !== t && this.recoverLevel(e, t, r, i);
                }
              }),
              (l.recoverLevel = function(e, t, r, i) {
                var a,
                  n,
                  s,
                  o = this,
                  l = this.hls.config,
                  u = e.details,
                  c = this._levels[t];
                if ((c.loadError++, (c.fragmentError = i), r)) {
                  if (!(this.levelRetryCount + 1 <= l.levelLoadingMaxRetry))
                    return (
                      d.b.error(
                        'level controller, cannot recover from ' + u + ' error'
                      ),
                      (this.currentLevelIndex = null),
                      this.clearTimer(),
                      void (e.fatal = !0)
                    );
                  (n = Math.min(
                    Math.pow(2, this.levelRetryCount) *
                      l.levelLoadingRetryDelay,
                    l.levelLoadingMaxRetryTimeout
                  )),
                    (this.timer = setTimeout(function() {
                      return o.loadLevel();
                    }, n)),
                    (e.levelRetry = !0),
                    this.levelRetryCount++,
                    d.b.warn(
                      'level controller, ' +
                        u +
                        ', retry in ' +
                        n +
                        ' ms, current retry count is ' +
                        this.levelRetryCount
                    );
                }
                (r || i) &&
                  ((a = c.url.length) > 1 && c.loadError < a
                    ? ((c.urlId = (c.urlId + 1) % a),
                      (c.details = void 0),
                      d.b.warn(
                        'level controller, ' +
                          u +
                          ' for level ' +
                          t +
                          ': switching to redundant URL-id ' +
                          c.urlId
                      ))
                    : -1 === this.manualLevelIndex
                    ? ((s = 0 === t ? this._levels.length - 1 : t - 1),
                      d.b.warn('level controller, ' + u + ': switch to ' + s),
                      (this.hls.nextAutoLevel = this.currentLevelIndex = s))
                    : i &&
                      (d.b.warn(
                        'level controller, ' + u + ': reload a fragment'
                      ),
                      (this.currentLevelIndex = null)));
              }),
              (l.onFragLoaded = function(e) {
                var t = e.frag;
                if (void 0 !== t && 'main' === t.type) {
                  var r = this._levels[t.level];
                  void 0 !== r &&
                    ((r.fragmentError = !1),
                    (r.loadError = 0),
                    (this.levelRetryCount = 0));
                }
              }),
              (l.onLevelLoaded = function(e) {
                var t = this,
                  r = e.level,
                  i = e.details;
                if (r === this.currentLevelIndex) {
                  var a = this._levels[r];
                  if (
                    (a.fragmentError ||
                      ((a.loadError = 0), (this.levelRetryCount = 0)),
                    i.live)
                  ) {
                    var n = ae(a.details, i, e.stats.trequest);
                    d.b.log(
                      'live playlist, reload in ' + Math.round(n) + ' ms'
                    ),
                      (this.timer = setTimeout(function() {
                        return t.loadLevel();
                      }, n));
                  } else this.clearTimer();
                }
              }),
              (l.onAudioTrackSwitched = function(e) {
                var t = this.hls.audioTracks[e.id].groupId,
                  r = this.hls.levels[this.currentLevelIndex];
                if (r && r.audioGroupIds) {
                  for (var i = -1, a = 0; a < r.audioGroupIds.length; a++)
                    if (r.audioGroupIds[a] === t) {
                      i = a;
                      break;
                    }
                  i !== r.urlId && ((r.urlId = i), this.startLoad());
                }
              }),
              (l.loadLevel = function() {
                if (
                  (d.b.debug('call to loadLevel'),
                  null !== this.currentLevelIndex && this.canload)
                ) {
                  var e = this._levels[this.currentLevelIndex];
                  if ('object' == typeof e && e.url.length > 0) {
                    var t = this.currentLevelIndex,
                      r = e.urlId,
                      i = e.url[r];
                    d.b.log(
                      'Attempt loading level index ' + t + ' with URL-id ' + r
                    ),
                      this.hls.trigger(u.a.LEVEL_LOADING, {
                        url: i,
                        level: t,
                        id: r
                      });
                  }
                }
              }),
              (l.removeLevel = function(e, t) {
                var r = this.levels
                  .filter(function(r, i) {
                    return (
                      i !== e ||
                      (r.url.length > 1 &&
                        void 0 !== t &&
                        ((r.url = r.url.filter(function(e, r) {
                          return r !== t;
                        })),
                        (r.urlId = 0),
                        !0))
                    );
                  })
                  .map(function(e, t) {
                    var r = e.details;
                    return (
                      r &&
                        r.fragments &&
                        r.fragments.forEach(function(e) {
                          e.level = t;
                        }),
                      e
                    );
                  });
                (this._levels = r),
                  this.hls.trigger(u.a.LEVELS_UPDATED, { levels: r });
              }),
              (a = i),
              (n = [
                {
                  key: 'levels',
                  get: function() {
                    return this._levels;
                  }
                },
                {
                  key: 'level',
                  get: function() {
                    return this.currentLevelIndex;
                  },
                  set: function(e) {
                    var t = this._levels;
                    t &&
                      ((e = Math.min(e, t.length - 1)),
                      (this.currentLevelIndex === e && t[e].details) ||
                        this.setLevelInternal(e));
                  }
                },
                {
                  key: 'manualLevel',
                  get: function() {
                    return this.manualLevelIndex;
                  },
                  set: function(e) {
                    (this.manualLevelIndex = e),
                      void 0 === this._startLevel && (this._startLevel = e),
                      -1 !== e && (this.level = e);
                  }
                },
                {
                  key: 'firstLevel',
                  get: function() {
                    return this._firstLevel;
                  },
                  set: function(e) {
                    this._firstLevel = e;
                  }
                },
                {
                  key: 'startLevel',
                  get: function() {
                    if (void 0 === this._startLevel) {
                      var e = this.hls.config.startLevel;
                      return void 0 !== e ? e : this._firstLevel;
                    }
                    return this._startLevel;
                  },
                  set: function(e) {
                    this._startLevel = e;
                  }
                },
                {
                  key: 'nextLoadLevel',
                  get: function() {
                    return -1 !== this.manualLevelIndex
                      ? this.manualLevelIndex
                      : this.hls.nextAutoLevel;
                  },
                  set: function(e) {
                    (this.level = e),
                      -1 === this.manualLevelIndex &&
                        (this.hls.nextAutoLevel = e);
                  }
                }
              ]) && xe(a.prototype, n),
              s && xe(a, s),
              i
            );
          })(h),
          Fe = r(4);
        function Ue(e, t) {
          var r;
          try {
            r = new Event('addtrack');
          } catch (e) {
            (r = document.createEvent('Event')).initEvent('addtrack', !1, !1);
          }
          (r.track = e), t.dispatchEvent(r);
        }
        function Ne(e) {
          if (null == e ? void 0 : e.cues)
            for (; e.cues.length > 0; ) e.removeCue(e.cues[0]);
        }
        var Be = (function(e) {
          var t, r;
          function i(t) {
            var r;
            return (
              ((r =
                e.call(
                  this,
                  t,
                  u.a.MEDIA_ATTACHED,
                  u.a.MEDIA_DETACHING,
                  u.a.FRAG_PARSING_METADATA,
                  u.a.LIVE_BACK_BUFFER_REACHED
                ) || this).id3Track = void 0),
              (r.media = void 0),
              r
            );
          }
          (r = e),
            ((t = i).prototype = Object.create(r.prototype)),
            (t.prototype.constructor = t),
            (t.__proto__ = r);
          var a = i.prototype;
          return (
            (a.destroy = function() {
              h.prototype.destroy.call(this);
            }),
            (a.onMediaAttached = function(e) {
              (this.media = e.media), this.media;
            }),
            (a.onMediaDetaching = function() {
              Ne(this.id3Track),
                (this.id3Track = void 0),
                (this.media = void 0);
            }),
            (a.getID3Track = function(e) {
              for (var t = 0; t < e.length; t++) {
                var r = e[t];
                if ('metadata' === r.kind && 'id3' === r.label)
                  return Ue(r, this.media), r;
              }
              return this.media.addTextTrack('metadata', 'id3');
            }),
            (a.onFragParsingMetadata = function(e) {
              var t = e.frag,
                r = e.samples;
              this.id3Track ||
                ((this.id3Track = this.getID3Track(this.media.textTracks)),
                (this.id3Track.mode = 'hidden'));
              for (
                var i =
                    window.WebKitDataCue ||
                    window.VTTCue ||
                    window.TextTrackCue,
                  a = 0;
                a < r.length;
                a++
              ) {
                var n = Fe.a.getID3Frames(r[a].data);
                if (n) {
                  var s = Math.max(r[a].pts, 0),
                    o = a < r.length - 1 ? r[a + 1].pts : t.endPTS;
                  o || (o = t.start + t.duration),
                    s === o
                      ? (o += 1e-4)
                      : s > o &&
                        (d.b.warn(
                          'detected an id3 sample with endTime < startTime, adjusting endTime to (startTime + 0.25)'
                        ),
                        (o = s + 0.25));
                  for (var l = 0; l < n.length; l++) {
                    var u = n[l];
                    if (!Fe.a.isTimeStampFrame(u)) {
                      var c = new i(s, o, '');
                      (c.value = u), this.id3Track.addCue(c);
                    }
                  }
                }
              }
            }),
            (a.onLiveBackBufferReached = function(e) {
              var t = e.bufferEnd,
                r = this.id3Track;
              if (r && r.cues && r.cues.length) {
                var i = (function(e, t) {
                  if (t < e[0].endTime) return e[0];
                  if (t > e[e.length - 1].endTime) return e[e.length - 1];
                  for (var r = 0, i = e.length - 1; r <= i; ) {
                    var a = Math.floor((i + r) / 2);
                    if (t < e[a].endTime) i = a - 1;
                    else {
                      if (!(t > e[a].endTime)) return e[a];
                      r = a + 1;
                    }
                  }
                  return e[r].endTime - t < t - e[i].endTime ? e[r] : e[i];
                })(r.cues, t);
                if (i) for (; r.cues[0] !== i; ) r.removeCue(r.cues[0]);
              }
            }),
            i
          );
        })(h);
        var Ge = (function() {
            function e(e) {
              (this.alpha_ = void 0),
                (this.estimate_ = void 0),
                (this.totalWeight_ = void 0),
                (this.alpha_ = e ? Math.exp(Math.log(0.5) / e) : 0),
                (this.estimate_ = 0),
                (this.totalWeight_ = 0);
            }
            var t = e.prototype;
            return (
              (t.sample = function(e, t) {
                var r = Math.pow(this.alpha_, e);
                (this.estimate_ = t * (1 - r) + r * this.estimate_),
                  (this.totalWeight_ += e);
              }),
              (t.getTotalWeight = function() {
                return this.totalWeight_;
              }),
              (t.getEstimate = function() {
                if (this.alpha_) {
                  var e = 1 - Math.pow(this.alpha_, this.totalWeight_);
                  return this.estimate_ / e;
                }
                return this.estimate_;
              }),
              e
            );
          })(),
          Ke = (function() {
            function e(e, t, r, i) {
              (this.hls = void 0),
                (this.defaultEstimate_ = void 0),
                (this.minWeight_ = void 0),
                (this.minDelayMs_ = void 0),
                (this.slow_ = void 0),
                (this.fast_ = void 0),
                (this.hls = e),
                (this.defaultEstimate_ = i),
                (this.minWeight_ = 0.001),
                (this.minDelayMs_ = 50),
                (this.slow_ = new Ge(t)),
                (this.fast_ = new Ge(r));
            }
            var t = e.prototype;
            return (
              (t.sample = function(e, t) {
                var r = (e = Math.max(e, this.minDelayMs_)) / 1e3,
                  i = (8 * t) / r;
                this.fast_.sample(r, i), this.slow_.sample(r, i);
              }),
              (t.canEstimate = function() {
                var e = this.fast_;
                return e && e.getTotalWeight() >= this.minWeight_;
              }),
              (t.getEstimate = function() {
                return this.canEstimate()
                  ? Math.min(this.fast_.getEstimate(), this.slow_.getEstimate())
                  : this.defaultEstimate_;
              }),
              (t.destroy = function() {}),
              e
            );
          })();
        function je(e, t) {
          for (var r = 0; r < t.length; r++) {
            var i = t[r];
            (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              'value' in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        var He = window.performance,
          Ve = (function(e) {
            var t, r;
            function i(t) {
              var r;
              return (
                ((r =
                  e.call(
                    this,
                    t,
                    u.a.FRAG_LOADING,
                    u.a.FRAG_LOADED,
                    u.a.FRAG_BUFFERED,
                    u.a.ERROR
                  ) || this).lastLoadedFragLevel = 0),
                (r._nextAutoLevel = -1),
                (r.hls = t),
                (r.timer = null),
                (r._bwEstimator = null),
                (r.onCheck = r._abandonRulesCheck.bind(
                  (function(e) {
                    if (void 0 === e)
                      throw new ReferenceError(
                        "this hasn't been initialised - super() hasn't been called"
                      );
                    return e;
                  })(r)
                )),
                r
              );
            }
            (r = e),
              ((t = i).prototype = Object.create(r.prototype)),
              (t.prototype.constructor = t),
              (t.__proto__ = r);
            var a,
              n,
              s,
              c = i.prototype;
            return (
              (c.destroy = function() {
                this.clearTimer(), h.prototype.destroy.call(this);
              }),
              (c.onFragLoading = function(e) {
                var t = e.frag;
                if (
                  'main' === t.type &&
                  (this.timer ||
                    ((this.fragCurrent = t),
                    (this.timer = setInterval(this.onCheck, 100))),
                  !this._bwEstimator)
                ) {
                  var r,
                    i,
                    a = this.hls,
                    n = a.config,
                    s = t.level;
                  a.levels[s].details.live
                    ? ((r = n.abrEwmaFastLive), (i = n.abrEwmaSlowLive))
                    : ((r = n.abrEwmaFastVoD), (i = n.abrEwmaSlowVoD)),
                    (this._bwEstimator = new Ke(
                      a,
                      i,
                      r,
                      n.abrEwmaDefaultEstimate
                    ));
                }
              }),
              (c._abandonRulesCheck = function() {
                var e = this.hls,
                  t = e.media,
                  r = this.fragCurrent;
                if (r) {
                  var i = r.loader;
                  if (!i || (i.stats && i.stats.aborted))
                    return (
                      d.b.warn(
                        'frag loader destroy or aborted, disarm abandonRules'
                      ),
                      this.clearTimer(),
                      void (this._nextAutoLevel = -1)
                    );
                  var a = i.stats;
                  if (
                    t &&
                    a &&
                    ((!t.paused && 0 !== t.playbackRate) || !t.readyState) &&
                    r.autoLevel &&
                    r.level
                  ) {
                    var n = He.now() - a.trequest,
                      s = Math.abs(t.playbackRate);
                    if (n > (500 * r.duration) / s) {
                      var o = e.levels,
                        l = Math.max(1, a.bw ? a.bw / 8 : (1e3 * a.loaded) / n),
                        c = o[r.level];
                      if (!c) return;
                      var h = c.realBitrate
                          ? Math.max(c.realBitrate, c.bitrate)
                          : c.bitrate,
                        f = a.total
                          ? a.total
                          : Math.max(
                              a.loaded,
                              Math.round((r.duration * h) / 8)
                            ),
                        g = t.currentTime,
                        p = (f - a.loaded) / l,
                        v =
                          (H.bufferInfo(t, g, e.config.maxBufferHole).end - g) /
                          s;
                      if (v < (2 * r.duration) / s && p > v) {
                        var m,
                          y = e.minAutoLevel;
                        for (m = r.level - 1; m > y; m--) {
                          var b = o[m].realBitrate
                            ? Math.max(o[m].realBitrate, o[m].bitrate)
                            : o[m].bitrate;
                          if ((r.duration * b) / (6.4 * l) < v) break;
                        }
                        void 0 < p &&
                          (d.b.warn(
                            'loading too slow, abort fragment loading and switch to level ' +
                              m +
                              ':fragLoadedDelay[' +
                              m +
                              ']<fragLoadedDelay[' +
                              (r.level - 1) +
                              '];bufferStarvationDelay:' +
                              (void 0).toFixed(1) +
                              '<' +
                              p.toFixed(1) +
                              ':' +
                              v.toFixed(1)
                          ),
                          (e.nextLoadLevel = m),
                          this._bwEstimator.sample(n, a.loaded),
                          i.abort(),
                          this.clearTimer(),
                          e.trigger(u.a.FRAG_LOAD_EMERGENCY_ABORTED, {
                            frag: r,
                            stats: a
                          }));
                      }
                    }
                  }
                }
              }),
              (c.onFragLoaded = function(e) {
                var t = e.frag;
                if ('main' === t.type && Object(l.a)(t.sn)) {
                  if (
                    (this.clearTimer(),
                    (this.lastLoadedFragLevel = t.level),
                    (this._nextAutoLevel = -1),
                    this.hls.config.abrMaxWithRealBitrate)
                  ) {
                    var r = this.hls.levels[t.level],
                      i = (r.loaded ? r.loaded.bytes : 0) + e.stats.loaded,
                      a = (r.loaded ? r.loaded.duration : 0) + e.frag.duration;
                    (r.loaded = { bytes: i, duration: a }),
                      (r.realBitrate = Math.round((8 * i) / a));
                  }
                  if (e.frag.bitrateTest) {
                    var n = e.stats;
                    (n.tparsed = n.tbuffered = n.tload), this.onFragBuffered(e);
                  }
                }
              }),
              (c.onFragBuffered = function(e) {
                var t = e.stats,
                  r = e.frag;
                if (
                  !0 !== t.aborted &&
                  'main' === r.type &&
                  Object(l.a)(r.sn) &&
                  (!r.bitrateTest || t.tload === t.tbuffered)
                ) {
                  var i = t.tparsed - t.trequest;
                  d.b.log(
                    'latency/loading/parsing/append/kbps:' +
                      Math.round(t.tfirst - t.trequest) +
                      '/' +
                      Math.round(t.tload - t.tfirst) +
                      '/' +
                      Math.round(t.tparsed - t.tload) +
                      '/' +
                      Math.round(t.tbuffered - t.tparsed) +
                      '/' +
                      Math.round((8 * t.loaded) / (t.tbuffered - t.trequest))
                  ),
                    this._bwEstimator.sample(i, t.loaded),
                    (t.bwEstimate = this._bwEstimator.getEstimate()),
                    r.bitrateTest
                      ? (this.bitrateTestDelay = i / 1e3)
                      : (this.bitrateTestDelay = 0);
                }
              }),
              (c.onError = function(e) {
                switch (e.details) {
                  case o.a.FRAG_LOAD_ERROR:
                  case o.a.FRAG_LOAD_TIMEOUT:
                    this.clearTimer();
                }
              }),
              (c.clearTimer = function() {
                clearInterval(this.timer), (this.timer = null);
              }),
              (c._findBestLevel = function(e, t, r, i, a, n, s, o, l) {
                for (var u = a; u >= i; u--) {
                  var c = l[u];
                  if (c) {
                    var h = c.details,
                      f = h ? h.totalduration / h.fragments.length : t,
                      g = !!h && h.live,
                      p = void 0;
                    p = u <= e ? s * r : o * r;
                    var v = l[u].realBitrate
                        ? Math.max(l[u].realBitrate, l[u].bitrate)
                        : l[u].bitrate,
                      m = (v * f) / p;
                    if (
                      (d.b.trace(
                        'level/adjustedbw/bitrate/avgDuration/maxFetchDuration/fetchDuration: ' +
                          u +
                          '/' +
                          Math.round(p) +
                          '/' +
                          v +
                          '/' +
                          f +
                          '/' +
                          n +
                          '/' +
                          m
                      ),
                      p > v && (!m || (g && !this.bitrateTestDelay) || m < n))
                    )
                      return u;
                  }
                }
                return -1;
              }),
              (a = i),
              (n = [
                {
                  key: 'nextAutoLevel',
                  get: function() {
                    var e = this._nextAutoLevel,
                      t = this._bwEstimator;
                    if (!(-1 === e || (t && t.canEstimate()))) return e;
                    var r = this._nextABRAutoLevel;
                    return -1 !== e && (r = Math.min(e, r)), r;
                  },
                  set: function(e) {
                    this._nextAutoLevel = e;
                  }
                },
                {
                  key: '_nextABRAutoLevel',
                  get: function() {
                    var e = this.hls,
                      t = e.maxAutoLevel,
                      r = e.levels,
                      i = e.config,
                      a = e.minAutoLevel,
                      n = e.media,
                      s = this.lastLoadedFragLevel,
                      o = this.fragCurrent ? this.fragCurrent.duration : 0,
                      l = n ? n.currentTime : 0,
                      u =
                        n && 0 !== n.playbackRate
                          ? Math.abs(n.playbackRate)
                          : 1,
                      c = this._bwEstimator
                        ? this._bwEstimator.getEstimate()
                        : i.abrEwmaDefaultEstimate,
                      h = (H.bufferInfo(n, l, i.maxBufferHole).end - l) / u,
                      f = this._findBestLevel(
                        s,
                        o,
                        c,
                        a,
                        t,
                        h,
                        i.abrBandWidthFactor,
                        i.abrBandWidthUpFactor,
                        r
                      );
                    if (f >= 0) return f;
                    d.b.trace(
                      'rebuffering expected to happen, lets try to find a quality level minimizing the rebuffering'
                    );
                    var g = o
                        ? Math.min(o, i.maxStarvationDelay)
                        : i.maxStarvationDelay,
                      p = i.abrBandWidthFactor,
                      v = i.abrBandWidthUpFactor;
                    if (0 === h) {
                      var m = this.bitrateTestDelay;
                      m &&
                        ((g =
                          (o
                            ? Math.min(o, i.maxLoadingDelay)
                            : i.maxLoadingDelay) - m),
                        d.b.trace(
                          'bitrate test took ' +
                            Math.round(1e3 * m) +
                            'ms, set first fragment max fetchDuration to ' +
                            Math.round(1e3 * g) +
                            ' ms'
                        ),
                        (p = v = 1));
                    }
                    return (
                      (f = this._findBestLevel(s, o, c, a, t, h + g, p, v, r)),
                      Math.max(f, 0)
                    );
                  }
                }
              ]) && je(a.prototype, n),
              s && je(a, s),
              i
            );
          })(h);
        var Ye = q(),
          We = (function(e) {
            var t, r;
            function i(t) {
              var r;
              return (
                ((r =
                  e.call(
                    this,
                    t,
                    u.a.MEDIA_ATTACHING,
                    u.a.MEDIA_DETACHING,
                    u.a.MANIFEST_PARSED,
                    u.a.BUFFER_RESET,
                    u.a.BUFFER_APPENDING,
                    u.a.BUFFER_CODECS,
                    u.a.BUFFER_EOS,
                    u.a.BUFFER_FLUSHING,
                    u.a.LEVEL_PTS_UPDATED,
                    u.a.LEVEL_UPDATED
                  ) || this)._msDuration = null),
                (r._levelDuration = null),
                (r._levelTargetDuration = 10),
                (r._live = null),
                (r._objectUrl = null),
                (r._needsFlush = !1),
                (r._needsEos = !1),
                (r.config = void 0),
                (r.audioTimestampOffset = void 0),
                (r.bufferCodecEventsExpected = 0),
                (r._bufferCodecEventsTotal = 0),
                (r.media = null),
                (r.mediaSource = null),
                (r.segments = []),
                (r.parent = void 0),
                (r.appending = !1),
                (r.appended = 0),
                (r.appendError = 0),
                (r.flushBufferCounter = 0),
                (r.tracks = {}),
                (r.pendingTracks = {}),
                (r.sourceBuffer = {}),
                (r.flushRange = []),
                (r._onMediaSourceOpen = function() {
                  d.b.log('media source opened'),
                    r.hls.trigger(u.a.MEDIA_ATTACHED, { media: r.media });
                  var e = r.mediaSource;
                  e &&
                    e.removeEventListener('sourceopen', r._onMediaSourceOpen),
                    r.checkPendingTracks();
                }),
                (r._onMediaSourceClose = function() {
                  d.b.log('media source closed');
                }),
                (r._onMediaSourceEnded = function() {
                  d.b.log('media source ended');
                }),
                (r._onSBUpdateEnd = function() {
                  if (r.audioTimestampOffset && r.sourceBuffer.audio) {
                    var e = r.sourceBuffer.audio;
                    d.b.warn(
                      'change mpeg audio timestamp offset from ' +
                        e.timestampOffset +
                        ' to ' +
                        r.audioTimestampOffset
                    ),
                      (e.timestampOffset = r.audioTimestampOffset),
                      delete r.audioTimestampOffset;
                  }
                  r._needsFlush && r.doFlush(),
                    r._needsEos && r.checkEos(),
                    (r.appending = !1);
                  var t = r.parent,
                    i = r.segments.reduce(function(e, r) {
                      return r.parent === t ? e + 1 : e;
                    }, 0),
                    a = {},
                    n = r.sourceBuffer;
                  for (var s in n) {
                    var o = n[s];
                    if (!o)
                      throw Error(
                        'handling source buffer update end error: source buffer for ' +
                          s +
                          ' uninitilized and unable to update buffered TimeRanges.'
                      );
                    a[s] = o.buffered;
                  }
                  r.hls.trigger(u.a.BUFFER_APPENDED, {
                    parent: t,
                    pending: i,
                    timeRanges: a
                  }),
                    r._needsFlush || r.doAppending(),
                    r.updateMediaElementDuration(),
                    0 === i && r.flushLiveBackBuffer();
                }),
                (r._onSBUpdateError = function(e) {
                  d.b.error('sourceBuffer error:', e),
                    r.hls.trigger(u.a.ERROR, {
                      type: o.b.MEDIA_ERROR,
                      details: o.a.BUFFER_APPENDING_ERROR,
                      fatal: !1
                    });
                }),
                (r.config = t.config),
                r
              );
            }
            (r = e),
              ((t = i).prototype = Object.create(r.prototype)),
              (t.prototype.constructor = t),
              (t.__proto__ = r);
            var a = i.prototype;
            return (
              (a.destroy = function() {
                h.prototype.destroy.call(this);
              }),
              (a.onLevelPtsUpdated = function(e) {
                var t = e.type,
                  r = this.tracks.audio;
                if ('audio' === t && r && 'audio/mpeg' === r.container) {
                  var i = this.sourceBuffer.audio;
                  if (!i)
                    throw Error(
                      'Level PTS Updated and source buffer for audio uninitalized'
                    );
                  if (Math.abs(i.timestampOffset - e.start) > 0.1) {
                    var a = i.updating;
                    try {
                      i.abort();
                    } catch (e) {
                      d.b.warn('can not abort audio buffer: ' + e);
                    }
                    a
                      ? (this.audioTimestampOffset = e.start)
                      : (d.b.warn(
                          'change mpeg audio timestamp offset from ' +
                            i.timestampOffset +
                            ' to ' +
                            e.start
                        ),
                        (i.timestampOffset = e.start));
                  }
                }
              }),
              (a.onManifestParsed = function(e) {
                var t = 2;
                ((e.audio && !e.video) || !e.altAudio) && (t = 1),
                  (this.bufferCodecEventsExpected = this._bufferCodecEventsTotal = t),
                  d.b.log(
                    this.bufferCodecEventsExpected +
                      ' bufferCodec event(s) expected'
                  );
              }),
              (a.onMediaAttaching = function(e) {
                var t = (this.media = e.media);
                if (t && Ye) {
                  var r = (this.mediaSource = new Ye());
                  r.addEventListener('sourceopen', this._onMediaSourceOpen),
                    r.addEventListener('sourceended', this._onMediaSourceEnded),
                    r.addEventListener('sourceclose', this._onMediaSourceClose),
                    (t.src = window.URL.createObjectURL(r)),
                    (this._objectUrl = t.src);
                }
              }),
              (a.onMediaDetaching = function() {
                d.b.log('media source detaching');
                var e = this.mediaSource;
                if (e) {
                  if ('open' === e.readyState)
                    try {
                      e.endOfStream();
                    } catch (e) {
                      d.b.warn(
                        'onMediaDetaching:' +
                          e.message +
                          ' while calling endOfStream'
                      );
                    }
                  e.removeEventListener('sourceopen', this._onMediaSourceOpen),
                    e.removeEventListener(
                      'sourceended',
                      this._onMediaSourceEnded
                    ),
                    e.removeEventListener(
                      'sourceclose',
                      this._onMediaSourceClose
                    ),
                    this.media &&
                      (this._objectUrl &&
                        window.URL.revokeObjectURL(this._objectUrl),
                      this.media.src === this._objectUrl
                        ? (this.media.removeAttribute('src'), this.media.load())
                        : d.b.warn(
                            'media.src was changed by a third party - skip cleanup'
                          )),
                    (this.mediaSource = null),
                    (this.media = null),
                    (this._objectUrl = null),
                    (this.bufferCodecEventsExpected = this._bufferCodecEventsTotal),
                    (this.pendingTracks = {}),
                    (this.tracks = {}),
                    (this.sourceBuffer = {}),
                    (this.flushRange = []),
                    (this.segments = []),
                    (this.appended = 0);
                }
                this.hls.trigger(u.a.MEDIA_DETACHED);
              }),
              (a.checkPendingTracks = function() {
                var e = this.bufferCodecEventsExpected,
                  t = this.pendingTracks,
                  r = Object.keys(t).length;
                ((r && !e) || 2 === r) &&
                  (this.createSourceBuffers(t),
                  (this.pendingTracks = {}),
                  this.doAppending());
              }),
              (a.onBufferReset = function() {
                var e = this.sourceBuffer;
                for (var t in e) {
                  var r = e[t];
                  try {
                    r &&
                      (this.mediaSource &&
                        this.mediaSource.removeSourceBuffer(r),
                      r.removeEventListener('updateend', this._onSBUpdateEnd),
                      r.removeEventListener('error', this._onSBUpdateError));
                  } catch (e) {}
                }
                (this.sourceBuffer = {}),
                  (this.flushRange = []),
                  (this.segments = []),
                  (this.appended = 0);
              }),
              (a.onBufferCodecs = function(e) {
                var t = this;
                Object.keys(this.sourceBuffer).length ||
                  (Object.keys(e).forEach(function(r) {
                    t.pendingTracks[r] = e[r];
                  }),
                  (this.bufferCodecEventsExpected = Math.max(
                    this.bufferCodecEventsExpected - 1,
                    0
                  )),
                  this.mediaSource &&
                    'open' === this.mediaSource.readyState &&
                    this.checkPendingTracks());
              }),
              (a.createSourceBuffers = function(e) {
                var t = this.sourceBuffer,
                  r = this.mediaSource;
                if (!r)
                  throw Error(
                    'createSourceBuffers called when mediaSource was null'
                  );
                for (var i in e)
                  if (!t[i]) {
                    var a = e[i];
                    if (!a)
                      throw Error(
                        'source buffer exists for track ' +
                          i +
                          ', however track does not'
                      );
                    var n = a.levelCodec || a.codec,
                      s = a.container + ';codecs=' + n;
                    d.b.log('creating sourceBuffer(' + s + ')');
                    try {
                      var l = (t[i] = r.addSourceBuffer(s));
                      l.addEventListener('updateend', this._onSBUpdateEnd),
                        l.addEventListener('error', this._onSBUpdateError),
                        (this.tracks[i] = {
                          buffer: l,
                          codec: n,
                          id: a.id,
                          container: a.container,
                          levelCodec: a.levelCodec
                        });
                    } catch (e) {
                      d.b.error(
                        'error while trying to add sourceBuffer:' + e.message
                      ),
                        this.hls.trigger(u.a.ERROR, {
                          type: o.b.MEDIA_ERROR,
                          details: o.a.BUFFER_ADD_CODEC_ERROR,
                          fatal: !1,
                          err: e,
                          mimeType: s
                        });
                    }
                  }
                this.hls.trigger(u.a.BUFFER_CREATED, { tracks: this.tracks });
              }),
              (a.onBufferAppending = function(e) {
                this._needsFlush ||
                  (this.segments
                    ? this.segments.push(e)
                    : (this.segments = [e]),
                  this.doAppending());
              }),
              (a.onBufferEos = function(e) {
                for (var t in this.sourceBuffer)
                  if (!e.type || e.type === t) {
                    var r = this.sourceBuffer[t];
                    r &&
                      !r.ended &&
                      ((r.ended = !0), d.b.log(t + ' sourceBuffer now EOS'));
                  }
                this.checkEos();
              }),
              (a.checkEos = function() {
                var e = this.sourceBuffer,
                  t = this.mediaSource;
                if (t && 'open' === t.readyState) {
                  for (var r in e) {
                    var i = e[r];
                    if (i) {
                      if (!i.ended) return;
                      if (i.updating) return void (this._needsEos = !0);
                    }
                  }
                  d.b.log(
                    'all media data are available, signal endOfStream() to MediaSource and stop loading fragment'
                  );
                  try {
                    t.endOfStream();
                  } catch (e) {
                    d.b.warn(
                      'exception while calling mediaSource.endOfStream()'
                    );
                  }
                  this._needsEos = !1;
                } else this._needsEos = !1;
              }),
              (a.onBufferFlushing = function(e) {
                e.type
                  ? this.flushRange.push({
                      start: e.startOffset,
                      end: e.endOffset,
                      type: e.type
                    })
                  : (this.flushRange.push({
                      start: e.startOffset,
                      end: e.endOffset,
                      type: 'video'
                    }),
                    this.flushRange.push({
                      start: e.startOffset,
                      end: e.endOffset,
                      type: 'audio'
                    })),
                  (this.flushBufferCounter = 0),
                  this.doFlush();
              }),
              (a.flushLiveBackBuffer = function() {
                if (this._live) {
                  var e = this.config.liveBackBufferLength;
                  if (isFinite(e) && !(e < 0))
                    if (this.media)
                      for (
                        var t = this.media.currentTime,
                          r = this.sourceBuffer,
                          i = Object.keys(r),
                          a = t - Math.max(e, this._levelTargetDuration),
                          n = i.length - 1;
                        n >= 0;
                        n--
                      ) {
                        var s = i[n],
                          o = r[s];
                        if (o) {
                          var l = o.buffered;
                          l.length > 0 &&
                            a > l.start(0) &&
                            this.removeBufferRange(s, o, 0, a) &&
                            this.hls.trigger(u.a.LIVE_BACK_BUFFER_REACHED, {
                              bufferEnd: a
                            });
                        }
                      }
                    else
                      d.b.error(
                        'flushLiveBackBuffer called without attaching media'
                      );
                }
              }),
              (a.onLevelUpdated = function(e) {
                var t = e.details;
                t.fragments.length > 0 &&
                  ((this._levelDuration =
                    t.totalduration + t.fragments[0].start),
                  (this._levelTargetDuration =
                    t.averagetargetduration || t.targetduration || 10),
                  (this._live = t.live),
                  this.updateMediaElementDuration());
              }),
              (a.updateMediaElementDuration = function() {
                var e,
                  t = this.config;
                if (
                  null !== this._levelDuration &&
                  this.media &&
                  this.mediaSource &&
                  this.sourceBuffer &&
                  0 !== this.media.readyState &&
                  'open' === this.mediaSource.readyState
                ) {
                  for (var r in this.sourceBuffer) {
                    var i = this.sourceBuffer[r];
                    if (i && !0 === i.updating) return;
                  }
                  (e = this.media.duration),
                    null === this._msDuration &&
                      (this._msDuration = this.mediaSource.duration),
                    !0 === this._live && !0 === t.liveDurationInfinity
                      ? (d.b.log('Media Source duration is set to Infinity'),
                        (this._msDuration = this.mediaSource.duration = 1 / 0))
                      : ((this._levelDuration > this._msDuration &&
                          this._levelDuration > e) ||
                          !Object(l.a)(e)) &&
                        (d.b.log(
                          'Updating Media Source duration to ' +
                            this._levelDuration.toFixed(3)
                        ),
                        (this._msDuration = this.mediaSource.duration = this._levelDuration));
                }
              }),
              (a.doFlush = function() {
                for (; this.flushRange.length; ) {
                  var e = this.flushRange[0];
                  if (!this.flushBuffer(e.start, e.end, e.type))
                    return void (this._needsFlush = !0);
                  this.flushRange.shift(), (this.flushBufferCounter = 0);
                }
                if (0 === this.flushRange.length) {
                  this._needsFlush = !1;
                  var t = 0,
                    r = this.sourceBuffer;
                  try {
                    for (var i in r) {
                      var a = r[i];
                      a && (t += a.buffered.length);
                    }
                  } catch (e) {
                    d.b.error('error while accessing sourceBuffer.buffered');
                  }
                  (this.appended = t), this.hls.trigger(u.a.BUFFER_FLUSHED);
                }
              }),
              (a.doAppending = function() {
                var e = this.config,
                  t = this.hls,
                  r = this.segments,
                  i = this.sourceBuffer;
                if (Object.keys(i).length) {
                  if (!this.media || this.media.error)
                    return (
                      (this.segments = []),
                      void d.b.error(
                        'trying to append although a media error occured, flush segment and abort'
                      )
                    );
                  if (!this.appending) {
                    var a = r.shift();
                    if (a)
                      try {
                        var n = i[a.type];
                        if (!n) return void this._onSBUpdateEnd();
                        if (n.updating) return void r.unshift(a);
                        (n.ended = !1),
                          (this.parent = a.parent),
                          n.appendBuffer(a.data),
                          (this.appendError = 0),
                          this.appended++,
                          (this.appending = !0);
                      } catch (i) {
                        d.b.error(
                          'error while trying to append buffer:' + i.message
                        ),
                          r.unshift(a);
                        var s = {
                          type: o.b.MEDIA_ERROR,
                          parent: a.parent,
                          details: '',
                          fatal: !1
                        };
                        22 === i.code
                          ? ((this.segments = []),
                            (s.details = o.a.BUFFER_FULL_ERROR))
                          : (this.appendError++,
                            (s.details = o.a.BUFFER_APPEND_ERROR),
                            this.appendError > e.appendErrorMaxRetry &&
                              (d.b.log(
                                'fail ' +
                                  e.appendErrorMaxRetry +
                                  ' times to append segment in sourceBuffer'
                              ),
                              (this.segments = []),
                              (s.fatal = !0))),
                          t.trigger(u.a.ERROR, s);
                      }
                  }
                }
              }),
              (a.flushBuffer = function(e, t, r) {
                var i = this.sourceBuffer;
                if (!Object.keys(i).length) return !0;
                var a = 'null';
                if (
                  (this.media && (a = this.media.currentTime.toFixed(3)),
                  d.b.log(
                    'flushBuffer,pos/start/end: ' + a + '/' + e + '/' + t
                  ),
                  this.flushBufferCounter >= this.appended)
                )
                  return d.b.warn('abort flushing too many retries'), !0;
                var n = i[r];
                if (n) {
                  if (((n.ended = !1), n.updating))
                    return (
                      d.b.warn('cannot flush, sb updating in progress'), !1
                    );
                  if (this.removeBufferRange(r, n, e, t))
                    return this.flushBufferCounter++, !1;
                }
                return d.b.log('buffer flushed'), !0;
              }),
              (a.removeBufferRange = function(e, t, r, i) {
                try {
                  for (var a = 0; a < t.buffered.length; a++) {
                    var n = t.buffered.start(a),
                      s = t.buffered.end(a),
                      o = Math.max(n, r),
                      l = Math.min(s, i);
                    if (Math.min(l, s) - o > 0.5) {
                      var u = 'null';
                      return (
                        this.media && (u = this.media.currentTime.toString()),
                        d.b.log(
                          'sb remove ' +
                            e +
                            ' [' +
                            o +
                            ',' +
                            l +
                            '], of [' +
                            n +
                            ',' +
                            s +
                            '], pos:' +
                            u
                        ),
                        t.remove(o, l),
                        !0
                      );
                    }
                  }
                } catch (e) {
                  d.b.warn('removeBufferRange failed', e);
                }
                return !1;
              }),
              i
            );
          })(h);
        function qe(e, t) {
          for (var r = 0; r < t.length; r++) {
            var i = t[r];
            (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              'value' in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        var Xe = (function(e) {
          var t, r;
          function i(t) {
            var r;
            return (
              ((r =
                e.call(
                  this,
                  t,
                  u.a.FPS_DROP_LEVEL_CAPPING,
                  u.a.MEDIA_ATTACHING,
                  u.a.MANIFEST_PARSED,
                  u.a.LEVELS_UPDATED,
                  u.a.BUFFER_CODECS,
                  u.a.MEDIA_DETACHING
                ) || this).autoLevelCapping = Number.POSITIVE_INFINITY),
              (r.firstLevel = null),
              (r.levels = []),
              (r.media = null),
              (r.restrictedLevels = []),
              (r.timer = null),
              (r.clientRect = null),
              r
            );
          }
          (r = e),
            ((t = i).prototype = Object.create(r.prototype)),
            (t.prototype.constructor = t),
            (t.__proto__ = r);
          var a,
            n,
            s,
            o = i.prototype;
          return (
            (o.destroy = function() {
              this.hls.config.capLevelToPlayerSize &&
                ((this.media = null),
                (this.clientRect = null),
                this.stopCapping());
            }),
            (o.onFpsDropLevelCapping = function(e) {
              i.isLevelAllowed(e.droppedLevel, this.restrictedLevels) &&
                this.restrictedLevels.push(e.droppedLevel);
            }),
            (o.onMediaAttaching = function(e) {
              this.media =
                e.media instanceof window.HTMLVideoElement ? e.media : null;
            }),
            (o.onManifestParsed = function(e) {
              var t = this.hls;
              (this.restrictedLevels = []),
                (this.levels = e.levels),
                (this.firstLevel = e.firstLevel),
                t.config.capLevelToPlayerSize && e.video && this.startCapping();
            }),
            (o.onBufferCodecs = function(e) {
              this.hls.config.capLevelToPlayerSize &&
                e.video &&
                this.startCapping();
            }),
            (o.onLevelsUpdated = function(e) {
              this.levels = e.levels;
            }),
            (o.onMediaDetaching = function() {
              this.stopCapping();
            }),
            (o.detectPlayerSize = function() {
              if (this.media) {
                var e = this.levels ? this.levels.length : 0;
                if (e) {
                  var t = this.hls;
                  (t.autoLevelCapping = this.getMaxLevel(e - 1)),
                    t.autoLevelCapping > this.autoLevelCapping &&
                      t.streamController.nextLevelSwitch(),
                    (this.autoLevelCapping = t.autoLevelCapping);
                }
              }
            }),
            (o.getMaxLevel = function(e) {
              var t = this;
              if (!this.levels) return -1;
              var r = this.levels.filter(function(r, a) {
                return i.isLevelAllowed(a, t.restrictedLevels) && a <= e;
              });
              return (
                (this.clientRect = null),
                i.getMaxLevelByMediaSize(r, this.mediaWidth, this.mediaHeight)
              );
            }),
            (o.startCapping = function() {
              this.timer ||
                ((this.autoLevelCapping = Number.POSITIVE_INFINITY),
                (this.hls.firstLevel = this.getMaxLevel(this.firstLevel)),
                clearInterval(this.timer),
                (this.timer = setInterval(
                  this.detectPlayerSize.bind(this),
                  1e3
                )),
                this.detectPlayerSize());
            }),
            (o.stopCapping = function() {
              (this.restrictedLevels = []),
                (this.firstLevel = null),
                (this.autoLevelCapping = Number.POSITIVE_INFINITY),
                this.timer &&
                  ((this.timer = clearInterval(this.timer)),
                  (this.timer = null));
            }),
            (o.getDimensions = function() {
              if (this.clientRect) return this.clientRect;
              var e = this.media,
                t = { width: 0, height: 0 };
              if (e) {
                var r = e.getBoundingClientRect();
                (t.width = r.width),
                  (t.height = r.height),
                  t.width ||
                    t.height ||
                    ((t.width = r.right - r.left || e.width || 0),
                    (t.height = r.bottom - r.top || e.height || 0));
              }
              return (this.clientRect = t), t;
            }),
            (i.isLevelAllowed = function(e, t) {
              return void 0 === t && (t = []), -1 === t.indexOf(e);
            }),
            (i.getMaxLevelByMediaSize = function(e, t, r) {
              if (!e || (e && !e.length)) return -1;
              for (var i, a, n = e.length - 1, s = 0; s < e.length; s += 1) {
                var o = e[s];
                if (
                  (o.width >= t || o.height >= r) &&
                  ((i = o),
                  !(a = e[s + 1]) ||
                    i.width !== a.width ||
                    i.height !== a.height)
                ) {
                  n = s;
                  break;
                }
              }
              return n;
            }),
            (a = i),
            (s = [
              {
                key: 'contentScaleFactor',
                get: function() {
                  var e = 1;
                  try {
                    e = window.devicePixelRatio;
                  } catch (e) {}
                  return e;
                }
              }
            ]),
            (n = [
              {
                key: 'mediaWidth',
                get: function() {
                  return this.getDimensions().width * i.contentScaleFactor;
                }
              },
              {
                key: 'mediaHeight',
                get: function() {
                  return this.getDimensions().height * i.contentScaleFactor;
                }
              }
            ]) && qe(a.prototype, n),
            s && qe(a, s),
            i
          );
        })(h);
        var ze = window.performance,
          Qe = (function(e) {
            var t, r;
            function i(t) {
              return e.call(this, t, u.a.MEDIA_ATTACHING) || this;
            }
            (r = e),
              ((t = i).prototype = Object.create(r.prototype)),
              (t.prototype.constructor = t),
              (t.__proto__ = r);
            var a = i.prototype;
            return (
              (a.destroy = function() {
                this.timer && clearInterval(this.timer),
                  (this.isVideoPlaybackQualityAvailable = !1);
              }),
              (a.onMediaAttaching = function(e) {
                var t = this.hls.config;
                t.capLevelOnFPSDrop &&
                  ('function' ==
                    typeof (this.video =
                      e.media instanceof window.HTMLVideoElement
                        ? e.media
                        : null).getVideoPlaybackQuality &&
                    (this.isVideoPlaybackQualityAvailable = !0),
                  clearInterval(this.timer),
                  (this.timer = setInterval(
                    this.checkFPSInterval.bind(this),
                    t.fpsDroppedMonitoringPeriod
                  )));
              }),
              (a.checkFPS = function(e, t, r) {
                var i = ze.now();
                if (t) {
                  if (this.lastTime) {
                    var a = i - this.lastTime,
                      n = r - this.lastDroppedFrames,
                      s = t - this.lastDecodedFrames,
                      o = (1e3 * n) / a,
                      l = this.hls;
                    if (
                      (l.trigger(u.a.FPS_DROP, {
                        currentDropped: n,
                        currentDecoded: s,
                        totalDroppedFrames: r
                      }),
                      o > 0 && n > l.config.fpsDroppedMonitoringThreshold * s)
                    ) {
                      var c = l.currentLevel;
                      d.b.warn(
                        'drop FPS ratio greater than max allowed value for currentLevel: ' +
                          c
                      ),
                        c > 0 &&
                          (-1 === l.autoLevelCapping ||
                            l.autoLevelCapping >= c) &&
                          ((c -= 1),
                          l.trigger(u.a.FPS_DROP_LEVEL_CAPPING, {
                            level: c,
                            droppedLevel: l.currentLevel
                          }),
                          (l.autoLevelCapping = c),
                          l.streamController.nextLevelSwitch());
                    }
                  }
                  (this.lastTime = i),
                    (this.lastDroppedFrames = r),
                    (this.lastDecodedFrames = t);
                }
              }),
              (a.checkFPSInterval = function() {
                var e = this.video;
                if (e)
                  if (this.isVideoPlaybackQualityAvailable) {
                    var t = e.getVideoPlaybackQuality();
                    this.checkFPS(e, t.totalVideoFrames, t.droppedVideoFrames);
                  } else
                    this.checkFPS(
                      e,
                      e.webkitDecodedFrameCount,
                      e.webkitDroppedFrameCount
                    );
              }),
              i
            );
          })(h),
          $e = (function() {
            function e(e) {
              e && e.xhrSetup && (this.xhrSetup = e.xhrSetup);
            }
            var t = e.prototype;
            return (
              (t.destroy = function() {
                this.abort(), (this.loader = null);
              }),
              (t.abort = function() {
                var e = this.loader;
                e &&
                  4 !== e.readyState &&
                  ((this.stats.aborted = !0), e.abort()),
                  window.clearTimeout(this.requestTimeout),
                  (this.requestTimeout = null),
                  window.clearTimeout(this.retryTimeout),
                  (this.retryTimeout = null);
              }),
              (t.load = function(e, t, r) {
                (this.context = e),
                  (this.config = t),
                  (this.callbacks = r),
                  (this.stats = {
                    trequest: window.performance.now(),
                    retry: 0
                  }),
                  (this.retryDelay = t.retryDelay),
                  this.loadInternal();
              }),
              (t.loadInternal = function() {
                var e,
                  t = this.context;
                e = this.loader = new window.XMLHttpRequest();
                var r = this.stats;
                (r.tfirst = 0), (r.loaded = 0);
                var i = this.xhrSetup;
                try {
                  if (i)
                    try {
                      i(e, t.url);
                    } catch (r) {
                      e.open('GET', t.url, !0), i(e, t.url);
                    }
                  e.readyState || e.open('GET', t.url, !0);
                } catch (r) {
                  return void this.callbacks.onError(
                    { code: e.status, text: r.message },
                    t,
                    e
                  );
                }
                t.rangeEnd &&
                  e.setRequestHeader(
                    'Range',
                    'bytes=' + t.rangeStart + '-' + (t.rangeEnd - 1)
                  ),
                  (e.onreadystatechange = this.readystatechange.bind(this)),
                  (e.onprogress = this.loadprogress.bind(this)),
                  (e.responseType = t.responseType),
                  (this.requestTimeout = window.setTimeout(
                    this.loadtimeout.bind(this),
                    this.config.timeout
                  )),
                  e.send();
              }),
              (t.readystatechange = function(e) {
                var t = e.currentTarget,
                  r = t.readyState,
                  i = this.stats,
                  a = this.context,
                  n = this.config;
                if (!i.aborted && r >= 2)
                  if (
                    (window.clearTimeout(this.requestTimeout),
                    0 === i.tfirst &&
                      (i.tfirst = Math.max(
                        window.performance.now(),
                        i.trequest
                      )),
                    4 === r)
                  ) {
                    var s = t.status;
                    if (s >= 200 && s < 300) {
                      var o, l;
                      (i.tload = Math.max(i.tfirst, window.performance.now())),
                        (l =
                          'arraybuffer' === a.responseType
                            ? (o = t.response).byteLength
                            : (o = t.responseText).length),
                        (i.loaded = i.total = l);
                      var u = { url: t.responseURL, data: o };
                      this.callbacks.onSuccess(u, i, a, t);
                    } else
                      i.retry >= n.maxRetry || (s >= 400 && s < 499)
                        ? (d.b.error(s + ' while loading ' + a.url),
                          this.callbacks.onError(
                            { code: s, text: t.statusText },
                            a,
                            t
                          ))
                        : (d.b.warn(
                            s +
                              ' while loading ' +
                              a.url +
                              ', retrying in ' +
                              this.retryDelay +
                              '...'
                          ),
                          this.destroy(),
                          (this.retryTimeout = window.setTimeout(
                            this.loadInternal.bind(this),
                            this.retryDelay
                          )),
                          (this.retryDelay = Math.min(
                            2 * this.retryDelay,
                            n.maxRetryDelay
                          )),
                          i.retry++);
                  } else
                    this.requestTimeout = window.setTimeout(
                      this.loadtimeout.bind(this),
                      n.timeout
                    );
              }),
              (t.loadtimeout = function() {
                d.b.warn('timeout while loading ' + this.context.url),
                  this.callbacks.onTimeout(this.stats, this.context, null);
              }),
              (t.loadprogress = function(e) {
                var t = e.currentTarget,
                  r = this.stats;
                (r.loaded = e.loaded),
                  e.lengthComputable && (r.total = e.total);
                var i = this.callbacks.onProgress;
                i && i(r, this.context, null, t);
              }),
              e
            );
          })();
        function Je(e, t) {
          for (var r = 0; r < t.length; r++) {
            var i = t[r];
            (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              'value' in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        var Ze = (function(e) {
          var t, r;
          function i(t) {
            var r;
            return (
              ((r =
                e.call(
                  this,
                  t,
                  u.a.MANIFEST_LOADING,
                  u.a.MANIFEST_PARSED,
                  u.a.AUDIO_TRACK_LOADED,
                  u.a.AUDIO_TRACK_SWITCHED,
                  u.a.LEVEL_LOADED,
                  u.a.ERROR
                ) || this)._trackId = -1),
              (r._selectDefaultTrack = !0),
              (r.tracks = []),
              (r.trackIdBlacklist = Object.create(null)),
              (r.audioGroupId = null),
              r
            );
          }
          (r = e),
            ((t = i).prototype = Object.create(r.prototype)),
            (t.prototype.constructor = t),
            (t.__proto__ = r);
          var a,
            n,
            s,
            l = i.prototype;
          return (
            (l.onManifestLoading = function() {
              (this.tracks = []),
                (this._trackId = -1),
                (this._selectDefaultTrack = !0);
            }),
            (l.onManifestParsed = function(e) {
              var t = (this.tracks = e.audioTracks || []);
              this.hls.trigger(u.a.AUDIO_TRACKS_UPDATED, { audioTracks: t }),
                this._selectAudioGroup(this.hls.nextLoadLevel);
            }),
            (l.onAudioTrackLoaded = function(e) {
              if (e.id >= this.tracks.length)
                d.b.warn('Invalid audio track id:', e.id);
              else {
                if (
                  (d.b.log('audioTrack ' + e.id + ' loaded'),
                  (this.tracks[e.id].details = e.details),
                  e.details.live && !this.hasInterval())
                ) {
                  var t = 1e3 * e.details.targetduration;
                  this.setInterval(t);
                }
                !e.details.live && this.hasInterval() && this.clearInterval();
              }
            }),
            (l.onAudioTrackSwitched = function(e) {
              var t = this.tracks[e.id].groupId;
              t && this.audioGroupId !== t && (this.audioGroupId = t);
            }),
            (l.onLevelLoaded = function(e) {
              this._selectAudioGroup(e.level);
            }),
            (l.onError = function(e) {
              e.type === o.b.NETWORK_ERROR &&
                (e.fatal && this.clearInterval(),
                e.details === o.a.AUDIO_TRACK_LOAD_ERROR &&
                  (d.b.warn('Network failure on audio-track id:', e.context.id),
                  this._handleLoadError()));
            }),
            (l._setAudioTrack = function(e) {
              if (this._trackId === e && this.tracks[this._trackId].details)
                d.b.debug(
                  'Same id as current audio-track passed, and track details available -> no-op'
                );
              else if (e < 0 || e >= this.tracks.length)
                d.b.warn('Invalid id passed to audio-track controller');
              else {
                var t = this.tracks[e];
                d.b.log('Now switching to audio-track index ' + e),
                  this.clearInterval(),
                  (this._trackId = e);
                var r = t.url,
                  i = t.type,
                  a = t.id;
                this.hls.trigger(u.a.AUDIO_TRACK_SWITCHING, {
                  id: a,
                  type: i,
                  url: r
                }),
                  this._loadTrackDetailsIfNeeded(t);
              }
            }),
            (l.doTick = function() {
              this._updateTrack(this._trackId);
            }),
            (l._selectAudioGroup = function(e) {
              var t = this.hls.levels[e];
              if (t && t.audioGroupIds) {
                var r = t.audioGroupIds[t.urlId];
                this.audioGroupId !== r &&
                  ((this.audioGroupId = r), this._selectInitialAudioTrack());
              }
            }),
            (l._selectInitialAudioTrack = function() {
              var e = this,
                t = this.tracks;
              if (t.length) {
                var r = this.tracks[this._trackId],
                  i = null;
                if ((r && (i = r.name), this._selectDefaultTrack)) {
                  var a = t.filter(function(e) {
                    return e.default;
                  });
                  a.length
                    ? (t = a)
                    : d.b.warn('No default audio tracks defined');
                }
                var n = !1,
                  s = function() {
                    t.forEach(function(t) {
                      n ||
                        (e.audioGroupId && t.groupId !== e.audioGroupId) ||
                        (i && i !== t.name) ||
                        (e._setAudioTrack(t.id), (n = !0));
                    });
                  };
                s(),
                  n || ((i = null), s()),
                  n ||
                    (d.b.error(
                      'No track found for running audio group-ID: ' +
                        this.audioGroupId
                    ),
                    this.hls.trigger(u.a.ERROR, {
                      type: o.b.MEDIA_ERROR,
                      details: o.a.AUDIO_TRACK_LOAD_ERROR,
                      fatal: !0
                    }));
              }
            }),
            (l._needsTrackLoading = function(e) {
              var t = e.details,
                r = e.url;
              return !(t && !t.live) && !!r;
            }),
            (l._loadTrackDetailsIfNeeded = function(e) {
              if (this._needsTrackLoading(e)) {
                var t = e.url,
                  r = e.id;
                d.b.log('loading audio-track playlist for id: ' + r),
                  this.hls.trigger(u.a.AUDIO_TRACK_LOADING, { url: t, id: r });
              }
            }),
            (l._updateTrack = function(e) {
              if (!(e < 0 || e >= this.tracks.length)) {
                this.clearInterval(),
                  (this._trackId = e),
                  d.b.log('trying to update audio-track ' + e);
                var t = this.tracks[e];
                this._loadTrackDetailsIfNeeded(t);
              }
            }),
            (l._handleLoadError = function() {
              this.trackIdBlacklist[this._trackId] = !0;
              var e = this._trackId,
                t = this.tracks[e],
                r = t.name,
                i = t.language,
                a = t.groupId;
              d.b.warn(
                'Loading failed on audio track id: ' +
                  e +
                  ', group-id: ' +
                  a +
                  ', name/language: "' +
                  r +
                  '" / "' +
                  i +
                  '"'
              );
              for (var n = e, s = 0; s < this.tracks.length; s++) {
                if (!this.trackIdBlacklist[s])
                  if (this.tracks[s].name === r) {
                    n = s;
                    break;
                  }
              }
              n !== e
                ? (d.b.log(
                    'Attempting audio-track fallback id:',
                    n,
                    'group-id:',
                    this.tracks[n].groupId
                  ),
                  this._setAudioTrack(n))
                : d.b.warn(
                    'No fallback audio-track found for name/language: "' +
                      r +
                      '" / "' +
                      i +
                      '"'
                  );
            }),
            (a = i),
            (n = [
              {
                key: 'audioTracks',
                get: function() {
                  return this.tracks;
                }
              },
              {
                key: 'audioTrack',
                get: function() {
                  return this._trackId;
                },
                set: function(e) {
                  this._setAudioTrack(e), (this._selectDefaultTrack = !1);
                }
              }
            ]) && Je(a.prototype, n),
            s && Je(a, s),
            i
          );
        })(ge);
        function et(e, t) {
          for (var r = 0; r < t.length; r++) {
            var i = t[r];
            (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              'value' in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        var tt = window.performance,
          rt = (function(e) {
            var t, r;
            function i(t, r) {
              var i;
              return (
                ((i =
                  e.call(
                    this,
                    t,
                    u.a.MEDIA_ATTACHED,
                    u.a.MEDIA_DETACHING,
                    u.a.AUDIO_TRACKS_UPDATED,
                    u.a.AUDIO_TRACK_SWITCHING,
                    u.a.AUDIO_TRACK_LOADED,
                    u.a.KEY_LOADED,
                    u.a.FRAG_LOADED,
                    u.a.FRAG_PARSING_INIT_SEGMENT,
                    u.a.FRAG_PARSING_DATA,
                    u.a.FRAG_PARSED,
                    u.a.ERROR,
                    u.a.BUFFER_RESET,
                    u.a.BUFFER_CREATED,
                    u.a.BUFFER_APPENDED,
                    u.a.BUFFER_FLUSHED,
                    u.a.INIT_PTS_FOUND
                  ) || this).fragmentTracker = r),
                (i.config = t.config),
                (i.audioCodecSwap = !1),
                (i._state = pe),
                (i.initPTS = []),
                (i.waitingFragment = null),
                (i.videoTrackCC = null),
                i
              );
            }
            (r = e),
              ((t = i).prototype = Object.create(r.prototype)),
              (t.prototype.constructor = t),
              (t.__proto__ = r);
            var a,
              n,
              s,
              c = i.prototype;
            return (
              (c.onInitPtsFound = function(e) {
                var t = e.id,
                  r = e.frag.cc,
                  i = e.initPTS;
                'main' === t &&
                  ((this.initPTS[r] = i),
                  (this.videoTrackCC = r),
                  d.b.log(
                    'InitPTS for cc: ' + r + ' found from video track: ' + i
                  ),
                  this.state === Le && this.tick());
              }),
              (c.startLoad = function(e) {
                if (this.tracks) {
                  var t = this.lastCurrentTime;
                  this.stopLoad(),
                    this.setInterval(100),
                    (this.fragLoadError = 0),
                    t > 0 && -1 === e
                      ? (d.b.log(
                          'audio:override startPosition with lastCurrentTime @' +
                            t.toFixed(3)
                        ),
                        (this.state = me))
                      : ((this.lastCurrentTime = this.startPosition
                          ? this.startPosition
                          : e),
                        (this.state = ve)),
                    (this.nextLoadPosition = this.startPosition = this.lastCurrentTime),
                    this.tick();
                } else (this.startPosition = e), (this.state = pe);
              }),
              (c.doTick = function() {
                var e,
                  t,
                  r,
                  i = this.hls,
                  a = i.config;
                switch (this.state) {
                  case we:
                  case ye:
                  case Ae:
                    break;
                  case ve:
                    (this.state = Se), (this.loadedmetadata = !1);
                    break;
                  case me:
                    var n = this.tracks;
                    if (!n) break;
                    if (
                      !this.media &&
                      (this.startFragRequested || !a.startFragPrefetch)
                    )
                      break;
                    if (this.loadedmetadata) e = this.media.currentTime;
                    else if (void 0 === (e = this.nextLoadPosition)) break;
                    var s = this.mediaBuffer ? this.mediaBuffer : this.media,
                      o = this.videoBuffer ? this.videoBuffer : this.media,
                      c =
                        e < a.maxBufferHole
                          ? Math.max(2, a.maxBufferHole)
                          : a.maxBufferHole,
                      h = H.bufferInfo(s, e, c),
                      f = H.bufferInfo(o, e, c),
                      g = h.len,
                      p = h.end,
                      v = this.fragPrevious,
                      m = Math.min(a.maxBufferLength, a.maxMaxBufferLength),
                      y = Math.max(m, f.len),
                      b = this.audioSwitch,
                      T = this.trackId;
                    if ((g < y || b) && T < n.length) {
                      if (void 0 === (r = n[T].details)) {
                        this.state = Se;
                        break;
                      }
                      if (!b && this._streamEnded(h, r))
                        return (
                          this.hls.trigger(u.a.BUFFER_EOS, { type: 'audio' }),
                          void (this.state = ke)
                        );
                      var E,
                        S = r.fragments,
                        _ = S.length,
                        R = S[0].start,
                        A = S[_ - 1].start + S[_ - 1].duration;
                      if (b)
                        if (r.live && !r.PTSKnown)
                          d.b.log(
                            'switching audiotrack, live stream, unknown PTS,load first fragment'
                          ),
                            (p = 0);
                        else if (((p = e), r.PTSKnown && e < R)) {
                          if (!(h.end > R || h.nextStart)) return;
                          d.b.log(
                            'alt audio track ahead of main track, seek to start of alt audio track'
                          ),
                            (this.media.currentTime = R + 0.05);
                        }
                      if (r.initSegment && !r.initSegment.data)
                        E = r.initSegment;
                      else if (p <= R) {
                        if (
                          ((E = S[0]),
                          null !== this.videoTrackCC &&
                            E.cc !== this.videoTrackCC &&
                            (E = (function(e, t) {
                              return j.search(e, function(e) {
                                return e.cc < t ? 1 : e.cc > t ? -1 : 0;
                              });
                            })(S, this.videoTrackCC)),
                          r.live && E.loadIdx && E.loadIdx === this.fragLoadIdx)
                        ) {
                          var k = h.nextStart ? h.nextStart : R;
                          return (
                            d.b.log(
                              'no alt audio available @currentTime:' +
                                this.media.currentTime +
                                ', seeking @' +
                                (k + 0.05)
                            ),
                            void (this.media.currentTime = k + 0.05)
                          );
                        }
                      } else {
                        var w,
                          L = a.maxFragLookUpTolerance,
                          D = v ? S[v.sn - S[0].sn + 1] : void 0,
                          O = function(e) {
                            var t = Math.min(L, e.duration);
                            return e.start + e.duration - t <= p
                              ? 1
                              : e.start - t > p && e.start
                              ? -1
                              : 0;
                          };
                        p < A
                          ? (p > A - L && (L = 0),
                            (w = D && !O(D) ? D : j.search(S, O)))
                          : (w = S[_ - 1]),
                          w &&
                            ((E = w),
                            (R = w.start),
                            v &&
                              E.level === v.level &&
                              E.sn === v.sn &&
                              (E.sn < r.endSN
                                ? ((E = S[E.sn + 1 - r.startSN]),
                                  d.b.log(
                                    'SN just loaded, load next one: ' + E.sn
                                  ))
                                : (E = null)));
                      }
                      E &&
                        (E.encrypted
                          ? (d.b.log(
                              'Loading key for ' +
                                E.sn +
                                ' of [' +
                                r.startSN +
                                ' ,' +
                                r.endSN +
                                '],track ' +
                                T
                            ),
                            (this.state = be),
                            i.trigger(u.a.KEY_LOADING, { frag: E }))
                          : ((this.fragCurrent = E),
                            (b || this.fragmentTracker.getState(E) === U) &&
                              (d.b.log(
                                'Loading ' +
                                  E.sn +
                                  ', cc: ' +
                                  E.cc +
                                  ' of [' +
                                  r.startSN +
                                  ' ,' +
                                  r.endSN +
                                  '],track ' +
                                  T +
                                  ', currentTime:' +
                                  e +
                                  ',bufferEnd:' +
                                  p.toFixed(3)
                              ),
                              'initSegment' !== E.sn &&
                                (this.startFragRequested = !0),
                              Object(l.a)(E.sn) &&
                                (this.nextLoadPosition = E.start + E.duration),
                              i.trigger(u.a.FRAG_LOADING, { frag: E }),
                              (this.state = Te))));
                    }
                    break;
                  case Se:
                    (t = this.tracks[this.trackId]) &&
                      t.details &&
                      (this.state = me);
                    break;
                  case Ee:
                    var C = tt.now(),
                      I = this.retryDate,
                      P = (s = this.media) && s.seeking;
                    (!I || C >= I || P) &&
                      (d.b.log(
                        'audioStreamController: retryDate reached, switch back to IDLE state'
                      ),
                      (this.state = me));
                    break;
                  case Le:
                    var x = this.videoTrackCC;
                    if (void 0 === this.initPTS[x]) break;
                    var M = this.waitingFragment;
                    if (M) {
                      var F = M.frag.cc;
                      x !== F
                        ? (t = this.tracks[this.trackId]).details &&
                          t.details.live &&
                          (d.b.warn(
                            'Waiting fragment CC (' +
                              F +
                              ') does not match video track CC (' +
                              x +
                              ')'
                          ),
                          (this.waitingFragment = null),
                          (this.state = me))
                        : ((this.state = Te),
                          this.onFragLoaded(this.waitingFragment),
                          (this.waitingFragment = null));
                    } else this.state = me;
                }
              }),
              (c.onMediaAttached = function(e) {
                var t = (this.media = this.mediaBuffer = e.media);
                (this.onvseeking = this.onMediaSeeking.bind(this)),
                  (this.onvended = this.onMediaEnded.bind(this)),
                  t.addEventListener('seeking', this.onvseeking),
                  t.addEventListener('ended', this.onvended);
                var r = this.config;
                this.tracks &&
                  r.autoStartLoad &&
                  this.startLoad(r.startPosition);
              }),
              (c.onMediaDetaching = function() {
                var e = this.media;
                e &&
                  e.ended &&
                  (d.b.log(
                    'MSE detaching and video ended, reset startPosition'
                  ),
                  (this.startPosition = this.lastCurrentTime = 0)),
                  e &&
                    (e.removeEventListener('seeking', this.onvseeking),
                    e.removeEventListener('ended', this.onvended),
                    (this.onvseeking = this.onvseeked = this.onvended = null)),
                  (this.media = this.mediaBuffer = this.videoBuffer = null),
                  (this.loadedmetadata = !1),
                  this.fragmentTracker.removeAllFragments(),
                  this.stopLoad();
              }),
              (c.onAudioTracksUpdated = function(e) {
                d.b.log('audio tracks updated'), (this.tracks = e.audioTracks);
              }),
              (c.onAudioTrackSwitching = function(e) {
                var t = !!e.url;
                (this.trackId = e.id),
                  (this.fragCurrent = null),
                  (this.state = ye),
                  (this.waitingFragment = null),
                  t
                    ? this.setInterval(100)
                    : this.demuxer &&
                      (this.demuxer.destroy(), (this.demuxer = null)),
                  t && ((this.audioSwitch = !0), (this.state = me)),
                  this.tick();
              }),
              (c.onAudioTrackLoaded = function(e) {
                var t = e.details,
                  r = e.id,
                  i = this.tracks[r],
                  a = t.totalduration,
                  n = 0;
                if (
                  (d.b.log(
                    'track ' +
                      r +
                      ' loaded [' +
                      t.startSN +
                      ',' +
                      t.endSN +
                      '],duration:' +
                      a
                  ),
                  t.live)
                ) {
                  var s = i.details;
                  s && t.fragments.length > 0
                    ? (re(s, t),
                      (n = t.fragments[0].start),
                      t.PTSKnown
                        ? d.b.log('live audio playlist sliding:' + n.toFixed(3))
                        : d.b.log(
                            'live audio playlist - outdated PTS, unknown sliding'
                          ))
                    : ((t.PTSKnown = !1),
                      d.b.log(
                        'live audio playlist - first load, unknown sliding'
                      ));
                } else t.PTSKnown = !1;
                if (((i.details = t), !this.startFragRequested)) {
                  if (-1 === this.startPosition) {
                    var o = t.startTimeOffset;
                    Object(l.a)(o)
                      ? (d.b.log(
                          'start time offset found in playlist, adjust startPosition to ' +
                            o
                        ),
                        (this.startPosition = o))
                      : t.live
                      ? ((this.startPosition = this.computeLivePosition(n, t)),
                        d.b.log(
                          'compute startPosition for audio-track to ' +
                            this.startPosition
                        ))
                      : (this.startPosition = 0);
                  }
                  this.nextLoadPosition = this.startPosition;
                }
                this.state === Se && (this.state = me), this.tick();
              }),
              (c.onKeyLoaded = function() {
                this.state === be && ((this.state = me), this.tick());
              }),
              (c.onFragLoaded = function(e) {
                var t = this.fragCurrent,
                  r = e.frag;
                if (
                  this.state === Te &&
                  t &&
                  'audio' === r.type &&
                  r.level === t.level &&
                  r.sn === t.sn
                ) {
                  var i = this.tracks[this.trackId],
                    a = i.details,
                    n = a.totalduration,
                    s = t.level,
                    o = t.sn,
                    l = t.cc,
                    c =
                      this.config.defaultAudioCodec ||
                      i.audioCodec ||
                      'mp4a.40.2',
                    h = (this.stats = e.stats);
                  if ('initSegment' === o)
                    (this.state = me),
                      (h.tparsed = h.tbuffered = tt.now()),
                      (a.initSegment.data = e.payload),
                      this.hls.trigger(u.a.FRAG_BUFFERED, {
                        stats: h,
                        frag: t,
                        id: 'audio'
                      }),
                      this.tick();
                  else {
                    (this.state = _e),
                      (this.appended = !1),
                      this.demuxer || (this.demuxer = new J(this.hls, 'audio'));
                    var f = this.initPTS[l],
                      g = a.initSegment ? a.initSegment.data : [];
                    if (a.initSegment || void 0 !== f) {
                      (this.pendingBuffering = !0),
                        d.b.log(
                          'Demuxing ' +
                            o +
                            ' of [' +
                            a.startSN +
                            ' ,' +
                            a.endSN +
                            '],track ' +
                            s
                        );
                      this.demuxer.push(e.payload, g, c, null, t, n, !1, f);
                    } else
                      d.b.log(
                        'unknown video PTS for continuity counter ' +
                          l +
                          ', waiting for video PTS before demuxing audio frag ' +
                          o +
                          ' of [' +
                          a.startSN +
                          ' ,' +
                          a.endSN +
                          '],track ' +
                          s
                      ),
                        (this.waitingFragment = e),
                        (this.state = Le);
                  }
                }
                this.fragLoadError = 0;
              }),
              (c.onFragParsingInitSegment = function(e) {
                var t = this.fragCurrent,
                  r = e.frag;
                if (
                  t &&
                  'audio' === e.id &&
                  r.sn === t.sn &&
                  r.level === t.level &&
                  this.state === _e
                ) {
                  var i,
                    a = e.tracks;
                  if ((a.video && delete a.video, (i = a.audio))) {
                    (i.levelCodec = i.codec),
                      (i.id = e.id),
                      this.hls.trigger(u.a.BUFFER_CODECS, a),
                      d.b.log(
                        'audio track:audio,container:' +
                          i.container +
                          ',codecs[level/parsed]=[' +
                          i.levelCodec +
                          '/' +
                          i.codec +
                          ']'
                      );
                    var n = i.initSegment;
                    if (n) {
                      var s = {
                        type: 'audio',
                        data: n,
                        parent: 'audio',
                        content: 'initSegment'
                      };
                      this.audioSwitch
                        ? (this.pendingData = [s])
                        : ((this.appended = !0),
                          (this.pendingBuffering = !0),
                          this.hls.trigger(u.a.BUFFER_APPENDING, s));
                    }
                    this.tick();
                  }
                }
              }),
              (c.onFragParsingData = function(e) {
                var t = this,
                  r = this.fragCurrent,
                  i = e.frag;
                if (
                  r &&
                  'audio' === e.id &&
                  'audio' === e.type &&
                  i.sn === r.sn &&
                  i.level === r.level &&
                  this.state === _e
                ) {
                  var a = this.trackId,
                    n = this.tracks[a],
                    s = this.hls;
                  Object(l.a)(e.endPTS) ||
                    ((e.endPTS = e.startPTS + r.duration),
                    (e.endDTS = e.startDTS + r.duration)),
                    r.addElementaryStream(p.AUDIO),
                    d.b.log(
                      'parsed ' +
                        e.type +
                        ',PTS:[' +
                        e.startPTS.toFixed(3) +
                        ',' +
                        e.endPTS.toFixed(3) +
                        '],DTS:[' +
                        e.startDTS.toFixed(3) +
                        '/' +
                        e.endDTS.toFixed(3) +
                        '],nb:' +
                        e.nb
                    ),
                    te(n.details, r, e.startPTS, e.endPTS);
                  var c = this.audioSwitch,
                    h = this.media,
                    f = !1;
                  if (c)
                    if (h && h.readyState) {
                      var g = h.currentTime;
                      d.b.log('switching audio track : currentTime:' + g),
                        g >= e.startPTS &&
                          (d.b.log(
                            'switching audio track : flushing all audio'
                          ),
                          (this.state = Ae),
                          s.trigger(u.a.BUFFER_FLUSHING, {
                            startOffset: 0,
                            endOffset: Number.POSITIVE_INFINITY,
                            type: 'audio'
                          }),
                          (f = !0),
                          (this.audioSwitch = !1),
                          s.trigger(u.a.AUDIO_TRACK_SWITCHED, { id: a }));
                    } else
                      (this.audioSwitch = !1),
                        s.trigger(u.a.AUDIO_TRACK_SWITCHED, { id: a });
                  var v = this.pendingData;
                  if (!v)
                    return (
                      d.b.warn(
                        'Apparently attempt to enqueue media payload without codec initialization data upfront'
                      ),
                      void s.trigger(u.a.ERROR, {
                        type: o.b.MEDIA_ERROR,
                        details: null,
                        fatal: !0
                      })
                    );
                  this.audioSwitch ||
                    ([e.data1, e.data2].forEach(function(t) {
                      t &&
                        t.length &&
                        v.push({
                          type: e.type,
                          data: t,
                          parent: 'audio',
                          content: 'data'
                        });
                    }),
                    !f &&
                      v.length &&
                      (v.forEach(function(e) {
                        t.state === _e &&
                          ((t.pendingBuffering = !0),
                          t.hls.trigger(u.a.BUFFER_APPENDING, e));
                      }),
                      (this.pendingData = []),
                      (this.appended = !0))),
                    this.tick();
                }
              }),
              (c.onFragParsed = function(e) {
                var t = this.fragCurrent,
                  r = e.frag;
                t &&
                  'audio' === e.id &&
                  r.sn === t.sn &&
                  r.level === t.level &&
                  this.state === _e &&
                  ((this.stats.tparsed = tt.now()),
                  (this.state = Re),
                  this._checkAppendedParsed());
              }),
              (c.onBufferReset = function() {
                (this.mediaBuffer = this.videoBuffer = null),
                  (this.loadedmetadata = !1);
              }),
              (c.onBufferCreated = function(e) {
                var t = e.tracks.audio;
                t &&
                  ((this.mediaBuffer = t.buffer), (this.loadedmetadata = !0)),
                  e.tracks.video && (this.videoBuffer = e.tracks.video.buffer);
              }),
              (c.onBufferAppended = function(e) {
                if ('audio' === e.parent) {
                  var t = this.state;
                  (t !== _e && t !== Re) ||
                    ((this.pendingBuffering = e.pending > 0),
                    this._checkAppendedParsed());
                }
              }),
              (c._checkAppendedParsed = function() {
                if (
                  !(
                    this.state !== Re ||
                    (this.appended && this.pendingBuffering)
                  )
                ) {
                  var e = this.fragCurrent,
                    t = this.stats,
                    r = this.hls;
                  if (e) {
                    (this.fragPrevious = e),
                      (t.tbuffered = tt.now()),
                      r.trigger(u.a.FRAG_BUFFERED, {
                        stats: t,
                        frag: e,
                        id: 'audio'
                      });
                    var i = this.mediaBuffer ? this.mediaBuffer : this.media;
                    i && d.b.log('audio buffered : ' + ne.toString(i.buffered)),
                      this.audioSwitch &&
                        this.appended &&
                        ((this.audioSwitch = !1),
                        r.trigger(u.a.AUDIO_TRACK_SWITCHED, {
                          id: this.trackId
                        })),
                      (this.state = me);
                  }
                  this.tick();
                }
              }),
              (c.onError = function(e) {
                var t = e.frag;
                if (!t || 'audio' === t.type)
                  switch (e.details) {
                    case o.a.FRAG_LOAD_ERROR:
                    case o.a.FRAG_LOAD_TIMEOUT:
                      var r = e.frag;
                      if (r && 'audio' !== r.type) break;
                      if (!e.fatal) {
                        var i = this.fragLoadError;
                        i ? i++ : (i = 1);
                        var a = this.config;
                        if (i <= a.fragLoadingMaxRetry) {
                          this.fragLoadError = i;
                          var n = Math.min(
                            Math.pow(2, i - 1) * a.fragLoadingRetryDelay,
                            a.fragLoadingMaxRetryTimeout
                          );
                          d.b.warn(
                            'AudioStreamController: frag loading failed, retry in ' +
                              n +
                              ' ms'
                          ),
                            (this.retryDate = tt.now() + n),
                            (this.state = Ee);
                        } else
                          d.b.error(
                            'AudioStreamController: ' +
                              e.details +
                              ' reaches max retry, redispatch as fatal ...'
                          ),
                            (e.fatal = !0),
                            (this.state = we);
                      }
                      break;
                    case o.a.AUDIO_TRACK_LOAD_ERROR:
                    case o.a.AUDIO_TRACK_LOAD_TIMEOUT:
                    case o.a.KEY_LOAD_ERROR:
                    case o.a.KEY_LOAD_TIMEOUT:
                      this.state !== we &&
                        ((this.state = e.fatal ? we : me),
                        d.b.warn(
                          'AudioStreamController: ' +
                            e.details +
                            ' while loading frag, now switching to ' +
                            this.state +
                            ' state ...'
                        ));
                      break;
                    case o.a.BUFFER_FULL_ERROR:
                      if (
                        'audio' === e.parent &&
                        (this.state === _e || this.state === Re)
                      ) {
                        var s = this.mediaBuffer,
                          l = this.media.currentTime;
                        if (
                          s &&
                          H.isBuffered(s, l) &&
                          H.isBuffered(s, l + 0.5)
                        ) {
                          var c = this.config;
                          c.maxMaxBufferLength >= c.maxBufferLength &&
                            ((c.maxMaxBufferLength /= 2),
                            d.b.warn(
                              'AudioStreamController: reduce max buffer length to ' +
                                c.maxMaxBufferLength +
                                's'
                            )),
                            (this.state = me);
                        } else
                          d.b.warn(
                            'AudioStreamController: buffer full error also media.currentTime is not buffered, flush audio buffer'
                          ),
                            (this.fragCurrent = null),
                            (this.state = Ae),
                            this.hls.trigger(u.a.BUFFER_FLUSHING, {
                              startOffset: 0,
                              endOffset: Number.POSITIVE_INFINITY,
                              type: 'audio'
                            });
                      }
                  }
              }),
              (c.onBufferFlushed = function() {
                var e = this,
                  t = this.pendingData;
                t && t.length
                  ? (d.b.log(
                      'AudioStreamController: appending pending audio data after buffer flushed'
                    ),
                    t.forEach(function(t) {
                      e.hls.trigger(u.a.BUFFER_APPENDING, t);
                    }),
                    (this.appended = !0),
                    (this.pendingData = []),
                    (this.state = Re))
                  : ((this.state = me),
                    (this.fragPrevious = null),
                    this.tick());
              }),
              (a = i),
              (n = [
                {
                  key: 'state',
                  set: function(e) {
                    if (this.state !== e) {
                      var t = this.state;
                      (this._state = e),
                        d.b.log('audio stream:' + t + '->' + e);
                    }
                  },
                  get: function() {
                    return this._state;
                  }
                }
              ]) && et(a.prototype, n),
              s && et(a, s),
              i
            );
          })(Oe),
          it = (function() {
            if ('undefined' != typeof window && window.VTTCue)
              return window.VTTCue;
            var e = { '': !0, lr: !0, rl: !0 },
              t = { start: !0, middle: !0, end: !0, left: !0, right: !0 };
            function r(e) {
              return (
                'string' == typeof e && !!t[e.toLowerCase()] && e.toLowerCase()
              );
            }
            function i(e) {
              for (var t = 1; t < arguments.length; t++) {
                var r = arguments[t];
                for (var i in r) e[i] = r[i];
              }
              return e;
            }
            function a(t, a, n) {
              var s = this,
                o = { enumerable: !0 };
              s.hasBeenReset = !1;
              var l = '',
                u = !1,
                d = t,
                c = a,
                h = n,
                f = null,
                g = '',
                p = !0,
                v = 'auto',
                m = 'start',
                y = 50,
                b = 'middle',
                T = 50,
                E = 'middle';
              Object.defineProperty(
                s,
                'id',
                i({}, o, {
                  get: function() {
                    return l;
                  },
                  set: function(e) {
                    l = '' + e;
                  }
                })
              ),
                Object.defineProperty(
                  s,
                  'pauseOnExit',
                  i({}, o, {
                    get: function() {
                      return u;
                    },
                    set: function(e) {
                      u = !!e;
                    }
                  })
                ),
                Object.defineProperty(
                  s,
                  'startTime',
                  i({}, o, {
                    get: function() {
                      return d;
                    },
                    set: function(e) {
                      if ('number' != typeof e)
                        throw new TypeError(
                          'Start time must be set to a number.'
                        );
                      (d = e), (this.hasBeenReset = !0);
                    }
                  })
                ),
                Object.defineProperty(
                  s,
                  'endTime',
                  i({}, o, {
                    get: function() {
                      return c;
                    },
                    set: function(e) {
                      if ('number' != typeof e)
                        throw new TypeError(
                          'End time must be set to a number.'
                        );
                      (c = e), (this.hasBeenReset = !0);
                    }
                  })
                ),
                Object.defineProperty(
                  s,
                  'text',
                  i({}, o, {
                    get: function() {
                      return h;
                    },
                    set: function(e) {
                      (h = '' + e), (this.hasBeenReset = !0);
                    }
                  })
                ),
                Object.defineProperty(
                  s,
                  'region',
                  i({}, o, {
                    get: function() {
                      return f;
                    },
                    set: function(e) {
                      (f = e), (this.hasBeenReset = !0);
                    }
                  })
                ),
                Object.defineProperty(
                  s,
                  'vertical',
                  i({}, o, {
                    get: function() {
                      return g;
                    },
                    set: function(t) {
                      var r = (function(t) {
                        return (
                          'string' == typeof t &&
                          !!e[t.toLowerCase()] && t.toLowerCase()
                        );
                      })(t);
                      if (!1 === r)
                        throw new SyntaxError(
                          'An invalid or illegal string was specified.'
                        );
                      (g = r), (this.hasBeenReset = !0);
                    }
                  })
                ),
                Object.defineProperty(
                  s,
                  'snapToLines',
                  i({}, o, {
                    get: function() {
                      return p;
                    },
                    set: function(e) {
                      (p = !!e), (this.hasBeenReset = !0);
                    }
                  })
                ),
                Object.defineProperty(
                  s,
                  'line',
                  i({}, o, {
                    get: function() {
                      return v;
                    },
                    set: function(e) {
                      if ('number' != typeof e && 'auto' !== e)
                        throw new SyntaxError(
                          'An invalid number or illegal string was specified.'
                        );
                      (v = e), (this.hasBeenReset = !0);
                    }
                  })
                ),
                Object.defineProperty(
                  s,
                  'lineAlign',
                  i({}, o, {
                    get: function() {
                      return m;
                    },
                    set: function(e) {
                      var t = r(e);
                      if (!t)
                        throw new SyntaxError(
                          'An invalid or illegal string was specified.'
                        );
                      (m = t), (this.hasBeenReset = !0);
                    }
                  })
                ),
                Object.defineProperty(
                  s,
                  'position',
                  i({}, o, {
                    get: function() {
                      return y;
                    },
                    set: function(e) {
                      if (e < 0 || e > 100)
                        throw new Error('Position must be between 0 and 100.');
                      (y = e), (this.hasBeenReset = !0);
                    }
                  })
                ),
                Object.defineProperty(
                  s,
                  'positionAlign',
                  i({}, o, {
                    get: function() {
                      return b;
                    },
                    set: function(e) {
                      var t = r(e);
                      if (!t)
                        throw new SyntaxError(
                          'An invalid or illegal string was specified.'
                        );
                      (b = t), (this.hasBeenReset = !0);
                    }
                  })
                ),
                Object.defineProperty(
                  s,
                  'size',
                  i({}, o, {
                    get: function() {
                      return T;
                    },
                    set: function(e) {
                      if (e < 0 || e > 100)
                        throw new Error('Size must be between 0 and 100.');
                      (T = e), (this.hasBeenReset = !0);
                    }
                  })
                ),
                Object.defineProperty(
                  s,
                  'align',
                  i({}, o, {
                    get: function() {
                      return E;
                    },
                    set: function(e) {
                      var t = r(e);
                      if (!t)
                        throw new SyntaxError(
                          'An invalid or illegal string was specified.'
                        );
                      (E = t), (this.hasBeenReset = !0);
                    }
                  })
                ),
                (s.displayState = void 0);
            }
            return (
              (a.prototype.getCueAsHTML = function() {
                return window.WebVTT.convertCueToDOMTree(window, this.text);
              }),
              a
            );
          })(),
          at = function() {
            return {
              decode: function(e) {
                if (!e) return '';
                if ('string' != typeof e)
                  throw new Error('Error - expected string data.');
                return decodeURIComponent(encodeURIComponent(e));
              }
            };
          };
        function nt() {
          (this.window = window),
            (this.state = 'INITIAL'),
            (this.buffer = ''),
            (this.decoder = new at()),
            (this.regionList = []);
        }
        function st() {
          this.values = Object.create(null);
        }
        function ot(e, t, r, i) {
          var a = i ? e.split(i) : [e];
          for (var n in a)
            if ('string' == typeof a[n]) {
              var s = a[n].split(r);
              if (2 === s.length) t(s[0], s[1]);
            }
        }
        st.prototype = {
          set: function(e, t) {
            this.get(e) || '' === t || (this.values[e] = t);
          },
          get: function(e, t, r) {
            return r
              ? this.has(e)
                ? this.values[e]
                : t[r]
              : this.has(e)
              ? this.values[e]
              : t;
          },
          has: function(e) {
            return e in this.values;
          },
          alt: function(e, t, r) {
            for (var i = 0; i < r.length; ++i)
              if (t === r[i]) {
                this.set(e, t);
                break;
              }
          },
          integer: function(e, t) {
            /^-?\d+$/.test(t) && this.set(e, parseInt(t, 10));
          },
          percent: function(e, t) {
            return (
              !!(
                t.match(/^([\d]{1,3})(\.[\d]*)?%$/) &&
                (t = parseFloat(t)) >= 0 &&
                t <= 100
              ) && (this.set(e, t), !0)
            );
          }
        };
        var lt = new it(0, 0, 0),
          ut = 'middle' === lt.align ? 'middle' : 'center';
        function dt(e, t, r) {
          var i = e;
          function a() {
            var t = (function(e) {
              function t(e, t, r, i) {
                return 3600 * (0 | e) + 60 * (0 | t) + (0 | r) + (0 | i) / 1e3;
              }
              var r = e.match(/^(\d+):(\d{2})(:\d{2})?\.(\d{3})/);
              return r
                ? r[3]
                  ? t(r[1], r[2], r[3].replace(':', ''), r[4])
                  : r[1] > 59
                  ? t(r[1], r[2], 0, r[4])
                  : t(0, r[1], r[2], r[4])
                : null;
            })(e);
            if (null === t) throw new Error('Malformed timestamp: ' + i);
            return (e = e.replace(/^[^\sa-zA-Z-]+/, '')), t;
          }
          function n() {
            e = e.replace(/^\s+/, '');
          }
          if ((n(), (t.startTime = a()), n(), '--\x3e' !== e.substr(0, 3)))
            throw new Error(
              "Malformed time stamp (time stamps must be separated by '--\x3e'): " +
                i
            );
          (e = e.substr(3)),
            n(),
            (t.endTime = a()),
            n(),
            (function(e, t) {
              var i = new st();
              ot(
                e,
                function(e, t) {
                  switch (e) {
                    case 'region':
                      for (var a = r.length - 1; a >= 0; a--)
                        if (r[a].id === t) {
                          i.set(e, r[a].region);
                          break;
                        }
                      break;
                    case 'vertical':
                      i.alt(e, t, ['rl', 'lr']);
                      break;
                    case 'line':
                      var n = t.split(','),
                        s = n[0];
                      i.integer(e, s),
                        i.percent(e, s) && i.set('snapToLines', !1),
                        i.alt(e, s, ['auto']),
                        2 === n.length &&
                          i.alt('lineAlign', n[1], ['start', ut, 'end']);
                      break;
                    case 'position':
                      (n = t.split(',')),
                        i.percent(e, n[0]),
                        2 === n.length &&
                          i.alt('positionAlign', n[1], [
                            'start',
                            ut,
                            'end',
                            'line-left',
                            'line-right',
                            'auto'
                          ]);
                      break;
                    case 'size':
                      i.percent(e, t);
                      break;
                    case 'align':
                      i.alt(e, t, ['start', ut, 'end', 'left', 'right']);
                  }
                },
                /:/,
                /\s/
              ),
                (t.region = i.get('region', null)),
                (t.vertical = i.get('vertical', ''));
              var a = i.get('line', 'auto');
              'auto' === a && -1 === lt.line && (a = -1),
                (t.line = a),
                (t.lineAlign = i.get('lineAlign', 'start')),
                (t.snapToLines = i.get('snapToLines', !0)),
                (t.size = i.get('size', 100)),
                (t.align = i.get('align', ut));
              var n = i.get('position', 'auto');
              'auto' === n &&
                50 === lt.position &&
                (n =
                  'start' === t.align || 'left' === t.align
                    ? 0
                    : 'end' === t.align || 'right' === t.align
                    ? 100
                    : 50),
                (t.position = n);
            })(e, t);
        }
        function ct(e) {
          return e.replace(/<br(?: \/)?>/gi, '\n');
        }
        nt.prototype = {
          parse: function(e) {
            var t = this;
            function r() {
              var e = t.buffer,
                r = 0;
              for (e = ct(e); r < e.length && '\r' !== e[r] && '\n' !== e[r]; )
                ++r;
              var i = e.substr(0, r);
              return (
                '\r' === e[r] && ++r,
                '\n' === e[r] && ++r,
                (t.buffer = e.substr(r)),
                i
              );
            }
            e && (t.buffer += t.decoder.decode(e, { stream: !0 }));
            try {
              var i;
              if ('INITIAL' === t.state) {
                if (!/\r\n|\n/.test(t.buffer)) return this;
                var a = (i = r()).match(/^(ï»¿)?WEBVTT([ \t].*)?$/);
                if (!a || !a[0]) throw new Error('Malformed WebVTT signature.');
                t.state = 'HEADER';
              }
              for (var n = !1; t.buffer; ) {
                if (!/\r\n|\n/.test(t.buffer)) return this;
                switch ((n ? (n = !1) : (i = r()), t.state)) {
                  case 'HEADER':
                    /:/.test(i)
                      ? ot(i, function(e, t) {}, /:/)
                      : i || (t.state = 'ID');
                    continue;
                  case 'NOTE':
                    i || (t.state = 'ID');
                    continue;
                  case 'ID':
                    if (/^NOTE($|[ \t])/.test(i)) {
                      t.state = 'NOTE';
                      break;
                    }
                    if (!i) continue;
                    if (
                      ((t.cue = new it(0, 0, '')),
                      (t.state = 'CUE'),
                      -1 === i.indexOf('--\x3e'))
                    ) {
                      t.cue.id = i;
                      continue;
                    }
                  case 'CUE':
                    try {
                      dt(i, t.cue, t.regionList);
                    } catch (e) {
                      (t.cue = null), (t.state = 'BADCUE');
                      continue;
                    }
                    t.state = 'CUETEXT';
                    continue;
                  case 'CUETEXT':
                    var s = -1 !== i.indexOf('--\x3e');
                    if (!i || (s && (n = !0))) {
                      t.oncue && t.oncue(t.cue),
                        (t.cue = null),
                        (t.state = 'ID');
                      continue;
                    }
                    t.cue.text && (t.cue.text += '\n'), (t.cue.text += i);
                    continue;
                  case 'BADCUE':
                    i || (t.state = 'ID');
                    continue;
                }
              }
            } catch (e) {
              'CUETEXT' === t.state && t.cue && t.oncue && t.oncue(t.cue),
                (t.cue = null),
                (t.state = 'INITIAL' === t.state ? 'BADWEBVTT' : 'BADCUE');
            }
            return this;
          },
          flush: function() {
            try {
              if (
                ((this.buffer += this.decoder.decode()),
                (this.cue || 'HEADER' === this.state) &&
                  ((this.buffer += '\n\n'), this.parse()),
                'INITIAL' === this.state)
              )
                throw new Error('Malformed WebVTT signature.');
            } catch (e) {
              throw e;
            }
            return this.onflush && this.onflush(), this;
          }
        };
        var ht = nt;
        function ft(e, t, r, i) {
          for (
            var a, n, s, o, l, u = [], d = window.VTTCue || TextTrackCue, c = 0;
            c < i.rows.length;
            c++
          )
            if (((s = !0), (o = 0), (l = ''), !(a = i.rows[c]).isEmpty())) {
              for (var h = 0; h < a.chars.length; h++)
                a.chars[h].uchar.match(/\s/) && s
                  ? o++
                  : ((l += a.chars[h].uchar), (s = !1));
              (a.cueStartTime = t),
                t === r && (r += 1e-4),
                (n = new d(t, r, ct(l.trim()))),
                o >= 16 ? o-- : o++,
                navigator.userAgent.match(/Firefox\//)
                  ? (n.line = c + 1)
                  : (n.line = c > 7 ? c - 2 : c + 1),
                (n.align = 'left'),
                (n.position = Math.max(0, Math.min(100, (o / 32) * 100))),
                u.push(n),
                e && e.addCue(n);
            }
          return u;
        }
        var gt,
          pt = {
            42: 225,
            92: 233,
            94: 237,
            95: 243,
            96: 250,
            123: 231,
            124: 247,
            125: 209,
            126: 241,
            127: 9608,
            128: 174,
            129: 176,
            130: 189,
            131: 191,
            132: 8482,
            133: 162,
            134: 163,
            135: 9834,
            136: 224,
            137: 32,
            138: 232,
            139: 226,
            140: 234,
            141: 238,
            142: 244,
            143: 251,
            144: 193,
            145: 201,
            146: 211,
            147: 218,
            148: 220,
            149: 252,
            150: 8216,
            151: 161,
            152: 42,
            153: 8217,
            154: 9473,
            155: 169,
            156: 8480,
            157: 8226,
            158: 8220,
            159: 8221,
            160: 192,
            161: 194,
            162: 199,
            163: 200,
            164: 202,
            165: 203,
            166: 235,
            167: 206,
            168: 207,
            169: 239,
            170: 212,
            171: 217,
            172: 249,
            173: 219,
            174: 171,
            175: 187,
            176: 195,
            177: 227,
            178: 205,
            179: 204,
            180: 236,
            181: 210,
            182: 242,
            183: 213,
            184: 245,
            185: 123,
            186: 125,
            187: 92,
            188: 94,
            189: 95,
            190: 124,
            191: 8764,
            192: 196,
            193: 228,
            194: 214,
            195: 246,
            196: 223,
            197: 165,
            198: 164,
            199: 9475,
            200: 197,
            201: 229,
            202: 216,
            203: 248,
            204: 9487,
            205: 9491,
            206: 9495,
            207: 9499
          },
          vt = function(e) {
            var t = e;
            return pt.hasOwnProperty(e) && (t = pt[e]), String.fromCharCode(t);
          },
          mt = { 17: 1, 18: 3, 21: 5, 22: 7, 23: 9, 16: 11, 19: 12, 20: 14 },
          yt = { 17: 2, 18: 4, 21: 6, 22: 8, 23: 10, 19: 13, 20: 15 },
          bt = { 25: 1, 26: 3, 29: 5, 30: 7, 31: 9, 24: 11, 27: 12, 28: 14 },
          Tt = { 25: 2, 26: 4, 29: 6, 30: 8, 31: 10, 27: 13, 28: 15 },
          Et = [
            'white',
            'green',
            'blue',
            'cyan',
            'red',
            'yellow',
            'magenta',
            'black',
            'transparent'
          ];
        !(function(e) {
          (e[(e.ERROR = 0)] = 'ERROR'),
            (e[(e.TEXT = 1)] = 'TEXT'),
            (e[(e.WARNING = 2)] = 'WARNING'),
            (e[(e.INFO = 2)] = 'INFO'),
            (e[(e.DEBUG = 3)] = 'DEBUG'),
            (e[(e.DATA = 3)] = 'DATA');
        })(gt || (gt = {}));
        var St = (function() {
            function e() {
              (this.time = null), (this.verboseLevel = gt.ERROR);
            }
            return (
              (e.prototype.log = function(e, t) {
                this.verboseLevel >= e &&
                  d.b.log(this.time + ' [' + e + '] ' + t);
              }),
              e
            );
          })(),
          _t = function(e) {
            for (var t = [], r = 0; r < e.length; r++)
              t.push(e[r].toString(16));
            return t;
          },
          Rt = (function() {
            function e(e, t, r, i, a) {
              (this.foreground = void 0),
                (this.underline = void 0),
                (this.italics = void 0),
                (this.background = void 0),
                (this.flash = void 0),
                (this.foreground = e || 'white'),
                (this.underline = t || !1),
                (this.italics = r || !1),
                (this.background = i || 'black'),
                (this.flash = a || !1);
            }
            var t = e.prototype;
            return (
              (t.reset = function() {
                (this.foreground = 'white'),
                  (this.underline = !1),
                  (this.italics = !1),
                  (this.background = 'black'),
                  (this.flash = !1);
              }),
              (t.setStyles = function(e) {
                for (
                  var t = [
                      'foreground',
                      'underline',
                      'italics',
                      'background',
                      'flash'
                    ],
                    r = 0;
                  r < t.length;
                  r++
                ) {
                  var i = t[r];
                  e.hasOwnProperty(i) && (this[i] = e[i]);
                }
              }),
              (t.isDefault = function() {
                return (
                  'white' === this.foreground &&
                  !this.underline &&
                  !this.italics &&
                  'black' === this.background &&
                  !this.flash
                );
              }),
              (t.equals = function(e) {
                return (
                  this.foreground === e.foreground &&
                  this.underline === e.underline &&
                  this.italics === e.italics &&
                  this.background === e.background &&
                  this.flash === e.flash
                );
              }),
              (t.copy = function(e) {
                (this.foreground = e.foreground),
                  (this.underline = e.underline),
                  (this.italics = e.italics),
                  (this.background = e.background),
                  (this.flash = e.flash);
              }),
              (t.toString = function() {
                return (
                  'color=' +
                  this.foreground +
                  ', underline=' +
                  this.underline +
                  ', italics=' +
                  this.italics +
                  ', background=' +
                  this.background +
                  ', flash=' +
                  this.flash
                );
              }),
              e
            );
          })(),
          At = (function() {
            function e(e, t, r, i, a, n) {
              (this.uchar = void 0),
                (this.penState = void 0),
                (this.uchar = e || ' '),
                (this.penState = new Rt(t, r, i, a, n));
            }
            var t = e.prototype;
            return (
              (t.reset = function() {
                (this.uchar = ' '), this.penState.reset();
              }),
              (t.setChar = function(e, t) {
                (this.uchar = e), this.penState.copy(t);
              }),
              (t.setPenState = function(e) {
                this.penState.copy(e);
              }),
              (t.equals = function(e) {
                return (
                  this.uchar === e.uchar && this.penState.equals(e.penState)
                );
              }),
              (t.copy = function(e) {
                (this.uchar = e.uchar), this.penState.copy(e.penState);
              }),
              (t.isEmpty = function() {
                return ' ' === this.uchar && this.penState.isDefault();
              }),
              e
            );
          })(),
          kt = (function() {
            function e(e) {
              (this.chars = void 0),
                (this.pos = void 0),
                (this.currPenState = void 0),
                (this.cueStartTime = void 0),
                (this.logger = void 0),
                (this.chars = []);
              for (var t = 0; t < 100; t++) this.chars.push(new At());
              (this.logger = e), (this.pos = 0), (this.currPenState = new Rt());
            }
            var t = e.prototype;
            return (
              (t.equals = function(e) {
                for (var t = !0, r = 0; r < 100; r++)
                  if (!this.chars[r].equals(e.chars[r])) {
                    t = !1;
                    break;
                  }
                return t;
              }),
              (t.copy = function(e) {
                for (var t = 0; t < 100; t++) this.chars[t].copy(e.chars[t]);
              }),
              (t.isEmpty = function() {
                for (var e = !0, t = 0; t < 100; t++)
                  if (!this.chars[t].isEmpty()) {
                    e = !1;
                    break;
                  }
                return e;
              }),
              (t.setCursor = function(e) {
                this.pos !== e && (this.pos = e),
                  this.pos < 0
                    ? (this.logger.log(
                        gt.DEBUG,
                        'Negative cursor position ' + this.pos
                      ),
                      (this.pos = 0))
                    : this.pos > 100 &&
                      (this.logger.log(
                        gt.DEBUG,
                        'Too large cursor position ' + this.pos
                      ),
                      (this.pos = 100));
              }),
              (t.moveCursor = function(e) {
                var t = this.pos + e;
                if (e > 1)
                  for (var r = this.pos + 1; r < t + 1; r++)
                    this.chars[r].setPenState(this.currPenState);
                this.setCursor(t);
              }),
              (t.backSpace = function() {
                this.moveCursor(-1),
                  this.chars[this.pos].setChar(' ', this.currPenState);
              }),
              (t.insertChar = function(e) {
                e >= 144 && this.backSpace();
                var t = vt(e);
                this.pos >= 100
                  ? this.logger.log(
                      gt.ERROR,
                      'Cannot insert ' +
                        e.toString(16) +
                        ' (' +
                        t +
                        ') at position ' +
                        this.pos +
                        '. Skipping it!'
                    )
                  : (this.chars[this.pos].setChar(t, this.currPenState),
                    this.moveCursor(1));
              }),
              (t.clearFromPos = function(e) {
                var t;
                for (t = e; t < 100; t++) this.chars[t].reset();
              }),
              (t.clear = function() {
                this.clearFromPos(0), (this.pos = 0), this.currPenState.reset();
              }),
              (t.clearToEndOfRow = function() {
                this.clearFromPos(this.pos);
              }),
              (t.getTextString = function() {
                for (var e = [], t = !0, r = 0; r < 100; r++) {
                  var i = this.chars[r].uchar;
                  ' ' !== i && (t = !1), e.push(i);
                }
                return t ? '' : e.join('');
              }),
              (t.setPenStyles = function(e) {
                this.currPenState.setStyles(e),
                  this.chars[this.pos].setPenState(this.currPenState);
              }),
              e
            );
          })(),
          wt = (function() {
            function e(e) {
              (this.rows = void 0),
                (this.currRow = void 0),
                (this.nrRollUpRows = void 0),
                (this.lastOutputScreen = void 0),
                (this.logger = void 0),
                (this.rows = []);
              for (var t = 0; t < 15; t++) this.rows.push(new kt(e));
              (this.logger = e),
                (this.currRow = 14),
                (this.nrRollUpRows = null),
                (this.lastOutputScreen = null),
                this.reset();
            }
            var t = e.prototype;
            return (
              (t.reset = function() {
                for (var e = 0; e < 15; e++) this.rows[e].clear();
                this.currRow = 14;
              }),
              (t.equals = function(e) {
                for (var t = !0, r = 0; r < 15; r++)
                  if (!this.rows[r].equals(e.rows[r])) {
                    t = !1;
                    break;
                  }
                return t;
              }),
              (t.copy = function(e) {
                for (var t = 0; t < 15; t++) this.rows[t].copy(e.rows[t]);
              }),
              (t.isEmpty = function() {
                for (var e = !0, t = 0; t < 15; t++)
                  if (!this.rows[t].isEmpty()) {
                    e = !1;
                    break;
                  }
                return e;
              }),
              (t.backSpace = function() {
                this.rows[this.currRow].backSpace();
              }),
              (t.clearToEndOfRow = function() {
                this.rows[this.currRow].clearToEndOfRow();
              }),
              (t.insertChar = function(e) {
                this.rows[this.currRow].insertChar(e);
              }),
              (t.setPen = function(e) {
                this.rows[this.currRow].setPenStyles(e);
              }),
              (t.moveCursor = function(e) {
                this.rows[this.currRow].moveCursor(e);
              }),
              (t.setCursor = function(e) {
                this.logger.log(gt.INFO, 'setCursor: ' + e),
                  this.rows[this.currRow].setCursor(e);
              }),
              (t.setPAC = function(e) {
                this.logger.log(gt.INFO, 'pacData = ' + JSON.stringify(e));
                var t = e.row - 1;
                if (
                  (this.nrRollUpRows &&
                    t < this.nrRollUpRows - 1 &&
                    (t = this.nrRollUpRows - 1),
                  this.nrRollUpRows && this.currRow !== t)
                ) {
                  for (var r = 0; r < 15; r++) this.rows[r].clear();
                  var i = this.currRow + 1 - this.nrRollUpRows,
                    a = this.lastOutputScreen;
                  if (a) {
                    var n = a.rows[i].cueStartTime,
                      s = this.logger.time;
                    if (n && null !== s && n < s)
                      for (var o = 0; o < this.nrRollUpRows; o++)
                        this.rows[t - this.nrRollUpRows + o + 1].copy(
                          a.rows[i + o]
                        );
                  }
                }
                this.currRow = t;
                var l = this.rows[this.currRow];
                if (null !== e.indent) {
                  var u = e.indent,
                    d = Math.max(u - 1, 0);
                  l.setCursor(e.indent),
                    (e.color = l.chars[d].penState.foreground);
                }
                var c = {
                  foreground: e.color,
                  underline: e.underline,
                  italics: e.italics,
                  background: 'black',
                  flash: !1
                };
                this.setPen(c);
              }),
              (t.setBkgData = function(e) {
                this.logger.log(gt.INFO, 'bkgData = ' + JSON.stringify(e)),
                  this.backSpace(),
                  this.setPen(e),
                  this.insertChar(32);
              }),
              (t.setRollUpRows = function(e) {
                this.nrRollUpRows = e;
              }),
              (t.rollUp = function() {
                if (null !== this.nrRollUpRows) {
                  this.logger.log(gt.TEXT, this.getDisplayText());
                  var e = this.currRow + 1 - this.nrRollUpRows,
                    t = this.rows.splice(e, 1)[0];
                  t.clear(),
                    this.rows.splice(this.currRow, 0, t),
                    this.logger.log(gt.INFO, 'Rolling up');
                } else
                  this.logger.log(
                    gt.DEBUG,
                    'roll_up but nrRollUpRows not set yet'
                  );
              }),
              (t.getDisplayText = function(e) {
                e = e || !1;
                for (var t = [], r = '', i = -1, a = 0; a < 15; a++) {
                  var n = this.rows[a].getTextString();
                  n &&
                    ((i = a + 1),
                    e
                      ? t.push('Row ' + i + ": '" + n + "'")
                      : t.push(n.trim()));
                }
                return (
                  t.length > 0 &&
                    (r = e ? '[' + t.join(' | ') + ']' : t.join('\n')),
                  r
                );
              }),
              (t.getTextAndFormat = function() {
                return this.rows;
              }),
              e
            );
          })(),
          Lt = (function() {
            function e(e, t, r) {
              (this.chNr = void 0),
                (this.outputFilter = void 0),
                (this.mode = void 0),
                (this.verbose = void 0),
                (this.displayedMemory = void 0),
                (this.nonDisplayedMemory = void 0),
                (this.lastOutputScreen = void 0),
                (this.currRollUpRow = void 0),
                (this.writeScreen = void 0),
                (this.cueStartTime = void 0),
                (this.logger = void 0),
                (this.chNr = e),
                (this.outputFilter = t),
                (this.mode = null),
                (this.verbose = 0),
                (this.displayedMemory = new wt(r)),
                (this.nonDisplayedMemory = new wt(r)),
                (this.lastOutputScreen = new wt(r)),
                (this.currRollUpRow = this.displayedMemory.rows[14]),
                (this.writeScreen = this.displayedMemory),
                (this.mode = null),
                (this.cueStartTime = null),
                (this.logger = r);
            }
            var t = e.prototype;
            return (
              (t.reset = function() {
                (this.mode = null),
                  this.displayedMemory.reset(),
                  this.nonDisplayedMemory.reset(),
                  this.lastOutputScreen.reset(),
                  this.outputFilter.reset(),
                  (this.currRollUpRow = this.displayedMemory.rows[14]),
                  (this.writeScreen = this.displayedMemory),
                  (this.mode = null),
                  (this.cueStartTime = null);
              }),
              (t.getHandler = function() {
                return this.outputFilter;
              }),
              (t.setHandler = function(e) {
                this.outputFilter = e;
              }),
              (t.setPAC = function(e) {
                this.writeScreen.setPAC(e);
              }),
              (t.setBkgData = function(e) {
                this.writeScreen.setBkgData(e);
              }),
              (t.setMode = function(e) {
                e !== this.mode &&
                  ((this.mode = e),
                  this.logger.log(gt.INFO, 'MODE=' + e),
                  'MODE_POP-ON' === this.mode
                    ? (this.writeScreen = this.nonDisplayedMemory)
                    : ((this.writeScreen = this.displayedMemory),
                      this.writeScreen.reset()),
                  'MODE_ROLL-UP' !== this.mode &&
                    ((this.displayedMemory.nrRollUpRows = null),
                    (this.nonDisplayedMemory.nrRollUpRows = null)),
                  (this.mode = e));
              }),
              (t.insertChars = function(e) {
                for (var t = 0; t < e.length; t++)
                  this.writeScreen.insertChar(e[t]);
                var r =
                  this.writeScreen === this.displayedMemory
                    ? 'DISP'
                    : 'NON_DISP';
                this.logger.log(
                  gt.INFO,
                  r + ': ' + this.writeScreen.getDisplayText(!0)
                ),
                  ('MODE_PAINT-ON' !== this.mode &&
                    'MODE_ROLL-UP' !== this.mode) ||
                    (this.logger.log(
                      gt.TEXT,
                      'DISPLAYED: ' + this.displayedMemory.getDisplayText(!0)
                    ),
                    this.outputDataUpdate());
              }),
              (t.ccRCL = function() {
                this.logger.log(gt.INFO, 'RCL - Resume Caption Loading'),
                  this.setMode('MODE_POP-ON');
              }),
              (t.ccBS = function() {
                this.logger.log(gt.INFO, 'BS - BackSpace'),
                  'MODE_TEXT' !== this.mode &&
                    (this.writeScreen.backSpace(),
                    this.writeScreen === this.displayedMemory &&
                      this.outputDataUpdate());
              }),
              (t.ccAOF = function() {}),
              (t.ccAON = function() {}),
              (t.ccDER = function() {
                this.logger.log(gt.INFO, 'DER- Delete to End of Row'),
                  this.writeScreen.clearToEndOfRow(),
                  this.outputDataUpdate();
              }),
              (t.ccRU = function(e) {
                this.logger.log(gt.INFO, 'RU(' + e + ') - Roll Up'),
                  (this.writeScreen = this.displayedMemory),
                  this.setMode('MODE_ROLL-UP'),
                  this.writeScreen.setRollUpRows(e);
              }),
              (t.ccFON = function() {
                this.logger.log(gt.INFO, 'FON - Flash On'),
                  this.writeScreen.setPen({ flash: !0 });
              }),
              (t.ccRDC = function() {
                this.logger.log(gt.INFO, 'RDC - Resume Direct Captioning'),
                  this.setMode('MODE_PAINT-ON');
              }),
              (t.ccTR = function() {
                this.logger.log(gt.INFO, 'TR'), this.setMode('MODE_TEXT');
              }),
              (t.ccRTD = function() {
                this.logger.log(gt.INFO, 'RTD'), this.setMode('MODE_TEXT');
              }),
              (t.ccEDM = function() {
                this.logger.log(gt.INFO, 'EDM - Erase Displayed Memory'),
                  this.displayedMemory.reset(),
                  this.outputDataUpdate(!0);
              }),
              (t.ccCR = function() {
                this.logger.log(gt.INFO, 'CR - Carriage Return'),
                  this.writeScreen.rollUp(),
                  this.outputDataUpdate(!0);
              }),
              (t.ccENM = function() {
                this.logger.log(gt.INFO, 'ENM - Erase Non-displayed Memory'),
                  this.nonDisplayedMemory.reset();
              }),
              (t.ccEOC = function() {
                if (
                  (this.logger.log(gt.INFO, 'EOC - End Of Caption'),
                  'MODE_POP-ON' === this.mode)
                ) {
                  var e = this.displayedMemory;
                  (this.displayedMemory = this.nonDisplayedMemory),
                    (this.nonDisplayedMemory = e),
                    (this.writeScreen = this.nonDisplayedMemory),
                    this.logger.log(
                      gt.TEXT,
                      'DISP: ' + this.displayedMemory.getDisplayText()
                    );
                }
                this.outputDataUpdate(!0);
              }),
              (t.ccTO = function(e) {
                this.logger.log(gt.INFO, 'TO(' + e + ') - Tab Offset'),
                  this.writeScreen.moveCursor(e);
              }),
              (t.ccMIDROW = function(e) {
                var t = { flash: !1 };
                if (
                  ((t.underline = e % 2 == 1), (t.italics = e >= 46), t.italics)
                )
                  t.foreground = 'white';
                else {
                  var r = Math.floor(e / 2) - 16;
                  t.foreground = [
                    'white',
                    'green',
                    'blue',
                    'cyan',
                    'red',
                    'yellow',
                    'magenta'
                  ][r];
                }
                this.logger.log(gt.INFO, 'MIDROW: ' + JSON.stringify(t)),
                  this.writeScreen.setPen(t);
              }),
              (t.outputDataUpdate = function(e) {
                void 0 === e && (e = !1);
                var t = this.logger.time;
                null !== t &&
                  this.outputFilter &&
                  (null !== this.cueStartTime || this.displayedMemory.isEmpty()
                    ? this.displayedMemory.equals(this.lastOutputScreen) ||
                      (this.outputFilter.newCue(
                        this.cueStartTime,
                        t,
                        this.lastOutputScreen
                      ),
                      e &&
                        this.outputFilter.dispatchCue &&
                        this.outputFilter.dispatchCue(),
                      (this.cueStartTime = this.displayedMemory.isEmpty()
                        ? null
                        : t))
                    : (this.cueStartTime = t),
                  this.lastOutputScreen.copy(this.displayedMemory));
              }),
              (t.cueSplitAtTime = function(e) {
                this.outputFilter &&
                  (this.displayedMemory.isEmpty() ||
                    (this.outputFilter.newCue &&
                      this.outputFilter.newCue(
                        this.cueStartTime,
                        e,
                        this.displayedMemory
                      ),
                    (this.cueStartTime = e)));
              }),
              e
            );
          })();
        function Dt(e, t, r) {
          (r.a = e), (r.b = t);
        }
        function Ot(e, t, r) {
          return r.a === e && r.b === t;
        }
        var Ct = (function() {
            function e(e, t, r) {
              (this.channels = void 0),
                (this.currentChannel = 0),
                (this.cmdHistory = void 0),
                (this.logger = void 0);
              var i = new St();
              (this.channels = [null, new Lt(e, t, i), new Lt(e + 1, r, i)]),
                (this.cmdHistory = { a: null, b: null }),
                (this.logger = i);
            }
            var t = e.prototype;
            return (
              (t.getHandler = function(e) {
                return this.channels[e].getHandler();
              }),
              (t.setHandler = function(e, t) {
                this.channels[e].setHandler(t);
              }),
              (t.addData = function(e, t) {
                var r,
                  i,
                  a,
                  n = !1;
                this.logger.time = e;
                for (var s = 0; s < t.length; s += 2)
                  if (
                    ((i = 127 & t[s]), (a = 127 & t[s + 1]), 0 !== i || 0 !== a)
                  ) {
                    if (
                      (this.logger.log(
                        gt.DATA,
                        '[' + _t([t[s], t[s + 1]]) + '] -> (' + _t([i, a]) + ')'
                      ),
                      (r = this.parseCmd(i, a)) || (r = this.parseMidrow(i, a)),
                      r || (r = this.parsePAC(i, a)),
                      r || (r = this.parseBackgroundAttributes(i, a)),
                      !r && (n = this.parseChars(i, a)))
                    ) {
                      var o = this.currentChannel;
                      if (o && o > 0) this.channels[o].insertChars(n);
                      else
                        this.logger.log(
                          gt.WARNING,
                          'No channel found yet. TEXT-MODE?'
                        );
                    }
                    r ||
                      n ||
                      this.logger.log(
                        gt.WARNING,
                        "Couldn't parse cleaned data " +
                          _t([i, a]) +
                          ' orig: ' +
                          _t([t[s], t[s + 1]])
                      );
                  }
              }),
              (t.parseCmd = function(e, t) {
                var r = this.cmdHistory;
                if (
                  !(
                    (20 === e || 28 === e || 21 === e || 29 === e) &&
                    t >= 32 &&
                    t <= 47
                  ) &&
                  !((23 === e || 31 === e) && t >= 33 && t <= 35)
                )
                  return !1;
                if (Ot(e, t, r))
                  return (
                    Dt(null, null, r),
                    this.logger.log(
                      gt.DEBUG,
                      'Repeated command (' + _t([e, t]) + ') is dropped'
                    ),
                    !0
                  );
                var i = 20 === e || 21 === e || 23 === e ? 1 : 2,
                  a = this.channels[i];
                return (
                  20 === e || 21 === e || 28 === e || 29 === e
                    ? 32 === t
                      ? a.ccRCL()
                      : 33 === t
                      ? a.ccBS()
                      : 34 === t
                      ? a.ccAOF()
                      : 35 === t
                      ? a.ccAON()
                      : 36 === t
                      ? a.ccDER()
                      : 37 === t
                      ? a.ccRU(2)
                      : 38 === t
                      ? a.ccRU(3)
                      : 39 === t
                      ? a.ccRU(4)
                      : 40 === t
                      ? a.ccFON()
                      : 41 === t
                      ? a.ccRDC()
                      : 42 === t
                      ? a.ccTR()
                      : 43 === t
                      ? a.ccRTD()
                      : 44 === t
                      ? a.ccEDM()
                      : 45 === t
                      ? a.ccCR()
                      : 46 === t
                      ? a.ccENM()
                      : 47 === t && a.ccEOC()
                    : a.ccTO(t - 32),
                  Dt(e, t, r),
                  (this.currentChannel = i),
                  !0
                );
              }),
              (t.parseMidrow = function(e, t) {
                var r = 0;
                if ((17 === e || 25 === e) && t >= 32 && t <= 47) {
                  if ((r = 17 === e ? 1 : 2) !== this.currentChannel)
                    return (
                      this.logger.log(
                        gt.ERROR,
                        'Mismatch channel in midrow parsing'
                      ),
                      !1
                    );
                  var i = this.channels[r];
                  return (
                    !!i &&
                    (i.ccMIDROW(t),
                    this.logger.log(gt.DEBUG, 'MIDROW (' + _t([e, t]) + ')'),
                    !0)
                  );
                }
                return !1;
              }),
              (t.parsePAC = function(e, t) {
                var r,
                  i = this.cmdHistory;
                if (
                  !(
                    ((e >= 17 && e <= 23) || (e >= 25 && e <= 31)) &&
                    t >= 64 &&
                    t <= 127
                  ) &&
                  !((16 === e || 24 === e) && t >= 64 && t <= 95)
                )
                  return !1;
                if (Ot(e, t, i)) return Dt(null, null, i), !0;
                var a = e <= 23 ? 1 : 2;
                r =
                  t >= 64 && t <= 95
                    ? 1 === a
                      ? mt[e]
                      : bt[e]
                    : 1 === a
                    ? yt[e]
                    : Tt[e];
                var n = this.channels[a];
                return (
                  !!n &&
                  (n.setPAC(this.interpretPAC(r, t)),
                  Dt(e, t, i),
                  (this.currentChannel = a),
                  !0)
                );
              }),
              (t.interpretPAC = function(e, t) {
                var r = t,
                  i = {
                    color: null,
                    italics: !1,
                    indent: null,
                    underline: !1,
                    row: e
                  };
                return (
                  (r = t > 95 ? t - 96 : t - 64),
                  (i.underline = 1 == (1 & r)),
                  r <= 13
                    ? (i.color = [
                        'white',
                        'green',
                        'blue',
                        'cyan',
                        'red',
                        'yellow',
                        'magenta',
                        'white'
                      ][Math.floor(r / 2)])
                    : r <= 15
                    ? ((i.italics = !0), (i.color = 'white'))
                    : (i.indent = 4 * Math.floor((r - 16) / 2)),
                  i
                );
              }),
              (t.parseChars = function(e, t) {
                var r,
                  i = null,
                  a = null;
                if (
                  (e >= 25 ? ((r = 2), (a = e - 8)) : ((r = 1), (a = e)),
                  a >= 17 && a <= 19)
                ) {
                  var n = t;
                  (n = 17 === a ? t + 80 : 18 === a ? t + 112 : t + 144),
                    this.logger.log(
                      gt.INFO,
                      "Special char '" + vt(n) + "' in channel " + r
                    ),
                    (i = [n]);
                } else e >= 32 && e <= 127 && (i = 0 === t ? [e] : [e, t]);
                if (i) {
                  var s = _t(i);
                  this.logger.log(gt.DEBUG, 'Char codes =  ' + s.join(',')),
                    Dt(e, t, this.cmdHistory);
                }
                return i;
              }),
              (t.parseBackgroundAttributes = function(e, t) {
                var r;
                if (
                  !((16 === e || 24 === e) && t >= 32 && t <= 47) &&
                  !((23 === e || 31 === e) && t >= 45 && t <= 47)
                )
                  return !1;
                var i = {};
                16 === e || 24 === e
                  ? ((r = Math.floor((t - 32) / 2)),
                    (i.background = Et[r]),
                    t % 2 == 1 && (i.background = i.background + '_semi'))
                  : 45 === t
                  ? (i.background = 'transparent')
                  : ((i.foreground = 'black'), 47 === t && (i.underline = !0));
                var a = e <= 23 ? 1 : 2;
                return (
                  this.channels[a].setBkgData(i), Dt(e, t, this.cmdHistory), !0
                );
              }),
              (t.reset = function() {
                for (var e = 0; e < Object.keys(this.channels).length; e++) {
                  var t = this.channels[e];
                  t && t.reset();
                }
                this.cmdHistory = { a: null, b: null };
              }),
              (t.cueSplitAtTime = function(e) {
                for (var t = 0; t < this.channels.length; t++) {
                  var r = this.channels[t];
                  r && r.cueSplitAtTime(e);
                }
              }),
              e
            );
          })(),
          It = (function() {
            function e(e, t) {
              (this.timelineController = void 0),
                (this.cueRanges = []),
                (this.trackName = void 0),
                (this.startTime = null),
                (this.endTime = null),
                (this.screen = null),
                (this.timelineController = e),
                (this.trackName = t);
            }
            var t = e.prototype;
            return (
              (t.dispatchCue = function() {
                null !== this.startTime &&
                  (this.timelineController.addCues(
                    this.trackName,
                    this.startTime,
                    this.endTime,
                    this.screen,
                    this.cueRanges
                  ),
                  (this.startTime = null));
              }),
              (t.newCue = function(e, t, r) {
                (null === this.startTime || this.startTime > e) &&
                  (this.startTime = e),
                  (this.endTime = t),
                  (this.screen = r),
                  this.timelineController.createCaptionsTrack(this.trackName);
              }),
              (t.reset = function() {
                this.cueRanges = [];
              }),
              e
            );
          })(),
          Pt = function(e, t, r) {
            return e.substr(r || 0, t.length) === t;
          },
          xt = function(e) {
            for (var t = 5381, r = e.length; r; )
              t = (33 * t) ^ e.charCodeAt(--r);
            return (t >>> 0).toString();
          },
          Mt = {
            parse: function(e, t, r, i, a, n) {
              var s,
                o = Object(Fe.b)(new Uint8Array(e))
                  .trim()
                  .replace(/\r\n|\n\r|\n|\r/g, '\n')
                  .split('\n'),
                u = '00:00.000',
                d = 0,
                c = 0,
                h = 0,
                f = [],
                g = !0,
                p = !1,
                v = new ht();
              (v.oncue = function(e) {
                var t = r[i],
                  a = r.ccOffset;
                t &&
                  t.new &&
                  (void 0 !== c
                    ? (a = r.ccOffset = t.start)
                    : (function(e, t, r) {
                        var i = e[t],
                          a = e[i.prevCC];
                        if (!a || (!a.new && i.new))
                          return (
                            (e.ccOffset = e.presentationOffset = i.start),
                            void (i.new = !1)
                          );
                        for (; a && a.new; )
                          (e.ccOffset += i.start - a.start),
                            (i.new = !1),
                            (a = e[(i = a).prevCC]);
                        e.presentationOffset = r;
                      })(r, i, h)),
                  h && (a = h - r.presentationOffset),
                  p && ((e.startTime += a - c), (e.endTime += a - c)),
                  (e.id =
                    xt(e.startTime.toString()) +
                    xt(e.endTime.toString()) +
                    xt(e.text)),
                  (e.text = decodeURIComponent(encodeURIComponent(e.text))),
                  e.endTime > 0 && f.push(e);
              }),
                (v.onparsingerror = function(e) {
                  s = e;
                }),
                (v.onflush = function() {
                  s && n ? n(s) : a(f);
                }),
                o.forEach(function(e) {
                  if (g) {
                    if (Pt(e, 'X-TIMESTAMP-MAP=')) {
                      (g = !1),
                        (p = !0),
                        e
                          .substr(16)
                          .split(',')
                          .forEach(function(e) {
                            Pt(e, 'LOCAL:')
                              ? (u = e.substr(6))
                              : Pt(e, 'MPEGTS:') && (d = parseInt(e.substr(7)));
                          });
                      try {
                        t + (9e4 * r[i].start || 0) < 0 && (t += 8589934592),
                          (d -= t),
                          (c =
                            (function(e) {
                              var t = parseInt(e.substr(-3)),
                                r = parseInt(e.substr(-6, 2)),
                                i = parseInt(e.substr(-9, 2)),
                                a =
                                  e.length > 9
                                    ? parseInt(e.substr(0, e.indexOf(':')))
                                    : 0;
                              if (
                                !(
                                  Object(l.a)(t) &&
                                  Object(l.a)(r) &&
                                  Object(l.a)(i) &&
                                  Object(l.a)(a)
                                )
                              )
                                throw Error(
                                  'Malformed X-TIMESTAMP-MAP: Local:' + e
                                );
                              return (
                                (t += 1e3 * r), (t += 6e4 * i), (t += 36e5 * a)
                              );
                            })(u) / 1e3),
                          (h = d / 9e4);
                      } catch (e) {
                        (p = !1), (s = e);
                      }
                      return;
                    }
                    '' === e && (g = !1);
                  }
                  v.parse(e + '\n');
                }),
                v.flush();
            }
          };
        function Ft(e) {
          if (void 0 === e)
            throw new ReferenceError(
              "this hasn't been initialised - super() hasn't been called"
            );
          return e;
        }
        function Ut(e, t) {
          return e && e.label === t.name && !(e.textTrack1 || e.textTrack2);
        }
        var Nt = (function(e) {
          var t, r;
          function i(t) {
            var r;
            if (
              (((r =
                e.call(
                  this,
                  t,
                  u.a.MEDIA_ATTACHING,
                  u.a.MEDIA_DETACHING,
                  u.a.FRAG_PARSING_USERDATA,
                  u.a.FRAG_DECRYPTED,
                  u.a.MANIFEST_LOADING,
                  u.a.MANIFEST_LOADED,
                  u.a.FRAG_LOADED,
                  u.a.INIT_PTS_FOUND
                ) || this).media = null),
              (r.config = void 0),
              (r.enabled = !0),
              (r.Cues = void 0),
              (r.textTracks = []),
              (r.tracks = []),
              (r.initPTS = []),
              (r.unparsedVttFrags = []),
              (r.captionsTracks = {}),
              (r.nonNativeCaptionsTracks = {}),
              (r.captionsProperties = void 0),
              (r.cea608Parser1 = void 0),
              (r.cea608Parser2 = void 0),
              (r.lastSn = -1),
              (r.prevCC = -1),
              (r.vttCCs = {
                ccOffset: 0,
                presentationOffset: 0,
                0: { start: 0, prevCC: -1, new: !1 }
              }),
              (r.hls = t),
              (r.config = t.config),
              (r.Cues = t.config.cueHandler),
              (r.captionsProperties = {
                textTrack1: {
                  label: r.config.captionsTextTrack1Label,
                  languageCode: r.config.captionsTextTrack1LanguageCode
                },
                textTrack2: {
                  label: r.config.captionsTextTrack2Label,
                  languageCode: r.config.captionsTextTrack2LanguageCode
                },
                textTrack3: {
                  label: r.config.captionsTextTrack3Label,
                  languageCode: r.config.captionsTextTrack3LanguageCode
                },
                textTrack4: {
                  label: r.config.captionsTextTrack4Label,
                  languageCode: r.config.captionsTextTrack4LanguageCode
                }
              }),
              r.config.enableCEA708Captions)
            ) {
              var i = new It(Ft(r), 'textTrack1'),
                a = new It(Ft(r), 'textTrack2'),
                n = new It(Ft(r), 'textTrack3'),
                s = new It(Ft(r), 'textTrack4');
              (r.cea608Parser1 = new Ct(1, i, a)),
                (r.cea608Parser2 = new Ct(3, n, s));
            }
            return r;
          }
          (r = e),
            ((t = i).prototype = Object.create(r.prototype)),
            (t.prototype.constructor = t),
            (t.__proto__ = r);
          var a = i.prototype;
          return (
            (a.addCues = function(e, t, r, i, a) {
              for (var n, s, o, l, d = !1, c = a.length; c--; ) {
                var h = a[c],
                  f =
                    ((n = h[0]),
                    (s = h[1]),
                    (o = t),
                    (l = r),
                    Math.min(s, l) - Math.max(n, o));
                if (
                  f >= 0 &&
                  ((h[0] = Math.min(h[0], t)),
                  (h[1] = Math.max(h[1], r)),
                  (d = !0),
                  f / (r - t) > 0.5)
                )
                  return;
              }
              if ((d || a.push([t, r]), this.config.renderTextTracksNatively))
                this.Cues.newCue(this.captionsTracks[e], t, r, i);
              else {
                var g = this.Cues.newCue(null, t, r, i);
                this.hls.trigger(u.a.CUES_PARSED, {
                  type: 'captions',
                  cues: g,
                  track: e
                });
              }
            }),
            (a.onInitPtsFound = function(e) {
              var t = this,
                r = e.frag,
                i = e.id,
                a = e.initPTS,
                n = this.unparsedVttFrags;
              'main' === i && (this.initPTS[r.cc] = a),
                n.length &&
                  ((this.unparsedVttFrags = []),
                  n.forEach(function(e) {
                    t.onFragLoaded(e);
                  }));
            }),
            (a.getExistingTrack = function(e) {
              var t = this.media;
              if (t)
                for (var r = 0; r < t.textTracks.length; r++) {
                  var i = t.textTracks[r];
                  if (i[e]) return i;
                }
              return null;
            }),
            (a.createCaptionsTrack = function(e) {
              this.config.renderTextTracksNatively
                ? this.createNativeTrack(e)
                : this.createNonNativeTrack(e);
            }),
            (a.createNativeTrack = function(e) {
              if (!this.captionsTracks[e]) {
                var t = this.captionsProperties,
                  r = this.captionsTracks,
                  i = this.media,
                  a = t[e],
                  n = a.label,
                  s = a.languageCode,
                  o = this.getExistingTrack(e);
                if (o) (r[e] = o), Ne(r[e]), Ue(r[e], i);
                else {
                  var l = this.createTextTrack('captions', n, s);
                  l && ((l[e] = !0), (r[e] = l));
                }
              }
            }),
            (a.createNonNativeTrack = function(e) {
              if (!this.nonNativeCaptionsTracks[e]) {
                var t = this.captionsProperties[e];
                if (t) {
                  var r = {
                    _id: e,
                    label: t.label,
                    kind: 'captions',
                    default: !!t.media && !!t.media.default,
                    closedCaptions: t.media
                  };
                  (this.nonNativeCaptionsTracks[e] = r),
                    this.hls.trigger(u.a.NON_NATIVE_TEXT_TRACKS_FOUND, {
                      tracks: [r]
                    });
                }
              }
            }),
            (a.createTextTrack = function(e, t, r) {
              var i = this.media;
              if (i) return i.addTextTrack(e, t, r);
            }),
            (a.destroy = function() {
              e.prototype.destroy.call(this);
            }),
            (a.onMediaAttaching = function(e) {
              (this.media = e.media), this._cleanTracks();
            }),
            (a.onMediaDetaching = function() {
              var e = this.captionsTracks;
              Object.keys(e).forEach(function(t) {
                Ne(e[t]), delete e[t];
              }),
                (this.nonNativeCaptionsTracks = {});
            }),
            (a.onManifestLoading = function() {
              (this.lastSn = -1),
                (this.prevCC = -1),
                (this.vttCCs = {
                  ccOffset: 0,
                  presentationOffset: 0,
                  0: { start: 0, prevCC: -1, new: !1 }
                }),
                this._cleanTracks(),
                (this.tracks = []),
                (this.captionsTracks = {}),
                (this.nonNativeCaptionsTracks = {});
            }),
            (a._cleanTracks = function() {
              var e = this.media;
              if (e) {
                var t = e.textTracks;
                if (t) for (var r = 0; r < t.length; r++) Ne(t[r]);
              }
            }),
            (a.onManifestLoaded = function(e) {
              var t = this;
              if (
                ((this.textTracks = []),
                (this.unparsedVttFrags = this.unparsedVttFrags || []),
                (this.initPTS = []),
                this.cea608Parser1 &&
                  this.cea608Parser2 &&
                  (this.cea608Parser1.reset(), this.cea608Parser2.reset()),
                this.config.enableWebVTT)
              ) {
                var r = e.subtitles || [],
                  i = this.tracks && r && this.tracks.length === r.length;
                if (
                  ((this.tracks = e.subtitles || []),
                  this.config.renderTextTracksNatively)
                ) {
                  var a = this.media ? this.media.textTracks : [];
                  this.tracks.forEach(function(e, r) {
                    var i;
                    if (r < a.length) {
                      for (var n = null, s = 0; s < a.length; s++)
                        if (Ut(a[s], e)) {
                          n = a[s];
                          break;
                        }
                      n && (i = n);
                    }
                    i || (i = t.createTextTrack('subtitles', e.name, e.lang)),
                      e.default
                        ? (i.mode = t.hls.subtitleDisplay
                            ? 'showing'
                            : 'hidden')
                        : (i.mode = 'disabled'),
                      t.textTracks.push(i);
                  });
                } else if (!i && this.tracks && this.tracks.length) {
                  var n = this.tracks.map(function(e) {
                    return {
                      label: e.name,
                      kind: e.type.toLowerCase(),
                      default: e.default,
                      subtitleTrack: e
                    };
                  });
                  this.hls.trigger(u.a.NON_NATIVE_TEXT_TRACKS_FOUND, {
                    tracks: n
                  });
                }
              }
              this.config.enableCEA708Captions &&
                e.captions &&
                e.captions.forEach(function(e) {
                  var r = /(?:CC|SERVICE)([1-4])/.exec(e.instreamId);
                  if (r) {
                    var i = 'textTrack' + r[1],
                      a = t.captionsProperties[i];
                    a &&
                      ((a.label = e.name),
                      e.lang && (a.languageCode = e.lang),
                      (a.media = e));
                  }
                });
            }),
            (a.onFragLoaded = function(e) {
              var t = e.frag,
                r = e.payload,
                i = this.cea608Parser1,
                a = this.cea608Parser2,
                n = this.initPTS,
                s = this.lastSn,
                o = this.unparsedVttFrags;
              if ('main' === t.type) {
                var d = t.sn;
                t.sn !== s + 1 && i && a && (i.reset(), a.reset()),
                  (this.lastSn = d);
              } else if ('subtitle' === t.type)
                if (r.byteLength) {
                  if (!Object(l.a)(n[t.cc]))
                    return (
                      o.push(e),
                      void (
                        n.length &&
                        this.hls.trigger(u.a.SUBTITLE_FRAG_PROCESSED, {
                          success: !1,
                          frag: t
                        })
                      )
                    );
                  var c = t.decryptdata;
                  (null != c && null != c.key && 'AES-128' === c.method) ||
                    this._parseVTTs(t, r);
                } else
                  this.hls.trigger(u.a.SUBTITLE_FRAG_PROCESSED, {
                    success: !1,
                    frag: t
                  });
            }),
            (a._parseVTTs = function(e, t) {
              var r = this,
                i = this.hls,
                a = this.prevCC,
                n = this.textTracks,
                s = this.vttCCs;
              s[e.cc] ||
                ((s[e.cc] = { start: e.start, prevCC: a, new: !0 }),
                (this.prevCC = e.cc)),
                Mt.parse(
                  t,
                  this.initPTS[e.cc],
                  s,
                  e.cc,
                  function(t) {
                    if (r.config.renderTextTracksNatively) {
                      var a = n[e.level];
                      if ('disabled' === a.mode)
                        return void i.trigger(u.a.SUBTITLE_FRAG_PROCESSED, {
                          success: !1,
                          frag: e
                        });
                      t.forEach(function(e) {
                        if (!a.cues.getCueById(e.id))
                          try {
                            if ((a.addCue(e), !a.cues.getCueById(e.id)))
                              throw new Error('addCue is failed for: ' + e);
                          } catch (r) {
                            d.b.debug('Failed occurred on adding cues: ' + r);
                            var t = new window.TextTrackCue(
                              e.startTime,
                              e.endTime,
                              e.text
                            );
                            (t.id = e.id), a.addCue(t);
                          }
                      });
                    } else {
                      var s = r.tracks[e.level].default
                        ? 'default'
                        : 'subtitles' + e.level;
                      i.trigger(u.a.CUES_PARSED, {
                        type: 'subtitles',
                        cues: t,
                        track: s
                      });
                    }
                    i.trigger(u.a.SUBTITLE_FRAG_PROCESSED, {
                      success: !0,
                      frag: e
                    });
                  },
                  function(t) {
                    d.b.log('Failed to parse VTT cue: ' + t),
                      i.trigger(u.a.SUBTITLE_FRAG_PROCESSED, {
                        success: !1,
                        frag: e
                      });
                  }
                );
            }),
            (a.onFragDecrypted = function(e) {
              var t = e.frag,
                r = e.payload;
              if ('subtitle' === t.type) {
                if (!Object(l.a)(this.initPTS[t.cc]))
                  return void this.unparsedVttFrags.push(e);
                this._parseVTTs(t, r);
              }
            }),
            (a.onFragParsingUserdata = function(e) {
              var t = this.cea608Parser1,
                r = this.cea608Parser2;
              if (this.enabled && t && r)
                for (var i = 0; i < e.samples.length; i++) {
                  var a = e.samples[i].bytes;
                  if (a) {
                    var n = this.extractCea608Data(a);
                    t.addData(e.samples[i].pts, n[0]),
                      r.addData(e.samples[i].pts, n[1]);
                  }
                }
            }),
            (a.extractCea608Data = function(e) {
              for (var t = 31 & e[0], r = 2, i = [[], []], a = 0; a < t; a++) {
                var n = e[r++],
                  s = 127 & e[r++],
                  o = 127 & e[r++],
                  l = 3 & n;
                (0 === s && 0 === o) ||
                  (0 != (4 & n) &&
                    ((0 !== l && 1 !== l) || (i[l].push(s), i[l].push(o))));
              }
              return i;
            }),
            i
          );
        })(h);
        function Bt(e, t) {
          for (var r = 0; r < t.length; r++) {
            var i = t[r];
            (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              'value' in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        function Gt(e) {
          for (var t = [], r = 0; r < e.length; r++) {
            var i = e[r];
            'subtitles' === i.kind && i.label && t.push(e[r]);
          }
          return t;
        }
        var Kt = (function(e) {
            var t, r;
            function i(t) {
              var r;
              return (
                ((r =
                  e.call(
                    this,
                    t,
                    u.a.MEDIA_ATTACHED,
                    u.a.MEDIA_DETACHING,
                    u.a.MANIFEST_LOADED,
                    u.a.SUBTITLE_TRACK_LOADED
                  ) || this).tracks = []),
                (r.trackId = -1),
                (r.media = null),
                (r.stopped = !0),
                (r.subtitleDisplay = !0),
                (r.queuedDefaultTrack = null),
                r
              );
            }
            (r = e),
              ((t = i).prototype = Object.create(r.prototype)),
              (t.prototype.constructor = t),
              (t.__proto__ = r);
            var a,
              n,
              s,
              o = i.prototype;
            return (
              (o.destroy = function() {
                h.prototype.destroy.call(this);
              }),
              (o.onMediaAttached = function(e) {
                var t = this;
                (this.media = e.media),
                  this.media &&
                    (Object(l.a)(this.queuedDefaultTrack) &&
                      ((this.subtitleTrack = this.queuedDefaultTrack),
                      (this.queuedDefaultTrack = null)),
                    (this.trackChangeListener = this._onTextTracksChanged.bind(
                      this
                    )),
                    (this.useTextTrackPolling = !(
                      this.media.textTracks &&
                      'onchange' in this.media.textTracks
                    )),
                    this.useTextTrackPolling
                      ? (this.subtitlePollingInterval = setInterval(function() {
                          t.trackChangeListener();
                        }, 500))
                      : this.media.textTracks.addEventListener(
                          'change',
                          this.trackChangeListener
                        ));
              }),
              (o.onMediaDetaching = function() {
                this.media &&
                  (this.useTextTrackPolling
                    ? clearInterval(this.subtitlePollingInterval)
                    : this.media.textTracks.removeEventListener(
                        'change',
                        this.trackChangeListener
                      ),
                  Object(l.a)(this.subtitleTrack) &&
                    (this.queuedDefaultTrack = this.subtitleTrack),
                  Gt(this.media.textTracks).forEach(function(e) {
                    Ne(e);
                  }),
                  (this.subtitleTrack = -1),
                  (this.media = null));
              }),
              (o.onManifestLoaded = function(e) {
                var t = this,
                  r = e.subtitles || [];
                (this.tracks = r),
                  this.hls.trigger(u.a.SUBTITLE_TRACKS_UPDATED, {
                    subtitleTracks: r
                  }),
                  r.forEach(function(e) {
                    e.default &&
                      (t.media
                        ? (t.subtitleTrack = e.id)
                        : (t.queuedDefaultTrack = e.id));
                  });
              }),
              (o.onSubtitleTrackLoaded = function(e) {
                var t = this,
                  r = e.id,
                  i = e.details,
                  a = this.trackId,
                  n = this.tracks,
                  s = n[a];
                if (r >= n.length || r !== a || !s || this.stopped)
                  this._clearReloadTimer();
                else if ((d.b.log('subtitle track ' + r + ' loaded'), i.live)) {
                  var o = ae(s.details, i, e.stats.trequest);
                  d.b.log('Reloading live subtitle playlist in ' + o + 'ms'),
                    (this.timer = setTimeout(function() {
                      t._loadCurrentTrack();
                    }, o));
                } else this._clearReloadTimer();
              }),
              (o.startLoad = function() {
                (this.stopped = !1), this._loadCurrentTrack();
              }),
              (o.stopLoad = function() {
                (this.stopped = !0), this._clearReloadTimer();
              }),
              (o._clearReloadTimer = function() {
                this.timer && (clearTimeout(this.timer), (this.timer = null));
              }),
              (o._loadCurrentTrack = function() {
                var e = this.trackId,
                  t = this.tracks,
                  r = this.hls,
                  i = t[e];
                e < 0 ||
                  !i ||
                  (i.details && !i.details.live) ||
                  (d.b.log('Loading subtitle track ' + e),
                  r.trigger(u.a.SUBTITLE_TRACK_LOADING, { url: i.url, id: e }));
              }),
              (o._toggleTrackModes = function(e) {
                var t = this.media,
                  r = this.subtitleDisplay,
                  i = this.trackId;
                if (t) {
                  var a = Gt(t.textTracks);
                  if (-1 === e)
                    [].slice.call(a).forEach(function(e) {
                      e.mode = 'disabled';
                    });
                  else {
                    var n = a[i];
                    n && (n.mode = 'disabled');
                  }
                  var s = a[e];
                  s && (s.mode = r ? 'showing' : 'hidden');
                }
              }),
              (o._setSubtitleTrackInternal = function(e) {
                var t = this.hls,
                  r = this.tracks;
                !Object(l.a)(e) ||
                  e < -1 ||
                  e >= r.length ||
                  ((this.trackId = e),
                  d.b.log('Switching to subtitle track ' + e),
                  t.trigger(u.a.SUBTITLE_TRACK_SWITCH, { id: e }),
                  this._loadCurrentTrack());
              }),
              (o._onTextTracksChanged = function() {
                if (this.media && this.hls.config.renderTextTracksNatively) {
                  for (
                    var e = -1, t = Gt(this.media.textTracks), r = 0;
                    r < t.length;
                    r++
                  )
                    if ('hidden' === t[r].mode) e = r;
                    else if ('showing' === t[r].mode) {
                      e = r;
                      break;
                    }
                  this.subtitleTrack = e;
                }
              }),
              (a = i),
              (n = [
                {
                  key: 'subtitleTracks',
                  get: function() {
                    return this.tracks;
                  }
                },
                {
                  key: 'subtitleTrack',
                  get: function() {
                    return this.trackId;
                  },
                  set: function(e) {
                    this.trackId !== e &&
                      (this._toggleTrackModes(e),
                      this._setSubtitleTrackInternal(e));
                  }
                }
              ]) && Bt(a.prototype, n),
              s && Bt(a, s),
              i
            );
          })(h),
          jt = r(7);
        var Ht,
          Vt = window.performance,
          Yt = (function(e) {
            var t, r;
            function i(t, r) {
              var i;
              return (
                ((i =
                  e.call(
                    this,
                    t,
                    u.a.MEDIA_ATTACHED,
                    u.a.MEDIA_DETACHING,
                    u.a.ERROR,
                    u.a.KEY_LOADED,
                    u.a.FRAG_LOADED,
                    u.a.SUBTITLE_TRACKS_UPDATED,
                    u.a.SUBTITLE_TRACK_SWITCH,
                    u.a.SUBTITLE_TRACK_LOADED,
                    u.a.SUBTITLE_FRAG_PROCESSED,
                    u.a.LEVEL_UPDATED
                  ) || this).fragmentTracker = r),
                (i.config = t.config),
                (i.state = pe),
                (i.tracks = []),
                (i.tracksBuffered = []),
                (i.currentTrackId = -1),
                (i.decrypter = new jt.a(t, t.config)),
                (i.lastAVStart = 0),
                (i._onMediaSeeking = i.onMediaSeeking.bind(
                  (function(e) {
                    if (void 0 === e)
                      throw new ReferenceError(
                        "this hasn't been initialised - super() hasn't been called"
                      );
                    return e;
                  })(i)
                )),
                i
              );
            }
            (r = e),
              ((t = i).prototype = Object.create(r.prototype)),
              (t.prototype.constructor = t),
              (t.__proto__ = r);
            var a = i.prototype;
            return (
              (a.onSubtitleFragProcessed = function(e) {
                var t = e.frag,
                  r = e.success;
                if (((this.fragPrevious = t), (this.state = me), r)) {
                  var i = this.tracksBuffered[this.currentTrackId];
                  if (i) {
                    for (var a, n = t.start, s = 0; s < i.length; s++)
                      if (n >= i[s].start && n <= i[s].end) {
                        a = i[s];
                        break;
                      }
                    var o = t.start + t.duration;
                    a ? (a.end = o) : ((a = { start: n, end: o }), i.push(a));
                  }
                }
              }),
              (a.onMediaAttached = function(e) {
                var t = e.media;
                (this.media = t),
                  t.addEventListener('seeking', this._onMediaSeeking),
                  (this.state = me);
              }),
              (a.onMediaDetaching = function() {
                var e = this;
                this.media &&
                  (this.media.removeEventListener(
                    'seeking',
                    this._onMediaSeeking
                  ),
                  this.fragmentTracker.removeAllFragments(),
                  (this.currentTrackId = -1),
                  this.tracks.forEach(function(t) {
                    e.tracksBuffered[t.id] = [];
                  }),
                  (this.media = null),
                  (this.state = pe));
              }),
              (a.onError = function(e) {
                var t = e.frag;
                t && 'subtitle' === t.type && (this.state = me);
              }),
              (a.onSubtitleTracksUpdated = function(e) {
                var t = this;
                d.b.log('subtitle tracks updated'),
                  (this.tracksBuffered = []),
                  (this.tracks = e.subtitleTracks),
                  this.tracks.forEach(function(e) {
                    t.tracksBuffered[e.id] = [];
                  });
              }),
              (a.onSubtitleTrackSwitch = function(e) {
                if (
                  ((this.currentTrackId = e.id),
                  this.tracks &&
                    this.tracks.length &&
                    -1 !== this.currentTrackId)
                ) {
                  var t = this.tracks[this.currentTrackId];
                  t && t.details && this.setInterval(500);
                } else this.clearInterval();
              }),
              (a.onSubtitleTrackLoaded = function(e) {
                var t = e.id,
                  r = e.details,
                  i = this.currentTrackId,
                  a = this.tracks,
                  n = a[i];
                t >= a.length ||
                  t !== i ||
                  !n ||
                  (r.live &&
                    (function(e, t, r) {
                      void 0 === r && (r = 0);
                      var i = -1;
                      ie(e, t, function(e, t, r) {
                        (t.start = e.start), (i = r);
                      });
                      var a = t.fragments;
                      if (i < 0)
                        a.forEach(function(e) {
                          e.start += r;
                        });
                      else
                        for (var n = i + 1; n < a.length; n++)
                          a[n].start = a[n - 1].start + a[n - 1].duration;
                    })(n.details, r, this.lastAVStart),
                  (n.details = r),
                  this.setInterval(500));
              }),
              (a.onKeyLoaded = function() {
                this.state === be && (this.state = me);
              }),
              (a.onFragLoaded = function(e) {
                var t = this.fragCurrent,
                  r = e.frag.decryptdata,
                  i = e.frag,
                  a = this.hls;
                if (
                  this.state === Te &&
                  t &&
                  'subtitle' === e.frag.type &&
                  t.sn === e.frag.sn &&
                  e.payload.byteLength > 0 &&
                  r &&
                  r.key &&
                  'AES-128' === r.method
                ) {
                  var n = Vt.now();
                  this.decrypter.decrypt(
                    e.payload,
                    r.key.buffer,
                    r.iv.buffer,
                    function(e) {
                      var t = Vt.now();
                      a.trigger(u.a.FRAG_DECRYPTED, {
                        frag: i,
                        payload: e,
                        stats: { tstart: n, tdecrypt: t }
                      });
                    }
                  );
                }
              }),
              (a.onLevelUpdated = function(e) {
                var t = e.details.fragments;
                this.lastAVStart = t.length ? t[0].start : 0;
              }),
              (a.doTick = function() {
                if (this.media)
                  switch (this.state) {
                    case me:
                      var e = this.config,
                        t = this.currentTrackId,
                        r = this.fragmentTracker,
                        i = this.media,
                        a = this.tracks;
                      if (!a || !a[t] || !a[t].details) break;
                      var n,
                        s = e.maxBufferHole,
                        o = e.maxFragLookUpTolerance,
                        l = Math.min(e.maxBufferLength, e.maxMaxBufferLength),
                        c = H.bufferedInfo(
                          this._getBuffered(),
                          i.currentTime,
                          s
                        ),
                        h = c.end,
                        f = c.len,
                        g = a[t].details,
                        p = g.fragments,
                        v = p.length,
                        m = p[v - 1].start + p[v - 1].duration;
                      if (f > l) return;
                      var y = this.fragPrevious;
                      h < m
                        ? (y &&
                            g.hasProgramDateTime &&
                            (n = le(p, y.endProgramDateTime, o)),
                          n || (n = ue(y, p, h, o)))
                        : (n = p[v - 1]),
                        n && n.encrypted
                          ? (d.b.log('Loading key for ' + n.sn),
                            (this.state = be),
                            this.hls.trigger(u.a.KEY_LOADING, { frag: n }))
                          : n &&
                            r.getState(n) === U &&
                            ((this.fragCurrent = n),
                            (this.state = Te),
                            this.hls.trigger(u.a.FRAG_LOADING, { frag: n }));
                  }
                else this.state = me;
              }),
              (a.stopLoad = function() {
                (this.lastAVStart = 0), e.prototype.stopLoad.call(this);
              }),
              (a._getBuffered = function() {
                return this.tracksBuffered[this.currentTrackId] || [];
              }),
              (a.onMediaSeeking = function() {
                this.fragPrevious = null;
              }),
              i
            );
          })(Oe);
        !(function(e) {
          (e.WIDEVINE = 'com.widevine.alpha'),
            (e.PLAYREADY = 'com.microsoft.playready');
        })(Ht || (Ht = {}));
        var Wt =
          'undefined' != typeof window &&
          window.navigator &&
          window.navigator.requestMediaKeySystemAccess
            ? window.navigator.requestMediaKeySystemAccess.bind(
                window.navigator
              )
            : null;
        function qt(e, t) {
          for (var r = 0; r < t.length; r++) {
            var i = t[r];
            (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              'value' in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        var Xt = (function(e) {
          var t, r;
          function i(t) {
            var r;
            return (
              ((r =
                e.call(
                  this,
                  t,
                  u.a.MEDIA_ATTACHED,
                  u.a.MEDIA_DETACHED,
                  u.a.MANIFEST_PARSED
                ) || this)._widevineLicenseUrl = void 0),
              (r._licenseXhrSetup = void 0),
              (r._emeEnabled = void 0),
              (r._requestMediaKeySystemAccess = void 0),
              (r._drmSystemOptions = void 0),
              (r._config = void 0),
              (r._mediaKeysList = []),
              (r._media = null),
              (r._hasSetMediaKeys = !1),
              (r._requestLicenseFailureCount = 0),
              (r.mediaKeysPromise = null),
              (r._onMediaEncrypted = function(e) {
                if (
                  (d.b.log(
                    'Media is encrypted using "' +
                      e.initDataType +
                      '" init data type'
                  ),
                  !r.mediaKeysPromise)
                )
                  return (
                    d.b.error(
                      'Fatal: Media is encrypted but no CDM access or no keys have been requested'
                    ),
                    void r.hls.trigger(u.a.ERROR, {
                      type: o.b.KEY_SYSTEM_ERROR,
                      details: o.a.KEY_SYSTEM_NO_KEYS,
                      fatal: !0
                    })
                  );
                var t = function(t) {
                  r._media &&
                    (r._attemptSetMediaKeys(t),
                    r._generateRequestWithPreferredKeySession(
                      e.initDataType,
                      e.initData
                    ));
                };
                r.mediaKeysPromise.then(t).catch(t);
              }),
              (r._config = t.config),
              (r._widevineLicenseUrl = r._config.widevineLicenseUrl),
              (r._licenseXhrSetup = r._config.licenseXhrSetup),
              (r._emeEnabled = r._config.emeEnabled),
              (r._requestMediaKeySystemAccess =
                r._config.requestMediaKeySystemAccessFunc),
              (r._drmSystemOptions = t.config.drmSystemOptions),
              r
            );
          }
          (r = e),
            ((t = i).prototype = Object.create(r.prototype)),
            (t.prototype.constructor = t),
            (t.__proto__ = r);
          var a,
            n,
            s,
            l = i.prototype;
          return (
            (l.getLicenseServerUrl = function(e) {
              switch (e) {
                case Ht.WIDEVINE:
                  if (!this._widevineLicenseUrl) break;
                  return this._widevineLicenseUrl;
              }
              throw new Error(
                'no license server URL configured for key-system "' + e + '"'
              );
            }),
            (l._attemptKeySystemAccess = function(e, t, r) {
              var i = this,
                a = (function(e, t, r, i) {
                  switch (e) {
                    case Ht.WIDEVINE:
                      return (function(e, t, r) {
                        var i = {
                          audioCapabilities: [],
                          videoCapabilities: []
                        };
                        return (
                          e.forEach(function(e) {
                            i.audioCapabilities.push({
                              contentType: 'audio/mp4; codecs="' + e + '"',
                              robustness: r.audioRobustness || ''
                            });
                          }),
                          t.forEach(function(e) {
                            i.videoCapabilities.push({
                              contentType: 'video/mp4; codecs="' + e + '"',
                              robustness: r.videoRobustness || ''
                            });
                          }),
                          [i]
                        );
                      })(t, r, i);
                    default:
                      throw new Error('Unknown key-system: ' + e);
                  }
                })(e, t, r, this._drmSystemOptions);
              d.b.log('Requesting encrypted media key-system access');
              var n = this.requestMediaKeySystemAccess(e, a);
              (this.mediaKeysPromise = n.then(function(t) {
                return i._onMediaKeySystemAccessObtained(e, t);
              })),
                n.catch(function(t) {
                  d.b.error(
                    'Failed to obtain key-system "' + e + '" access:',
                    t
                  );
                });
            }),
            (l._onMediaKeySystemAccessObtained = function(e, t) {
              var r = this;
              d.b.log('Access for key-system "' + e + '" obtained');
              var i = {
                mediaKeysSessionInitialized: !1,
                mediaKeySystemAccess: t,
                mediaKeySystemDomain: e
              };
              this._mediaKeysList.push(i);
              var a = Promise.resolve()
                .then(function() {
                  return t.createMediaKeys();
                })
                .then(function(t) {
                  return (
                    (i.mediaKeys = t),
                    d.b.log('Media-keys created for key-system "' + e + '"'),
                    r._onMediaKeysCreated(),
                    t
                  );
                });
              return (
                a.catch(function(e) {
                  d.b.error('Failed to create media-keys:', e);
                }),
                a
              );
            }),
            (l._onMediaKeysCreated = function() {
              var e = this;
              this._mediaKeysList.forEach(function(t) {
                t.mediaKeysSession ||
                  ((t.mediaKeysSession = t.mediaKeys.createSession()),
                  e._onNewMediaKeySession(t.mediaKeysSession));
              });
            }),
            (l._onNewMediaKeySession = function(e) {
              var t = this;
              d.b.log('New key-system session ' + e.sessionId),
                e.addEventListener(
                  'message',
                  function(r) {
                    t._onKeySessionMessage(e, r.message);
                  },
                  !1
                );
            }),
            (l._onKeySessionMessage = function(e, t) {
              d.b.log('Got EME message event, creating license request'),
                this._requestLicense(t, function(t) {
                  d.b.log(
                    'Received license data (length: ' +
                      (t ? t.byteLength : t) +
                      '), updating key-session'
                  ),
                    e.update(t);
                });
            }),
            (l._attemptSetMediaKeys = function(e) {
              if (!this._media)
                throw new Error(
                  'Attempted to set mediaKeys without first attaching a media element'
                );
              if (!this._hasSetMediaKeys) {
                var t = this._mediaKeysList[0];
                if (!t || !t.mediaKeys)
                  return (
                    d.b.error(
                      'Fatal: Media is encrypted but no CDM access or no keys have been obtained yet'
                    ),
                    void this.hls.trigger(u.a.ERROR, {
                      type: o.b.KEY_SYSTEM_ERROR,
                      details: o.a.KEY_SYSTEM_NO_KEYS,
                      fatal: !0
                    })
                  );
                d.b.log('Setting keys for encrypted media'),
                  this._media.setMediaKeys(t.mediaKeys),
                  (this._hasSetMediaKeys = !0);
              }
            }),
            (l._generateRequestWithPreferredKeySession = function(e, t) {
              var r = this,
                i = this._mediaKeysList[0];
              if (!i)
                return (
                  d.b.error(
                    'Fatal: Media is encrypted but not any key-system access has been obtained yet'
                  ),
                  void this.hls.trigger(u.a.ERROR, {
                    type: o.b.KEY_SYSTEM_ERROR,
                    details: o.a.KEY_SYSTEM_NO_ACCESS,
                    fatal: !0
                  })
                );
              if (i.mediaKeysSessionInitialized)
                d.b.warn('Key-Session already initialized but requested again');
              else {
                var a = i.mediaKeysSession;
                if (!a)
                  return (
                    d.b.error(
                      'Fatal: Media is encrypted but no key-session existing'
                    ),
                    void this.hls.trigger(u.a.ERROR, {
                      type: o.b.KEY_SYSTEM_ERROR,
                      details: o.a.KEY_SYSTEM_NO_SESSION,
                      fatal: !0
                    })
                  );
                if (!t)
                  return (
                    d.b.warn(
                      'Fatal: initData required for generating a key session is null'
                    ),
                    void this.hls.trigger(u.a.ERROR, {
                      type: o.b.KEY_SYSTEM_ERROR,
                      details: o.a.KEY_SYSTEM_NO_INIT_DATA,
                      fatal: !0
                    })
                  );
                d.b.log(
                  'Generating key-session request for "' +
                    e +
                    '" init data type'
                ),
                  (i.mediaKeysSessionInitialized = !0),
                  a
                    .generateRequest(e, t)
                    .then(function() {
                      d.b.debug('Key-session generation succeeded');
                    })
                    .catch(function(e) {
                      d.b.error('Error generating key-session request:', e),
                        r.hls.trigger(u.a.ERROR, {
                          type: o.b.KEY_SYSTEM_ERROR,
                          details: o.a.KEY_SYSTEM_NO_SESSION,
                          fatal: !1
                        });
                    });
              }
            }),
            (l._createLicenseXhr = function(e, t, r) {
              var i = new XMLHttpRequest(),
                a = this._licenseXhrSetup;
              try {
                if (a)
                  try {
                    a(i, e);
                  } catch (t) {
                    i.open('POST', e, !0), a(i, e);
                  }
                i.readyState || i.open('POST', e, !0);
              } catch (e) {
                throw new Error('issue setting up KeySystem license XHR ' + e);
              }
              return (
                (i.responseType = 'arraybuffer'),
                (i.onreadystatechange = this._onLicenseRequestReadyStageChange.bind(
                  this,
                  i,
                  e,
                  t,
                  r
                )),
                i
              );
            }),
            (l._onLicenseRequestReadyStageChange = function(e, t, r, i) {
              switch (e.readyState) {
                case 4:
                  if (200 === e.status)
                    (this._requestLicenseFailureCount = 0),
                      d.b.log('License request succeeded'),
                      'arraybuffer' !== e.responseType &&
                        d.b.warn(
                          'xhr response type was not set to the expected arraybuffer for license request'
                        ),
                      i(e.response);
                  else {
                    if (
                      (d.b.error(
                        'License Request XHR failed (' +
                          t +
                          '). Status: ' +
                          e.status +
                          ' (' +
                          e.statusText +
                          ')'
                      ),
                      this._requestLicenseFailureCount++,
                      this._requestLicenseFailureCount > 3)
                    )
                      return void this.hls.trigger(u.a.ERROR, {
                        type: o.b.KEY_SYSTEM_ERROR,
                        details: o.a.KEY_SYSTEM_LICENSE_REQUEST_FAILED,
                        fatal: !0
                      });
                    var a = 3 - this._requestLicenseFailureCount + 1;
                    d.b.warn(
                      'Retrying license request, ' + a + ' attempts left'
                    ),
                      this._requestLicense(r, i);
                  }
              }
            }),
            (l._generateLicenseRequestChallenge = function(e, t) {
              switch (e.mediaKeySystemDomain) {
                case Ht.WIDEVINE:
                  return t;
              }
              throw new Error(
                'unsupported key-system: ' + e.mediaKeySystemDomain
              );
            }),
            (l._requestLicense = function(e, t) {
              d.b.log('Requesting content license for key-system');
              var r = this._mediaKeysList[0];
              if (!r)
                return (
                  d.b.error(
                    'Fatal error: Media is encrypted but no key-system access has been obtained yet'
                  ),
                  void this.hls.trigger(u.a.ERROR, {
                    type: o.b.KEY_SYSTEM_ERROR,
                    details: o.a.KEY_SYSTEM_NO_ACCESS,
                    fatal: !0
                  })
                );
              try {
                var i = this.getLicenseServerUrl(r.mediaKeySystemDomain),
                  a = this._createLicenseXhr(i, e, t);
                d.b.log('Sending license request to URL: ' + i);
                var n = this._generateLicenseRequestChallenge(r, e);
                a.send(n);
              } catch (e) {
                d.b.error('Failure requesting DRM license: ' + e),
                  this.hls.trigger(u.a.ERROR, {
                    type: o.b.KEY_SYSTEM_ERROR,
                    details: o.a.KEY_SYSTEM_LICENSE_REQUEST_FAILED,
                    fatal: !0
                  });
              }
            }),
            (l.onMediaAttached = function(e) {
              if (this._emeEnabled) {
                var t = e.media;
                (this._media = t),
                  t.addEventListener('encrypted', this._onMediaEncrypted);
              }
            }),
            (l.onMediaDetached = function() {
              var e = this._media,
                t = this._mediaKeysList;
              e &&
                (e.removeEventListener('encrypted', this._onMediaEncrypted),
                (this._media = null),
                (this._mediaKeysList = []),
                Promise.all(
                  t.map(function(e) {
                    if (e.mediaKeysSession)
                      return e.mediaKeysSession.close().catch(function() {});
                  })
                )
                  .then(function() {
                    return e.setMediaKeys(null);
                  })
                  .catch(function() {}));
            }),
            (l.onManifestParsed = function(e) {
              if (this._emeEnabled) {
                var t = e.levels.map(function(e) {
                    return e.audioCodec;
                  }),
                  r = e.levels.map(function(e) {
                    return e.videoCodec;
                  });
                this._attemptKeySystemAccess(Ht.WIDEVINE, t, r);
              }
            }),
            (a = i),
            (n = [
              {
                key: 'requestMediaKeySystemAccess',
                get: function() {
                  if (!this._requestMediaKeySystemAccess)
                    throw new Error(
                      'No requestMediaKeySystemAccess function configured'
                    );
                  return this._requestMediaKeySystemAccess;
                }
              }
            ]) && qt(a.prototype, n),
            s && qt(a, s),
            i
          );
        })(h);
        function zt(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var i = Object.getOwnPropertySymbols(e);
            t &&
              (i = i.filter(function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, i);
          }
          return r;
        }
        function Qt(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? zt(Object(r), !0).forEach(function(t) {
                  $t(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : zt(Object(r)).forEach(function(t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        function $t(e, t, r) {
          return (
            t in e
              ? Object.defineProperty(e, t, {
                  value: r,
                  enumerable: !0,
                  configurable: !0,
                  writable: !0
                })
              : (e[t] = r),
            e
          );
        }
        var Jt = Qt(
          Qt(
            {
              autoStartLoad: !0,
              startPosition: -1,
              defaultAudioCodec: void 0,
              debug: !1,
              capLevelOnFPSDrop: !1,
              capLevelToPlayerSize: !1,
              initialLiveManifestSize: 1,
              maxBufferLength: 30,
              maxBufferSize: 6e7,
              maxBufferHole: 0.5,
              lowBufferWatchdogPeriod: 0.5,
              highBufferWatchdogPeriod: 3,
              nudgeOffset: 0.1,
              nudgeMaxRetry: 3,
              maxFragLookUpTolerance: 0.25,
              liveSyncDurationCount: 3,
              liveMaxLatencyDurationCount: 1 / 0,
              liveSyncDuration: void 0,
              liveMaxLatencyDuration: void 0,
              liveDurationInfinity: !1,
              liveBackBufferLength: 1 / 0,
              maxMaxBufferLength: 600,
              enableWorker: !0,
              enableSoftwareAES: !0,
              manifestLoadingTimeOut: 1e4,
              manifestLoadingMaxRetry: 1,
              manifestLoadingRetryDelay: 1e3,
              manifestLoadingMaxRetryTimeout: 64e3,
              startLevel: void 0,
              levelLoadingTimeOut: 1e4,
              levelLoadingMaxRetry: 4,
              levelLoadingRetryDelay: 1e3,
              levelLoadingMaxRetryTimeout: 64e3,
              fragLoadingTimeOut: 2e4,
              fragLoadingMaxRetry: 6,
              fragLoadingRetryDelay: 1e3,
              fragLoadingMaxRetryTimeout: 64e3,
              startFragPrefetch: !1,
              fpsDroppedMonitoringPeriod: 5e3,
              fpsDroppedMonitoringThreshold: 0.2,
              appendErrorMaxRetry: 3,
              loader: $e,
              fLoader: void 0,
              pLoader: void 0,
              xhrSetup: void 0,
              licenseXhrSetup: void 0,
              abrController: Ve,
              bufferController: We,
              capLevelController: Xe,
              fpsController: Qe,
              stretchShortVideoTrack: !1,
              maxAudioFramesDrift: 1,
              forceKeyFrameOnDiscontinuity: !0,
              abrEwmaFastLive: 3,
              abrEwmaSlowLive: 9,
              abrEwmaFastVoD: 3,
              abrEwmaSlowVoD: 9,
              abrEwmaDefaultEstimate: 5e5,
              abrBandWidthFactor: 0.95,
              abrBandWidthUpFactor: 0.7,
              abrMaxWithRealBitrate: !1,
              maxStarvationDelay: 4,
              maxLoadingDelay: 4,
              minAutoBitrate: 0,
              emeEnabled: !1,
              widevineLicenseUrl: void 0,
              drmSystemOptions: {},
              requestMediaKeySystemAccessFunc: Wt,
              testBandwidth: !0
            },
            {
              cueHandler: i,
              enableCEA708Captions: !0,
              enableWebVTT: !0,
              captionsTextTrack1Label: 'English',
              captionsTextTrack1LanguageCode: 'en',
              captionsTextTrack2Label: 'Spanish',
              captionsTextTrack2LanguageCode: 'es',
              captionsTextTrack3Label: 'Unknown CC',
              captionsTextTrack3LanguageCode: '',
              captionsTextTrack4Label: 'Unknown CC',
              captionsTextTrack4LanguageCode: '',
              renderTextTracksNatively: !0
            }
          ),
          {},
          {
            subtitleStreamController: Yt,
            subtitleTrackController: Kt,
            timelineController: Nt,
            audioStreamController: rt,
            audioTrackController: Ze,
            emeController: Xt
          }
        );
        function Zt(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var i = Object.getOwnPropertySymbols(e);
            t &&
              (i = i.filter(function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, i);
          }
          return r;
        }
        function er(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Zt(Object(r), !0).forEach(function(t) {
                  tr(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Zt(Object(r)).forEach(function(t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        function tr(e, t, r) {
          return (
            t in e
              ? Object.defineProperty(e, t, {
                  value: r,
                  enumerable: !0,
                  configurable: !0,
                  writable: !0
                })
              : (e[t] = r),
            e
          );
        }
        function rr(e) {
          if (void 0 === e)
            throw new ReferenceError(
              "this hasn't been initialised - super() hasn't been called"
            );
          return e;
        }
        function ir(e, t) {
          for (var r = 0; r < t.length; r++) {
            var i = t[r];
            (i.enumerable = i.enumerable || !1),
              (i.configurable = !0),
              'value' in i && (i.writable = !0),
              Object.defineProperty(e, i.key, i);
          }
        }
        function ar(e, t, r) {
          return t && ir(e.prototype, t), r && ir(e, r), e;
        }
        var nr = (function(e) {
          var t, r;
          function i(t) {
            var r;
            void 0 === t && (t = {}),
              ((r = e.call(this) || this).config = void 0),
              (r._autoLevelCapping = void 0),
              (r.abrController = void 0),
              (r.capLevelController = void 0),
              (r.levelController = void 0),
              (r.streamController = void 0),
              (r.networkControllers = void 0),
              (r.audioTrackController = void 0),
              (r.subtitleTrackController = void 0),
              (r.emeController = void 0),
              (r.coreComponents = void 0),
              (r.media = null),
              (r.url = null);
            var a = i.DefaultConfig;
            if (
              (t.liveSyncDurationCount || t.liveMaxLatencyDurationCount) &&
              (t.liveSyncDuration || t.liveMaxLatencyDuration)
            )
              throw new Error(
                "Illegal hls.js config: don't mix up liveSyncDurationCount/liveMaxLatencyDurationCount and liveSyncDuration/liveMaxLatencyDuration"
              );
            r.config = er(er({}, a), t);
            var n = rr(r).config;
            if (
              void 0 !== n.liveMaxLatencyDurationCount &&
              n.liveMaxLatencyDurationCount <= n.liveSyncDurationCount
            )
              throw new Error(
                'Illegal hls.js config: "liveMaxLatencyDurationCount" must be gt "liveSyncDurationCount"'
              );
            if (
              void 0 !== n.liveMaxLatencyDuration &&
              (void 0 === n.liveSyncDuration ||
                n.liveMaxLatencyDuration <= n.liveSyncDuration)
            )
              throw new Error(
                'Illegal hls.js config: "liveMaxLatencyDuration" must be gt "liveSyncDuration"'
              );
            Object(d.a)(n.debug), (r._autoLevelCapping = -1);
            var s = (r.abrController = new n.abrController(rr(r))),
              o = new n.bufferController(rr(r)),
              l = (r.capLevelController = new n.capLevelController(rr(r))),
              u = new n.fpsController(rr(r)),
              c = new x(rr(r)),
              h = new M(rr(r)),
              f = new F(rr(r)),
              g = new Be(rr(r)),
              p = (r.levelController = new Me(rr(r))),
              v = new K(rr(r)),
              m = [p, (r.streamController = new Pe(rr(r), v))],
              y = n.audioStreamController;
            y && m.push(new y(rr(r), v)), (r.networkControllers = m);
            var b = [c, h, f, s, o, l, u, g, v];
            if ((y = n.audioTrackController)) {
              var T = new y(rr(r));
              (r.audioTrackController = T), b.push(T);
            }
            if ((y = n.subtitleTrackController)) {
              var E = new y(rr(r));
              (r.subtitleTrackController = E), m.push(E);
            }
            if ((y = n.emeController)) {
              var S = new y(rr(r));
              (r.emeController = S), b.push(S);
            }
            return (
              (y = n.subtitleStreamController) && m.push(new y(rr(r), v)),
              (y = n.timelineController) && b.push(new y(rr(r))),
              (r.coreComponents = b),
              r
            );
          }
          (r = e),
            ((t = i).prototype = Object.create(r.prototype)),
            (t.prototype.constructor = t),
            (t.__proto__ = r),
            (i.isSupported = function() {
              return (function() {
                var e = q();
                if (!e) return !1;
                var t = self.SourceBuffer || self.WebKitSourceBuffer,
                  r =
                    e &&
                    'function' == typeof e.isTypeSupported &&
                    e.isTypeSupported(
                      'video/mp4; codecs="avc1.42E01E,mp4a.40.2"'
                    ),
                  i =
                    !t ||
                    (t.prototype &&
                      'function' == typeof t.prototype.appendBuffer &&
                      'function' == typeof t.prototype.remove);
                return !!r && !!i;
              })();
            }),
            ar(i, null, [
              {
                key: 'version',
                get: function() {
                  return '0.14.0';
                }
              },
              {
                key: 'Events',
                get: function() {
                  return u.a;
                }
              },
              {
                key: 'ErrorTypes',
                get: function() {
                  return o.b;
                }
              },
              {
                key: 'ErrorDetails',
                get: function() {
                  return o.a;
                }
              },
              {
                key: 'DefaultConfig',
                get: function() {
                  return i.defaultConfig ? i.defaultConfig : Jt;
                },
                set: function(e) {
                  i.defaultConfig = e;
                }
              }
            ]);
          var a = i.prototype;
          return (
            (a.destroy = function() {
              d.b.log('destroy'),
                this.trigger(u.a.DESTROYING),
                this.detachMedia(),
                this.coreComponents
                  .concat(this.networkControllers)
                  .forEach(function(e) {
                    e.destroy();
                  }),
                (this.url = null),
                this.removeAllListeners(),
                (this._autoLevelCapping = -1);
            }),
            (a.attachMedia = function(e) {
              d.b.log('attachMedia'),
                (this.media = e),
                this.trigger(u.a.MEDIA_ATTACHING, { media: e });
            }),
            (a.detachMedia = function() {
              d.b.log('detachMedia'),
                this.trigger(u.a.MEDIA_DETACHING),
                (this.media = null);
            }),
            (a.loadSource = function(e) {
              (e = s.buildAbsoluteURL(window.location.href, e, {
                alwaysNormalize: !0
              })),
                d.b.log('loadSource:' + e),
                (this.url = e),
                this.trigger(u.a.MANIFEST_LOADING, { url: e });
            }),
            (a.startLoad = function(e) {
              void 0 === e && (e = -1),
                d.b.log('startLoad(' + e + ')'),
                this.networkControllers.forEach(function(t) {
                  t.startLoad(e);
                });
            }),
            (a.stopLoad = function() {
              d.b.log('stopLoad'),
                this.networkControllers.forEach(function(e) {
                  e.stopLoad();
                });
            }),
            (a.swapAudioCodec = function() {
              d.b.log('swapAudioCodec'), this.streamController.swapAudioCodec();
            }),
            (a.recoverMediaError = function() {
              d.b.log('recoverMediaError');
              var e = this.media;
              this.detachMedia(), e && this.attachMedia(e);
            }),
            (a.removeLevel = function(e, t) {
              void 0 === t && (t = 0), this.levelController.removeLevel(e, t);
            }),
            ar(i, [
              {
                key: 'levels',
                get: function() {
                  return this.levelController.levels;
                }
              },
              {
                key: 'currentLevel',
                get: function() {
                  return this.streamController.currentLevel;
                },
                set: function(e) {
                  d.b.log('set currentLevel:' + e),
                    (this.loadLevel = e),
                    this.streamController.immediateLevelSwitch();
                }
              },
              {
                key: 'nextLevel',
                get: function() {
                  return this.streamController.nextLevel;
                },
                set: function(e) {
                  d.b.log('set nextLevel:' + e),
                    (this.levelController.manualLevel = e),
                    this.streamController.nextLevelSwitch();
                }
              },
              {
                key: 'loadLevel',
                get: function() {
                  return this.levelController.level;
                },
                set: function(e) {
                  d.b.log('set loadLevel:' + e),
                    (this.levelController.manualLevel = e);
                }
              },
              {
                key: 'nextLoadLevel',
                get: function() {
                  return this.levelController.nextLoadLevel;
                },
                set: function(e) {
                  this.levelController.nextLoadLevel = e;
                }
              },
              {
                key: 'firstLevel',
                get: function() {
                  return Math.max(
                    this.levelController.firstLevel,
                    this.minAutoLevel
                  );
                },
                set: function(e) {
                  d.b.log('set firstLevel:' + e),
                    (this.levelController.firstLevel = e);
                }
              },
              {
                key: 'startLevel',
                get: function() {
                  return this.levelController.startLevel;
                },
                set: function(e) {
                  d.b.log('set startLevel:' + e),
                    -1 !== e && (e = Math.max(e, this.minAutoLevel)),
                    (this.levelController.startLevel = e);
                }
              },
              {
                key: 'capLevelToPlayerSize',
                set: function(e) {
                  var t = !!e;
                  t !== this.config.capLevelToPlayerSize &&
                    (t
                      ? this.capLevelController.startCapping()
                      : (this.capLevelController.stopCapping(),
                        (this.autoLevelCapping = -1),
                        this.streamController.nextLevelSwitch()),
                    (this.config.capLevelToPlayerSize = t));
                }
              },
              {
                key: 'autoLevelCapping',
                get: function() {
                  return this._autoLevelCapping;
                },
                set: function(e) {
                  d.b.log('set autoLevelCapping:' + e),
                    (this._autoLevelCapping = e);
                }
              },
              {
                key: 'bandwidthEstimate',
                get: function() {
                  var e = this.abrController._bwEstimator;
                  return e ? e.getEstimate() : NaN;
                }
              },
              {
                key: 'autoLevelEnabled',
                get: function() {
                  return -1 === this.levelController.manualLevel;
                }
              },
              {
                key: 'manualLevel',
                get: function() {
                  return this.levelController.manualLevel;
                }
              },
              {
                key: 'minAutoLevel',
                get: function() {
                  for (
                    var e = this.levels,
                      t = this.config.minAutoBitrate,
                      r = e ? e.length : 0,
                      i = 0;
                    i < r;
                    i++
                  ) {
                    if (
                      (e[i].realBitrate
                        ? Math.max(e[i].realBitrate, e[i].bitrate)
                        : e[i].bitrate) > t
                    )
                      return i;
                  }
                  return 0;
                }
              },
              {
                key: 'maxAutoLevel',
                get: function() {
                  var e = this.levels,
                    t = this.autoLevelCapping;
                  return -1 === t && e && e.length ? e.length - 1 : t;
                }
              },
              {
                key: 'nextAutoLevel',
                get: function() {
                  return Math.min(
                    Math.max(
                      this.abrController.nextAutoLevel,
                      this.minAutoLevel
                    ),
                    this.maxAutoLevel
                  );
                },
                set: function(e) {
                  this.abrController.nextAutoLevel = Math.max(
                    this.minAutoLevel,
                    e
                  );
                }
              },
              {
                key: 'audioTracks',
                get: function() {
                  var e = this.audioTrackController;
                  return e ? e.audioTracks : [];
                }
              },
              {
                key: 'audioTrack',
                get: function() {
                  var e = this.audioTrackController;
                  return e ? e.audioTrack : -1;
                },
                set: function(e) {
                  var t = this.audioTrackController;
                  t && (t.audioTrack = e);
                }
              },
              {
                key: 'liveSyncPosition',
                get: function() {
                  return this.streamController.liveSyncPosition;
                }
              },
              {
                key: 'subtitleTracks',
                get: function() {
                  var e = this.subtitleTrackController;
                  return e ? e.subtitleTracks : [];
                }
              },
              {
                key: 'subtitleTrack',
                get: function() {
                  var e = this.subtitleTrackController;
                  return e ? e.subtitleTrack : -1;
                },
                set: function(e) {
                  var t = this.subtitleTrackController;
                  t && (t.subtitleTrack = e);
                }
              },
              {
                key: 'subtitleDisplay',
                get: function() {
                  var e = this.subtitleTrackController;
                  return !!e && e.subtitleDisplay;
                },
                set: function(e) {
                  var t = this.subtitleTrackController;
                  t && (t.subtitleDisplay = e);
                }
              }
            ]),
            i
          );
        })(z);
        nr.defaultConfig = void 0;
      }
    ]).default;
  });
