document.security_sha1 = {};
