<div dir='rtl'>

# جعل موقع ويب بث الفيديو 

> أنشئ موقعًا للبث عبر الإنترنت لمشاهدة الأفلام والمسلسلات التلفزيونية على جهاز الكمبيوتر والجهاز المحمول والتلفزيون

![AR](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/ar.svg?sanitize=true)

`اختر لغتك`

[![RU](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/ru.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.ru.md) | [![ES](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/es.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.es.md) | [![DE](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/de.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.de.md) | [![FR](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/fr.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.fr.md) | [![JA](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/ja.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.ja.md) | [![PT](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/pt.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.pt.md) | [![IT](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/it.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.it.md) | [![ZH](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/zh.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.zh.md) | [![PL](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/pl.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.pl.md)
:---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---:
[![NL](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/nl.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.nl.md) | [![TR](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/tr.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.tr.md) | [![CS](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/cs.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.cs.md) | [![KO](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/ko.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.ko.md) | [![VI](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/vi.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.vi.md) | [![SV](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/sv.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.sv.md) | [![HU](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/hu.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.hu.md) | [![EL](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/el.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.el.md) | [![RO](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/ro.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.ro.md)
[![SK](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/sk.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.sk.md) | [![DA](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/da.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.da.md) | [![ID](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/id.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.id.md) | [![FI](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/fi.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.fi.md) | [![TH](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/th.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.th.md) | [![BG](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/bg.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.bg.md) | [![UK](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/uk.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.uk.md) | [![EN](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/en.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.en.md) | [![SQ](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/sq.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.sq.md)
[![LT](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/lt.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.lt.md) | [![HR](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/hr.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.hr.md) | [![SR](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/sr.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.sr.md) | [![BN](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/bn.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.bn.md) | [![SL](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/sl.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.sl.md) | [![ET](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/et.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.et.md) | [![LV](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/lv.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.lv.md) | [![HI](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/hi.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.hi.md) | [![SW](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/locales/sw.svg?sanitize=true)](https://github.com/CinemaPress/CinemaPress/blob/master/doc/README.sw.md)

![Admin-panel](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/screenshot.png)

- **Default languages**: English, Russian
- **Supported devices**: PC :computer:, Mobile :iphone:, TV :tv:

## كيفية تثبيت CinemaPress؟ 

> #### تثبيت عبر المحطة

`bash <(wget git.io/JGKNq -qO-)`

![تثبيت عبر المحطة](https://raw.githubusercontent.com/CinemaPress/CinemaPress/master/themes/default/public/admin/images/min/cli.png)

## أين تشتري خادم VPS؟

> يجب أن يكون نظام التشغيل **Debian, CentOS, Fedora, Ubuntu (Latest Stable Version)** بدون لوحات تحكم!

···· | UA-Hosting | Inferno | PQ | Zomro
:---: | :---: | :---: | :---: | :---:
:earth_americas: | `Netherlands` | `Netherlands` | `Netherlands` | `Netherlands`
:computer: | `2x2700MHz` | `2x2600MHz` | `2x2800MHz` | `3x2400MHz`
:rocket: | `4GB` | `2GB` | `4GB` | `4GB`
:floppy_disk: | `60GB` |  `30GB` | `50GB` | `40GB`
:dollar: | `$9.9` | `$8.5*` | `$7.3` | `$5.9`
···· | **[تحديد](https://cinemapressio.github.io/ref/ua-hosting.html)** | **[تحديد](https://cinemapressio.github.io/ref/inferno.html)** | **[تحديد](https://cinemapressio.github.io/ref/pq.html)** | **[تحديد](https://cinemapressio.github.io/ref/zomro.html)**

> `*` - خصم **15%** ، رمز الترويجي: `CinemaPress15`

## من أين تشتري اسم النطاق؟

···· | Tonic | InternetBS | Pananames | Namecheap
:---: | :---: | :---: | :---: | :---:
:earth_americas: | `Tonga` | `Bahamas` | `Panama` | `USA`
:moneybag: | `Card` | `PayPal` | `WebMoney` | `Bitcoin`
:see_no_evil: | :lock:* | :unlock: | :unlock: | :unlock:
:dollar: | `> $50/year` | `> $1/year` | `> $1/year` | `> $1/year`
···· | **[تحديد](https://cinemapressio.github.io/ref/tonic.html)** | **[تحديد](https://cinemapressio.github.io/ref/internetbs.html)** | **[تحديد](https://cinemapressio.github.io/ref/pananames.html)** | **[تحديد](https://cinemapressio.github.io/ref/namecheap.html)**

> `*` - لا يتم إرسال البيانات إلى قاعدة بيانات WHOIS العامة

##أين تشتري VPN؟

···· | Surfshark | CyberGhost | PureVPN
:---: | :---: | :---: | :---:
:earth_americas: | `BVI` | `Romania` | `Hong Kong`
:moneybag: | `Bitcoin` | `PayPal` | `QIWI`
:see_no_evil: | :lock: | :lock: | :lock:
:dollar: | `$47/2 years` | `$99/3 years` | `$99/5 years`
···· | **[تحديد](https://cinemapressio.github.io/ref/surfshark.html)** | **[تحديد](https://cinemapressio.github.io/ref/cyberghost.html)** | **[تحديد](https://cinemapressio.github.io/ref/purevpn.html)**

## موضوع «hodor»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Hodor/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Hodor/) / [BitBucket](https://bitbucket.org/cinemapress/theme-hodor/)

> CLI: `cinemapress theme example.com hodor`

> **DEMO:** `«hodor»`

[![قالب «hodor»](https://raw.githubusercontent.com/CinemaPress/Theme-Hodor/master/screenshot.png)](https://github.com/CinemaPress/Theme-Hodor/)

## موضوع «sansa»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Sansa/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Sansa/) / [BitBucket](https://bitbucket.org/cinemapress/theme-sansa/)

> CLI: `cinemapress theme example.com sansa`

> **DEMO:** `«sansa»`

[![قالب «sansa»](https://raw.githubusercontent.com/CinemaPress/Theme-Sansa/master/screenshot.png)](https://github.com/CinemaPress/Theme-Sansa/)

## موضوع «robb»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Robb/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Robb/) / [BitBucket](https://bitbucket.org/cinemapress/theme-robb/)

> CLI: `cinemapress theme example.com robb`

> **DEMO:** `«robb»`

[![قالب «robb»](https://raw.githubusercontent.com/CinemaPress/Theme-Robb/master/screenshot.png)](https://github.com/CinemaPress/Theme-Robb/)

## موضوع «ramsay»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Ramsay/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Ramsay/) / [BitBucket](https://bitbucket.org/cinemapress/theme-ramsay/)

> CLI: `cinemapress theme example.com ramsay`

> **DEMO:** `«ramsay»`

[![قالب «ramsay»](https://raw.githubusercontent.com/CinemaPress/Theme-Ramsay/master/screenshot.png)](https://github.com/CinemaPress/Theme-Ramsay/)

## موضوع «tyrion»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Tyrion/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Tyrion/) / [BitBucket](https://bitbucket.org/cinemapress/theme-tyrion/)

> CLI: `cinemapress theme example.com tyrion`

> **DEMO:** `«tyrion»`

[![قالب «tyrion»](https://raw.githubusercontent.com/CinemaPress/Theme-Tyrion/master/screenshot.png)](https://github.com/CinemaPress/Theme-Tyrion/)

## موضوع «cersei»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Cersei/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Cersei/) / [BitBucket](https://bitbucket.org/cinemapress/theme-cersei/)

> CLI: `cinemapress theme example.com cersei`

> **DEMO:** `«cersei»`

[![قالب «cersei»](https://raw.githubusercontent.com/CinemaPress/Theme-Cersei/master/screenshot.png)](https://github.com/CinemaPress/Theme-Cersei/)

## موضوع «joffrey»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Joffrey/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Joffrey/) / [BitBucket](https://bitbucket.org/cinemapress/theme-joffrey/)

> CLI: `cinemapress theme example.com joffrey`

> **DEMO:** `«joffrey»`

[![قالب «joffrey»](https://raw.githubusercontent.com/CinemaPress/Theme-Joffrey/master/screenshot.png)](https://github.com/CinemaPress/Theme-Joffrey/)

## موضوع «drogo»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Drogo/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Drogo/) / [BitBucket](https://bitbucket.org/cinemapress/theme-drogo/)

> CLI: `cinemapress theme example.com drogo`

> **DEMO:** `«drogo»`

[![قالب «drogo»](https://raw.githubusercontent.com/CinemaPress/Theme-Drogo/master/screenshot.png)](https://github.com/CinemaPress/Theme-Drogo/)

## موضوع «bran»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Bran/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Bran/) / [BitBucket](https://bitbucket.org/cinemapress/theme-bran/)

> CLI: `cinemapress theme example.com bran`

> **DEMO:** `«bran»`

[![قالب «bran»](https://raw.githubusercontent.com/CinemaPress/Theme-Bran/master/screenshot.png)](https://github.com/CinemaPress/Theme-Bran/)

## موضوع «arya»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Arya/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Arya/) / [BitBucket](https://bitbucket.org/cinemapress/theme-arya/)

> CLI: `cinemapress theme example.com arya`

> **DEMO:** `«arya»`

[![قالب «arya»](https://raw.githubusercontent.com/CinemaPress/Theme-Arya/master/screenshot.png)](https://github.com/CinemaPress/Theme-Arya/)

## موضوع «mormont»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Mormont/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Mormont/) / [BitBucket](https://bitbucket.org/cinemapress/theme-mormont/)

> CLI: `cinemapress theme example.com mormont`

> **DEMO:** `«mormont»`

[![قالب «mormont»](https://raw.githubusercontent.com/CinemaPress/Theme-Mormont/master/screenshot.png)](https://github.com/CinemaPress/Theme-Mormont/)

## موضوع «tarly»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Tarly/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Tarly/) / [BitBucket](https://bitbucket.org/cinemapress/theme-tarly/)

> CLI: `cinemapress theme example.com tarly`

> **DEMO:** `«tarly»`

[![قالب «tarly»](https://raw.githubusercontent.com/CinemaPress/Theme-Tarly/master/screenshot.png)](https://github.com/CinemaPress/Theme-Tarly/)

## موضوع «daenerys»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Daenerys/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Daenerys/) / [BitBucket](https://bitbucket.org/cinemapress/theme-daenerys/)

> CLI: `cinemapress theme example.com daenerys` 

> **DEMO:** `«daenerys»`

[![قالب «daenerys»](https://raw.githubusercontent.com/CinemaPress/Theme-Daenerys/master/screenshot.png)](https://github.com/CinemaPress/Theme-Daenerys/)

## موضوع «tormund»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Tormund/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Tormund/) / [BitBucket](https://bitbucket.org/cinemapress/theme-tormund/)

> CLI: `cinemapress theme example.com tormund` 

> **DEMO:** `«tormund»`

[![قالب «tormund»](https://raw.githubusercontent.com/CinemaPress/Theme-Tormund/master/screenshot.png)](https://github.com/CinemaPress/Theme-Tormund/)

## موضوع «snow»

> FTP: [GitHub](https://github.com/CinemaPress/Theme-Snow/) / [GitLab](https://gitlab.com/CinemaPress/Theme-Snow/) / [BitBucket](https://bitbucket.org/cinemapress/theme-snow/)

> CLI: `cinemapress theme example.com snow` 

> **DEMO:** `«snow»`

[![قالب «snow»](https://raw.githubusercontent.com/CinemaPress/Theme-Snow/master/screenshot.png)](https://github.com/CinemaPress/Theme-Snow/)

## الخيارات والوحدات CinemaPress

يمكن الاطلاع على معلومات مفصلة عن جميع الخيارات ووحدات النظام في الوثائق.

> Copyright (c) 2014 - ···· [CinemaPress](https://github.com/CinemaPress/CinemaPress)

</div>