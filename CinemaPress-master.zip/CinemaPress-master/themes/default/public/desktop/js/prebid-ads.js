var e = document.createElement('div');
e.id = 'CinemaPress';
e.style.display = 'none';
document.body.appendChild(e);
